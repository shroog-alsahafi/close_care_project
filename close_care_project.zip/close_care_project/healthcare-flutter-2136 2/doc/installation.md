Follow these steps to get this project with updated flutter Libs:

1.Take fresh clone of flutter_base_project project from master branch:

```
http://192.168.10.23/flutter/healthcare-flutter-2136.git
```

2.Enable dart Support to your project

```
set path of dart sdk to your project eg: /opt/flutter/bin/cache/dart-sdk
```

3.Go to project root and execute the following command in console to get the required dependencies:

```
flutter pub get
```

4. Open terminal and run follwing command:

```
flutter packages pub run build_runner build

```
