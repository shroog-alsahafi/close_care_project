import 'package:geolocator/geolocator.dart' as Geo;
import '../../export.dart';

class LocationServices {
  static LocationServices getInstance() {
    return LocationServices();
  }

  Future<LocationDetails> getCurrentLocation() async {
    Geo.Position position =
        await LocationServices.getInstance().getGeoLocationPosition();
    LocationDetails locationDetails = LocationDetails()
      ..longitude = position.longitude
      ..latitude = position.latitude;
    return locationDetails;
  }

  Future<Geo.Position> getGeoLocationPosition() async {
    bool serviceEnabled;
    Geo.LocationPermission permission;
    serviceEnabled = await Geo.Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      await Geo.Geolocator.openLocationSettings();
      customLoader.hide();
      return Future.error(keyLocationServicesDisabled.tr);
    }
    permission = await Geo.Geolocator.checkPermission();
    if (permission == Geo.LocationPermission.denied) {
      permission = await Geo.Geolocator.requestPermission();

      if (permission == Geo.LocationPermission.denied) {
        customLoader.hide();
        return Future.error(keyLocationServicesDenied.tr);
      }
    }
    if (permission == Geo.LocationPermission.deniedForever) {
      customLoader.hide();
      return Future.error(keyLocationServicesPermanentlyDenied.tr);
    }
    customLoader.hide();
    return await Geo.Geolocator.getCurrentPosition(
        desiredAccuracy: Geo.LocationAccuracy.high);
  }
}

class LocationDetails {
  dynamic latitude;
  dynamic longitude;
  dynamic placeName;

  LocationDetails({this.latitude, this.longitude, this.placeName});
}
