import '../../../export.dart';

class FieldChecker {
  static String? fieldChecker({String? value, message}) {
    if (value == null || value.toString().trim().isEmpty) {
      return "$message ${keyCannotEmpty.tr}";
    }
    return null;
  }

  static String? fieldZipCodeChecker({String? value, message}) {
    if (value == null || value.toString().trim().isEmpty) {
      return "$message ${keyCannotEmpty.tr}";
    } else if (value.length < 6) {
      return '$message Please enter 6 digits';
    }
    return null;
  }

  static String? fieldCvvChecker({String? value, message}) {
    if (value == null || value.toString().trim().isEmpty) {
      return "$message ${keyCannotEmpty.tr}";
    } else if (value.length < 3) {
      return 'Please enter 3 digits';
    }
    return null;
  }
}
