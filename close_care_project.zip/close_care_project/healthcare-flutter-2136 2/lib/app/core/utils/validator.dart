/*================================================== Password Validator ===================================================*/

import 'package:get/get.dart';
import 'package:intl_phone_field/countries.dart';

import '../translations/local_keys.dart';
import '../values/app_strings.dart';

class PasswordFormValidator {

  static String? validateEmail(String value) {
    if (value.toString().trim().isEmpty) {
      return stringEmailCannotEmpty;
    } else if (value.isEmpty) {
      return stringEmailCannotEmpty;
    } else if (!GetUtils.isEmail(value.trim())) {
      return stringInvalidEmail;
    }
    return null;
  }

  static String? validateMobile(String value) {
    if (value.isEmpty) {
      return strPhoneCannotEmpty;
    } else if (value.length < 8 || value.length > 15) {
      return strPhoneNumberInvalid;
    } else if (!validateNumber(value)) {
      return strSpecialCharacter;
    }
    return null;
  }

  static String? validatPassword({String? value, String? valueMessage, bool isSecure = true}) {
    var pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$';
    RegExp regExp = RegExp(pattern);
    if (value!.isEmpty) {
      return valueMessage ?? keyPasswordEmpty.tr;
    } else if (value.length < 8) {
      return !isSecure ? null : keyPasswordCharacter.tr;
    } else if (!regExp.hasMatch(value)) {
      return !isSecure ? null : keyPasswordSecure.tr;
    }
    return null;
  }

  static String? idMatch({String? value, String? password}) {
    if (value!.isEmpty) {
      return keyConfirmNewPassword.tr;
    } else if (value != password) {
      return keyConfirmMatchPassword.tr;
    }
    return null;
  }

  static String? validateNewPassword(String value) {
    var pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$';
    RegExp regExp = RegExp(pattern);
    if (value.isEmpty) {
      return keyNewPasswordEmpty.tr;
    } else if (value.length < 8) {
      return keyPasswordMustCharacterEmpty.tr;
    } else if (!regExp.hasMatch(value)) {
      return keyPasswordIsNotSecure.tr;
    }
    return null;
  }

  static String? validatePassword(String value) {
    var pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\£&*~]).{8,}$';
    RegExp regExp = RegExp(pattern);
    if (value.isEmpty) {
      return keyPasswordEmpty.tr;
    } else if (value.length < 8) {
      return keyPasswordMustCharacterEmpty.tr;
    } else if (!regExp.hasMatch(value)) {
      return keyPasswordIsNotSecure.tr;
    }
    return null;
  }

  static String? validateUrl(String value) {
    String pattern = r"(https?:\/\/)?(www\.)?instagram\.com\/([a-zA-Z0-9_]+)";
    RegExp regExp = RegExp(pattern);
    if (value.isEmpty) {
      return keyUrlEmpty.tr;
    } else if (!regExp.hasMatch(value)) {
      return keyInvalidInstaUrlEmpty.tr;
    }
    return null;
  }

  static String? validateChangePassword(String value) {
    var pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\£&*~]).{8,}$';
    RegExp regExp = RegExp(pattern);
    if (value.isEmpty) {
      return keyNewPasswordEmpty.tr;
    } else if (value.length < 8) {
      return keyPasswordMustCharacterEmpty.tr;
    } else if (!regExp.hasMatch(value)) {
      return keyPasswordIsNotSecure.tr;
    }
    return null;
  }

  static String? validateConfirmPasswordMatch({String? value, String? password, String? message, String? valueMessage}) {
    if (value!.isEmpty) {
      return valueMessage ?? keyConfirmEmptyPassword.tr;
    } else if (value != password) {
      return message ?? keyPassAndConfirmMatch.tr;
    }
    return null;
  }

  static String? accountNo(String value) {
    if (value.toString().trim().isEmpty) {
      return keyAccountNumberEmpty.tr;
    } else if (value.length < 8 && value.length <= 16) {
      return keyValidAccountNumber.tr;
    }
    return null;
  }

  static String? validateConfirmNewPasswordMatch({String? value, String? password}) {
    if (value!.isEmpty) {
      return keyConfirmPasswordCanNotBeEmpty.tr;
    } else if (value != password) {
      return keyPasswordAndConfirmShouldBeMatch.tr;
    }
    return null;
  }

  static String? confirmAccountNo({String? value, String? password, String? message, String? valueMessage, repeatMatch}) {
    if (value!.isEmpty) {
      return valueMessage ?? keyAccountNumberEmpty.tr;
    } else if (value != password) {
      return message ?? repeatMatch;
    }
    return null;
  }

  static String? ibanNumber(String value) {
    if (value.toString().trim().isEmpty) {
      return keyIbanNumberEmpty.tr;
    } else if (value.length < 16 && value.length <= 34) {
      return keyEnterIbanNumber.tr;
    }
    return null;
  }

  static String? validateAccountMatch({String? value, String? password, String? message, String? valueMessage, repeatMatch}) {
    if (value!.isEmpty) {
      return valueMessage ?? strRepeatPasswordEmpty;
    } else if (value != password) {
      return message ?? repeatMatch;
    }
    return null;
  }

  static String? validateOldPassword({String? value, String? password}) {
    var pattern = r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\£&*~]).{8,}$';
    RegExp regExp = RegExp(pattern);
    if (value!.isEmpty) {
      return keyOldPasswordEmpty.tr;
    } else if (!regExp.hasMatch(value)) {
      return keyOldPasswordSecure.tr;
    }
    return null;
  }
}

class EmailValidator {
  static String? validateEmail(String value) {
    if (value.isEmpty) {
      return "Email cannot be empty!";
    } else if (!GetUtils.isEmail(value.trim())) {
      return "Please enter a valid email!";
    }
    return null;
  }
}

String? validateEmailMethod(String value) {
  final bool emailValid = RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value);
  if (value.toString().trim().isEmpty) {
    return "${"Email cannot be empty!"}";
  } else if (value.isEmpty) {
    return "Email cannot be empty!";
  } else if (!emailValid) {
    return "Please enter a valid email!";
  }
  return null;
}
/*================================================== Phone Number Validator ===================================================*/

class PhoneNumberValidate {
  static String? validateMobile(String? value) {
    if (value!.isEmpty) {
      return "Phone number cannot be empty!";
    } else if (value.length < 8 || value.length > 15) {
      return "Please enter a Phone number between 8-15 digits!";
    } else if (!validateNumber(value)) {
      return "Please enter only number, can not contain special character!";
    }
    return null;
  }

  static String? validatePhoneNumber(String value, Country? selectedCountry) {
    if (value == '') {
      return "Mobile number cannot be empty!";
    } else if (selectedCountry != null) {
      if (value.length < selectedCountry.minLength) {
        return "Please enter a Phone number between 8-15 digits!";
      }
    } else if (!GetUtils.isPhoneNumber(value.trim())) {
      return "Please enter a Phone number between 8-15 digits!";
    } else {}
    return null;
  }
}

bool validateNumber(String value) {
  var pattern = r'^[0-9]+$';
  RegExp regex = RegExp(pattern);
  return (!regex.hasMatch(value)) ? false : true;
}

class FieldChecker {
  static String? fieldChecker({String? value, message}) {
    if (value == null || value.toString().trim().isEmpty) {
      return "$message ${"cannot be empty!"}";
    }
    return null;
  }

  static String? dropdownChecker(Object? value, message) {
    if (value == null || value.toString().trim().isEmpty) {
      return "$message $strCannotBeEmpty";
    }

    return null;
  }

  static String? otpChecker(String? value, message) {
    if (value == null || value.toString().trim().isEmpty) {
      return "$message $strCannotBeEmpty";
    } else if (value.length < 4) {
      return "$message $strCannotBeEmpty";
    }

    return null;
  }
}
