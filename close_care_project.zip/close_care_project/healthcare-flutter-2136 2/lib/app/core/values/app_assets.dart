/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

const String iconAbout = "assets/icons/about.png";
const String iconAccount_info = "assets/icons/account_info.png";
const String iconProfile = "assets/icons/iconProfile.png";
const String iconBack = "assets/icons/back.png";
const String iconFaq = "assets/icons/faq.png";
const String iconImg1 = "assets/icons/img1.png";
const String iconImg2 = "assets/icons/img2.png";
const String iconImg3 = "assets/icons/img3.png";
const String iconLanguage = "assets/icons/language.png";
const String iconLogout = "assets/icons/logout.png";
const String iconMenu = "assets/icons/ic_menu.png";
const String iconSearch = "assets/icons/ic_search.png";
const String iconSlider1 = "assets/icons/slider1.png";
const String iconSlider2 = "assets/icons/slider2.png";
const String iconSlider3 = "assets/icons/slider3.png";
const String iconSmallLogo = "assets/icons/splashlogo.jpg";
const String iconNoSignal = 'assets/icons/no-signal.png';
const String iconAlertGif = "assets/icons/alert.gif";
const String iconTestBg = "assets/icons/ic_onboarding.png";
const String iconApple = "assets/icons/appleIcon.png";
const String iconGoogle = "assets/icons/googleIcon.png";
const String iconFacebook = "assets/icons/facebookIcon.png";
const String iconEnglish = "assets/icons/flagEnglish.png";
const String iconArabic = "assets/icons/flagArabic.png";
const String iconCustomer = "assets/icons/customer.png";
const String iconServiceProvider = "assets/icons/serviceProvider.png";
const String iconCamera = "assets/icons/cameraIcon.png";
const String iconSplash = "assets/icons/splashIcon.png";
const String onboarding1 = "assets/icons/onboarding1.png";
const String onboarding2 = "assets/icons/onboarding2.png";
const String onboarding3 = "assets/icons/onboarding3.png";
const String iconArrow = "assets/icons/Arrow.png";
const String iconNext = "assets/icons/next.png";
const String iconMyBookings = "assets/icons/mybookings.png";
const String iconTransactions = "assets/icons/transactions.png";
const String iconCall = "assets/icons/call.png";
const String iconSettings = "assets/icons/settings.png";
const String iconHome = "assets/icons/home.png";
const String iconNotification = "assets/icons/notification.png";
const String iconNotification2 = "assets/icons/notification2.png";
const String iconKey = "assets/icons/key.png";
const String iconAboutUs = "assets/icons/aboutUs.png";
const String iconDeleteAccount = "assets/icons/deleteAccount.png";
const String iconPrivacy = "assets/icons/privacy.png";
const String iconCategory = "assets/icons/categoryImage.png";
const String iconService = "assets/icons/service.png";
const String iconsIcStar1 = 'assets/icons/ic_star1.png';
const String iconsIcDone = 'assets/icons/ic_done.png';

const String iconsHomeUnfilled = 'assets/icons/home (1).png';
const String iconsHomeFilled = 'assets/icons/homefilled.png';
const String iconsServiceFilled = 'assets/icons/servicefilled.png';
const String iconsServiceUnFilled = 'assets/icons/serviceUnfilled.png';
const String iconsProfileFilled = 'assets/icons/profilefilled.png';
const String iconsProfileUnFilled = 'assets/icons/profile.png';
const String iconsBookingUnFilled = 'assets/icons/ic_booking_unfilled.png';
const String iconsBookingFilled = 'assets/icons/ic_booking_filled.png';
const String iconNotifications = 'assets/icons/ic_notification.png';
const String iconTransaction = 'assets/icons/ic_transcation.png';
const String iconNotify = 'assets/icons/notify.png';
const String iconFilter = 'assets/icons/filter.png';
const String iconCalendar = 'assets/icons/ic_calendar1.png';
const String iconDoctor = 'assets/icons/ic_doctor.png';
const String iconEdit = 'assets/icons/ic_edit.png';
const String iconUpload = 'assets/icons/upload.png';
const String iconCrossed = 'assets/icons/cross.png';
const String iconClock = 'assets/icons/ic_clock.png';
const String iconCheck = 'assets/icons/ic_check.png';
const String iconMessage = 'assets/icons/ic_message.png';
const String iconUnderReview = 'assets/icons/under_review.png';
const String iconUploadDocuments = 'assets/icons/ic_upload.png';
const String iconCross = 'assets/icons/ic_cross.png';
const String iconChat = 'assets/icons/chat.png';
const String iconEye = 'assets/icons/eye.png';
const String iconPatients = 'assets/icons/patients.png';
const String iconRatingReview = 'assets/icons/rating_reviews.png';
const String iconBanner = 'assets/icons/banner.png';
const String iconCalender = 'assets/icons/calender.png';
const String iconMap = 'assets/icons/map.png';
const String iconCreditCard = 'assets/icons/creditcard.png';
const String iconVector = 'assets/icons/Vector.png';
const String iconGrowth = 'assets/icons/growth.png';
const String iconAttach = 'assets/icons/attach.png';
const String iconSend = 'assets/icons/send.png';
const String iconFile = 'assets/icons/file.png';
const String iconCheckMark = 'assets/icons/check-mark 3.png';
const String iconPdf = 'assets/icons/icon_pdf.png';
const String iconArabicIcon = 'assets/icons/arabic_icon.png';
const String iconRefund = 'assets/icons/refund.png';

const String iconAppLogo = 'assets/icons/app_logo.png';