/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

enum ViewType { bottomNav, drawer }

const LANGUAGE_ENGLISH = 1;
const LANGUAGE_ARABIC = 2;

const ROLE_CUSTOMER = 2;
const ROLE_SERVICE_PROVIDER = 4;

const OTP_NOT_VERIFIED = 0;
const OTP_VERIFIED = 1;

const STATE_INACTIVE = 0;
const STATE_ACTIVE = 1;

const int typeMondayConst = 1;
const int typeTuesdayConst = 2;
const int typeWednesdayConst = 3;
const int typeThursdayConst = 4;
const int typeFridayConst = 5;
const int typeSaturdayConst = 6;
const int typeSundayConst = 7;
const int typeCustomConst = 8;
const int typeUnavailableConst = 9;
const NOTIFICATION_STATE_ACTIVE = 1;
const NOTIFICATION_STATE_INACTIVE = 0;

const PHYSIOTHERAPIST = 1;
const NURSE = 2;

const TYPE_IQAMA = 5;
const TYPE_BLS_LICENSE = 6;
const TYPE_MEDICAL_INSURANCE = 7;
const TYPE_PROFESSIONAL_QUALIFICATION = 8;

const STATE_UNAVAILABILITY = 2;

const MONDAY = 1;

const TUESDAY = 2;

const WEDNESDAY = 3;

const THURSDAY = 4;

const FRIDAY = 5;

const SATURDAY = 6;

const SUNDAY = 7;

const DAY = 0;

const DATE = 1;

const STATE_PENDING = 3;

const STATE_INPROGRESS = 4;

const STATE_COMPLETED = 5;

const STATE_REJECTED = 6;

const STATE_ACCEPTED = 7;

const STATE_CANCELLED = 8;

const BOOKING_TYPE_TODAY = 1;

const BOOKING_TYPE_ONLY_TODAY = 0;

const BOOKING_TYPE_UPCOMING = 2;

const BOOKING_TYPE_PAST = 3;

const BOOKING_TYPE_REST = 4;

const WEEKLY = 3;
const MONTHLY = 4;
const YEARLY = 5;

const PAYMENT_STATE_PENDING = 0;
const PAYMENT_STATE_SUCCESS = 1;
const PAYMENT_STATE_IN_PROGRESS = 2;
const PAYMENT_STATE_FAIL = 3;
