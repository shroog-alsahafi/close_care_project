/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

//Network

const String stringRequestCancelled = "Request cancelled";
const String stringNotSubType = 'is not a subtype of';
const String stringUnableToProcessData = 'Unable to process data';
const String stringProcessData = 'process data';
const String stringConnectionTimeout = 'Connection timeout';
const String stringInternetConnection = 'No Internet Connection';
const String stringTimeOut = 'Time out';
const String stringUnAuthRequest = 'Unauthorised Request';
const String stringNotFound = 'Not Found';
const String stringRequestTimeOut = 'Request Time out';
const String stringInternalServerError = 'Internal Server Error';
const String stringInternetServiceUnavailable = 'Service Unavailable';
const String stringSomethingsIsWrong = 'Something is wrong';
const String socketExceptions = 'Socket Exceptions';
const String stringUnexpectedException = 'Unexpected Exceptions';
const String stringFormatException = 'Format Exceptions';
const String stringConnectionRefused = 'Connection refused';
const String stringNetworkUnreachable = 'Network is unreachable';
const String stringServerMaintenance =
    "Something went wrong. Please try again later";
const String stringPleaseTryAgain = "Please try again later";
const String stringFailedToConnect = "Failed host lookup";

const String stringDemoExpired = "Demo Expired";
const String stringAppDemoExpiredDesc =
    "This application's demo is no longer available. Please reach out to the development team for latest version.";

const String stringAppName = 'Flutter GetX Base';
const String stringExitWarning = 'Press again to exit the app';

const String stringFbSignInCancelled = 'Facebook Sign In Cancelled';
const String stringGoogleSignInCancelled = 'Google Sign In Cancelled';
const String stringAppleSignInCancelled = 'Apple Sign In Cancelled';

const String stringDummyText =
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';

const String stringChooseMedia = "Please select an image";

const String stringLogout = "Logout";
const String stringLogoutHeading = "Do you really want to log out?";
const String stringCancel = "Cancel";

const String stringDelete = "Delete";
const String stringDeleteAccount = "Delete Account";
const String stringDeleteHeading = "Do you really want to delete your account?";

const String stringTitle = "Title";
const String stringReadMore = "...Read More";
const String stringReadLess = "...Read Less";

const String stringLogInSuccess = "Login Successfully";
const String stringLogoutSuccess = "Logout Successfully";
const String stringAccountDeleteSuccess = "Account Deleted Successfully";

const String stringDownloading = "Downloading...";
const String stringEmail = "email";
const String stringEmailEmptyValidation = "Please enter email address";
const String stringEmailValidValidation = "Please enter valid email address";
const String stringLoginHeading =
    "Use the email and password that you registered in Flutter website.";
const String stringPassword = "password";
const String stringPasswordEmptyValidation = "Please enter password";
const String stringForgotPassword = "forgot password?";
const String stringLogin = "login";
const String stringDontHaveAccount =
    "Don't have an account? Create an account in";
const String stringSignUp = "Sign Up";
const String stringWebsite = "website";
const String stringRegister = "Register";
const String stringAlreadyHaveAccount = "Already have an account? ";
const String stringSignIn = "Sign In";
const String stringFAQs = "FAQs";
const String stringAboutUs = "About Us";
const String strNoImage = "No image selected";

const String strRequestCancelled = "Request cancelled";
const String strNotSubType = 'is not a subtype of';
const String strUnableToProcessData = 'Unable to process data';
const String strProcessData = 'process data';
const String strConnectionTimeOut = 'Connection timeout';
const String strNoInternetConnection = 'No Internet Connection';
const String strTimeOut = 'Time out';
const String strTryAgain = 'Try again';
const String strBadCertificate = 'Bad Certificate ';
const String strConnectionError = 'Connection Error ';
const String strUnauthorizeRequest = 'Unauthorised Request';
const String strUnauthorizeException = 'Unauthorised Exception';
const String strNotFound = 'Not Found';
const String strPageNotFound = 'Page Not Found';
const String strRequestTimeOut = 'Request Time out';
const String strInternalServerError = 'Internal Server Error';
const String strServiceUnavailable = 'Service Unavailable';
const String strUnauthorizedRequest = 'Unauthorised Request';
const String strSomethingWorg = 'Something is wrong';
const String strSocketExceptions = 'Socket Exception';
const String strUnExceptedExption = 'Unexpected Exceptions';
const String strFormetException = 'Format Exceptions';
const String strForbidden = 'Forbidden ';
const String strPermanentMove =
    'A page has been permanently moved to a new location ';
const String strUnprocessable = 'Unprocessable entity ';
const String strConnectionRefused = 'Connection refused';
const String strNetworkUnReachable = 'Network is unreachable';
const String strServerUnderMaintance =
    "Something went wrong. Please try again later";
const String strPleaseTryAgain = "Please try again later";
const String strFalidToHostLookup = "Failed host lookup";
const String stringInvalidEmail = "Please enter a valid email address!";
const String stringEmailCannotEmpty = "Email address cannot be empty!";
const String stringNoInternetConnection =
    "No internet connection found.Check your connection or try again.";
const String stringConfirmPassword = "Confirm password";
const String stringNewPassword = "New password";
const String strPasswordEmpty = "Password must contain at least 8 characters!";
const String strEmptyPassword = "Password cannot be empty!";
const String strPasswordSecure =
    "Password isn\'t secure. It must contain one or more Capital character, small character, numeric value and special character!";
const String strRepeatPasswordEmpty = "Confirm Password cannot be empty!";
const String strRepeatPasswordMatch =
    "Password and Confirm password should match!";
const String stringRepeatPassword = "Confirm password";
const String strPhoneCannotEmpty = 'Phone number cannot be empty!';
const String strPhoneNumberInvalid = "Please enter a valid Phone number!";
const String strSpecialCharacter =
    "Please enter only number, can not contain special character!";
const String stringVerifyCode = "Verification Code on this Mail!";
const String strCannotBeEmpty = "cannot be empty!";
const String strRepeatAccountMatch =
    "Account and Confirm account number should match!";
