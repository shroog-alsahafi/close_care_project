import 'package:healthcare/export.dart';

import '../../modules/setting/controller/setting_screen_controller.dart';

class AlertDialogWidget extends StatelessWidget {
  final String action;
  final int recordId;
  final String title;
  final String descrption;
  final int? serviceId;
  final Function(dynamic) voidCallback;

  AlertDialogWidget(
      {Key? key,
      required this.action,
      required this.recordId,
      required this.title,
      required this.descrption,
      required this.voidCallback,
      this.serviceId})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        // mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Container(
              margin: EdgeInsets.symmetric(horizontal: margin_12),
              width: Get.width,
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(radius_20)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [_dialogTitle(), _logoutSubTitle(), _dialogButton()],
              ).marginAll(margin_20)),
        ],
      ).marginAll(margin_10),
    );
  }

  Widget _dialogTitle() => TextView(
      text: title,
      textAlign: TextAlign.center,
      textStyle: textStyleBodyLarge().copyWith(fontWeight: FontWeight.w600, fontSize: font_20, color: Colors.black));

  Widget _logoutSubTitle() => TextView(
          text: descrption,
          maxLine: 3,
          textAlign: TextAlign.center,
          textStyle: textStyleBody2().copyWith(fontWeight: FontWeight.w400, fontSize: font_16, color: Colors.black))
      .paddingOnly(bottom: margin_10, top: margin_15, left: margin_20, right: margin_20);

  Widget _dialogButton() {
    return Row(
      children: [
        yesButton(),
        SizedBox(width: margin_15),
        noButton(),
      ],
    ).marginOnly(top: margin_10);
  }

  yesButton() {
    return Expanded(
        child: MaterialButtonWidget(
            padding2: EdgeInsets.all(margin_13),
            elevation: 0.0,
            onPressed: () {
              if (action == keyDeleteAccount.tr) {
                if (Get.isRegistered<SettingScreenController>()) {
                  Get.find<SettingScreenController>().hitDeleteAccountApiCall();
                } else {
                  final controller = Get.put(SettingScreenController());
                  controller.hitDeleteAccountApiCall();
                }
              } else if (action == keyLogout.tr) {
                HomeController().hitLogoutApiCall();
              }
            },
            buttonRadius: radius_5,
            textColor: Colors.white,
            buttonColor: colorAppColors,
            buttonText: action == keyLogout.tr
                ? keyYes.tr
                : action == keyDeleteAccount.tr
                    ? keyYes.tr
                    : keyNo.tr));
  }

  noButton() {
    return Expanded(
        child: Container(
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(radius_5), border: Border.all(color: colorAppColors)),
      child: MaterialButtonWidget(
        padding2: EdgeInsets.all(margin_13),
        elevation: 0.0,
        onPressed: () {
          Get.back();
        },
        buttonRadius: radius_5,
        textColor: colorAppColors,
        buttonColor: Colors.white,
        buttonText: action == keyLogout
            ? keyNo.tr
            : action == keyDeleteAccount
                ? keyNo.tr
                : keyNo.tr,
      ),
    ));
  }
}
