import 'package:intl/intl.dart';
import '../../../export.dart';
import '../../modules/bookings/controller/bookings_view_list_controller.dart';
import '../utils/time_ago.dart';

class BookingListWidget extends StatelessWidget {
  final bool? iconWidget;
  final actionWidget;
  final itemIndex;
  const BookingListWidget({
    Key? key,
    this.iconWidget,
    this.actionWidget,
    this.itemIndex,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final controller = Get.put(BookingsViewController());

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          decoration: BoxDecoration(color: bgContainerColor, borderRadius: BorderRadius.circular(radius_10)),
          child: IntrinsicHeight(
            child: Row(
              children: [
                Container(
                  child: NetworkImageWidget(
                    imageurl: controller.servicesProviderList[itemIndex].providerProfile,
                    imageWidth: height_60,
                    radiusAll: radius_10,
                    imageHeight: height_60,
                  ).paddingOnly(left: margin_10),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TextView(
                        text: controller.servicesProviderList[itemIndex].providerFullName.toString().capitalizeFirst ?? "",
                        textStyle: textStyleBody1().copyWith(fontSize: font_14, fontWeight: FontWeight.w600),
                      ),
                      TextView(
                        maxLine: 1,
                        textAlign: TextAlign.start,
                        text: controller.servicesProviderList[itemIndex].service?.title ?? "",
                        textStyle: textStyleBody1().copyWith(fontSize: font_13, fontWeight: FontWeight.w400),
                      ).paddingSymmetric(vertical: margin_3),
                      Row(
                        children: [
                          AssetImageWidget(imageUrl: iconClock, imageHeight: height_18).paddingOnly(right: margin_7),
                          TextView(
                              text: "${DateFormat("dd MMM yyyy").format(DateTime.parse(controller.servicesProviderList[itemIndex].date.toString()))}",
                              textStyle: textStyleBody1().copyWith(fontSize: font_15))
                        ],
                      ),
                    ],
                  ).paddingOnly(left: margin_10, top: margin_10, bottom: margin_10),
                ),
                actionWidget,
              ],
            ),
          ),
        ).paddingOnly(top: margin_10),
      ],
    ).paddingOnly(bottom: margin_10);
  }
}
