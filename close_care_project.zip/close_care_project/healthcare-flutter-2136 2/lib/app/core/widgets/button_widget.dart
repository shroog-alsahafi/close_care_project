import 'package:healthcare/export.dart';

class MaterialButtonWidget extends StatelessWidget {
  final String? buttonText;
  final Color? buttonColor;
  final Color? textColor;
  final double? buttonRadius;
  final double? minWidth;
  final double? minHeight;
  final double? padding;
  final EdgeInsetsGeometry? padding2;
  final onPressed;
  final decoration;
  final elevation;
  final borderColor;
  final bool? isSocial;
  final double? fontsize;
  final dynamic fontWeight;
  final  iconWidget;

  const MaterialButtonWidget({
    Key? key,
    this.buttonText = "",
    this.buttonColor,
    this.textColor,
    this.buttonRadius = defaultRaduis,
    this.decoration,
    this.borderColor,
    this.isSocial = false,
    this.onPressed,
    this.elevation,
    this.iconWidget,
    this.fontsize,
    this.minWidth,
    this.minHeight,
    this.padding,
    this.padding2,
    this.fontWeight,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
        height: minHeight,
        splashColor: Colors.transparent,
        minWidth: minWidth ?? Get.width,
        color: buttonColor ?? colorAppColors,
        elevation: elevation ?? radius_4,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(buttonRadius!),side: BorderSide(
          color: borderColor ?? Colors.transparent
        )),
        onPressed: onPressed,
        padding:
            padding2 ?? EdgeInsets.symmetric(vertical: padding ?? margin_10),
        child: TextView(
            text: buttonText!,
            textStyle: textStyleButton().copyWith(
                color: textColor ?? Colors.white,
                fontSize: fontsize,
                fontWeight: fontWeight ?? FontWeight.w500)));
  }
}
