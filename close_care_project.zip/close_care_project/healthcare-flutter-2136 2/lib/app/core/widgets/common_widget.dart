import 'package:flutter_rating_bar/flutter_rating_bar.dart';

import '../../../export.dart';

class CommonWidget extends StatelessWidget {
  final bool? iconWidget;
  final actionWidget;
  final otherData;
  final itemIndex;
  final controller;
  const CommonWidget({
    Key? key,
    this.iconWidget,
    this.otherData,
    this.actionWidget,
    this.itemIndex,
    required this.controller,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        GestureDetector(
          onTap: () {
            Get.toNamed(AppRoutes.bookingDetailsScreenRouteCustomerSide, arguments: {
              "id": (otherData ?? controller.servicesProviderList)[itemIndex].id,
              "dataModel": (otherData ?? controller.servicesProviderList)[itemIndex],
            });
          },
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(color: bgContainerColor, borderRadius: BorderRadius.circular(radius_10)),
            child: IntrinsicHeight(
              child: Row(
                children: [
                  Container(
                    child: NetworkImageWidget(
                      imageurl: (otherData ?? controller.servicesProviderList)[itemIndex].profileFile ??
                          (otherData ?? controller.servicesProviderList)[itemIndex].providerDetail?.imageFile ??
                          "",
                      imageWidth: height_60,
                      radiusAll: radius_10,
                      imageHeight: height_60,
                    ).paddingOnly(left: margin_10),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextView(
                          text: (otherData ?? controller.servicesProviderList)[itemIndex].fullName ?? "",
                          textStyle: textStyleBody1().copyWith(fontSize: font_14, fontWeight: FontWeight.w600),
                        ),
                        TextView(
                          maxLine: 1,
                          textAlign: TextAlign.start,
                          text: (otherData ?? controller.servicesProviderList)[itemIndex].providerDetail?.degreeName ?? "",
                          textStyle: textStyleBody1().copyWith(fontSize: font_13, fontWeight: FontWeight.w400),
                        ).paddingSymmetric(vertical: margin_3),
                        iconWidget == true
                            ? Row(
                                children: [
                                  AssetImageWidget(imageUrl: iconClock, imageHeight: height_18).paddingOnly(right: margin_8),
                                  TextView(text: "22 Sep, 2024", textStyle: textStyleBody1().copyWith(fontSize: font_15))
                                ],
                              )
                            : Row(
                                children: [
                                  ratingsView(
                                    rating: (otherData ?? controller.servicesProviderList)[itemIndex].avgRating,
                                  ),
                                  TextView(
                                          text: (otherData ?? controller.servicesProviderList)[itemIndex].avgRating ?? "",
                                          textStyle: textStyleBody1().copyWith(fontSize: font_15))
                                      .paddingOnly(left: margin_10)
                                ],
                              )
                      ],
                    ).paddingOnly(left: margin_10, top: margin_10, bottom: margin_10),
                  ),
                  actionWidget ??
                      Container(
                        height: double.infinity,
                        width: width_28,
                        decoration: BoxDecoration(
                          color: colorAppColor,
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(radius_10),
                            bottomRight: Radius.circular(radius_10),
                          ),
                        ),
                        child: Icon(Icons.arrow_forward_ios_rounded, size: height_20, color: colorWhite),
                      )
                ],
              ),
            ),
          ).paddingOnly(top: margin_10),
        ),
      ],
    ).paddingOnly(bottom: margin_10);
  }

  _seeAllRow({required String text, required void Function()? onTap}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        TextView(text: text, textStyle: TextStyle(fontSize: font_17, color: Colors.black, fontWeight: FontWeight.w500)),
        GestureDetector(
          onTap: onTap,
          child: TextView(
            text: keySeeAll.tr,
            textStyle: TextStyle(
                decoration: TextDecoration.underline,
                color: Colors.transparent,
                decorationColor: colorAppColors,
                fontSize: font_14,
                shadows: [Shadow(color: colorAppColor, offset: Offset(0, -3))],
                fontWeight: FontWeight.w400),
          ),
        )
      ],
    );
  }
}
