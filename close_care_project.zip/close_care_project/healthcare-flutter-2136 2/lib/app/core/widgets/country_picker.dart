/*
 * @copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 *  Proprietary and confidential :  All information contained herein is, and remains
 *  the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
import 'package:intl_phone_field/countries.dart';
import 'package:intl_phone_field/country_picker_dialog.dart';

import '../../../export.dart';
import 'intl_phone_fieldd.dart';

class CountryPicker extends StatelessWidget {
  Country? selectedCountry;
  final onCountryChanged;
  final readOnly;
  final label;
  final textStyle;
  final headingColor;
  final borderRadius;
  final borderColor;
  final decoration;
  final isShadow;
  final onChange;
  final fillColor;
  final suffix;
  final enabled;
  final mandatory;
  final TextEditingController? textController;
  final FocusNode? focusNode;
  final TextEditingController? countryController;

  CountryPicker({
    Key? key,
    this.readOnly,
    this.headingColor,
    this.borderRadius,
    this.borderColor,
    this.decoration,
    this.fillColor,
    this.onChange,
    this.mandatory,
    this.suffix,
    this.isShadow = false,
    this.enabled = true,
    required this.selectedCountry,
    required this.textController,
    required this.focusNode,
    required this.countryController,
    required this.onCountryChanged,
    this.label,
    this.textStyle,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        SizedBox(
          height: height_10,
        ),
        textFieldTitle(keyPhoneNumber.tr),
        SizedBox(
          height: height_8,
        ),
        IntlPhoneFieldd(
          enabled: enabled ?? true,
          showCountryFlag: true,
          cursorColor: Colors.grey,
          showDropdownIcon: true,
          readOnly: readOnly ?? false,
          keyboardType: TextInputType.number,
          validator: (data) => PhoneNumberValidate.validatePhoneNumber(textController?.text ?? data.toString(), selectedCountry),
          initialCountryCode: selectedCountry?.code,
          invalidNumberMessage: keyPhoneNumberInvalid.tr,
          dropdownTextStyle: textStyleBodyMedium().copyWith(color: Colors.grey, fontSize: font_13, fontWeight: FontWeight.w400),
          controller: textController,
          focusNode: focusNode,
          dropdownIcon: Icon(
            Icons.arrow_drop_down_rounded,
            color: Colors.grey,
          ),
          pickerDialogStyle: PickerDialogStyle(backgroundColor: Colors.white),
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            FilteringTextInputFormatter.allow(
              RegExp(r'[0-9]'),
            ),
            FilteringTextInputFormatter.deny(
              RegExp(r'^0+'), //users can't type 0 at 1st position
            ),
          ],
          style: textStyleBodyMedium().copyWith(fontWeight: FontWeight.w500, color: Colors.black),
          decoration: InputDecoration(
              filled: true,
              suffix: SizedBox(child: suffix).paddingOnly(
                right: margin_14,
              ),
              errorStyle: Theme.of(Get.context!).textTheme.bodyText1!.copyWith(
                  fontSize: font_10,
                  fontWeight: FontWeight.w400,
                  color: Colors.red),
              counterText: "",
              errorMaxLines: 2,
              fillColor: fillColor ?? Colors.grey.shade200,
              // hintText: "Enter your phone number",
              hintStyle: textStyleBody1().copyWith(fontSize: font_14, color: Colors.grey.shade400, fontWeight: FontWeight.w400),
              focusedErrorBorder: decoration ??
                  OutlineInputBorder(
                      borderRadius: BorderRadius.circular(borderRadius ?? radius_6),
                      borderSide:
                          borderColor == true ? BorderSide(color: Colors.grey.shade300) : BorderSide(color: Colors.transparent, width: margin_1)),
              errorBorder: decoration ??
                  OutlineInputBorder(
                      borderRadius: BorderRadius.circular(borderRadius ?? radius_6),
                      borderSide: borderColor == true ? BorderSide(color: Colors.grey.shade300) : BorderSide.none),
              enabledBorder: decoration ??
                  OutlineInputBorder(
                      borderRadius: BorderRadius.circular(borderRadius ?? radius_6),
                      borderSide: borderColor == true ? BorderSide(color: Colors.grey.shade300) : BorderSide.none),
              border: decoration ??
                  OutlineInputBorder(
                      borderRadius: BorderRadius.circular(borderRadius ?? radius_6),
                      borderSide: borderColor == true ? BorderSide(color: Colors.grey.shade300) : BorderSide.none),
              disabledBorder: decoration ??
                  OutlineInputBorder(
                      borderRadius: BorderRadius.circular(borderRadius ?? radius_6),
                      borderSide: borderColor == true ? BorderSide(color: Colors.grey.shade300) : BorderSide.none),
              focusedBorder: decoration ??
                  OutlineInputBorder(
                      borderRadius: BorderRadius.circular(borderRadius ?? radius_6),
                      borderSide: borderColor == true ? BorderSide(color: Colors.grey.shade300) : BorderSide.none),
              contentPadding: EdgeInsets.only(top: margin_15, left: margin_20, bottom: margin_15)),
          onChanged: onChange ?? (phone) {},
          onCountryChanged: onCountryChanged ??
              (country) {
                selectedCountry = country;
                countryController?.text = selectedCountry!.name;
                textController?.clear();
              },
        ),
      ],
    );
  }
}

class PhoneNumberValidate {
  static String? validatePhoneNumber(String value, Country? selectedCountry, {title}) {
    if (value == '') {
      return title ?? keyPhoneNumberEmpty.tr;
    } else if (selectedCountry != null) {
      if (value.length < selectedCountry.minLength) {
        return keyPhoneNumberInvalid.tr;
      }
    } else if (!GetUtils.isPhoneNumber(value.trim())) {
      return keyPhoneNumberInvalid.tr;
    }
    return null;
  }
}
