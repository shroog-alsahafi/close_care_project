/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import '../../../export.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String? appBarTitleText;
  final actionWidget;
  final bottomPadding;
  final topPadding;
  final Color? bgColor;
  final appBarTitleWidget;
  final leadingIcon;
  final bool? isDrawerIcon;
  final bool? isBackIcon;
  final bool? centerTitle;
  final bool? iconWhite;
  final systemOverlayStyle;
  final void Function()? onTap;

  CustomAppBar(
      {Key? key,
      this.appBarTitleText,
      this.onTap,
      this.actionWidget,
      this.bottomPadding,
      this.topPadding,
      this.isDrawerIcon = false,
      this.appBarTitleWidget,
      this.systemOverlayStyle,
      this.leadingIcon,
      this.isBackIcon = true,
      this.centerTitle = false,
      this.bgColor,
      this.iconWhite = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      toolbarHeight: height_65,
      elevation: 0.0,
      bottomOpacity: 0.0,
      leading: isBackIcon! ? _backIcon() : Container(),
      centerTitle: centerTitle ?? false,
      leadingWidth: width_50,
      surfaceTintColor: Colors.transparent,
      title: appBarTitleWidget ??
          (appBarTitleText != "" || appBarTitleText != null
              ? TextView(
                  text: appBarTitleText ?? "",
                  textAlign: TextAlign.center,
                  textStyle: TextStyle(fontSize: font_17, fontWeight: FontWeight.w500, color: Colors.black),
                )
              : SizedBox(
                  height: 0,
                  width: 0,
                )),
      titleSpacing: width_5,
      shadowColor: Colors.transparent,
      backgroundColor: bgColor ?? Colors.white,
      actions: actionWidget ?? [],
      systemOverlayStyle: systemOverlayStyle ??
          SystemUiOverlayStyle.dark.copyWith(
            statusBarColor: Colors.transparent,
            statusBarBrightness: Brightness.light,
          ),
    );
  }

  _backIcon() {
    return Align(
      alignment: Alignment.topLeft,
      child: InkWell(
        splashColor: Colors.transparent,
        child: isDrawerIcon == false
            ?leadingIcon?? Icon(
                Icons.arrow_back_ios,
                size: height_22,
                color: colorAppColor,
              ).paddingOnly(top: margin_20, left: margin_10)
            : AssetImageWidget(
                imageHeight: height_60,
                imageWidth: width_60,
                imageUrl: iconMenu,
              ).paddingOnly(left: margin_10),
        onTap: onTap ??
            () {
              Get.back(result: true);
            },
      ),
    );
  }

  @override
  Size get preferredSize => Size.fromHeight(height_60);
}
