import '../../../export.dart';

class MyGridItem extends StatelessWidget {
  final String text;
  final bool isSelected;
  final String? endTime;
  final Color? color;

  const MyGridItem(
      {Key? key,
      required this.text,
      required this.isSelected,
      this.endTime,
      this.color})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: margin_13),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius_7),
          border: Border.all(
              color: isSelected ? colorAppColor : Colors.grey.shade300),
          color: isSelected ? colorAppColor : greyColor),
      child: Center(
        child: TextView(
          text: text,
          textStyle: textStyleBody1().copyWith(
              color: !isSelected ? Colors.black : Colors.white,
              fontWeight: !isSelected ? FontWeight.w500 : FontWeight.w800,
              fontSize: font_12),
        ),
      ),
    );
  }
}

class SelectedDate extends StatelessWidget {
  final String text;
  final String subText;
  final bool isSelected;
  final Color? color;

  const SelectedDate(
      {Key? key,
      required this.text,
      required this.isSelected,
      this.color,
      required this.subText})
      : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      width: width_65,
      height: height_120,
      decoration: BoxDecoration(
          color: isSelected ? colorAppColor : Colors.white,
          borderRadius: BorderRadius.circular(radius_7),
          border: Border.all(color: colorAppColor)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextView(
            textAlign: TextAlign.start,
            text: text,
            textStyle: textStyleBodyMedium().copyWith(
                color: !isSelected ? colorAppColor : Colors.white,
                fontSize: font_16),
          ),
          SizedBox(height: margin_5),
          TextView(
            textAlign: TextAlign.start,
            text: subText,
            textStyle: textStyleTitle().copyWith(
              fontSize: font_16,
              color: !isSelected ? colorAppColor : Colors.white,
            ),
          ),
        ],
      ),
    ).paddingSymmetric(horizontal: margin_5, vertical: margin_15);
  }
}
