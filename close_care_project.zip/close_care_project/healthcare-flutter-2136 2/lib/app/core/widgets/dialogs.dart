import 'package:healthcare/app/service_provider_app/Home/controllers/home_controller_provider.dart';
import 'package:healthcare/export.dart';

import '../../service_provider_app/Home/models/booking_provider_res_model.dart';

logoutDialog() {
  return Get.dialog(
    Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        height: Get.height,
        width: Get.width,
        color: Colors.white10,
        alignment: Alignment.center,
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: margin_40),
          decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.white, blurRadius: 4)],
              border: Border.all(color: Colors.white, width: width_4),
              borderRadius: BorderRadius.circular(margin_10)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              getInkWell(
                onTap: () {
                  Get.back();
                },
                child: Align(
                    alignment: Alignment.topRight,
                    child: Icon(
                      Icons.close,
                      color: Colors.black,
                    )),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: margin_40),
                decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [BoxShadow(color: Colors.white, blurRadius: 4)],
                    border: Border.all(color: Colors.white, width: width_4),
                    borderRadius: BorderRadius.circular(margin_10)),
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    AssetImageWidget(imageUrl: iconSmallLogo, imageHeight: height_70).marginOnly(bottom: height_10),
                    TextView(
                      text: stringLogoutHeading,
                      textStyle: textStyleTitle(),
                      maxLine: 5,
                      textAlign: TextAlign.center,
                    ).marginOnly(bottom: height_10),
                    Row(
                      children: [
                        Expanded(
                            child: _yesBtn(
                                    onTap: () {
                                      storage.remove(LOCALKEY_token);
                                      log.e(storage.read(LOCALKEY_token));
                                      log.e(storage.read(LOCALKEY_myAccount));
                                      Get.offAllNamed(AppRoutes.logIn);
                                      toast(stringLogoutSuccess);
                                    },
                                    label: stringLogout)
                                .marginOnly(right: width_10)),
                        Expanded(child: _noBtn().marginOnly(left: width_10)),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ),
    barrierDismissible: false,
  );
}

deleteAccountDialog() {
  return Get.dialog(
    Scaffold(
      backgroundColor: Colors.white,
      body: Container(
        height: Get.height,
        width: Get.width,
        color: Colors.white10,
        alignment: Alignment.center,
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: margin_40),
          decoration: BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.white, blurRadius: 4)],
              border: Border.all(color: Colors.white, width: width_4),
              borderRadius: BorderRadius.circular(margin_10)),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              getInkWell(
                onTap: () {
                  Get.back();
                },
                child: Align(
                    alignment: Alignment.topRight,
                    child: Icon(
                      Icons.close,
                      color: Colors.black,
                    )),
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: margin_40),
                decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [BoxShadow(color: Colors.white, blurRadius: 4)],
                    border: Border.all(color: Colors.white, width: width_4),
                    borderRadius: BorderRadius.circular(margin_10)),
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    AssetImageWidget(imageUrl: iconSmallLogo, imageHeight: 70).marginOnly(bottom: height_10),
                    TextView(text: stringDeleteHeading, maxLine: 5, textAlign: TextAlign.center, textStyle: textStyleTitle())
                        .marginOnly(bottom: height_10),
                    Row(
                      children: [
                        Expanded(
                            child: _yesBtn(
                                    onTap: () {
                                      storage.remove(LOCALKEY_token);
                                      log.e(storage.read(LOCALKEY_token));
                                      log.e(storage.read(LOCALKEY_myAccount));
                                      Get.offAllNamed(AppRoutes.logIn);
                                      toast(stringAccountDeleteSuccess);
                                    },
                                    label: stringDelete)
                                .marginOnly(right: width_10)),
                        Expanded(child: _noBtn().marginOnly(left: width_10)),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ),
    barrierDismissible: false,
  );
}

Widget _yesBtn({onTap, label}) {
  return MaterialButtonWidget(onPressed: onTap ?? () {}, buttonText: label ?? '', buttonColor: colorVioletM);
}

Widget _noBtn() {
  return MaterialButtonWidget(
      onPressed: () {
        Get.back();
      },
      buttonText: stringCancel,
      buttonColor: colorVioletM);
}

appExpirationDialog() {
  return Get.dialog(
    AlertDialog(
      title: Container(
          height: height_150,
          width: Get.width,
          alignment: Alignment.center,
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(radius_10),
                topRight: Radius.circular(radius_10),
              )),
          child: AssetImageWidget(imageUrl: iconAlertGif, imageFitType: BoxFit.cover)),
      titlePadding: EdgeInsets.zero,
      contentPadding: EdgeInsets.zero,
      content: Container(
        padding: EdgeInsets.symmetric(
          horizontal: margin_10,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextView(
              text: stringDemoExpired,
              maxLine: 5,
              textAlign: TextAlign.center,
              textStyle: textStyleTitle(),
            ).marginOnly(
              bottom: height_10,
            ),
            TextView(
              text: stringAppDemoExpiredDesc,
              maxLine: 5,
              textAlign: TextAlign.center,
              textStyle: textStyleSubTitle(),
            ).marginOnly(bottom: height_10),
          ],
        ),
      ),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius_10)),
    ),
    barrierColor: Colors.grey.shade300,
    barrierDismissible: false,
  );
}

underReviewDialog() {
  Future.delayed(Duration(seconds: 3)).then(
    (value) => Get.offAllNamed(AppRoutes.logIn),
  );
  return Get.dialog(
    DoubleBackButtonWidget(
      child: AlertDialog(
        title: Container(
          height: height_150,
          width: Get.width,
          alignment: Alignment.center,
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(radius_10),
                topRight: Radius.circular(radius_10),
              )),
          child: AssetImageWidget(imageUrl: iconUnderReview, imageFitType: BoxFit.cover),
        ),
        titlePadding: EdgeInsets.zero,
        contentPadding: EdgeInsets.zero,
        content: TextView(
          text: keyYourProfileUnderReview.tr,
          maxLine: 5,
          textAlign: TextAlign.center,
          textStyle: textStyleTitle().copyWith(
            fontSize: font_18,
          ),
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius_10)),
      ),
    ),
    barrierColor: Colors.grey.shade300,
    barrierDismissible: false,
  );
}

orderDialog({required HomeControllerProvider controller, int? time, required BookingListProvider booking}) {
  RxInt start = time!.obs;
  Timer timer;
  const oneSec = const Duration(seconds: 1);
  timer = Timer.periodic(
    oneSec,
    (Timer timer) {
      if (start.value == 0) {
        timer.cancel();
      } else {
        start.value--;
      }
    },
  );

  Timer? _timer;

  _timer = Timer(Duration(seconds: start.value), () {
    timer.cancel();
    Get.back();
    controller.hitAcceptRejectApi(bookingId: booking.id, stateId: STATE_REJECTED, autoReject: true);
  });

  return Get.dialog(
    barrierDismissible: false,
    PopScope(
      canPop: true,
      onPopInvoked: (didPop) async {
        if (didPop) {
          _timer?.cancel();
          timer.cancel();
          return;
        }
      },
      child: AlertDialog(
        surfaceTintColor: Colors.white,
        content: Stack(
          children: [
            IntrinsicHeight(
              child: Column(
                children: [
                  NetworkImageWidget(
                    imageurl: booking.profileFile,
                    imageHeight: height_70,
                    imageWidth: height_70,
                    radiusAll: radius_10,
                  ),
                  titleTxt(title: booking.fullName),
                  TextView(
                    text: booking.service!.title ?? "",
                    textAlign: TextAlign.center,
                    textStyle: textStyleTitle().copyWith(
                      fontSize: font_12,
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(vertical: margin_10),
                    padding: EdgeInsets.all(margin_10),
                    decoration: BoxDecoration(color: secondColors, borderRadius: BorderRadius.circular(radius_5)),
                    child: Obx(
                      () => TextView(
                        text: "0${start.value ~/ 60} : "
                            "${start.value % 60 > 9 ? start.value % 60 : "0${start.value % 60}"} ${keyMin.tr}",
                        textStyle: textStyleTitle().copyWith(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: MaterialButtonWidget(
                            elevation: 0.0,
                            onPressed: () {
                              if (start.value == 0) {
                                Get.back();
                                controller.hitAcceptRejectApi(bookingId: booking.id, stateId: STATE_REJECTED, autoReject: true);
                              } else {
                                Get.back();
                                controller.hitAcceptRejectApi(bookingId: booking.id, stateId: STATE_ACCEPTED);
                              }
                            },
                            buttonRadius: radius_8,
                            textColor: Colors.white,
                            buttonColor: colorAppColors,
                            buttonText: keyAccept.tr),
                      ),
                      SizedBox(
                        width: width_10,
                      ),
                      Expanded(
                        child: MaterialButtonWidget(
                            elevation: 0.0,
                            onPressed: () {
                              Get.back();
                              controller.hitAcceptRejectApi(bookingId: booking.id, stateId: STATE_REJECTED);
                            },
                            borderColor: colorAppColors,
                            buttonRadius: radius_8,
                            textColor: Colors.black,
                            buttonColor: Colors.white,
                            buttonText: keyReject.tr),
                      ),
                    ],
                  )
                ],
              ),
            ),
            Positioned(
              right: 0,
              top: 0,
              child: GestureDetector(
                  onTap: () {
                    _timer?.cancel();
                    timer.cancel();
                    Get.back();
                  },
                  child: Icon(Icons.cancel_outlined)),
            )
          ],
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius_10)),
      ),
    ),
  );
}
