import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:healthcare/app/core/utils/helper_widget.dart';

class DoubleBackButtonController extends GetxController {
  final Duration duration;
  final TextStyle? textStyle;
  bool _doubleBackToExitPressedOnce = false;

  DoubleBackButtonController({required this.duration, this.textStyle});

  Future<bool> onBackPressed(BuildContext context) async {
    if (_doubleBackToExitPressedOnce) {
      return true;
    } else {
      showInSnackBar(message: 'Press back again to exit');
      /* ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Press back again to exit', style: textStyle ?? TextStyle()),
          duration: duration,
        ),
      );*/
      _doubleBackToExitPressedOnce = true;

      await Future.delayed(duration);
      _doubleBackToExitPressedOnce = false;
      return false;
    }
  }
}
