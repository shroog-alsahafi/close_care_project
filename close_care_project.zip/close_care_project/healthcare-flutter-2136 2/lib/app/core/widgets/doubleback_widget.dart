import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter/services.dart';
import 'doubleBack_controller.dart';

class DoubleBackButtonWidget extends StatelessWidget {
  final Widget child;
  final Duration? duration;
  final TextStyle? textStyle;

  DoubleBackButtonWidget({
    required this.child,
    this.duration = const Duration(seconds: 2),
    this.textStyle,
  });

  @override
  Widget build(BuildContext context) {
    final DoubleBackButtonController controller = Get.put(
      DoubleBackButtonController(
        duration: duration!,
        textStyle: textStyle,
      ),
    );

    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) {
          return;
        }
        bool shouldExit = await controller.onBackPressed(context);
        if (shouldExit) {
          SystemNavigator.pop();
        }
      },
      child: child,
    );
  }
}
