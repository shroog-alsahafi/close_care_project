import 'package:healthcare/app/service_provider_app/bookings/views/bookings_screen_provider.dart';

import '../../../export.dart';
import '../../service_provider_app/Home/controllers/home_controller_provider.dart';

customDrawer() {
  final controller = Get.find<HomeControllerProvider>();

  return Drawer(
    backgroundColor: colorAppColors,
    child: Column(
      children: [
        SizedBox(height: height_15),
        SizedBox(
          height: height_120,
          child: Obx(
            () => Row(
              children: [
                NetworkImageWidget(
                  imageurl: controller.userDetailDataModel.value.profileFile ?? iconProfile,
                  imageHeight: height_50,
                  imageWidth: width_50,
                  radiusAll: radius_5,
                ).marginSymmetric(horizontal: margin_10),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextView(
                      text: "${controller.userDetailDataModel.value.fullName}",
                      textStyle: TextStyle(color: Colors.white, fontSize: font_13),
                    ),
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            controller.scaffoldKey.currentState?.closeDrawer();
                            Get.toNamed(AppRoutes.profileViewScreenRoute);
                          },
                          child: TextView(
                            text: keyViewProfile.tr,
                            textStyle: TextStyle(color: Colors.white, fontSize: font_13),
                          ),
                        ),
                        SizedBox(width: width_3),
                        AssetImageWidget(
                          color: Colors.white,
                          imageUrl: iconNext,
                          imageWidth: width_13,
                          imageHeight: height_13,
                        )
                      ],
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
        Expanded(child: _tilesView())
      ],
    ),
  );
}

Widget _tilesView() {
  return Container(
    color: Colors.white,
    child: ListView(
      padding: EdgeInsets.zero,
      children: [
        customListTile(iconCalendar, keyAvailability.tr, () {
          Get.back();
          Get.toNamed(AppRoutes.addAvailabilityProvider);
        }),
        customListTile(iconHome, keyHome.tr, () {
          Get.back();
        }),
        customListTile(iconMyBookings, keyMyBookings.tr, () {
          Get.back();
          Get.to(() => BookingsScreenProvider());
        }),
        customListTile(iconPatients, keyMyPatients.tr, () {
          Get.back();
          Get.toNamed(AppRoutes.patientsScreen);
        }),
        customListTile(iconRatingReview, keyRatingReview.tr, () {
          Get.back();
          Get.toNamed(AppRoutes.ratingsReviewsScreenRoute);
        }),
        customListTile(iconGrowth, keyRevenueManagement.tr, () {
          Get.back();
          Get.toNamed(AppRoutes.revenueManagement);
        }),
        customListTile(iconRefund, keyRefund.tr, () {
          Get.back();
          Get.toNamed(AppRoutes.transactionScreenRoute);
        }),
        customListTile(iconTransactions, keyMyBank.tr, () {
          Get.back();
          Get.toNamed(AppRoutes.bankList);
        }),
        customListTile(iconCall, keyContactUs.tr, () {
          Get.back();
          Get.toNamed(AppRoutes.contactScreen);
        }),
        customListTile(iconSettings, keySettings.tr, () {
          Get.back();
          Get.toNamed(AppRoutes.settingScreen);
        }),
        customListTile(iconAboutUs, keyAboutUs.tr, () {
          Get.back();
          Get.to(AboutUsScreen());
        }),
        customListTile(iconLogout, keyLogout.tr, () {
          Get.back();
          _logoutAccountDialog();
        }),
      ],
    ),
  );
}

_logoutAccountDialog() {
  return Get.dialog(AlertDialogWidget(
    title: keyLogout.tr,
    descrption: keyLogoutDesc.tr,
    voidCallback: (data) {},
    recordId: 0,
    action: keyLogout.tr,
  ));
}

customListTile(imageUrl, text, VoidCallback? onTap) {
  return ListTile(
    onTap: onTap,
    leading: AssetImageWidget(
      imageUrl: imageUrl,
      imageHeight: height_18,
      color: colorAppColors,
    ),
    title: TextView(
      text: text,
      textStyle: textStyleBodyMedium().copyWith(fontWeight: FontWeight.w500, fontSize: font_16, color: Colors.black),
      textAlign: TextAlign.start,
    ),
  );
}
