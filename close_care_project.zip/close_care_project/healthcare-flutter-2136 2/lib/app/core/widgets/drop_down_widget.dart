/*
 * @copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import '../../../export.dart';

class DropDownWidget extends StatelessWidget {
  final String? hint;
  final String? tvHeading;
  final FocusNode? focusNode;
  final String? itemSelected;
  final List<DropdownMenuItem<Object>>? dropdownMenuItems;
  final String? Function(Object?)? validate;
  final Color? color;
  final Color? containerClr;
  final Color? borderSide;
  final double? radius;
  final icon;
  final padding;
  final Function(Object?)? onChanged;
  final RxBool isFocused = false.obs;

  DropDownWidget({
    Key? key,
    this.hint,
    this.tvHeading,
    this.focusNode,
    this.itemSelected,
    this.dropdownMenuItems,
    this.validate,
    this.radius,
    this.color,
    this.icon,
    this.onChanged,
    this.borderSide,
    this.containerClr,
    this.padding,
  }) {
    isFocused.value = focusNode?.hasFocus == true;
    focusNode?.addListener(() {
      isFocused.value = focusNode?.hasFocus == true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        tvHeading == '' ? SizedBox() : textFieldTitle(tvHeading ?? "").paddingOnly(bottom: margin_6),
        ButtonTheme(
          alignedDropdown: true,
          child: Container(
            // decoration: BoxDecoration(color: containerClr ?? colorGrey, borderRadius: BorderRadius.circular(radius ?? radius_10)),
            child: Theme(
              data: ThemeData(canvasColor: Colors.grey.shade600),
              child: DropdownButtonFormField(
                borderRadius: BorderRadius.circular(radius ?? radius_10),
                padding: padding ?? null,
                focusNode: focusNode,
                validator: validate,
                isDense: true,
                decoration: dropDownDecoration(),
                style: Theme.of(Get.context!).textTheme.headline1!.copyWith(
                      fontSize: font_16,
                      fontWeight: FontWeight.w500,
                      color: Colors.black,
                    ),
                hint: TextView(
                  text: hint ?? "Select Item",
                  textStyle: textStyleBodyLarge().copyWith(color: Colors.black),
                ),
                isExpanded: true,
                icon: icon ??
                    Icon(
                      Icons.keyboard_arrow_down_outlined,
                      color: colorAppColors,
                      size: height_25,
                    ),
                iconSize: margin_18,
                iconEnabledColor: color ?? Colors.grey,
                value: itemSelected,
                items: dropdownMenuItems,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                menuMaxHeight: Get.height * 0.5,
                onChanged: onChanged,
              ),
            ),
          ),
        ),
      ],
    );
  }

  OutlineInputBorder _decorationWidget({radius}) => OutlineInputBorder(
      borderRadius: BorderRadius.circular(radius), borderSide: BorderSide(color: borderSide ?? Colors.transparent, width: width_1));
}

InputDecoration dropDownDecoration() => InputDecoration(
    errorStyle: textStyleBody1().copyWith(color: Colors.red.shade300, fontSize: font_10),
    contentPadding: EdgeInsets.symmetric(vertical: margin_15, horizontal: margin_12),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(radius_7),
      borderSide: BorderSide(color: Colors.grey.shade300),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(radius_7),
      borderSide: BorderSide(color: Colors.grey.shade300),
    ),
    focusedErrorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(radius_7),
      borderSide: BorderSide(color: Colors.grey.shade300),
    ),
    disabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(radius_7),
      borderSide: BorderSide(color: Colors.grey.shade300),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(radius_7),
      borderSide: BorderSide(color: Colors.grey.shade300),
    ),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(radius_7),
      borderSide: BorderSide(color: Colors.grey.shade300),
    ));
