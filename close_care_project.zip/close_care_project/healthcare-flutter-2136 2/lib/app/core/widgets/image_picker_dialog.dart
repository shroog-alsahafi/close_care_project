/*
 * @copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *  @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 *  All Rights Reserved.
 *  Proprietary and confidential :  All information contained herein is, and remains
 *  the property of ToXSL Technologies Pvt. Ltd. and its partners.
 *  Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import '../../../export.dart';

class ImagePickerDialogWidget extends StatelessWidget {
  final String title;
  final bool isCameraDisable;
  final Function() galleryFunction;
  final Function()? cameraFunction;

  const ImagePickerDialogWidget({
    Key? key,
    required this.title,
    required this.galleryFunction,
    this.cameraFunction,
    this.isCameraDisable = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        Container(
            width: Get.width,
            decoration: BoxDecoration(
                color: colorWhite,
                borderRadius: BorderRadius.circular(margin_5)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _dialogTitle(),
                _dialogButton(),
              ],
            ).marginAll(margin_20)),
        _cancelButton()
      ],
    ).marginAll(margin_10);
  }

  Widget _dialogTitle() => TextView(
        text: title,
        textStyle: textStyleBodyMedium().copyWith(fontSize: font_17),
        textAlign: TextAlign.start,
      ).paddingOnly(bottom: margin_15);

  _cancelButton() => MaterialButtonWidget(
        onPressed: () {
          Get.back();
        },
        buttonRadius: margin_5,
        buttonColor: Colors.white,
        textColor: Colors.black,
        buttonText: keyCancel.tr,
      ).paddingSymmetric(vertical: margin_15);

  Widget _dialogButton() => Column(
        children: [
          !isCameraDisable
              ? InkWell(
                  onTap: cameraFunction,
                  child: TextView(
                    text: keyTakeImage.tr,
                    textStyle: textStyleBodyLarge(),
                    textAlign: TextAlign.start,
                  ).paddingSymmetric(vertical: margin_12),
                )
              : Container(),
          !isCameraDisable
              ? Divider(
                  color: Colors.grey.shade300,
                  thickness: margin_1,
                )
              : Container(),
          InkWell(
            onTap: galleryFunction,
            child: TextView(
              text: keyChooseImage.tr,
              textStyle: textStyleBodyLarge(),
              textAlign: TextAlign.start,
            ).paddingSymmetric(vertical: margin_12),
          )
        ],
      );
}
