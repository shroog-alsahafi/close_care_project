import 'package:healthcare/export.dart';

class ScreenHeading extends StatelessWidget {
  final String mainHeading;
  final String descHeading;

  const ScreenHeading({
    super.key,
    required this.mainHeading,
    required this.descHeading,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextView(
            text: mainHeading,
            textStyle: TextStyle(
              fontFamily: FontFamily.monteHeading,
                color: colorAppColors,
                fontSize: font_20,
                fontWeight: FontWeight.w600)),
        TextView(
            text: descHeading,
            textStyle: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w300,
                fontSize: font_14)),
      ],
    );
  }
}
