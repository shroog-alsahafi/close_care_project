import 'package:flutter_rating_bar/flutter_rating_bar.dart';

import '../../../export.dart';

class SelectServiceWidget extends StatelessWidget {
  final bool? iconWidget;
  final actionWidget;
  final index;
  final img;
  final name;
  final rating;
  final ratingStar;
  const SelectServiceWidget({
    Key? key,
    this.iconWidget,
    this.actionWidget,
    this.index,
    this.img,
    this.name,
    this.rating,
    this.ratingStar,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: double.infinity,
          decoration: BoxDecoration(color: greyColor, borderRadius: BorderRadius.circular(radius_10)),
          child: IntrinsicHeight(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  child: NetworkImageWidget(
                    imageurl: img,
                    imageWidth: height_60,
                    radiusAll: radius_10,
                    imageHeight: height_60,
                  ).paddingOnly(left: margin_10, top: margin_10, bottom: margin_10),
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      TextView(
                        textAlign: TextAlign.start,
                        text: name,
                        maxLine: 2,
                        textStyle: textStyleBody1().copyWith(fontSize: font_14, fontWeight: FontWeight.w600),
                      ),
                      Row(
                        children: [
                          ratingsView(rating: double.parse(ratingStar)),
                          TextView(text: rating, textStyle: textStyleBody1().copyWith(fontSize: font_15)).paddingOnly(left: margin_10)
                        ],
                      )
                    ],
                  ).paddingOnly(left: margin_10, top: margin_10, bottom: margin_10),
                ),
                actionWidget ??
                    Container(
                      height: double.infinity,
                      width: width_28,
                      decoration: BoxDecoration(
                          color: colorAppColor,
                          borderRadius: BorderRadius.only(topRight: Radius.circular(radius_10), bottomRight: Radius.circular(radius_10))),
                      child: Icon(Icons.arrow_forward_ios_rounded, size: height_20, color: colorWhite),
                    )
              ],
            ),
          ),
        ).paddingOnly(top: margin_10),
      ],
    ).paddingOnly(bottom: margin_10);
  }

  _seeAllRow({required String text, required void Function()? onTap}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        TextView(text: text, textStyle: TextStyle(fontSize: font_17, color: Colors.black, fontWeight: FontWeight.w500)),
        GestureDetector(
          onTap: onTap,
          child: TextView(
            text: keySeeAll.tr,
            textStyle: TextStyle(
                decoration: TextDecoration.underline,
                color: Colors.transparent,
                decorationColor: colorAppColors,
                fontSize: font_14,
                shadows: [Shadow(color: colorAppColor, offset: Offset(0, -3))],
                fontWeight: FontWeight.w400),
          ),
        )
      ],
    );
  }
}
