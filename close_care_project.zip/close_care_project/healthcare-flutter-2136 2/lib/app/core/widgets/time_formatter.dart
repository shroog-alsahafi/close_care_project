/*
 * @copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import 'package:intl/intl.dart';

String hourlyFormatter = 'HH:mm';
String hourFormatter = 'HH:mm:ss';
String hourlyAmPmFormatter = 'hh:mm a';
String dayFormatters = "yyyy-MM-dd ";
String yearFormatters = "yyyy";
String showDayFormatter = "dd-MM-yyyy";
String ratingDateFormatter = "dd/MM/yyyy";
String dateMonthFormatter = "dd MMMM yyyy";
String yearDayMonthFormatter = "yyyy-MM-dd";
String dayMonthYearFormatter = "dd MMM yyyy";
String monthFormatter = "MMM";
String dateFormatter = "dd";
String weekDateFormatter = 'EE, MMM d, yyyy';
String monthDateYearFormatter = "MMM dd, yyyy";
String yearDayMonthTimeFormatter = "yyyy/MM/dd HH:mm:ss";
String mainDateFormatter = "yyyy-MM-dd HH:mm:ss";
String mainDateTimeFormatter = "yyyy-MM-dd HH:mm";
String mainDateTimeFormatter2 = "yyyy-MM-dd HH:mm a";
String dateTimeFormatter = "dd-MM-yyyy hh:mm a";
String bookFormatter = "dd MMM HH:mm";
String notificationFormatter = "dd MMM yyyy, HH:mm";
//String dateTimeYearFormatter = "EEE, MMM dd, yyyy HH:mm:ss";
String dateTimeYearFormatter = "EEE, MMM dd, yyyy HH:mm";
String dateTimeYearFormatter2 = "EEE, MMM dd, yyyy";
String dateHour = "hh:mm";

String changeUtcToLocalString(
  String? date,
  String? formatter,
) {
  try {
    String formattedDate = DateFormat(formatter ?? mainDateFormatter).format(date != null ? DateTime.parse(date + 'Z').toLocal() : DateTime.now());
    return formattedDate;
  } catch (e) {
    return "";
  }
}

String changeDateFormat(
  String? date,
  String? formatter,
) {
  try {
    String formattedDate = DateFormat(formatter ?? mainDateFormatter).format(date != null ? DateTime.parse(date).toLocal() : DateTime.now());
    return formattedDate;
  } catch (e) {
    return "";
  }
}

String changeLocalToUtcString(String dateString, String? formatter) {
  try {
    String formattedDate = DateFormat(formatter ?? mainDateFormatter).format(DateTime.parse(dateString).toUtc());
    return formattedDate;
  } catch (e) {
    return "";
  }
}

String changeDateIntoString(DateTime date, String? formatter) {
  try {
    String formattedDate = DateFormat(formatter ?? mainDateFormatter).format(date);
    return formattedDate;
  } catch (e) {
    return "";
  }
}

DateTime changeIntoLocalDate(String dateString, {DateTime? defaultTime}) {
  try {
    return DateTime.parse(dateString);
  } catch (e) {
    return defaultTime!;
  }
}
