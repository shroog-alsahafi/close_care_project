import 'package:healthcare/export.dart';

class Validator {
  static String? fieldChecker(String value, String message) {
    if (value.isEmpty || value == "") {
      return "$message ${keyCannotEmpty.tr}";
    } else if (value != value.trim()) {
      return keyRemoveExtraSpaces.tr;
    } else {
      return null;
    }
  }

  static String? timeChecker(String value, String message) {
    if (value.isEmpty || value == "" || value.trim().isEmpty) {
      return "$message ${keyCannotEmpty.tr}";
    } else if (value[0] == "0") {
      return "Enter valid time in min";
    } else {
      return null;
    }
  }

  static String? time(String value1, String value2) {
    if (value1.trim().isEmpty && value2.trim().isEmpty) {
      return null;
    } else if (value1.trim().isEmpty || value2.trim().isEmpty) {
      return "Select both time";
    } else if (checkGreaterTime(value1, value2) == false) {
      return "Start time should be less than end time";
    } else {
      return null;
    }
  }

  static String? time2(String value1, String value2) {
    if (value1.trim().isEmpty && value2.trim().isEmpty) {
      return null;
    } else if (value1.trim().isEmpty || value2.trim().isEmpty) {
      return "Select both time";
    } else if (checkGreaterTime(value1, value2) == false) {
      return "End time should be greater than start time";
    } else {
      return null;
    }
  }

  static String? priceChecker(String value, String message) {
    if (value.isEmpty || value == "" || value.trim().isEmpty) {
      return "$message ${keyCannotEmpty.tr}";
    } else if (value[0] == "0") {
      return "Enter valid price";
    } else {
      return null;
    }
  }

  static String? validateLocation(String value, String message) {
    var pattern = r"^[^\s].+[^\s]$";
    RegExp regex = new RegExp(pattern);
    if (value.isEmpty || value == "") {
      return "$message ${keyCannotEmpty.tr}";
    } else if (value.toString().length < 3) {
      return keyMinimumRequirementThree.tr;
    } else if (!regex.hasMatch(value)) {
      return keyRemoveExtraSpaces.tr;
    } else {
      return null;
    }
  }

  static String? validateBusiness(String value, String message) {
    var pattern = r"^[^\s].+[^\s]$";
    RegExp regex = new RegExp(pattern);
    if (value.isEmpty || value == "") {
      return "$message ${keyCannotEmpty.tr}";
    } else if (value.toString().length < 5) {
      return "Professional classification number cannot be less than 5";
    } else if (!regex.hasMatch(value)) {
      return keyRemoveExtraSpaces.tr;
    } else {
      return null;
    }
  }

  static String? idMatch({String? value, String? password}) {
    if (value!.isEmpty) {
      return "Professional classification number cannot be empty";
    } else if (value == password) {
      return "Id and Professional classification number should no be same ";
    }
    return null;
  }

  static String? validateWebsite(String value, message) {
    var pattern = r"((https?:www\.)|(https?:\/\/)|(www\.))[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9]{1,6}(\/[-a-zA-Z0-9()@:%_\+.~#?&\/=]*)?";
    RegExp regex = new RegExp(pattern);
    if (value.isEmpty) {
      return "$message ${keyCannotEmpty.tr}";
    } else if (!regex.hasMatch(value)) {
      return keyEnterValidUrl.tr;
    }
    return null;
  }
}
