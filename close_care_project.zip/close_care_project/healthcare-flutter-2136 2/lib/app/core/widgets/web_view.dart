import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import '../../../export.dart';

class InAppWebBrowser extends StatefulWidget {
  final String? url;
  final String? title;
  final String? transactionID;

  const InAppWebBrowser({this.url, this.title, this.transactionID});

  @override
  // ignore: library_private_types_in_public_api
  _WebViewPagesState createState() => _WebViewPagesState();
}

class _WebViewPagesState extends State<InAppWebBrowser> {
  double progress = 0;
  final GlobalKey webViewKey = GlobalKey();
  InAppWebViewController? webViewController;
  PullToRefreshController? pullToRefreshController;
  InAppWebViewGroupOptions? options;

  Timer? timer;
  @override
  void initState() {
    webViewOptions();
    webViewInit();
    timer = Timer.periodic(
      Duration(seconds: 2),
      (timer) => hitPaymentStatusApiCall(),
    );
    super.initState();
  }

  webViewOptions() {
    options = InAppWebViewGroupOptions(
        crossPlatform: InAppWebViewOptions(
          useShouldOverrideUrlLoading: true,
          mediaPlaybackRequiresUserGesture: false,
        ),
        android: AndroidInAppWebViewOptions(
          useHybridComposition: true,
        ),
        ios: IOSInAppWebViewOptions(
          allowsInlineMediaPlayback: true,
        ));
  }

  webViewInit() {
    pullToRefreshController = PullToRefreshController(
        options: PullToRefreshOptions(
          color: Colors.blue,
        ),
        onRefresh: () async {
          if (Platform.isAndroid) {
            webViewController?.reload();
          } else if (Platform.isIOS) {
            webViewController?.loadUrl(
                urlRequest: URLRequest(url: await webViewController?.getUrl()));
          }
        });
  }

  hitPaymentStatusApiCall() async {
    try {
      final response = DioClient().post(
        "/api/booking/get-transaction",
        queryParameters: {"id": widget.transactionID},
        skipAuth: false,
      );
      MessageResponseModel messageResponseModel =
          MessageResponseModel.fromJson(await response);
      Get.offAllNamed(AppRoutes.home);
      showInSnackBar(message: messageResponseModel.message.toString());
    } catch (e, str) {
      Future.error(NetworkExceptions.getDioException(
          e, str, "/api/booking/get-transaction"));
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light.copyWith(
            statusBarColor: Colors.white,
            statusBarIconBrightness: Brightness.dark),
        child: SafeArea(
          child: Scaffold(
            backgroundColor: Colors.white,
            appBar: CustomAppBar(
              appBarTitleText: widget.title,
            ),
            body: Column(
              children: [
                Column(
                  children: [
                    progress < 1.0
                        ? LinearProgressIndicator(
                            value: progress,
                            color: colorAppColors,
                          )
                        : Container(),
                  ],
                ),
                Expanded(
                  child: InAppWebView(
                    key: webViewKey,
                    initialUrlRequest:
                        URLRequest(url: Uri.parse(widget.url ?? "")),
                    initialOptions: options,
                    pullToRefreshController: pullToRefreshController,
                    onWebViewCreated: (controller) {
                      webViewController = controller;
                    },
                    onLoadStart: (controller, url) {
                      debugPrint("loadUrl $url");
                    },
                    androidOnPermissionRequest:
                        (controller, origin, resources) async {
                      return PermissionRequestResponse(
                          resources: resources,
                          action: PermissionRequestResponseAction.GRANT);
                    },
                    onLoadStop: (controller, url) async {
                      pullToRefreshController?.endRefreshing();
                    },
                    onLoadError: (controller, url, code, message) {
                      pullToRefreshController?.endRefreshing();
                    },
                    onProgressChanged: (controller, progress) {
                      if (progress == 100) {
                        pullToRefreshController?.endRefreshing();
                      }
                      setState(() {
                        this.progress = progress / 100;
                      });
                    },
                    onConsoleMessage: (controller, consoleMessage) {
                      debugPrint("$consoleMessage");
                    },
                  ),
                ),
              ],
            ),
          ),
        ));
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }
}
