class MessageResponseModel {
  bool? success;
  String? message;
  dynamic detail;
  var count;
  String? copyrighths;
  String? createdOn;
  var otp;
  var id;
  var transactionId;

  MessageResponseModel({
    this.success,
    this.message,
    this.detail,
    this.count,
    this.id,
    this.copyrighths,
    this.otp,
    this.createdOn,
    this.transactionId,
  });

  MessageResponseModel.fromJson(Map json) {
    success = json['success'];
    message = json['message'];
    detail = json['detail'];
    otp = json['otp'];
    id = json['id'];
    count = json['count'];
    copyrighths = json['copyrighths'] ?? json["copyrights"];
    createdOn = json['created_on'];
    transactionId = json['booking_transaction_id'];
  }

  Map toJson() {
    final Map data = new Map();
    data['success'] = this.success;
    data['message'] = this.message;
    data['detail'] = this.detail;
    data['count'] = this.count;
    data['otp'] = this.otp;
    data['id'] = this.id;
    data['copyrighths'] = this.copyrighths;
    data['copyrights'] = this.copyrighths;
    data['created_on'] = this.createdOn;
    data['booking_transaction_id'] = this.transactionId;
    return data;
  }
}
