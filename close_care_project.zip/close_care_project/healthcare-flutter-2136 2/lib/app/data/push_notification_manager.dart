import 'package:healthcare/app/modules/bookings/controller/service_detail_controller.dart';
import 'package:healthcare/app/service_provider_app/Home/controllers/home_controller_provider.dart';
import 'package:healthcare/app/service_provider_app/bookings/controllers/booking_detail_controller_provider.dart';

import '../../export.dart';

@pragma('vm:entry-point')
Future _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
}

class PushNotificationsManager {
  var ios = new DarwinInitializationSettings();
  ChooseRoleModel? userRole;

  PushNotificationsManager._();

  factory PushNotificationsManager() => _instance;
  static final PushNotificationsManager _instance = PushNotificationsManager._();
  FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  bool _initialized = false;

  Future init() async {
    if (!_initialized) {
      _firebaseMessaging.requestPermission(alert: true, sound: true);
      _firebaseMessaging.setForegroundNotificationPresentationOptions(alert: true, badge: true, sound: true);
      _firebaseMessaging.getToken().then((value) {
        deviceToken = value;
      });
      FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
      getInitialMessage();
      onMessage();
      onAppOpened();
      _initialized = true;
    }
  }

  getInitialMessage() async {
    await Future.delayed(Duration(milliseconds: 500));
    _firebaseMessaging.getInitialMessage().then(
      (message) async {
        if (message != null) {
          notificationRedirection(message);
        }
      },
    );
  }

  onMessage() {
    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      var notification = message.data;
      var androids = AndroidInitializationSettings('@drawable/notify');
      var iOSPlatformChannelSpecifics = DarwinNotificationDetails();
      var platform = new InitializationSettings(android: androids, iOS: ios);
      flutterLocalNotificationsPlugin.initialize(platform, onDidReceiveNotificationResponse: (NotificationResponse data) {
        notificationRedirection(message);
      });
      if (Platform.isAndroid) {
        var androidPlatformChannelSpecifics = AndroidNotificationDetails(
          'com.app.healthcare',
          'healthcare',
          icon: '@drawable/notify',
          importance: Importance.max,
          groupKey: "healthcare",
          color: colorAppColor,
          priority: Priority.high,
          setAsGroupSummary: true,
          groupAlertBehavior: GroupAlertBehavior.all,
          playSound: true,
          enableVibration: true,
        );

        var platformChannelSpecifics = NotificationDetails(android: androidPlatformChannelSpecifics, iOS: iOSPlatformChannelSpecifics);
        await flutterLocalNotificationsPlugin.show(0, message.notification?.title, message.notification?.body, platformChannelSpecifics, payload: jsonEncode(notification));
      }
    });
  }

  onAppOpened() {
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      notificationRedirection(message);
    });
  }

  _getUserRole() async {
    userRole = await getUserRole();
  }

  notificationRedirection(RemoteMessage message) async {
    // isNotification = true;
    isNotified = true;
   await _getUserRole();
    var action = message.data['controller'];
    var objId = message.data['model_id'];
    var userName=message.data['username']??'';
    var bookingId=message.data['booking_id']??'';
    var toId=message.data['created_by_id']??'';

    switch (action) {

      case 'booking':
        print('userRole?.roleType======${userRole?.roleType}');
        if (userRole?.roleType == ROLE_CUSTOMER) {
          if (Get.currentRoute == AppRoutes.serviceDetail) {
            Get.put(ServiceDetailController()).hitBookingDetailApi(serviceId: objId);
          } else {
            Get.toNamed(
              AppRoutes.serviceDetail,
              arguments: {'id': objId, "argIsFromNotification": true},
            );
          }
        } else {

          if (Get.currentRoute == AppRoutes.bookingDetailScreenProvider) {
            Get.put(BookingsDetailControllerProvider()).bookingId = objId;
            Get.put(BookingsDetailControllerProvider()).hitBookingDetailsApi();
          } else {
            Get.toNamed(AppRoutes.bookingDetailScreenProvider, arguments: {argBookingID: objId, "argIsFromNotification": true});
            Get.put(HomeControllerProvider()).hitPatientRequestApi();
          }
        }
        break;
      case 'chat':
        Get.toNamed(AppRoutes.msgChatScreen, arguments: {
          "toId": toId,
            "toName": userName,
          "bookingId": bookingId,
        });
        break;
      case 'review':
        Get.toNamed(AppRoutes.ratingsReviewsScreenRoute);
        break;
      default:
      if(userRole?.roleType==ROLE_SERVICE_PROVIDER){
        Get.put(HomeControllerProvider()).hitPatientRequestApi();
        Get.put(HomeControllerProvider()).hitBookingListApi();
      }else{

      }
    }
  }

  Future<bool> isUserSessionValid(notificationUserToken) async {
    await GetStorage.init();
    final preferenceManagerr = Get.put(PreferenceManger());
    var authToken;

    try {
      authToken = await preferenceManagerr.getAuthToken();
    } catch (e) {
      authToken = await Get.put(PreferenceManger()).getAuthToken();
    }
    if (authToken == null) {
      Get.offAllNamed(AppRoutes.logIn);
      preferenceManagerr.clearLoginData();
      return false;
    }
    if (authToken != notificationUserToken) {
      return false;
    }
    return true;
  }
}
