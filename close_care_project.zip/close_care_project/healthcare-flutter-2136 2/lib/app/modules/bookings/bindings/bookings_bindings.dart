import 'package:get/get.dart';
import 'package:healthcare/app/modules/bookings/controller/booking_details_controller.dart';
import 'package:healthcare/app/modules/bookings/controller/confirm_booking_controller.dart';
import 'package:healthcare/app/modules/bookings/controller/select_date_time_controller.dart';
import '../controller/book_service_controller.dart';
import '../controller/give_rating_controller.dart';
import '../controller/select_service_detail_controller.dart';
import '../controller/select_service_view_controller.dart';

class BookingBindings extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ConfirmBookingController());
    Get.lazyPut(() => SelectDateTimeController());
    Get.lazyPut(() => BookingDetailsController());
    Get.lazyPut<BookServiceController>(() => BookServiceController());
    Get.lazyPut<SelectServiceViewController>(
        () => SelectServiceViewController());
    Get.lazyPut<SelectServiceDetailController>(
        () => SelectServiceDetailController());
    Get.lazyPut<GiveRatingController>(() => GiveRatingController());
  }
}
