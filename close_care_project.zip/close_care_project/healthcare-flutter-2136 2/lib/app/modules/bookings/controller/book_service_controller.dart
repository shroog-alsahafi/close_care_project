import 'package:healthcare/app/modules/bookings/controller/select_date_time_controller.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import '../../../../export.dart';
import '../../../core/widgets/time_formatter.dart';
import '../../../service_provider_app/services/controllers/service_details_controller_provider.dart';

class BookServiceController extends GetxController {
  @override
  void onInit() {
    if (Get.arguments != null) {
      // isEdit = Get.arguments[argIsEdit];
    }
    super.onInit();
  }

  @override
  void onReady() {
    hitAddBookingApi();
    super.onReady();
  }

  RxInt selectedDay = DateTime.now().day.obs;
  var selectedFormattedDate = DateFormat(yearDayMonthFormatter).format(DateTime.now());

  var selectedFormattedWeekDay = DateTime.now().weekday;
  RxInt selectedDateIndex = 0.obs;
  var selectedDate;
  ScrollController scrollController = ScrollController();
  RxInt? selectedMonth, selectedYear;
  RxString formattedDate = DateFormat('MMM yyyy').format(DateTime.now()).obs;
  bool isEdit = false;
  List<AptStaticList> aptlist = [
    AptStaticList(title: "In Person", image: iconFilter),
    AptStaticList(title: "Video Call", image: iconFilter),
    AptStaticList(title: "Phone Call", image: iconFilter),
  ];
  RxInt selectedIndex = 0.obs;
  RxInt selectedTimeIndex = 0.obs;

  RxList<String> selectedImages = <String>[].obs;
  RxString profileImage = "".obs;

  selectImg() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.custom,
        allowedExtensions: ['jpg', 'jpeg', 'png']);
    if (result != null) {
      result.files.forEach((element) {
        selectedImages.add(element.path!);
      });
    }
  }

  RxList<WeekDaysModel> weedDaysList = <WeekDaysModel>[
    WeekDaysModel(id: 1, day: "Mon"),
    WeekDaysModel(id: 2, day: "Tue"),
    WeekDaysModel(id: 3, day: "Wed"),
    WeekDaysModel(id: 4, day: "Thu"),
    WeekDaysModel(id: 5, day: "Fri"),
    WeekDaysModel(id: 6, day: "Sat"),
    WeekDaysModel(id: 7, day: "Sun"),
  ].obs;

  List<String> slotsList = [];
  RxList<String> cardList = <String>[].obs;
  var controller = Get.find<SelectDateTimeController>();

  hitAddBookingApi() async {
    customLoader.show(Get.overlayContext);
    try {
      var requestBody = {
        "Booking[booking_service_type]": "2",
        "Booking[service_id]": controller.servicesProviderList.id.toString() ?? '',
        "Booking[date]": controller.selectedFormattedDate.toString() ?? '',
        "Booking[address]": controller.selectedFormattedDate.toString() ?? '',
        "Booking[start_time]": selectedDay ?? '',
        "Booking[end_time]": selectedIndex ?? '',
        "File[key]": ""
      };
      var response = DioClient().post(
        "/api/booking/service-booking",
        data: requestBody,
        skipAuth: false,
      );
      ErrorMessageResponseModel errorMessageResponseModel =
          ErrorMessageResponseModel.fromJson(await response);
      Get.offAllNamed(AppRoutes.home);
      showInSnackBar(message: errorMessageResponseModel.message.toString());
      customLoader.hide();
      update();
    } catch (e, str) {
      customLoader.hide();

      Future.error(NetworkExceptions.getDioException(
          e, str, "/api/booking/service-booking"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}

class AptStaticList {
  var image;
  var title;

  AptStaticList({this.title, this.image});
}
