import 'package:healthcare/app/modules/bookings/model/service_detail_response_model.dart';
import 'package:intl/intl.dart';

import '../../../../export.dart';
import '../../../core/widgets/time_formatter.dart';
import '../../authentication/model/response_model/provider_service_res_model.dart';
import '../../ratings_reviews/model/ratings_list_response_model.dart';
import '../model/rating_list_model_response.dart';

class BookingDetailsController extends GetxController {
  final PreferenceManger preferenceManger = Get.put(PreferenceManger());
  SignupResponseModel signUpResponseModel = SignupResponseModel();
  var lat,long;
  var distance;
  @override
  void onInit() {
    getProfileData();
    _getArgs();
    super.onInit();
  }
  getProfileData()async{
    preferenceManger.getSavedLoginData().then((value) {
      if (value != null) {
        signUpResponseModel = value;
        print('SingleUpResponseMOdel=====${signUpResponseModel.detail?.latitude}');
        print('SingleUpResponseMOdel=====${signUpResponseModel.detail?.fullName}');
      }
    });
  }

  var serviceName;
  bool centerTitle = true;
  @override
  void onReady() {
    hitListRatingApi();
    hitBookingDetailsApi();
    super.onReady();
  }

  int page = 0;
  var providerID;
  _getArgs() {
    if (Get.arguments != null) {
      providerID = Get.arguments["id"];
      serviceName = Get.arguments["serviceName"];
    }
  }

  ServiceProviderDetailResponseModel serviceProviderDetailResponseModel = ServiceProviderDetailResponseModel();
  Rx<UserDetailDataModel> servicesProviderList = UserDetailDataModel().obs;
  var selectedFormattedDate = DateFormat("yyyy-MM-dd").format(DateTime.now());
  RxString selectedService = "".obs;
  RxList<ProviderServiceList> serviceList = <ProviderServiceList>[].obs;
  RxList<ProviderServiceList> selectedServiceList = <ProviderServiceList>[].obs;

  RxBool isLoading = false.obs;
  hitBookingDetailsApi() async {
    isLoading.value = true;
    try {
      final response = DioClient().get(
        "/api/user/service-provider-detail",
        queryParameters: {
          "provider_id": providerID,
          "page": page,
        },
        skipAuth: false,
      );
      serviceProviderDetailResponseModel = ServiceProviderDetailResponseModel.fromJson(await response);
      if (serviceProviderDetailResponseModel.list != null) {
        servicesProviderList.value = serviceProviderDetailResponseModel.list![0];
        serviceList.value = serviceProviderDetailResponseModel.list![0].providerDetail?.providerServices ?? [];
      }
      double dis =haversineDistance(double.parse(serviceProviderDetailResponseModel.list![0].latitude), double.parse(serviceProviderDetailResponseModel.list![0].longitude), double.parse(signUpResponseModel.detail?.latitude), double.parse(signUpResponseModel.detail?.longitude));
      distance=dis.toStringAsFixed(2);
      isLoading.value = false;
    } catch (e, str) {
      print("eeeeeeeeeeeeeee$e\n$str");
      isLoading.value = false;
      Future.error(NetworkExceptions.getDioException(e, str, "/api/user/service-provider-detail"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  RxList<RatingDataModel> ratingList = <RatingDataModel>[].obs;
  RatingsListResponseModel ratingListResponseModel = RatingsListResponseModel();
  hitListRatingApi() async {
    try {
      final response = DioClient().post(
        "/api/rating/rating-list",
        skipAuth: false,
        queryParameters: {'page': page, "id": providerID},
      );
      ratingListResponseModel = RatingsListResponseModel.fromJson(await response);
      ratingList.value = ratingListResponseModel.list ?? [];
      customLoader.hide();
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/rating/rating-list"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}
