import 'package:healthcare/export.dart';

import '../model/booking_list_model.dart';

class BookingsViewController extends GetxController {
  ChooseRoleModel? userRole;
  @override
  void onReady() {
    paginateItemsList();
    hitBookingListApi();
    _getUserRole();
    super.onReady();
  }
  _getUserRole() async {
    userRole = await getUserRole();
  }

  RxInt isUpcomings = 1.obs;
  // RxBool isUpcoming = true.obs;
  RxList<BookingList> servicesProviderList = <BookingList>[].obs;
  int page = 0;
  RxBool isLoading = false.obs;
  BookingListResponseModel servicesProviderResponseModel = BookingListResponseModel();

  hitBookingListApi() async {
    if (page == 0) {
      isLoading.value = true;
      servicesProviderList.clear();
    }
    try {
      final response = DioClient().get(
        "/api/booking/list",
        queryParameters: {"page": page, "type": isUpcomings.value},
        skipAuth: false,
      );
      servicesProviderResponseModel = BookingListResponseModel.fromJson(await response);
      servicesProviderList.addAll(servicesProviderResponseModel.list ?? []);
      isLoading.value = false;
    } catch (e, str) {
      isLoading.value = false;
      Future.error(NetworkExceptions.getDioException(e, str, "/booking/list"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  ScrollController scrollController = ScrollController();
  paginateItemsList() {
    scrollController.addListener(() {
      if (scrollController.position.pixels == scrollController.position.maxScrollExtent) {
        if (page < servicesProviderResponseModel.meta!.pageCount!) {
          page++;
          hitBookingListApi();
        }
      }
    });
  }
}
