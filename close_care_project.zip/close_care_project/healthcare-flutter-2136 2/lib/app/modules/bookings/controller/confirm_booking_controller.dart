import 'dart:math';

import 'package:flutter_paypal_native/flutter_paypal_native.dart';
import 'package:flutter_paypal_native/models/custom/currency_code.dart';
import 'package:flutter_paypal_native/models/custom/environment.dart';
import 'package:flutter_paypal_native/models/custom/order_callback.dart';
import 'package:flutter_paypal_native/models/custom/purchase_unit.dart';
import 'package:flutter_paypal_native/models/custom/user_action.dart';
import 'package:flutter_paypal_native/str_helper.dart';
import 'package:healthcare/app/core/widgets/web_view.dart';
import 'package:healthcare/app/modules/bookings/controller/booking_details_controller.dart';
import 'package:healthcare/app/modules/bookings/controller/select_date_time_controller.dart';
import 'package:healthcare/app/modules/bookings/controller/select_service_detail_controller.dart';
import 'package:healthcare/export.dart';

class ConfirmBookingController extends GetxController {
  var selectDateController = Get.find<SelectDateTimeController>();
  var sll = Get.find<SelectServiceDetailController>();
  final bookingController = Get.find<BookingDetailsController>();
  var distance;

  @override
  void onInit() {
    getArgument();
    initPayPal();
    super.onInit();
  }

  getArgument() {
    if (Get.arguments != null) {
      distance = Get.arguments['distance'] ?? '';
      print('Distance======$distance');
    }
  }

  hitAddBookingApi() async {
    customLoader.show(Get.overlayContext);
    try {
      var requestBody = {
        "Booking[day_ids]": selectDateController.selectedFormattedWeekDay.toString() ?? '',
        "Booking[service_id]": sll.id ?? bookingController.selectedServiceList.first.serviceId,
        "Booking[date]": selectDateController.selectedFormattedDate.toString() ?? '',
        "Booking[start_time]": selectDateController.slotsList[int.parse(selectDateController.selectedTimeIndex.value)].startTime.toString().split(" ")[1] ?? '',
        "Booking[end_time]": selectDateController.slotsList[int.parse(selectDateController.selectedTimeIndex.value)].endTime.toString().split(" ")[1] ?? '',
        "File[key][]": await convertListToMultipart(selectDateController.selectedImages.value),
        "Booking[provider_id]": selectDateController.id,
        "Booking[price]": bookingController.servicesProviderList.value.providerDetail?.providerServices?.first.rates,
        "Booking[total_price]":
            "${double.parse(bookingController.servicesProviderList.value.providerDetail?.providerServices!.first.rates ?? "0") + double.parse(bookingController.servicesProviderList.value.providerDetail?.providerServices!.first.commissionPrice ?? "0")}",
      };
      var response = DioClient()
          .post(
        "/api/booking/add",
        data: FormData.fromMap(requestBody),
        skipAuth: false,
      )
          .then((response) {
        MessageResponseModel messageResponseModel = MessageResponseModel.fromJson(response);
        Get.to(() => InAppWebBrowser(
              url: "$baseUrl/site/paypal/${response["details"]["booking_transaction_id"]}",
              title: "Make Payment",
              transactionID: "${response["details"]["booking_transaction_id"]}",
            ));
        customLoader.hide();
      }).onError((error, stackTrace) {
        print("oneror  $error\n$stackTrace");
        customLoader.hide();
        Future.error(NetworkExceptions.getDioException(error, stackTrace, "/api/booking/add"));
        showInSnackBar(message: NetworkExceptions.messageData);
      });
    } catch (e, str) {
      print("catch  $e\n$str");
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/add"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  /// pay pal

  String clientId = 'AZ_lZnOg1ssXJ_5Dz8b76wmiefiXzCcvgxNuVaWJPMVxqXKnuM1z98MT7aETfb1lXcW9V4l-1GcSkdQU';

  final _flutterPaypalPlugin = FlutterPaypalNative.instance;

  void initPayPal() async {
    //set debugMode for error logging
    FlutterPaypalNative.isDebugMode = true;

    //initiate payPal plugin
    await _flutterPaypalPlugin.init(
      //your app id !!! No Underscore!!! see readme.md for help
      returnUrl: "com.app.healthcare://paypalpay",
      //client id from developer dashboard
      clientID: clientId,

      //sandbox, staging, live etc
      payPalEnvironment: FPayPalEnvironment.sandbox,
      //what currency do you plan to use? default is US dollars
      currencyCode: FPayPalCurrencyCode.usd,
      // action paynow?;
      action: FPayPalUserAction.continuePayment,
    );

    //call backs for payment
    _flutterPaypalPlugin.setPayPalOrderCallback(
      callback: FPayPalOrderCallback(
        onCancel: () {
          //user canceled the payment
          print("");
        },
        onSuccess: (data) {
          //successfully paid
          //remove all items from queue
          _flutterPaypalPlugin.removeAllPurchaseItems();
          String orderID = data.orderId ?? "";
          print("$orderID");
        },
        onError: (data) {
          //an error occured
          print("${data.reason}");
        },
        onShippingChange: (data) {
          //the user updated the shipping address
          print(
            " ${data.shippingChangeAddress?.adminArea1 ?? ""}",
          );
        },
      ),
    );
  }

  makePayment() {
    //add 1 item to cart. Max is 4!
    if (_flutterPaypalPlugin.canAddMorePurchaseUnit) {
      _flutterPaypalPlugin.addPurchaseUnit(
        FPayPalPurchaseUnit(
          amount: 100.10,
          referenceId: "12",
        ),
      );
    }
    // initPayPal();
    _flutterPaypalPlugin.makeOrder(
      action: FPayPalUserAction.payNow,
    );
  }

  @override
  void onClose() {
    customLoader.hide();
    super.onClose();
  }
}
