import 'package:healthcare/app/modules/bookings/controller/service_detail_controller.dart';
import 'package:healthcare/export.dart';

class GiveRatingController extends GetxController {
  @override
  void onInit() {
    getArgs();
    super.onInit();
  }

  TextEditingController reviewController = TextEditingController();
  RxDouble rating = 0.0.obs;
  var id;
  var name;
  var fullName;
  var providerId;
  var image;
  final formGlobalKey = GlobalKey<FormState>();

  getArgs() {
    if (Get.arguments != null) {
      id = Get.arguments["id"];
      name = Get.arguments["name"];
      fullName = Get.arguments["fullName"];
      providerId = Get.arguments["providerId"];
      image = Get.arguments["image"];
    }
  }

  hitAddRatingApi() async {
    customLoader.show(Get.overlayContext!);
    var requestModal = {
      "Rating[rating]": rating.value,
      "Rating[comment]": reviewController.text,
      "Rating[title]": providerId,
    };
    try {
      final response = DioClient().post("/api/booking/add-rating", data: FormData.fromMap(requestModal), skipAuth: false, queryParameters: {
        "booking_id": id,
      });
      MessageResponseModel messageResponseModel = MessageResponseModel.fromJson(await response);
      customLoader.hide();
      Get.find<ServiceDetailController>().hitBookingDetailApi();
      Get.back();
      showInSnackBar(message: messageResponseModel.message ?? '');
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/add-rating"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}
