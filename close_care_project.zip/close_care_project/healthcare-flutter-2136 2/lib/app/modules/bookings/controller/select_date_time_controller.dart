import 'package:intl/intl.dart';
import 'package:healthcare/export.dart';

import '../../../core/widgets/time_formatter.dart';
import '../../services/models/data_model/service_provider_response_model.dart';
import '../model/slot_model.dart';

class SelectDateTimeController extends GetxController {
  RxInt selectedDay = DateTime.now().day.obs;
  var selectedFormattedDate = DateFormat(yearDayMonthFormatter).format(DateTime.now());
  var selectedFormattedWeekDay = DateTime.now().weekday;
  TextEditingController serviceController = TextEditingController();
  RxString selectedTimeIndex = "".obs;
  var distance;
  // ReqDataModel dataModel = ReqDataModel();
  final GlobalKey<FormState> formGlobalKey = GlobalKey<FormState>();

  ServicesProviderList servicesProviderList = ServicesProviderList();

  var selectedDate;
  ScrollController scrollController = ScrollController();
  RxInt? selectedMonth, selectedYear;
  RxString formattedDate = DateFormat('MMM yyyy').format(DateTime.now()).obs;
  List<SlotDataModel> slotsList = [];
  @override
  void onReady() {
    getArguments();
    serviceSlotsListing();
    scrollToCurrentDate();
    super.onReady();
  }

  scrollToCurrentDate() {
    if (selectedDay.value > 4)
      Future.delayed(Duration.zero, () {
        scrollController.animateTo(
          selectedDay.value * width_55,
          duration: Duration(milliseconds: 1000),
          curve: Curves.easeInOut,
        );
      });
  }

  var id;
  getArguments() {
    if (Get.arguments != null) {
      id = Get.arguments["provider_id"];
      distance=Get.arguments['distance']??'';
    }
  }

  serviceSlotsListing() async {
    customLoader.show(Get.overlayContext);

    try {
      final response = DioClient().get("/api/user/service-slot",
          queryParameters: {
            "day_id": selectedFormattedWeekDay ?? '',
            "provider_id": id ?? '',
            "date": selectedFormattedDate ?? '',
          },
          skipAuth: false);

      SlotListResponseModel slotListResponseModel = SlotListResponseModel.fromJson(await response);
      customLoader.hide();
      slotsList = slotListResponseModel.list ?? [];
      update();


    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/user/service-slot"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  RxList<String> selectedImages = <String>[].obs;
  selectImg() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: ['jpg', 'jpeg', 'png'],
    );
    if (result != null) {
      result.files.forEach((element) {
        selectedImages.add(element.path!);
      });
    }
  }
}
