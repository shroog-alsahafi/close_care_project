import 'package:get/get.dart';
import '../../../../main.dart';
import '../../../core/utils/helper_widget.dart';
import '../../../data/remote_service/network/dio_client.dart';
import '../../../data/remote_service/network/network_exceptions.dart';
import '../model/select_service_provider_detail_model.dart';
import '../model/service_detail_response_model.dart';

class SelectServiceDetailController extends GetxController {
  onReady() {
    getArguments();
    super.onReady();
  }

  var id;
  var typeId;
  ServiceProviderResponseModel serviceProviderDetailResponseModel = ServiceProviderResponseModel();
  int page = 0;
  var name;

  RxList<ServiceProviderList> serviceProviderDetailList = <ServiceProviderList>[].obs;

  RxBool isUpcoming = true.obs;

  getArguments() {
    if (Get.arguments != null) {
      id = Get.arguments["id"];
      typeId = Get.arguments["typeId"];
      name = Get.arguments["name"];
      hitSelectServiceProvider();
    }
  }

  hitSelectServiceProvider() async {
    customLoader.show(Get.overlayContext);
    try {
      final response = DioClient().get("/api/service/service-provider",
          queryParameters: {
            "id": id,
            "page": page,
          },
          skipAuth: false);
      serviceProviderDetailResponseModel = ServiceProviderResponseModel.fromJson(await response);
      customLoader.hide();
      if (page == 0) {
        serviceProviderDetailList.value = serviceProviderDetailResponseModel.list ?? [];
      } else {
        serviceProviderDetailList.addAll(serviceProviderDetailResponseModel.list ?? []);
      }
    } catch (e, str) {
      print("ssssss$e\n$str");
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/service/service-provider"));
      // showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}
