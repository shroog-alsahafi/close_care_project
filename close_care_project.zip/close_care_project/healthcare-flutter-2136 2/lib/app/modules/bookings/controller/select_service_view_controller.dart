import 'package:healthcare/export.dart';
import '../../services/models/data_model/service_provider_response_model.dart';
import '../model/select_service_model_response.dart';

class SelectServiceViewController extends GetxController {
  onReady() {
    hitSelectServiceApi();
    super.onReady();
  }

  SelectServiceListResponseModel selectServiceListResponseModel = SelectServiceListResponseModel();
  int page = 0;
  RxList<SelectServiceList> selectServiceList = <SelectServiceList>[].obs;
  RxInt isUpcomings = 1.obs;

  hitSelectServiceApi() async {
    customLoader.show(Get.overlayContext);
    try {
      final response = DioClient().get("/api/service/list",
          queryParameters: {
            "type_id": isUpcomings.value,
            "page": page,
          },
          skipAuth: false);
      selectServiceListResponseModel = SelectServiceListResponseModel.fromJson(await response);
      customLoader.hide();
      if (page == 0) {
        selectServiceList.value = selectServiceListResponseModel.list ?? [];
      } else {
        selectServiceList.addAll(selectServiceListResponseModel.list ?? []);
      }
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/service/list"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}
