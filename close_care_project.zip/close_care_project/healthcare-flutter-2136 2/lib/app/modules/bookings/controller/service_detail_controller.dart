import 'package:intl/intl.dart';

import '../../../../export.dart';
import '../../../service_provider_app/bookings/model/response_model/booking_detail_res_model.dart';
import '../model/booking_service_details_model_response.dart';

class ServiceDetailController extends GetxController {
  var id;
  bool isFromNotification=false;
  final PreferenceManger preferenceManger = Get.put(PreferenceManger());
  SignupResponseModel signUpResponseModel = SignupResponseModel();
  var lat,long;
  var distance;
  getArgs() {
    if (Get.arguments != null) {
      id = Get.arguments["id"];
      isFromNotification= Get.arguments['argIsFromNotification']??false;
    }
  }

  bool center = true;
  @override
  void onInit() {
    getArgs();
    getProfileData();
    super.onInit();
  }
  getProfileData()async{
    preferenceManger.getSavedLoginData().then((value) {
      if (value != null) {
        signUpResponseModel = value;
        print('SingleUpResponseMOdel=====${signUpResponseModel.detail?.latitude}');
        print('SingleUpResponseMOdel=====${signUpResponseModel.detail?.fullName}');
      }
    });
  }
  @override
  void onReady() {
    hitBookingDetailApi();
    super.onReady();
  }

  var selectedFormattedDate = DateFormat("yyyy-MM-dd").format(DateTime.now());
  var selectedFormattedTime = DateFormat("hh:mm a").format(DateTime.now());
  Rx<BookingDetail> bookingServiceDetail = BookingDetail().obs;
  BookingServiceDetailsResponseModel bookingServiceDetailsResponseModel = BookingServiceDetailsResponseModel();

  RxBool isLoading = false.obs;
  hitBookingDetailApi({serviceId}) async {
    isLoading.value = true;
    try {
      final response = DioClient().get("/api/booking/patient-info",
          queryParameters: {
            "id":serviceId?? id,
          },
          skipAuth: false);
      bookingServiceDetailsResponseModel = BookingServiceDetailsResponseModel.fromJson(await response);
      isLoading.value = false;
      bookingServiceDetail.value = bookingServiceDetailsResponseModel.detail!;
      print('bookingServiceDetail.value.latit====+${bookingServiceDetail.value.latitude}');
      if(bookingServiceDetail.value.latitude!='') {
        double dis = haversineDistance(
            double.parse(bookingServiceDetail.value.latitude ?? ""), double.parse(bookingServiceDetail.value.longitude ?? ""), double.parse(signUpResponseModel.detail?.latitude),
            double.parse(signUpResponseModel.detail?.longitude));
        distance = dis.toStringAsFixed(2);
      }
    } catch (e, str) {
      print("aaaaaaa$e\n$str");
      isLoading.value = false;
      Future.error(NetworkExceptions.getDioException(e, str, "api/booking/patient-info"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  hitCancelApi() async {
    customLoader.show(Get.overlayContext!);
    try {
      final response = DioClient().post(
        "/api/booking/change-state",
        queryParameters: {"id": id, "state_id": STATE_CANCELLED},
        skipAuth: false,
      );
      MessageResponseModel messageResponseModel = MessageResponseModel.fromJson(await response);
      hitBookingDetailApi();
      showInSnackBar(message: messageResponseModel.message ?? "");

      customLoader.hide();
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/change-state"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}
