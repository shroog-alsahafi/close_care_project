import 'dart:convert';

import '../../../service_provider_app/bookings/model/response_model/booking_detail_res_model.dart';

BookingServiceDetailsResponseModel bookingServiceDetailsResponseModelFromJson(String str) =>
    BookingServiceDetailsResponseModel.fromJson(json.decode(str));

String bookingServiceDetailsResponseModelToJson(BookingServiceDetailsResponseModel data) => json.encode(data.toJson());

class BookingServiceDetailsResponseModel {
  BookingDetail? detail;
  String? copyrights;

  BookingServiceDetailsResponseModel({
    this.detail,
    this.copyrights,
  });

  BookingServiceDetailsResponseModel copyWith({
    BookingDetail? detail,
    String? copyrights,
  }) =>
      BookingServiceDetailsResponseModel(
        detail: detail ?? this.detail,
        copyrights: copyrights ?? this.copyrights,
      );

  factory BookingServiceDetailsResponseModel.fromJson(Map<String, dynamic> json) => BookingServiceDetailsResponseModel(
        detail: json["detail"] == null ? null : BookingDetail.fromJson(json["detail"]),
        copyrights: json["copyrights"],
      );

  Map<String, dynamic> toJson() => {
        "detail": detail?.toJson(),
        "copyrights": copyrights,
      };
}
