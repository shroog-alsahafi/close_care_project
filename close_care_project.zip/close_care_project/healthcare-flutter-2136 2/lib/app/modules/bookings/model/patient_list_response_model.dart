class PatientListResponseModel {
  List<PatientDataModel>? list;
  Links? lLinks;
  Meta? mMeta;
  dynamic copyrights;

  PatientListResponseModel(
      {this.list, this.lLinks, this.mMeta, this.copyrights});

  PatientListResponseModel.fromJson(Map<String, dynamic> json) {
    if (json['list'] != null) {
      list = <PatientDataModel>[];
      json['list'].forEach((v) {
        list!.add(new PatientDataModel.fromJson(v));
      });
    }
    lLinks = json['_links'] != null ? new Links.fromJson(json['_links']) : null;
    mMeta = json['_meta'] != null ? new Meta.fromJson(json['_meta']) : null;
    copyrights = json['copyrights'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.list != null) {
      data['list'] = this.list!.map((v) => v.toJson()).toList();
    }
    if (this.lLinks != null) {
      data['_links'] = this.lLinks!.toJson();
    }
    if (this.mMeta != null) {
      data['_meta'] = this.mMeta!.toJson();
    }
    data['copyrights'] = this.copyrights;
    return data;
  }
}

class PatientDataModel {
  dynamic id;
  dynamic firstName;
  dynamic lastName;
  dynamic fullName;
  dynamic email;
  dynamic aboutMe;
  dynamic dateOfBirth;
  dynamic gender;
  dynamic contactNo;
  dynamic address;
  dynamic location;
  dynamic latitude;
  dynamic longitude;
  dynamic weight;
  dynamic bloodGroup;
  dynamic countryCode;
  dynamic language;
  dynamic profileFile;
  dynamic tos;
  dynamic roleId;
  dynamic stateId;
  dynamic typeId;
  dynamic otp;
  dynamic otpVerified;
  dynamic isProfileSetup;
  dynamic isApproved;
  dynamic country;
  dynamic avgRating;
  dynamic isNotify;
  dynamic timezone;
  dynamic createdOn;
  dynamic providerDetail;

  PatientDataModel(
      {this.id,
        this.firstName,
        this.lastName,
        this.fullName,
        this.email,
        this.aboutMe,
        this.dateOfBirth,
        this.gender,
        this.contactNo,
        this.address,
        this.location,
        this.latitude,
        this.longitude,
        this.weight,
        this.bloodGroup,
        this.countryCode,
        this.language,
        this.profileFile,
        this.tos,
        this.roleId,
        this.stateId,
        this.typeId,
        this.otp,
        this.otpVerified,
        this.isProfileSetup,
        this.isApproved,
        this.country,
        this.avgRating,
        this.isNotify,
        this.timezone,
        this.createdOn,
        this.providerDetail});

  PatientDataModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    firstName = json['first_name'];
    lastName = json['last_name'];
    fullName = json['full_name'];
    email = json['email'];
    aboutMe = json['about_me'];
    dateOfBirth = json['date_of_birth'];
    gender = json['gender'];
    contactNo = json['contact_no'];
    address = json['address'];
    location = json['location'];
    latitude = json['latitude'];
    longitude = json['longitude'];
    weight = json['weight'];
    bloodGroup = json['blood_group'];
    countryCode = json['country_code'];
    language = json['language'];
    profileFile = json['profile_file'];
    tos = json['tos'];
    roleId = json['role_id'];
    stateId = json['state_id'];
    typeId = json['type_id'];
    otp = json['otp'];
    otpVerified = json['otp_verified'];
    isProfileSetup = json['is_profile_setup'];
    isApproved = json['is_approved'];
    country = json['country'];
    avgRating = json['avg_rating'];
    isNotify = json['is_notify'];
    timezone = json['timezone'];
    createdOn = json['created_on'];
    providerDetail = json['providerDetail'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['full_name'] = this.fullName;
    data['email'] = this.email;
    data['about_me'] = this.aboutMe;
    data['date_of_birth'] = this.dateOfBirth;
    data['gender'] = this.gender;
    data['contact_no'] = this.contactNo;
    data['address'] = this.address;
    data['location'] = this.location;
    data['latitude'] = this.latitude;
    data['longitude'] = this.longitude;
    data['weight'] = this.weight;
    data['blood_group'] = this.bloodGroup;
    data['country_code'] = this.countryCode;
    data['language'] = this.language;
    data['profile_file'] = this.profileFile;
    data['tos'] = this.tos;
    data['role_id'] = this.roleId;
    data['state_id'] = this.stateId;
    data['type_id'] = this.typeId;
    data['otp'] = this.otp;
    data['otp_verified'] = this.otpVerified;
    data['is_profile_setup'] = this.isProfileSetup;
    data['is_approved'] = this.isApproved;
    data['country'] = this.country;
    data['avg_rating'] = this.avgRating;
    data['is_notify'] = this.isNotify;
    data['timezone'] = this.timezone;
    data['created_on'] = this.createdOn;
    data['providerDetail'] = this.providerDetail;
    return data;
  }
}

class Links {
  Self? self;
  Self? first;
  Self? last;

  Links({this.self, this.first, this.last});

  Links.fromJson(Map<String, dynamic> json) {
    self = json['self'] != null ? new Self.fromJson(json['self']) : null;
    first = json['first'] != null ? new Self.fromJson(json['first']) : null;
    last = json['last'] != null ? new Self.fromJson(json['last']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.self != null) {
      data['self'] = this.self!.toJson();
    }
    if (this.first != null) {
      data['first'] = this.first!.toJson();
    }
    if (this.last != null) {
      data['last'] = this.last!.toJson();
    }
    return data;
  }
}

class Self {
  dynamic href;

  Self({this.href});

  Self.fromJson(Map<String, dynamic> json) {
    href = json['href'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['href'] = this.href;
    return data;
  }
}

class Meta {
  dynamic totalCount;
  dynamic pageCount;
  dynamic currentPage;
  dynamic perPage;

  Meta({this.totalCount, this.pageCount, this.currentPage, this.perPage});

  Meta.fromJson(Map<String, dynamic> json) {
    totalCount = json['totalCount'];
    pageCount = json['pageCount'];
    currentPage = json['currentPage'];
    perPage = json['perPage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['totalCount'] = this.totalCount;
    data['pageCount'] = this.pageCount;
    data['currentPage'] = this.currentPage;
    data['perPage'] = this.perPage;
    return data;
  }
}