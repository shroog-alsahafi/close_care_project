// import 'dart:convert';
//
// import '../../../core/model/meta.dart';
//
// RatingListResponseModel ratingListResponseModelFromJson(String str) => RatingListResponseModel.fromJson(json.decode(str));
//
// String ratingListResponseModelToJson(RatingListResponseModel data) => json.encode(data.toJson());
//
// class RatingListResponseModel {
//   List<RatingList>? list;
//   Links? links;
//   Meta? meta;
//   String? copyrights;
//
//   RatingListResponseModel({
//     this.list,
//     this.links,
//     this.meta,
//     this.copyrights,
//   });
//
//   RatingListResponseModel copyWith({
//     List<RatingList>? list,
//     Links? links,
//     Meta? meta,
//     String? copyrights,
//   }) =>
//       RatingListResponseModel(
//         list: list ?? this.list,
//         links: links ?? this.links,
//         meta: meta ?? this.meta,
//         copyrights: copyrights ?? this.copyrights,
//       );
//
//   factory RatingListResponseModel.fromJson(Map<String, dynamic> json) => RatingListResponseModel(
//         list: json["list"] == null ? [] : List<RatingList>.from(json["list"]!.map((x) => RatingList.fromJson(x))),
//         links: json["_links"] == null ? null : Links.fromJson(json["_links"]),
//         meta: json["_meta"] == null ? null : Meta.fromJson(json["_meta"]),
//         copyrights: json["copyrights"],
//       );
//
//   Map<String, dynamic> toJson() => {
//         "list": list == null ? [] : List<dynamic>.from(list!.map((x) => x.toJson())),
//         "_links": links?.toJson(),
//         "_meta": meta?.toJson(),
//         "copyrights": copyrights,
//       };
// }
//
// class RatingList {
//   int? id;
//   int? modelId;
//   String? modelType;
//   double? rating;
//   String? title;
//   String? profile;
//   String? comment;
//   int? stateId;
//   int? typeId;
//   DateTime? createdOn;
//   int? createdById;
//
//   RatingList({
//     this.id,
//     this.modelId,
//     this.modelType,
//     this.rating,
//     this.profile,
//     this.title,
//     this.comment,
//     this.stateId,
//     this.typeId,
//     this.createdOn,
//     this.createdById,
//   });
//
//   RatingList copyWith({
//     int? id,
//     int? modelId,
//     String? modelType,
//     double? rating,
//     String? title,
//     String? profile,
//     String? comment,
//     int? stateId,
//     int? typeId,
//     DateTime? createdOn,
//     int? createdById,
//   }) =>
//       RatingList(
//         id: id ?? this.id,
//         modelId: modelId ?? this.modelId,
//         modelType: modelType ?? this.modelType,
//         rating: rating ?? this.rating,
//         title: title ?? this.title,
//         profile: title ?? this.profile,
//         comment: comment ?? this.comment,
//         stateId: stateId ?? this.stateId,
//         typeId: typeId ?? this.typeId,
//         createdOn: createdOn ?? this.createdOn,
//         createdById: createdById ?? this.createdById,
//       );
//
//   factory RatingList.fromJson(Map<String, dynamic> json) => RatingList(
//         id: json["id"],
//         modelId: json["model_id"],
//         modelType: json["model_type"],
//         rating: json["rating"]?.toDouble(),
//         title: json["title"],
//         profile: json["profile_file"],
//         comment: json["comment"],
//         stateId: json["state_id"],
//         typeId: json["type_id"],
//         createdOn: json["created_on"] == null ? null : DateTime.parse(json["created_on"]),
//         createdById: json["created_by_id"],
//       );
//
//   Map<String, dynamic> toJson() => {
//         "id": id,
//         "model_id": modelId,
//         "model_type": modelType,
//         "rating": rating,
//         "title": title,
//         "profile_file": profile,
//         "comment": comment,
//         "state_id": stateId,
//         "type_id": typeId,
//         "created_on": createdOn?.toIso8601String(),
//         "created_by_id": createdById,
//       };
// }
//
// class Meta {
//   int? totalCount;
//   int? pageCount;
//   int? currentPage;
//   int? perPage;
//
//   Meta({
//     this.totalCount,
//     this.pageCount,
//     this.currentPage,
//     this.perPage,
//   });
//
//   Meta copyWith({
//     int? totalCount,
//     int? pageCount,
//     int? currentPage,
//     int? perPage,
//   }) =>
//       Meta(
//         totalCount: totalCount ?? this.totalCount,
//         pageCount: pageCount ?? this.pageCount,
//         currentPage: currentPage ?? this.currentPage,
//         perPage: perPage ?? this.perPage,
//       );
//
//   factory Meta.fromJson(Map<String, dynamic> json) => Meta(
//         totalCount: json["totalCount"],
//         pageCount: json["pageCount"],
//         currentPage: json["currentPage"],
//         perPage: json["perPage"],
//       );
//
//   Map<String, dynamic> toJson() => {
//         "totalCount": totalCount,
//         "pageCount": pageCount,
//         "currentPage": currentPage,
//         "perPage": perPage,
//       };
// }
