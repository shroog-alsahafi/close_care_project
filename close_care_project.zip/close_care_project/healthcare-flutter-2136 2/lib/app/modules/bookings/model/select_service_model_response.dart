// To parse this JSON data, do
//
//     final selectServiceListResponseModel = selectServiceListResponseModelFromJson(jsonString);

import 'package:meta/meta.dart';
import 'dart:convert';

SelectServiceListResponseModel selectServiceListResponseModelFromJson(String str) => SelectServiceListResponseModel.fromJson(json.decode(str));

String selectServiceListResponseModelToJson(SelectServiceListResponseModel data) => json.encode(data.toJson());

class SelectServiceListResponseModel {
  List<SelectServiceList>? list;
  String? copyrights;

  SelectServiceListResponseModel({
    this.list,
    this.copyrights,
  });

  factory SelectServiceListResponseModel.fromJson(Map<String, dynamic> json) => SelectServiceListResponseModel(
        list: List<SelectServiceList>.from(json["list"].map((x) => SelectServiceList.fromJson(x))),
        copyrights: json["copyrights"],
      );

  Map<String, dynamic> toJson() => {
        "list": List<dynamic>.from(list!.map((x) => x.toJson())),
        "copyrights": copyrights,
      };
}

class SelectServiceList {
  int? id;
  String? title;
  int? stateId;
  String? serviceImage;
  int? typeId;
  DateTime? createdOn;
  int? createdById;
  String? serviceAvgRating;

  SelectServiceList({
    this.id,
    this.title,
    this.stateId,
    this.serviceImage,
    this.typeId,
    this.createdOn,
    this.serviceAvgRating,
    this.createdById,
  });

  factory SelectServiceList.fromJson(Map<String, dynamic> json) => SelectServiceList(
        id: json["id"],
        title: json["title"],
        serviceImage: json["service_image"],
        stateId: json["state_id"],
        typeId: json["type_id"],
        createdOn: DateTime.parse(json["created_on"]),
        serviceAvgRating: double.parse("${json["service_avg_rating"] ?? "0"}").toStringAsFixed(1),
        createdById: json["created_by_id"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "state_id": stateId,
        "service_image": serviceImage,
        "type_id": typeId,
        "created_on": createdOn!.toIso8601String(),
        "service_avg_rating": serviceAvgRating,
        "created_by_id": createdById,
      };
}
