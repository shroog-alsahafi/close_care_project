// To parse this JSON data, do
//
//     final serviceProviderDetailResponseModel = serviceProviderDetailResponseModelFromJson(jsonString);

import 'dart:convert';

import 'package:healthcare/app/modules/authentication/model/response_model/provider_service_res_model.dart';
import '../../authentication/model/data_model/user_details_data_model.dart';
import '../../services/models/data_model/service_provider_response_model.dart';

ServiceProviderDetailResponseModel serviceProviderDetailResponseModelFromJson(String str) =>
    ServiceProviderDetailResponseModel.fromJson(json.decode(str));

String serviceProviderDetailResponseModelToJson(ServiceProviderDetailResponseModel data) => json.encode(data.toJson());

class ServiceProviderDetailResponseModel {
  List<UserDetailDataModel>? list;
  Links? links;
  Meta? meta;
  String? copyrights;

  ServiceProviderDetailResponseModel({
    this.list,
    this.links,
    this.meta,
    this.copyrights,
  });

  factory ServiceProviderDetailResponseModel.fromJson(Map<String, dynamic> json) => ServiceProviderDetailResponseModel(
        list: json["list"] == null ? [] : List<UserDetailDataModel>.from(json["list"]!.map((x) => UserDetailDataModel.fromJson(x))),
        links: json["_links"] == null ? null : Links.fromJson(json["_links"]),
        meta: json["_meta"] == null ? null : Meta.fromJson(json["_meta"]),
        copyrights: json["copyrights"],
      );

  Map<String, dynamic> toJson() => {
        "list": list == null ? [] : List<dynamic>.from(list!.map((x) => x.toJson())),
        "_links": links?.toJson(),
        "_meta": meta?.toJson(),
        "copyrights": copyrights,
      };
}