// To parse this JSON data, do
//
//     final slotListResponseModel = slotListResponseModelFromJson(jsonString);

import 'dart:convert';

SlotListResponseModel slotListResponseModelFromJson(String str) => SlotListResponseModel.fromJson(json.decode(str));

String slotListResponseModelToJson(SlotListResponseModel data) => json.encode(data.toJson());

class SlotListResponseModel {
  List<SlotDataModel>? list;
  String? copyrights;

  SlotListResponseModel({
    this.list,
    this.copyrights,
  });

  factory SlotListResponseModel.fromJson(Map<String, dynamic> json) => SlotListResponseModel(
        list: json["list"] == null ? [] : List<SlotDataModel>.from(json["list"]!.map((x) => SlotDataModel.fromJson(x))),
        copyrights: json["copyrights"],
      );

  Map<String, dynamic> toJson() => {
        "list": list == null ? [] : List<dynamic>.from(list!.map((x) => x.toJson())),
        "copyrights": copyrights,
      };
}

class SlotDataModel {
  DateTime? startTime;
  DateTime? endTime;
  String? dayId;
  bool? typeId;

  SlotDataModel({
    this.startTime,
    this.endTime,
    this.dayId,
    this.typeId,
  });

  factory SlotDataModel.fromJson(Map<String, dynamic> json) => SlotDataModel(
        startTime: json["start_time"] == null ? null : DateTime.parse(json["start_time"]),
        endTime: json["end_time"] == null ? null : DateTime.parse(json["end_time"]),
        dayId: json["day_id"],
        typeId: json["type_id"],
      );

  Map<String, dynamic> toJson() => {
        "start_time": startTime,
        "end_time": endTime,
        "day_id": dayId,
        "type_id": typeId,
      };
}
