import 'package:dotted_border/dotted_border.dart';
import 'package:intl/intl.dart';

import '../../../../export.dart';
import '../../../core/widgets/custom_grid_select_widget.dart';
import '../controller/book_service_controller.dart';

class BookServiceScreen extends GetView<BookServiceController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: CustomAppBar(
          appBarTitleText: keyBookService.tr,
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              textWidget(
                text: keyServicesNeeded.tr,
              ),
              TextFieldWidget(
                shadow: true,
                decoration: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey.shade400), borderRadius: BorderRadius.circular(radius_8)),
                onTap: () {},
                hideBorder: false,
                contentPadding: EdgeInsets.symmetric(vertical: margin_16, horizontal: margin_10),
                color: Colors.white,
                radius: radius_3,
              ).paddingOnly(top: margin_10),
              textWidget(text: keySelectDate.tr),
              monthsListing(context),
              textWidget(text: keySelectReminder.tr),
              _reminder(),
              textWidget(text: keyUploadReports.tr),
              _upload(controller.selectedImages),
              _continueButton()
            ],
          ).paddingSymmetric(
            horizontal: margin_15,
          ),
        ));
  }

  textWidget({text}) {
    return TextView(text: text, textStyle: textStyleBody1()).paddingOnly(top: margin_12, bottom: 0);
  }

  _continueButton() {
    return MaterialButtonWidget(
      buttonColor: colorAppColors,
      padding: margin_14,
      buttonRadius: radius_5,
      buttonText: keyContinue.tr,
      onPressed: () {},
    ).marginSymmetric(
      vertical: margin_30,
    );
  }

  Widget _reminder() {
    return GridView.builder(
        itemCount: 5,
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          mainAxisSpacing: 0,
          crossAxisSpacing: margin_12,
          childAspectRatio: 0.4 / 0.30,
        ),
        itemBuilder: (BuildContext context, int index) {
          var time = DateTime.parse("${DateTime.now()}").toLocal();
          var timeStr = "${DateFormat('h:mm a').format(time)}";

          return GestureDetector(
            onTap: () {
              controller.selectedIndex.value = index;

              controller.update();
            },
            child: Obx(() {
              return MyGridItem(
                text: timeStr,
                isSelected: index == controller.selectedIndex.value,
              );
            }),
          );
        }).paddingSymmetric(vertical: 0);
  }

  monthsListing(context) {
    int daysInMonth = DateUtils.getDaysInMonth(controller.selectedYear?.value ?? DateTime.now().year, controller.selectedMonth?.value ?? DateTime.now().month);

    return SizedBox(
      height: Get.height * .15,
      child: NotificationListener<ScrollNotification>(
        onNotification: (notification) {
          if (notification is ScrollEndNotification) {
            controller.selectedDateIndex.value = notification.metrics.pixels ~/ width_60;
          }
          return true;
        },
        child: ListView.builder(
          controller: controller.scrollController,
          scrollDirection: Axis.horizontal,
          padding: EdgeInsets.zero,
          itemCount: daysInMonth + 2,
          itemBuilder: (context, index) {
            int day = index + 1;
            DateTime date = DateTime(DateTime.now().year, DateTime.now().month, day);
            String weekdayName = DateFormat('EEE').format(date);
            int dayOfWeek = date.weekday;
            return Obx(
              () => GestureDetector(
                  onTap: () {
                    controller.selectedDay.value = day;
                    controller.selectedDateIndex.value = index;
                    controller.selectedFormattedWeekDay = dayOfWeek;
                    controller.selectedFormattedDate = DateFormat("yyyy-MM-dd").format(date);
                  },
                  child: SelectedDate(text: weekdayName, subText: day.toString(), isSelected: index == controller.selectedDateIndex.value)),
            );
          },
        ),
      ),
    );
  }

  _upload(list) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            GestureDetector(
                onTap: () {
                  controller.selectImg();
                },
                child: SizedBox(
                  height: height_80,
                  child: DottedBorder(
                    color: Colors.grey.shade400,
                    dashPattern: [5, 5],
                    borderType: BorderType.RRect,
                    radius: Radius.circular(radius_10),
                    strokeWidth: 1,
                    padding: EdgeInsets.symmetric(vertical: margin_35, horizontal: margin_30),
                    child: AssetImageWidget(imageUrl: iconUploadDocuments),
                  ),
                )),
            SizedBox(width: margin_15),
            Expanded(
              child: Container(
                height: height_95,
                child: Obx(() => list == null
                    ? SizedBox()
                    : ListView.separated(
                        physics: AlwaysScrollableScrollPhysics(),
                        itemCount: list.length,
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Stack(
                            children: [
                              SizedBox(
                                height: height_80,
                                child: DottedBorder(
                                  color: Colors.grey.shade400,
                                  dashPattern: [5, 5],
                                  borderType: BorderType.RRect,
                                  radius: Radius.circular(radius_10),
                                  strokeWidth: 1,
                                  child: list[index].contains("http")
                                      ? NetworkImageWidget(
                                          imageWidth: height_90,
                                          imageHeight: height_90,
                                          radiusAll: radius_10,
                                          imageurl: list[index],
                                        )
                                      : ClipRRect(
                                          borderRadius: BorderRadius.circular(radius_10),
                                          child: Image.file(
                                            File(list[index]),
                                            fit: BoxFit.fill,
                                            height: height_90,
                                            width: height_78,
                                          ),
                                        ),
                                ),
                              ).paddingOnly(top: margin_8),
                              Positioned(
                                  top: margin_2,
                                  right: margin_2,
                                  child: GestureDetector(
                                    onTap: () {
                                      list.removeAt(index);
                                    },
                                    child: AssetImageWidget(
                                      imageUrl: iconCrossed,
                                      imageWidth: width_20,
                                      imageHeight: width_20,
                                    ),
                                  )),
                            ],
                          );
                        },
                        separatorBuilder: (BuildContext context, int index) {
                          return SizedBox(width: width_10);
                        },
                      )),
              ),
            )
          ],
        ),
      ],
    );
  }

  grid() {
    return GridView.builder(
      itemCount: 6,
      physics: NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: height_15, crossAxisSpacing: width_10, childAspectRatio: 3.3),
      itemBuilder: (context, index) {
        return GestureDetector(
            onTap: () {
              controller.selectedTimeIndex.value = index;
            },
            child: Obx(
              () => Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(radius_15), color: controller.selectedTimeIndex.value == index ? colorAppColor : Color.fromRGBO(240, 242, 245, 1.0)),
                  child: TextView(
                    text: "09:00 AM",
                    textStyle: TextStyle(fontSize: font_15, color: controller.selectedTimeIndex.value == index ? Colors.red : Colors.grey.shade400),
                  )),
            ));
      },
    ).marginSymmetric(horizontal: width_15);
  }
}
