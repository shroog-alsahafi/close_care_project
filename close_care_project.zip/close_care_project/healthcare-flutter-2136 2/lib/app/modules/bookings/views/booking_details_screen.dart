import 'dart:math';

import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:healthcare/app/modules/bookings/controller/booking_details_controller.dart';
import 'package:healthcare/app/modules/bookings/views/see_all_ratings_reviews.dart';
import 'package:healthcare/export.dart';
import 'package:intl/intl.dart';

class BookingDetailsScreen extends GetView<BookingDetailsController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: CustomAppBar(),
        body: Obx(() {
          return controller.isLoading.value
              ? Center(
                  child: CircularProgressIndicator(
                    color: colorAppColors,
                  ),
                )
              : SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      NetworkImageWidget(
                        imageurl: controller.servicesProviderList.value.profileFile ?? controller.servicesProviderList.value.providerDetail?.imageFile ?? "",
                        imageWidth: Get.width,
                        imageHeight: height_220,
                      ).paddingOnly(bottom: margin_15),
                      Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Expanded(
                                          child: TextView(
                                            textAlign: TextAlign.start,
                                            text: controller.servicesProviderList.value.fullName.toString().capitalize ?? "",
                                            textStyle: textStyleBody1().copyWith(
                                              fontWeight: FontWeight.w800,
                                              fontSize: font_16,
                                            ),
                                          ),
                                        ),
                                        if (controller.servicesProviderList.value.providerDetail?.providerServices?.length != 0)
                                          Row(
                                            children: [
                                              TextView(
                                                textAlign: TextAlign.start,
                                                maxLine: 1,
                                                text: "\$${controller.servicesProviderList.value.providerDetail?.providerServices?.first.rates}",
                                                textStyle: textStyleBody1().copyWith(
                                                  color: colorAppColor,
                                                  fontWeight: FontWeight.w800,
                                                  fontSize: font_16,
                                                ),
                                              ),
                                            ],
                                          ),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        if (controller.servicesProviderList.value.providerDetail?.providerServices?.length != 0)
                                          Expanded(
                                            child: TextView(
                                              textAlign: TextAlign.start,
                                              text: "${controller.serviceName ?? controller.servicesProviderList.value.providerDetail?.providerServices?.first.title}",
                                              textStyle: textStyleBody1().copyWith(
                                                fontWeight: FontWeight.w500,
                                                fontSize: font_14,
                                              ),
                                            ).paddingSymmetric(vertical: margin_4),
                                          ),
                                        TextView(
                                          maxLine: 1,
                                          textAlign: TextAlign.start,
                                          text: "${keyExperience.tr} :- " + "${controller.servicesProviderList.value.providerDetail?.expYrs ?? "0"} years",
                                          textStyle: textStyleBody1().copyWith(
                                            fontWeight: FontWeight.w500,
                                            fontSize: font_14,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        TextView(
                                          maxLine: 1,
                                          textAlign: TextAlign.start,
                                          text: "${keyDegree.tr}:- " + "${controller.servicesProviderList.value.providerDetail?.degreeName}",
                                          textStyle: textStyleBody1().copyWith(
                                            fontWeight: FontWeight.w500,
                                            fontSize: font_14,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          Divider(
                            height: height_25,
                            color: Colors.grey.shade600,
                          ),
                          TextView(
                            textAlign: TextAlign.start,
                            text: controller.servicesProviderList.value.aboutMe.toString().capitalize!,
                            textStyle: textStyleTitle().copyWith(fontSize: font_11),
                          ),
                          SizedBox(height: height_10),
                          Divider(
                            height: height_0,
                            color: Colors.grey.shade600,
                          ),
                          ratingAndReviews(),
                          _continueButton()
                        ],
                      ).paddingSymmetric(horizontal: margin_10)
                    ],
                  ),
                );
        }));
  }

  _seeAllRow({required String text, required void Function()? onTap, bool showSeeAll = true}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        TextView(
          text: text,
          textStyle: TextStyle(
            fontSize: font_17,
            color: Colors.black,
            fontWeight: FontWeight.w500,
          ),
        ),
        if (showSeeAll)
          GestureDetector(
            onTap: onTap,
            child: TextView(
              text: keySeeAll.tr,
              textStyle: TextStyle(
                  decoration: TextDecoration.underline,
                  color: Colors.transparent,
                  decorationColor: colorAppColors,
                  fontSize: font_14,
                  shadows: [Shadow(color: colorAppColor, offset: Offset(0, -3))],
                  fontWeight: FontWeight.w400),
            ),
          )
      ],
    ).paddingOnly(top: margin_8);
  }

  Widget ratingAndReviews() {
    return Column(
      children: [
        _seeAllRow(
            showSeeAll: controller.ratingList.length < 6 ? false : true,
            text: keyRatingReview.tr,
            onTap: () {
              Get.to(() => SeeAllRatingReviews());
            }),
        controller.ratingList.length == 0
            ? noDataToShow(inputText: keyNoRatingFound.tr).paddingSymmetric(vertical: margin_25)
            : ListView.separated(
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemCount: min(controller.ratingList.length, 5),
                itemBuilder: (context, index) {
                  return Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      NetworkImageWidget(
                        imageurl: controller.ratingList[index].profileFile,
                        imageFitType: BoxFit.cover,
                        imageHeight: height_70,
                        imageWidth: height_70,
                        radiusAll: radius_10,
                      ),
                      Flexible(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: TextView(
                                      textAlign: TextAlign.start,
                                      text: controller.ratingList[index].fullName ?? "",
                                      textStyle: TextStyle(
                                        fontSize: font_15,
                                      )),
                                ),
                                TextView(
                                  text: " ${DateFormat("dd MMM yyyy").format(DateTime.parse(controller.selectedFormattedDate.toString()))}"
                                      "${utcToLocalLatest(controller.ratingList[index].createdOn.toString(), "")}",
                                  textStyle: TextStyle(
                                    fontSize: font_14,
                                    color: Colors.black,
                                  ),
                                ),
                              ],
                            ),
                            _ratings(controller.ratingList[index].rating ?? ""),
                            TextView(
                              textAlign: TextAlign.start,
                              text: controller.ratingList[index].comment ?? "",
                              textStyle: TextStyle(
                                fontSize: font_12,
                                color: Colors.black,
                                fontWeight: FontWeight.w500,
                              ),
                            )
                          ],
                        ).marginOnly(left: width_10),
                      ),
                    ],
                  ).marginSymmetric(horizontal: 0, vertical: height_15);
                },
                separatorBuilder: (BuildContext context, int index) {
                  return Divider(
                    color: Colors.grey.shade700,
                  );
                },
              ).marginOnly(bottom: height_10),
      ],
    );
  }

  _continueButton() {
    return MaterialButtonWidget(
      buttonRadius: radius_5,
      buttonText: keyContinue.tr,
      padding: 15,
      onPressed: () {
        Get.toNamed(
          AppRoutes.selectDateTimeScreenRoute,
          arguments: {"provider_id": controller.providerID,'distance':controller.distance},
        );
      },
    ).paddingOnly(bottom: margin_10);
  }

  Widget _ratings(rating) {
    return RatingBar.builder(
      initialRating: double.parse(rating.toString()),
      minRating: 1,
      direction: Axis.horizontal,
      itemSize: margin_16,
      unratedColor: Colors.grey.shade300,
      itemCount: 5,
      allowHalfRating: true,
      ignoreGestures: true,
      updateOnDrag: false,
      itemBuilder: (context, _) => AssetImageWidget(
        imageUrl: iconsIcStar1,
        imageHeight: margin_5,
        color: Colors.amber.shade600,
      ).paddingSymmetric(horizontal: margin_1, vertical: margin_0),
      onRatingUpdate: (rating) {},
    ).paddingOnly(top: margin_3, bottom: margin_4);
  }
}
