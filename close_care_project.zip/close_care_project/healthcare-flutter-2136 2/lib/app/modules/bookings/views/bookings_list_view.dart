import 'package:healthcare/export.dart';

import '../../../core/widgets/booking_list_widget.dart';
import '../../../service_provider_app/Home/views/home_screen_provider.dart';
import '../controller/bookings_view_list_controller.dart';

class BookingsView extends GetView<BookingsViewController> {
  final controller = Get.put(BookingsViewController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        centerTitle: true,
        appBarTitleText: keyBookings.tr,
      ),
      body: _bodyWidget(context),
    );
  }

  _bodyWidget(BuildContext context) => Padding(
        padding: EdgeInsets.symmetric(horizontal: margin_15),
        child: Column(mainAxisAlignment: MainAxisAlignment.start, children: [
          _tabsView(),
          SizedBox(height: height_8),
          Expanded(
            child: Obx(() {
              return controller.isLoading.value
                  ? Center(child: CircularProgressIndicator(color: colorAppColors))
                  : controller.servicesProviderList.isNotEmpty
                      ? RefreshIndicator(
                          onRefresh: () async {
                            controller.page = 0;
                            controller.hitBookingListApi();
                          },
                          child: ListView.separated(
                            controller: controller.scrollController,
                            itemCount: controller.servicesProviderList.length,
                            padding: EdgeInsets.only(bottom: margin_30),
                            itemBuilder: (BuildContext context, int index) {
                              return GestureDetector(
                                onTap: () {
                                  Get.toNamed(
                                    AppRoutes.serviceDetail,
                                    arguments: {"id": controller.servicesProviderList[index].id},
                                  );
                                },
                                child: BookingListWidget(
                                  itemIndex: index,
                                  iconWidget: true,
                                  actionWidget: Column(
                                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                                    children: [
                                      Container(
                                        padding: EdgeInsets.symmetric(vertical: margin_3, horizontal: margin_8),
                                        margin: EdgeInsets.symmetric(horizontal: margin_8, vertical: margin_10),
                                        decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(radius_5),
                                            color: statusTextColor(stateId: controller.servicesProviderList[index].stateId)),
                                        child: TextView(
                                          text: statusTxt(stateId: controller.servicesProviderList[index].stateId),
                                          textStyle: textStyleBody1().copyWith(fontSize: font_12, color: Colors.white),
                                        ),
                                      ),
                                      controller.servicesProviderList[index].stateId == STATE_ACCEPTED
                                          ? GestureDetector(
                                              onTap: () async {
                                                var result = await Get.toNamed(AppRoutes.msgChatScreen, arguments: {
                                                  "toId": controller.servicesProviderList[index].providerId,
                                                  "toName": controller.servicesProviderList[index].providerFullName,
                                                  "toProfile": controller.servicesProviderList[index].providerProfile,
                                                  "bookingId": controller.servicesProviderList[index].id,
                                                });
                                                if (result) {
                                                  controller.hitBookingListApi();
                                                }
                                              },
                                              child: msgWithIndicator(showIndicator: controller.servicesProviderList[index].isMsg),
                                            )
                                          : SizedBox()
                                    ],
                                  ),
                                ),
                              );
                            },
                            separatorBuilder: (BuildContext context, int index) {
                              return SizedBox();
                            },
                          ),
                        )
                      : noDataToShow();
            }),
          ),
        ]),
      );
  _tabsView() {
    return Obx(
      () => Row(
        children: [
          Expanded(
            child: InkWell(
              onTap: () {
                if (controller.isUpcomings.value != 1) {
                  controller.page = 0;
                  controller.isUpcomings.value = 1;
                  controller.hitBookingListApi();
                }
              },
              child: Container(
                padding: EdgeInsets.symmetric(vertical: margin_15),
                child: TextView(
                  text: keyOnGoing.tr,
                  textStyle: textStyleHeading2().copyWith(
                    fontSize: font_15,
                    color: controller.isUpcomings.value == 1 ? Colors.white : Colors.black,
                  ),
                ),
                decoration: BoxDecoration(
                  color: controller.isUpcomings.value == 1 ? colorAppColors : colorAppColors.withOpacity(.2),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(radius_5),
                    bottomLeft: Radius.circular(radius_5),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: InkWell(
              onTap: () {
                if (controller.isUpcomings.value != 3) {
                  controller.page = 0;
                  controller.isUpcomings.value = 3;
                  controller.hitBookingListApi();
                }
              },
              child: Container(
                padding: EdgeInsets.symmetric(vertical: margin_15),
                child: TextView(
                  text: keyPast.tr,
                  textStyle: textStyleHeading2().copyWith(
                    fontSize: font_15,
                    color: controller.isUpcomings.value == 3 ? Colors.white : Colors.black,
                  ),
                ),
                decoration: BoxDecoration(
                  color: controller.isUpcomings.value == 3 ? colorAppColors : colorAppColors.withOpacity(.2),
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(radius_5),
                    bottomRight: Radius.circular(radius_5),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget commonListTitle({required leadingImg, userName, serviceName, subtitle, textClr, Widget? trailingWidget}) => Row(
        children: [
          AssetImageWidget(
            imageUrl: leadingImg,
            imageWidth: height_60,
            imageHeight: height_60,
            imageFitType: BoxFit.cover,
            radiusAll: radius_10,
          ),
          SizedBox(
            width: width_10,
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextView(
                    text: serviceName ?? "",
                    textStyle: textStyleTitle().copyWith(fontSize: font_15, fontWeight: FontWeight.bold, color: textClr ?? Colors.grey)),
                TextView(
                    text: userName ?? "",
                    textStyle: textStyleTitle().copyWith(fontSize: font_14, fontWeight: FontWeight.normal, color: Colors.black)),
                IntrinsicHeight(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.lock_clock,
                        color: colorAppColor,
                        size: height_18,
                      ),
                      SizedBox(
                        width: width_2,
                      ),
                      TextView(
                        text: subtitle ?? "",
                        textStyle: textStyleTitle().copyWith(
                          fontSize: font_12,
                          color: textClr ?? Colors.black,
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
          IntrinsicHeight(
            child: Container(
              height: double.infinity,
              width: 35,
              decoration: BoxDecoration(
                  color: colorAppColor, borderRadius: BorderRadius.only(topRight: Radius.circular(15), bottomRight: Radius.circular(15))),
              child: Icon(Icons.arrow_forward_ios_rounded, size: 18, color: colorWhite),
            ),
          )
        ],
      );
}
