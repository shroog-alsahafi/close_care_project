import 'package:healthcare/app/modules/bookings/controller/booking_details_controller.dart';
import 'package:healthcare/app/modules/bookings/controller/confirm_booking_controller.dart';
import 'package:intl/intl.dart';

import '../../../../export.dart';
import '../controller/select_date_time_controller.dart';

class ConfirmBookingScreen extends GetView<ConfirmBookingController> {
  final bookingDetailsController = Get.find<BookingDetailsController>();
  final selectedTimeController = Get.find<SelectDateTimeController>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        centerTitle: true,
        appBarTitleText: "${keyConfirmBooking.tr}",
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: height_15,
          ),
          Container(
            padding: EdgeInsets.all(margin_10),
            decoration: BoxDecoration(color: greyColor, borderRadius: BorderRadius.circular(radius_8)),
            child: commonListTitle(
                leadingImg: bookingDetailsController.servicesProviderList.value.profileFile,
                serviceName: bookingDetailsController.servicesProviderList.value.fullName.toString().capitalize ?? "",
                userName: bookingDetailsController.serviceName ?? bookingDetailsController.selectedServiceList.first.title,
                subtitle:'${(controller.distance)}',
                textClr: Colors.black,
                imgHeight: height_70,
                trailingWidget: SizedBox()),
          ),
          SizedBox(
            height: height_15,
          ),
          _iconTextView(text: bookingDetailsController.servicesProviderList.value.location.toString().capitalize ?? "", icon: Icons.location_on_rounded),
          TextView(
              text: "${keyServiceProvider.tr} : ${bookingDetailsController.servicesProviderList.value.fullName.toString().capitalize ?? ""}",
              textStyle: textStyleBodyMedium().copyWith(
                fontWeight: FontWeight.w500,
                color: Colors.black,
              )),
          TextView(
              text: "${keyDateAndTime.tr} : ${DateFormat("dd MMM yyyy").format(DateTime.parse(selectedTimeController.selectedFormattedDate.toString()))}"
                  " (${utcToLocalLatest(selectedTimeController.slotsList[int.parse(selectedTimeController.selectedTimeIndex.value)].startTime.toString(), "hh:mm a")})",
              textStyle: textStyleBodyMedium().copyWith(
                fontWeight: FontWeight.w500,
                color: Colors.black,
              )),
          SizedBox(height: height_8),
          Divider(
            color: Colors.grey.shade300,
            height: height_13,
          ),
          titleTxt(title: "${keyPriceSummery.tr}"),
          Container(
            padding: EdgeInsets.symmetric(vertical: margin_15, horizontal: margin_10),
            decoration: BoxDecoration(color: greyColor, borderRadius: BorderRadius.circular(radius_10)),
            child: Column(
              children: [
                customRow(title: "${keyServiceFee.tr}", value: "\$${bookingDetailsController.servicesProviderList.value.providerDetail?.providerServices?.first.rates ?? ""}"),
                SizedBox(
                  height: height_2,
                ),
                customRow(title: "${keyBookingFee.tr}", value: "\$${bookingDetailsController.servicesProviderList.value.providerDetail?.providerServices?.first.commissionPrice}"),
                Divider(
                  color: Colors.grey,
                  height: height_12,
                  thickness: 1,
                ),
                customRow(
                    title: "${keyTotalPrice.tr}",
                    value:
                        "\$${double.parse(bookingDetailsController.servicesProviderList.value.providerDetail?.providerServices!.first.rates ?? "0") + double.parse(bookingDetailsController.servicesProviderList.value.providerDetail?.providerServices!.first.commissionPrice ?? "0")}"),
              ],
            ),
          ),
          SizedBox(height: height_10),
          SizedBox(height: height_25),
          _bookNowBtn(),
        ],
      ).paddingSymmetric(horizontal: margin_15),
    );
  }

  _bookNowBtn() => MaterialButtonWidget(
        onPressed: () {
          controller.hitAddBookingApi();
          // controller.makePayment();
        },
        buttonRadius: radius_5,
        buttonText: keyBookNow.tr,
        padding: height_12,
      );

  Widget customRow({title, value}) => Row(
        children: [
          TextView(
            text: "${title ?? ""}",
            textStyle: textStyleTitle().copyWith(
              color: Colors.black,
              fontWeight: FontWeight.w500,
            ),
          ),
          Spacer(),
          TextView(
            text: "${value ?? ""}",
            textStyle: textStyleTitle().copyWith(
              color: Colors.black,
            ),
          ),
        ],
      ).paddingSymmetric(horizontal: margin_5, vertical: margin_3);

  _iconTextView({IconData? icon, text, enableUnderline = false}) {
    return RichText(
        maxLines: 1,
        textAlign: TextAlign.start,
        text: TextSpan(children: [
          WidgetSpan(
              child: Icon(
            icon,
            color: colorAppColors,
            size: font_20,
          ).paddingOnly(right: margin_8)),
          TextSpan(
            text: text ?? "",
            style: enableUnderline == false
                ? textStyleBodyMedium().copyWith(color: Colors.black)
                : textStyleBodyMedium().copyWith(
                    decoration: TextDecoration.underline,
                    decorationColor: colorAppColors,
                    color: colorAppColors,
                  ),
          )
        ])).paddingOnly(bottom: margin_3);
  }

  Widget commonListTitle({required leadingImg, imgHeight, userName, serviceName, subtitle, textClr, Widget? trailingWidget}) => Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          NetworkImageWidget(
            imageurl: leadingImg,
            imageWidth: imgHeight ?? height_50,
            imageHeight: imgHeight ?? height_50,
            imageFitType: BoxFit.cover,
            radiusAll: radius_10,
          ),
          SizedBox(
            width: width_15,
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextView(
                  text: serviceName ?? "",
                  textStyle: textStyleTitle().copyWith(
                    fontSize: font_15,
                    fontWeight: FontWeight.w600,
                    color: textClr ?? Colors.black,
                  ),
                ),
                TextView(
                  textAlign: TextAlign.start,
                  text: userName ?? "",
                  textStyle: textStyleTitle().copyWith(
                    fontSize: font_13,
                    fontWeight: FontWeight.w500,
                    color: textClr ?? Colors.black,
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.location_on,
                      color: colorAppColor,
                      size: height_15,
                    ),
                    SizedBox(
                      width: width_2,
                    ),
                    TextView(
                      text: subtitle ?? "",
                      textStyle: textStyleTitle().copyWith(
                        fontSize: font_14,
                        fontWeight: FontWeight.w600,
                        color: textClr ?? Colors.black,
                      ),
                    ),
                    SizedBox(
                      width: width_15,
                    ),
                    ratingsView(rating: bookingDetailsController.servicesProviderList.value.avgRating),
                    SizedBox(
                      width: width_2,
                    ),
                    TextView(
                      text: bookingDetailsController.servicesProviderList.value.avgRating ?? "",
                      textStyle: textStyleTitle().copyWith(
                        fontSize: font_14,
                        fontWeight: FontWeight.w600,
                        color: textClr ?? Colors.black,
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
          trailingWidget ??
              Icon(
                Icons.navigate_next,
                color: Colors.black,
              ),
        ],
      );
}
