import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import '../../../../export.dart';
import '../controller/bookings_view_list_controller.dart';
import '../controller/give_rating_controller.dart';
import '../controller/service_detail_controller.dart';

class GiveRatingScreen extends GetView<GiveRatingController> {
  final serviceDetailController = Get.find<ServiceDetailController>();
  final bookingViewController = Get.find<BookingsViewController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        centerTitle: true,
        appBarTitleText: keyGiveRatings.tr,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Center(
                child: NetworkImageWidget(
              imageurl:  serviceDetailController.bookingServiceDetail.value.createdBy?.profileFile?? controller.image ?? "",
              imageFitType: BoxFit.cover,
              imageHeight: height_80,
              radiusAll: radius_8,
              imageWidth: height_80,
            )).paddingOnly(top: margin_20, bottom: margin_15),
            TextView(text: serviceDetailController.bookingServiceDetail.value.createdBy?.fullName?? "", textStyle: textStyleBody1().copyWith(fontSize: font_15)),
            TextView(
                    text: "${keyHowExperience.tr}\n ${bookingViewController.servicesProviderList[0].providerFullName ?? ""}",
                    textStyle: textStyleBody1().copyWith(fontSize: font_14, fontWeight: FontWeight.w500))
                .paddingOnly(top: margin_5, bottom: margin_20),
            _ratings(controller.rating.value),
            _review(),
          ],
        ),
      ),
    );
  }

  Widget _ratings(rating) {
    return RatingBar.builder(
      initialRating: rating,
      minRating: 1,
      direction: Axis.horizontal,
      itemSize: margin_30,
      unratedColor: Colors.grey.shade300,
      itemCount: 5,
      allowHalfRating: true,
      updateOnDrag: false,
      itemBuilder: (context, _) => AssetImageWidget(
        imageUrl: iconsIcStar1,
        color: Colors.amber.shade600,
      ),
      onRatingUpdate: (rating) {
        controller.rating.value = rating;
        controller.update();
        print("object $rating");
      },
    ).paddingOnly(top: margin_3, bottom: margin_4);
  }

  _review() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Divider(
          color: Colors.grey.shade400,
          height: height_50,
          thickness: 1,
        ),
        TextView(text: keyWriteAReview.tr, textStyle: textStyleBody1()).paddingOnly(bottom: margin_15),
        Form(
          key: controller.formGlobalKey,
          child: TextFieldWidget(
              textController: controller.reviewController,
              contentPadding: EdgeInsets.symmetric(vertical: margin_15, horizontal: margin_10),
              radius: radius_7,
              inputType: TextInputType.text,
              maxline: 5,
              minLine: 4,
              color: greyColor,
              hint: keyWriteReviewHere.tr,
              hintStyle: textStyleBody1().copyWith(color: Colors.grey.shade600, fontSize: font_13, fontWeight: FontWeight.w400),
              inputAction: TextInputAction.next,
              validate: (value) => FieldChecker.fieldChecker(value: value, message: keyReview.tr)).paddingOnly(
            bottom: margin_14,
          ),
        ),
        _submitButton()
      ],
    ).paddingSymmetric(horizontal: margin_12);
  }

  _submitButton() {
    return MaterialButtonWidget(
      buttonRadius: radius_5,
      buttonText: keySubmit.tr,
      padding: 15,
      onPressed: () {
        if (controller.formGlobalKey.currentState!.validate()) {
          controller.hitAddRatingApi();
        }
      },
    ).paddingSymmetric(vertical: margin_25);
  }
}
