import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:healthcare/app/modules/ratings_reviews/controller/ratings_reviews_controller.dart';
import 'package:healthcare/export.dart';
import 'package:intl/intl.dart';

import '../controller/booking_details_controller.dart';

class SeeAllRatingReviews extends GetView<BookingDetailsController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        centerTitle: true,
        appBarTitleText: keyRatingReview.tr,
      ),
      body: _ratingsListing(),
    );
  }

  _bodyView() {
    return ListView(
      padding: EdgeInsets.symmetric(horizontal: margin_15),
      children: [
        // _viewDetail(),
        _ratingsListing(),
      ],
    );
  }

  _ratingsListing() {
    return Obx(() => ListView.separated(
          padding: EdgeInsets.symmetric(horizontal: margin_15),
          itemCount: controller.ratingList.length,
          itemBuilder: (context, index) {
            var rating = controller.ratingList[index];
            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                NetworkImageWidget(
                  imageurl: controller.ratingList[index].profileFile ?? '',
                  imageHeight: height_60,
                  radiusAll: radius_30,
                  imageWidth: height_60,
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: TextView(
                                textAlign: TextAlign.start,
                                text: controller.ratingList[index].fullName.toString().capitalizeFirst ?? "",
                                textStyle: textStyleBodyMedium().copyWith(color: Colors.black, fontSize: font_13)),
                          ),
                          TextView(
                            text: "${utcToLocalLatest(controller.ratingList[index].createdOn.toString(), "dd MMM yyyy")}",
                            textStyle: TextStyle(
                              fontSize: font_14,
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                      controller.ratingList[index].rating.toString() == ''
                          ? SizedBox()
                          : _ratings(double.parse(controller.ratingList[index].rating.toString())),
                      SizedBox(
                        width: Get.width * .7,
                        child: TextView(
                            text: controller.ratingList[index].comment ?? '',
                            maxLine: 10,
                            textAlign: TextAlign.start,
                            textStyle: textStyleBodyMedium().copyWith(color: Colors.black, fontSize: font_12, fontWeight: FontWeight.w400)),
                      ),
                    ],
                  ).paddingOnly(left: margin_10),
                )
              ],
            ).paddingOnly(top: margin_15);
          },
          separatorBuilder: (BuildContext context, int index) {
            return Divider(
              color: Colors.grey.shade700,
              height: height_25,
            );
          },
        ));
  }

  ratingView() {
    return Expanded(
      flex: 3,
      child: Column(
        children: [
          ratingBarView(text: '5', value: 0.0),
          ratingBarView(text: '4', value: 0.8),
          ratingBarView(text: '3', value: 0.7),
          ratingBarView(text: '2', value: 0.5),
          ratingBarView(text: '1', value: 0.0),
        ],
      ),
    );
  }

  ratingBarView({text, value}) {
    return Row(
      children: [
        Text(
          text ?? "",
          style: textStyleBodySmall().copyWith(color: Colors.grey.shade600),
        ).paddingOnly(right: margin_5),
        AssetImageWidget(
          imageUrl: iconsIcStar1,
          imageHeight: height_10,
        ).paddingSymmetric(horizontal: margin_5),
        Expanded(
          child: LinearProgressIndicator(
            valueColor: AlwaysStoppedAnimation(colorAppColors),
            borderRadius: BorderRadius.circular(radius_5),
            backgroundColor: Colors.black,
            value: value ?? 1.0,
          ),
        ),
      ],
    ).paddingSymmetric(vertical: margin_1);
  }

  _viewDetail() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: margin_10, horizontal: margin_1),
      padding: EdgeInsets.symmetric(horizontal: margin_10, vertical: margin_10),
      decoration: BoxDecoration(
          color: colorGrey, borderRadius: BorderRadius.circular(radius_10), boxShadow: [BoxShadow(color: Colors.grey.shade400, blurRadius: 2.0)]),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _overallSection(),
          Expanded(
            child: Container(
                height: height_60,
                width: width_10,
                child: VerticalDivider(
                  thickness: width_3,
                  color: Colors.grey.shade200,
                  width: width_10,
                )),
          ),
          ratingView()
        ],
      ),
    ).paddingOnly(bottom: margin_12);
  }

  _overallSection() {
    return Expanded(
      flex: 3,
      child: Column(
        children: [
          Text(
            "3.0",
            style: textStyleHeading2().copyWith(color: Colors.white),
          ).paddingOnly(bottom: margin_2),
          _ratings(2.0),
          Text(
            textAlign: TextAlign.center,
            '25,455 Ratings & \n332 Reviews',
            style: textStyleBodySmall().copyWith().copyWith(fontSize: font_10, color: Colors.white),
          )
        ],
      ),
    );
  }

  Widget _ratings(rating) {
    return RatingBar.builder(
      initialRating: rating,
      minRating: 1,
      direction: Axis.horizontal,
      allowHalfRating: true,
      ignoreGestures: true,
      itemSize: margin_16,
      unratedColor: Colors.grey.shade300,
      itemCount: 5,
      updateOnDrag: false,
      itemBuilder: (context, _) => AssetImageWidget(
        imageUrl: iconsIcStar1,
        imageHeight: margin_5,
        color: Colors.amber.shade600,
      ).paddingSymmetric(horizontal: margin_1, vertical: margin_0),
      onRatingUpdate: (rating) {
        print(rating);
      },
    ).paddingOnly(top: margin_3, bottom: margin_4);
  }
}
