import 'package:dotted_border/dotted_border.dart';
import 'package:healthcare/app/modules/bookings/controller/booking_details_controller.dart';
import 'package:healthcare/app/modules/bookings/controller/select_date_time_controller.dart';
import 'package:healthcare/export.dart';
import 'package:intl/intl.dart';

import '../../authentication/model/response_model/provider_service_res_model.dart';

class SelectDateTimeScreen extends GetView<SelectDateTimeController> {
  int? selectedMonth, selectedYear;
  String formattedDate = DateFormat('MMM yyyy').format(DateTime.now());
  final controller = Get.put(SelectDateTimeController());
  final bookingController = Get.find<BookingDetailsController>();

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
        init: SelectDateTimeController(),
        builder: (controller) {
          return Scaffold(
            backgroundColor: Colors.white,
            appBar: CustomAppBar(
              appBarTitleText: keyBookService.tr,
              centerTitle: true,
            ),
            body: _bodyView(context),
          );
        });
  }

  _bodyView(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _serviceDropDown(title: keyServicesNeeded.tr, list: bookingController.serviceList, selectedList: bookingController.selectedServiceList, forDegree: true),
          GestureDetector(
            onTap: () async {
              var selectedDate;
              selectedDate = await showDatePicker(
                context: context,
                initialDate: controller.selectedDate ?? DateTime.now(),
                firstDate: DateTime.now(),
                lastDate: DateTime(2030),
              );
              controller.selectedDate = selectedDate;
              selectedMonth = selectedDate!.month;
              selectedYear = selectedDate!.year;
              controller.formattedDate.value = DateFormat('MMM yyyy').format(selectedDate!);
              controller.update();
            },
            child: Row(
              children: [
                textWidget(text: keySelectDate.tr),
                Icon(
                  Icons.keyboard_arrow_down_outlined,
                  color: Colors.white,
                ),
              ],
            ),
          ),
          _monthsListing(),
          textWidget(text: keySelectTime.tr),
          _gridView(),
          textWidget(text: keyUploadReports.tr),
          _upload(controller.selectedImages),
          controller.slotsList.length == 0 ? SizedBox() : _continueButton()
        ],
      ).paddingSymmetric(horizontal: margin_15, vertical: margin_10),
    );
  }

  _serviceDropDown({
    required String title,
    required RxList<ProviderServiceList> list,
    required RxList<ProviderServiceList> selectedList,
    bool forDegree = false,
  }) =>
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          textWidget(text: title),
          GestureDetector(
            onTap: () {
              _openDialog(list: list, selectedList: selectedList, forDegree: forDegree);
            },
            child: Container(
              padding: EdgeInsets.all(margin_3),
              margin: EdgeInsets.only(bottom: margin_10, top: margin_10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(radius_10),
                border: Border.all(color: Colors.grey.shade300),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                      child: SizedBox(
                    height: height_20,
                    child: Obx(
                      () => ListView.builder(
                          itemCount: selectedList.length,
                          scrollDirection: Axis.horizontal,
                          itemBuilder: (context, index) {
                            var service = selectedList[index];
                            return Container(
                              margin: EdgeInsets.symmetric(horizontal: margin_4),
                              padding: EdgeInsets.symmetric(horizontal: margin_5),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                border: Border.all(color: colorAppColors),
                                borderRadius: BorderRadius.circular(radius_8),
                              ),
                              child: TextView(
                                text: service.title ?? "",
                                textStyle: textStyleBody1().copyWith(fontSize: font_10),
                              ),
                            );
                          }),
                    ),
                  )),
                  SizedBox(),
                  IconButton(
                      onPressed: () {
                        _openDialog(list: list, selectedList: selectedList, forDegree: forDegree);
                      },
                      icon: Icon(Icons.keyboard_arrow_down)),
                ],
              ),
            ),
          ),
        ],
      );

  _openDialog({
    required RxList<ProviderServiceList> list,
    required RxList<ProviderServiceList> selectedList,
    bool forDegree = false,
  }) =>
      Get.dialog(Column(
        children: [
          Container(
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(radius_15)),
            margin: EdgeInsets.symmetric(horizontal: Get.width * 0.1, vertical: Get.height * 0.2),
            padding: EdgeInsets.all(margin_20),
            child: Obx(
              () => ConstrainedBox(
                constraints: BoxConstraints(maxHeight: Get.height * .8, minHeight: Get.height * .1),
                child: ListView.builder(
                    itemCount: list.length,
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      var service = list[index];
                      return RadioListTile(
                        contentPadding: EdgeInsets.zero,
                        value: forDegree == true ? (bookingController.selectedService.value == index.toString() ? true : false) : (service.selectedValue),
                        toggleable: true,
                        groupValue: service.groupValue,
                        onChanged: (val) {
                          if (!forDegree) {
                            service.selectedValue = !service.selectedValue!;
                            if (service.selectedValue == true) {
                              if (!selectedList.contains(service)) {
                                selectedList.add(service);
                              }
                            } else {
                              if (selectedList.contains(service)) {
                                selectedList.remove(service);
                              }
                            }
                            list.refresh();
                          } else {
                            bookingController.selectedService.value = index.toString();

                            service.selectedValue = !service.selectedValue!;

                            selectedList.clear();
                            if (!selectedList.contains(service)) {
                              selectedList.add(service);
                            }
                            list.refresh();
                          }
                        },
                        title: TextView(textAlign: TextAlign.start, text: service.title ?? "", textStyle: textStyleBody1()),
                      );
                    }),
              ),
            ),
          ),
        ],
      ));

  textWidget({text}) {
    return TextView(text: text, textStyle: textStyleBody1()).paddingOnly(top: margin_12, bottom: 0);
  }

  _upload(list) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            GestureDetector(
                onTap: () {
                  controller.selectImg();
                },
                child: SizedBox(
                  height: height_80,
                  width: height_80,
                  child: DottedBorder(
                    color: Colors.grey.shade400,
                    dashPattern: [5, 5],
                    borderType: BorderType.RRect,
                    radius: Radius.circular(radius_10),
                    strokeWidth: 1,
                    padding: EdgeInsets.all(margin_25),
                    child: AssetImageWidget(imageUrl: iconUploadDocuments),
                  ),
                )),
            SizedBox(width: margin_15),
            Expanded(
              child: Container(
                height: height_95,
                child: Obx(() => list == null
                    ? SizedBox()
                    : ListView.separated(
                        physics: AlwaysScrollableScrollPhysics(),
                        itemCount: list.length,
                        shrinkWrap: true,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          return Stack(
                            children: [
                              SizedBox(
                                height: height_80,
                                child: DottedBorder(
                                  color: Colors.grey.shade400,
                                  dashPattern: [5, 5],
                                  borderType: BorderType.RRect,
                                  radius: Radius.circular(radius_10),
                                  strokeWidth: 1,
                                  child: list[index].contains("http")
                                      ? NetworkImageWidget(
                                          imageWidth: height_90,
                                          imageHeight: height_90,
                                          radiusAll: radius_10,
                                          imageurl: list[index],
                                        )
                                      : ClipRRect(
                                          borderRadius: BorderRadius.circular(radius_10),
                                          child: Image.file(
                                            File(list[index]),
                                            fit: BoxFit.fill,
                                            height: height_90,
                                            width: height_78,
                                          ),
                                        ),
                                ),
                              ).paddingOnly(top: margin_8),
                              Positioned(
                                  top: margin_2,
                                  right: margin_2,
                                  child: GestureDetector(
                                    onTap: () {
                                      list.removeAt(index);
                                    },
                                    child: AssetImageWidget(
                                      imageUrl: iconCrossed,
                                      imageWidth: width_20,
                                      imageHeight: width_20,
                                    ),
                                  )),
                            ],
                          );
                        },
                        separatorBuilder: (BuildContext context, int index) {
                          return SizedBox(width: width_10);
                        },
                      )),
              ),
            )
          ],
        ),
      ],
    );
  }

  _monthsListing() {
    int daysInMonth = DateUtils.getDaysInMonth(
      controller.selectedYear?.value ?? DateTime.now().year,
      controller.selectedMonth?.value ?? DateTime.now().month,
    );

    return SizedBox(
      height: height_95,
      child: ListView.builder(
        controller: controller.scrollController,
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.zero,
        itemCount: daysInMonth,
        itemBuilder: (context, index) {
          int day = index + 1;
          DateTime date = DateTime(selectedYear ?? DateTime.now().year, selectedMonth ?? DateTime.now().month, day);
          String weekdayName = DateFormat('EEE').format(date);
          int dayOfWeek = date.weekday;
          return Obx(
            () => GestureDetector(
              onTap: () {
                controller.selectedDay.value = day;
                controller.selectedFormattedWeekDay = dayOfWeek;
                controller.selectedFormattedDate = DateFormat("yyyy-MM-dd").format(date);
                controller.serviceSlotsListing();
              },
              child: Container(
                alignment: Alignment.center,
                width: width_60,
                height: height_95,
                decoration: BoxDecoration(
                  color: controller.selectedDay.value != day ? Colors.white : colorAppColor,
                  border: Border.all(
                    color: controller.selectedDay.value != day ? colorAppColor : Colors.white,
                  ),
                  borderRadius: BorderRadius.circular(radius_10),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextView(
                      textAlign: TextAlign.start,
                      text: weekdayName,
                      textStyle: textStyleBodyMedium().copyWith(
                        color: controller.selectedDay.value != day ? colorAppColor : Colors.white,
                        fontSize: font_12,
                      ),
                    ),
                    SizedBox(height: margin_5),
                    TextView(
                      textAlign: TextAlign.start,
                      text: day.toString(),
                      textStyle: textStyleTitle().copyWith(
                        color: controller.selectedDay.value != day ? colorAppColor : Colors.white,
                        fontSize: font_16,
                      ),
                    ),
                  ],
                ),
              ).paddingSymmetric(horizontal: margin_5, vertical: margin_15),
            ),
          );
        },
      ),
    );
  }

  _gridView() {
    return controller.slotsList.length == 0
        ? noDataToShow(
            inputText: keyNoAvailabilityAddedByProvider.tr,
            color: Colors.grey.shade400,
          ).paddingSymmetric(vertical: margin_15)
        : GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4,
              childAspectRatio: 2 / 1,
            ),
            itemCount: controller.slotsList.length,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemBuilder: (context, int index) {
              var slot = controller.slotsList[index];
              return InkWell(
                splashColor: Colors.transparent,
                onTap: () {
                  if (slot.typeId == true) {
                    controller.selectedTimeIndex.value = index.toString();
                    controller.update();
                  }
                },
                child: Container(
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(radius_10),
                      color: slot.typeId == false
                          ? Colors.red.shade200
                          : controller.selectedTimeIndex.value == index.toString()
                              ? colorAppColors
                              : greyColor),
                  child: TextView(
                    text: utcToLocalLatest(slot.startTime!.toString(), "hh:mm a"),
                    textStyle: textStyleBodyMedium().copyWith(
                      fontSize: font_12,
                      color: slot.typeId == false
                          ? Colors.black26
                          : controller.selectedTimeIndex.value == index.toString()
                              ? Colors.white
                              : Colors.black,
                    ),
                  ),
                ).paddingAll(margin_5),
              );
            });
  }

  _continueButton() {
    return MaterialButtonWidget(
      buttonColor: colorAppColors,
      padding: margin_14,
      buttonRadius: radius_5,
      buttonText: keyContinue.tr,
      onPressed: () {
        if (bookingController.selectedServiceList.length == 0) {
          toast(keySelectService.tr);
        } else if (controller.selectedTimeIndex.value == "") {
          toast(keySelectDateAndTime.tr);
        } else {
          Get.toNamed(AppRoutes.confirmBookingScreenRoute,arguments: {'distance':controller.distance});
        }
      },
    ).marginSymmetric(
      vertical: margin_30,
    );
  }
}
