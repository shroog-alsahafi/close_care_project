import 'package:healthcare/app/core/widgets/common_widget.dart';
import 'package:healthcare/app/modules/bookings/controller/select_service_detail_controller.dart';
import '../../../../export.dart';
import '../../../core/widgets/service_provider_detail_widget.dart';

class SelectServiceDetailScreen extends GetView<SelectServiceDetailController> {
  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Scaffold(
        backgroundColor: Colors.white,
        appBar: CustomAppBar(
          centerTitle: true,
          appBarTitleText: controller.name ?? "",
        ),
        body: controller.serviceProviderDetailList.isNotEmpty
            ? ListView.separated(
                itemCount: controller.serviceProviderDetailList.length,
                shrinkWrap: true,
                padding: EdgeInsets.symmetric(horizontal: margin_10),
                itemBuilder: (BuildContext context, int index) {
                  return GestureDetector(
                      onTap: () {
                        Get.toNamed(AppRoutes.bookingDetailsScreenRouteCustomerSide, arguments: {
                          "id": controller.serviceProviderDetailList[index].createdById,
                          "serviceName": controller.serviceProviderDetailList[index].serviceName,
                        });
                      },
                      child: ServiceProviderDetailWidget(
                        itemIndex: index,
                      ));
                },
                separatorBuilder: (BuildContext context, int index) {
                  return SizedBox();
                })
            : noDataToShow(),
      );
    });
  }
}
