import 'package:healthcare/export.dart';

import '../../../core/widgets/select_service_widget.dart';
import '../controller/select_service_view_controller.dart';

class SelectServiceView extends GetView<SelectServiceViewController> {
  final controller = Get.put(SelectServiceViewController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        centerTitle: true,
        appBarTitleText: keySelectService.tr,
      ),
      body: _bodyWidget(),
    );
  }

  _bodyWidget() => SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: margin_15),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              _tabsView(),
              SizedBox(
                height: height_10,
              ),
              Obx(() {
                return controller.selectServiceList.isNotEmpty
                    ? ListView.separated(
                        itemCount: controller.selectServiceList.length,
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemBuilder: (BuildContext context, int index) {
                          return GestureDetector(
                              onTap: () {
                                Get.toNamed(AppRoutes.selectServiceDetail, arguments: {
                                  "id": controller.selectServiceList[index].id,
                                  "typeId": controller.isUpcomings.value,
                                  "name": controller.selectServiceList[index].title
                                });
                              },
                              child: SelectServiceWidget(
                                index: index,
                                img: controller.selectServiceList[index].serviceImage ?? "",
                                ratingStar: controller.selectServiceList[index].serviceAvgRating ?? "",
                                rating: controller.selectServiceList[index].serviceAvgRating ?? "",
                                name: controller.selectServiceList[index].title ?? "",
                              ));
                        },
                        separatorBuilder: (BuildContext context, int index) {
                          return SizedBox();
                        },
                      )
                    : noDataToShow().paddingOnly(top: margin_280);
              }),
            ],
          ),
        ),
      );

  _tabsView() {
    return Obx(
      () => Row(
        children: [
          Expanded(
            child: InkWell(
              onTap: () {
                if (controller.isUpcomings.value != 1) {
                  controller.isUpcomings.value = 1;
                  controller.hitSelectServiceApi();
                }
              },
              child: Container(
                padding: EdgeInsets.symmetric(vertical: margin_15),
                child: TextView(
                  text: keyPhysioTherapists.tr,
                  textStyle: textStyleHeading2().copyWith(
                    fontSize: font_15,
                    color: controller.isUpcomings.value == 1 ? Colors.white : Colors.black,
                  ),
                ),
                decoration: BoxDecoration(
                  color: controller.isUpcomings.value == 1 ? colorAppColors : colorAppColors.withOpacity(.2),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(radius_5),
                    bottomLeft: Radius.circular(radius_5),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: InkWell(
              onTap: () {
                if (controller.isUpcomings.value != 2) {
                  controller.isUpcomings.value = 2;
                  controller.hitSelectServiceApi();
                }
              },
              child: Container(
                padding: EdgeInsets.symmetric(vertical: margin_15),
                child: TextView(
                  text: keyNurse.tr,
                  textStyle: textStyleHeading2().copyWith(
                    fontSize: font_15,
                    color: controller.isUpcomings.value == 2 ? Colors.white : Colors.black,
                  ),
                ),
                decoration: BoxDecoration(
                  color: controller.isUpcomings.value == 2 ? colorAppColors : colorAppColors.withOpacity(.2),
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(radius_5),
                    bottomRight: Radius.circular(radius_5),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget commonListTitle({required leadingImg, userName, serviceName, subtitle, textClr, Widget? trailingWidget}) => Row(
        children: [
          AssetImageWidget(
            imageUrl: leadingImg,
            imageWidth: height_60,
            imageHeight: height_60,
            imageFitType: BoxFit.cover,
            radiusAll: radius_10,
          ),
          SizedBox(
            width: width_10,
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextView(
                  text: serviceName ?? "",
                  textStyle: textStyleTitle().copyWith(
                    fontSize: font_15,
                    fontWeight: FontWeight.bold,
                    color: textClr ?? Colors.grey,
                  ),
                ),
                TextView(
                  text: userName ?? "",
                  textStyle: textStyleTitle().copyWith(
                    fontSize: font_14,
                    fontWeight: FontWeight.normal,
                    color: Colors.black,
                  ),
                ),
                IntrinsicHeight(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.star_half,
                        color: Colors.orange,
                        size: height_18,
                      ),
                      SizedBox(
                        width: width_2,
                      ),
                      TextView(
                        text: subtitle ?? "",
                        textStyle: textStyleTitle().copyWith(
                          fontSize: font_12,
                          color: textClr ?? Colors.black,
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
          IntrinsicHeight(
            child: Container(
              height: double.infinity,
              width: 35,
              decoration: BoxDecoration(
                color: colorAppColor,
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(15),
                  bottomRight: Radius.circular(15),
                ),
              ),
              child: Icon(
                Icons.arrow_forward_ios_rounded,
                size: 18,
                color: colorWhite,
              ),
            ),
          )
        ],
      );
}
