import 'package:intl/intl.dart';
import '../../../../export.dart';
import '../controller/service_detail_controller.dart';

class ServiceDetailScreen extends GetView<ServiceDetailController> {
  final controller = Get.put(ServiceDetailController());

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (controller.isFromNotification == true) {
          isNotified = false;
          Get.offAllNamed(AppRoutes.home);
        } else {
          Get.back();
        }
        return true;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: CustomAppBar(
          leadingIcon: InkWell(
            onTap: () {
              if (controller.isFromNotification == true) {
                isNotified = false;
                Get.offAllNamed(AppRoutes.home);
              } else {
                Get.back();
              }
            },
            child: Icon(
              Icons.arrow_back_ios,
              size: height_22,
              color: colorAppColor,
            ).paddingOnly(top: margin_20, left: margin_10),
          ),
          centerTitle: controller.center,
          appBarTitleText: "${keyServiceDetail.tr}",
        ),
        body: Obx(() {
          return controller.isLoading.value
              ? Center(child: CircularProgressIndicator(color: colorAppColor))
              : SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: EdgeInsets.all(margin_10),
                        decoration: BoxDecoration(color: greyColor, borderRadius: BorderRadius.circular(radius_15)),
                        child: commonListTitle(
                            leadingImg: controller.bookingServiceDetail.value.providerProfile,
                            serviceName: controller.bookingServiceDetail.value.providerName.toString().capitalizeFirst ?? "",
                            userName: controller.bookingServiceDetail.value.serviceName ?? "",
                            subtitle: '${controller.distance??'0.0'} Km',
                            textClr: Colors.black,
                            imgHeight: height_70,
                            trailingWidget: SizedBox()),
                      ),
                      SizedBox(
                        height: height_15,
                      ),
                      _iconTextView(text: controller.bookingServiceDetail.value.createdBy?.location ?? "", icon: Icons.location_on_rounded),
                      TextView(
                          text: "${keyServiceProvider.tr} : ${controller.bookingServiceDetail.value.providerName.toString().capitalizeFirst ?? ""}",
                          textStyle: textStyleBodyMedium().copyWith(
                            fontWeight: FontWeight.w500,
                            color: Colors.black,
                          )),
                      TextView(
                          text:
                              "${keyDateAndTime.tr} : ${DateFormat("dd MMM yyyy").format(DateTime.parse(controller.bookingServiceDetail.value.date.toString()))}"
                              " (${utcToLocalLatest(DateFormat("yyyy-MM-dd ").format(DateTime.now()) + controller.bookingServiceDetail.value.startTime!, "hh:mm a") ?? ''})",
                          textStyle: textStyleBodyMedium().copyWith(
                            fontWeight: FontWeight.w500,
                            color: Colors.black,
                          )),
                      TextView(
                          text: "${keyAppointmentNO.tr} : ${controller.bookingServiceDetail.value.appointmentNo}",
                          textStyle: textStyleBodyMedium().copyWith(
                            fontWeight: FontWeight.w500,
                            color: Colors.black,
                          )),
                      SizedBox(height: height_8),
                      Divider(
                        color: Colors.grey.shade400,
                        height: height_13,
                      ),
                      TextView(text: keyPriceSummery.tr, textStyle: textStyleBody1().copyWith(fontSize: font_14))
                          .paddingOnly(bottom: margin_12, top: margin_8),
                      Container(
                        padding: EdgeInsets.symmetric(vertical: margin_15, horizontal: margin_10),
                        decoration: BoxDecoration(color: greyColor, borderRadius: BorderRadius.circular(radius_10)),
                        child: Column(
                          children: [
                            customRow(title: "${keyServiceFee.tr}", value: "\$${controller.bookingServiceDetail.value.price ?? .0}"),
                            SizedBox(
                              height: height_2,
                            ),
                            customRow(title: "${keyBookingFee.tr}", value: "\$${controller.bookingServiceDetail.value.commission ?? .0}"),
                            Divider(
                              color: Colors.grey,
                              height: height_8,
                            ),
                            customRow(title: "${keyTotalPrice.tr}", value: "\$${controller.bookingServiceDetail.value.totalPrice ?? .0}"),


                          ],
                        ),
                      ),

                      SizedBox(height: height_10),
                      Row(
                        children: [
                          AssetImageWidget(
                            imageUrl: iconCheck,
                            imageHeight: height_15,
                          ).paddingOnly(right: margin_8),
                          TextView(
                            text: keyPaymentCompleted.tr,
                            textStyle: textStyleBody1().copyWith(
                              fontSize: font_15,
                              color: colorAppColor,
                            ),
                          )
                        ],
                      ),
                      // _upLoadedReport(),
                      // SizedBox(height: 10.h,),
                      controller.bookingServiceDetail.value.submitReport==null?SizedBox():   submitReport(),
                      SizedBox(height: height_25),
                      controller.bookingServiceDetail.value.stateId == STATE_COMPLETED && controller.bookingServiceDetail.value.isRating == false
                          ? _giveReview()
                          : controller.bookingServiceDetail.value.stateId == STATE_ACCEPTED ||
                                  controller.bookingServiceDetail.value.stateId == STATE_PENDING
                              ? _cancelBtn()
                              : SizedBox(),
                    ],
                  ),
                );
        }).paddingSymmetric(horizontal: margin_15),
      ),
    );
  }
  submitReport(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextView(text: 'Submitted Report', textStyle: textStyleBodyMedium().copyWith(fontWeight: FontWeight.bold)),
        SizedBox(height: 10.h,),
        rowWidget(title: 'Name',subtitle: controller.bookingServiceDetail.value.submitReport?.name),
        rowWidget(title: 'Nationality',subtitle: controller.bookingServiceDetail.value.submitReport?.nationality.toString()),
        rowWidget(title: 'Blood pressure',subtitle: controller.bookingServiceDetail.value.submitReport?.bloodPressure.toString()),
        rowWidget(title: 'Pulse',subtitle: controller.bookingServiceDetail.value.submitReport?.pulse.toString()),
        rowWidget(title: 'Temperature',subtitle: controller.bookingServiceDetail.value.submitReport?.temperature.toString()),
        rowWidget(title: 'Skin',subtitle: controller.bookingServiceDetail.value.submitReport?.skin.toString()),
        rowWidget(title: 'Conclusion',subtitle: controller.bookingServiceDetail.value.submitReport?.conclusion.toString()),
      ],
    );
  }
  rowWidget({title,subtitle}){
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        TextView(text: '${title??""}:', textStyle: textStyleBodyMedium()),

        TextView(text: subtitle??"", textStyle: textStyleBodyMedium()),
      ],
    );
  }
  _upLoadedReport() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      titleTxt(title: keyUploadedReport.tr),
      SizedBox(
        height: height_100,
        child: ListView.separated(
          itemCount: (controller.bookingServiceDetail.value.uploadReport??[]).length,
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                Get.dialog(
                    barrierColor: Colors.white.withOpacity(1),
                    Stack(
                      children: [
                        NetworkImageWidget(
                          imageHeight: double.infinity,
                          imageWidth: double.infinity,
                          radiusAll: radius_5,
                          imageFitType: BoxFit.contain,
                          imageurl: controller.bookingServiceDetail.value.uploadReport?[index].url,
                        ).paddingAll(margin_20),
                        Positioned(
                            left: 0,
                            top: margin_15,
                            child: IconButton(
                                onPressed: () {
                                  Get.back();
                                },
                                icon: Icon(Icons.arrow_back_ios, color: colorAppColors))),
                      ],
                    ));
              },
              child: NetworkImageWidget(
                imageHeight: height_100,
                imageWidth: height_100,
                radiusAll: radius_5,
                imageurl: controller.bookingServiceDetail.value.uploadReport?[index].url,
              ),
            );
          },
          separatorBuilder: (BuildContext context, int index) {
            return SizedBox(width: width_10);
          },
        ),
      ),
    ],
  );

  _giveReview() => MaterialButtonWidget(
        onPressed: () {
          Get.toNamed(AppRoutes.giveRating, arguments: {
            "id": controller.bookingServiceDetail.value.id,
            "name": controller.bookingServiceDetail.value.serviceName,
            "fullName": controller.bookingServiceDetail.value.fullName,
            "providerId": controller.bookingServiceDetail.value.providerId,
            "image": controller.bookingServiceDetail.value.profileFile,
          });
        },
        buttonColor: Colors.green,
        buttonRadius: radius_5,
        buttonText: keyGiveReview.tr,
        padding: height_12,
      );

  _cancelBtn() => MaterialButtonWidget(
        onPressed: () {
          controller.hitCancelApi();
        },
        buttonRadius: radius_5,
        buttonText: keyCancel.tr,
        padding: height_12,
      );

  Widget customRow({title, value}) => Row(
        children: [
          TextView(
            text: "${title ?? ""}",
            textStyle: textStyleTitle().copyWith(
              color: Colors.black,
              fontWeight: FontWeight.w500,
            ),
          ),
          Spacer(),
          TextView(
            text: "${value ?? ""}",
            textStyle: textStyleTitle().copyWith(
              color: Colors.black,
            ),
          ),
        ],
      ).paddingSymmetric(horizontal: margin_5, vertical: margin_3);

  _iconTextView({IconData? icon, text, enableUnderline = false}) {
    return RichText(
        maxLines: 1,
        textAlign: TextAlign.start,
        text: TextSpan(children: [
          WidgetSpan(
              child: Icon(
            icon,
            color: colorAppColors,
            size: font_20,
          ).paddingOnly(right: margin_8)),
          TextSpan(
            text: text ?? "",
            style: enableUnderline == false
                ? textStyleBodyMedium().copyWith(color: Colors.black)
                : textStyleBodyMedium().copyWith(
                    decoration: TextDecoration.underline,
                    decorationColor: colorAppColors,
                    color: colorAppColors,
                  ),
          )
        ])).paddingOnly(bottom: margin_3);
  }

  Widget commonListTitle({
    required leadingImg,
    imgHeight,
    userName,
    serviceName,
    subtitle,
    textClr,
    Widget? trailingWidget,
  }) =>
      Row(
        children: [
          NetworkImageWidget(
              imageWidth: imgHeight ?? height_50,
              imageHeight: imgHeight ?? height_50,
              radiusAll: radius_10,
              imageurl: leadingImg ?? controller.bookingServiceDetail.value.profileFile ?? ""),
          SizedBox(
            width: width_15,
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: TextView(
                        textAlign: TextAlign.start,
                        text: serviceName ?? "",
                        textStyle: textStyleTitle().copyWith(
                          fontSize: font_15,
                          fontWeight: FontWeight.w600,
                          color: textClr ?? Colors.black,
                        ),
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(vertical: margin_3, horizontal: margin_8),
                      margin: EdgeInsets.symmetric(horizontal: margin_8),
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(radius_5),
                          color: statusTextColor(stateId: controller.bookingServiceDetail.value.stateId)),
                      child: TextView(
                        text: statusTxt(stateId: controller.bookingServiceDetail.value.stateId),
                        textStyle: textStyleBody1().copyWith(fontSize: font_12, color: Colors.white),
                      ),
                    ),
                  ],
                ),
                TextView(
                  text: userName ?? "",
                  textStyle: textStyleTitle().copyWith(
                    fontSize: font_14,
                    fontWeight: FontWeight.w500,
                    color: textClr ?? Colors.black,
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.location_on,
                      color: colorAppColor,
                      size: height_15,
                    ),
                    SizedBox(
                      width: width_2,
                    ),
                    TextView(
                      text: subtitle ?? "",
                      textStyle: textStyleTitle().copyWith(
                        fontSize: font_14,
                        fontWeight: FontWeight.w600,
                        color: textClr ?? Colors.black,
                      ),
                    ),
                    SizedBox(
                      width: width_15,
                    ),
                    ratingsView(rating: controller.bookingServiceDetail.value.providerRating ?? "0"),
                    SizedBox(
                      width: width_2,
                    ),
                    TextView(
                      text: controller.bookingServiceDetail.value.providerRating ?? "",
                      textStyle: textStyleTitle().copyWith(
                        fontSize: font_14,
                        fontWeight: FontWeight.w600,
                        color: textClr ?? Colors.black,
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
          trailingWidget ??
              Icon(
                Icons.navigate_next,
                color: Colors.black,
              ),
        ],
      );
}
