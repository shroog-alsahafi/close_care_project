import '../../../../export.dart';
import '../controller/messages_chat_controller.dart';

class MessagesChatBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<MessagesChatController>(() => MessagesChatController());
  }
}
