import 'dart:isolate';

import 'package:healthcare/app/modules/chat/model/message_list_response_model.dart';
import 'package:intl/intl.dart';

import '../../../../export.dart';
import '../model/data_model/message_list_data_model.dart';

class ChatController extends GetxController {
  int page = 0;
  MessageListResponseModel messageListResponseModel = MessageListResponseModel();
  RxList<MessageListDataModel> messageList = <MessageListDataModel>[].obs;
  ScrollController scrollController = ScrollController();
  late Isolate? isolate;
  Timer? timer;
  RxString noShowData = ''.obs;

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    hitMessageListApiCall();
    super.onReady();
  }

  Future<void> startIsolate() async {
    try {
      isolate = await Isolate.spawn(messageListData(), DateTime.now().toIso8601String());
    } catch (e) {}
  }

  messageListData() {
    timer = Timer.periodic(Duration(seconds: 3), (timer) {
      hitMessageListApiCall();
    });
  }

  void stopIsolate() {
    try {
      timer?.cancel();
      isolate?.kill();
      isolate = null;
    } catch (e) {}
  }

  @override
  void dispose() {
    stopIsolate();
    super.dispose();
  }

  @override
  void onClose() {
    stopIsolate();
    super.onClose();
  }

  paginateItemList() {
    scrollController.addListener(() {
      if (scrollController.position.pixels == scrollController.position.maxScrollExtent) {
        if (page < messageListResponseModel.meta!.pageCount!) {
          page++;
          hitMessageListApiCall();
        }
      }
    });
  }

  hitMessageListApiCall() async {

  }


  String formatLastMessageTime(String lastMessageTime) {
    if (lastMessageTime.isEmpty) {
      return '';
    }
    DateTime lastMessageDateTime;
    try {
      lastMessageDateTime = DateTime.parse(lastMessageTime);
    } catch (e) {

      return ''; // Return default value or handle the error as needed
    }
    DateTime today = DateTime.now();
    String formattedTime = DateFormat.jm().format(lastMessageDateTime);
    if (lastMessageDateTime.year == today.year && lastMessageDateTime.month == today.month && lastMessageDateTime.day == today.day) {
      return '$formattedTime';
    } else {
      // Format for displaying day name and time
      String formattedDate = DateFormat('E').format(lastMessageDateTime);
      return '$formattedDate  $formattedTime';
    }
  }
}
