import 'package:http/http.dart' as http;
import 'package:image_gallery_saver/image_gallery_saver.dart';

import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:open_filex/open_filex.dart';

import 'package:permission_handler/permission_handler.dart';

import '../../../../export.dart';
import '../../../service_provider_app/Home/models/booking_provider_res_model.dart';
import '../../bookings/model/booking_list_model.dart';
import '../model/chat_response_model.dart';
import '../model/data_model/chat_data_model.dart';
import '../model/send_message_response.dart';

class MessagesChatController extends GetxController {
  Timer? timer;
  RxBool emptyCheck = true.obs;
  RxBool isLoadingMsg = false.obs;

  RxString profileImage = "".obs;

  int page = 0;
  // EmojiData? emojiData;
  RxString selectedEmoji = ''.obs;
  ChatMessageResponse chatMessageResponse = ChatMessageResponse();
  SendMessageResponse sendMessageResponse = SendMessageResponse();
  ScrollController scrollController = ScrollController();
  TextEditingController chatTextController = TextEditingController();
  var messageType;
  SignupResponseModel signupResponseModel=SignupResponseModel();
  dynamic isOnline = "";
  RxString noShowData = ''.obs;
  @override
  void onInit() {
    getArguments();
    getProfileData();
    super.onInit();
  }

  var toID;
  var userName = "";
  var userProfile = "";
  var bookingId = "";
  getArguments() {
    if (Get.arguments != null) {
      toID = Get.arguments["toId"] ?? "";
      userName = Get.arguments["toName"] ?? "";
      userProfile = Get.arguments["toProfile"] ?? "";
      bookingId = Get.arguments["bookingId"].toString() ?? "";
      // isOnline = ;
    }
  }

  void getProfileData()async{
    signupResponseModel=await PreferenceManger().getSavedLoginData();
  }

  @override
  void onReady() async {
    loadChatList();
    timer = Timer.periodic(
      Duration(seconds: 2),
      (timer) => getNewMessage(),
    );

    await Future.delayed(
      Duration(seconds: 1),
    );
    scroll();
    super.onReady();
  }

  @override
  void onClose() {
    timer?.cancel();
    super.onClose();
  }

  updateImageFile(Future<PickedFile?> imagePath) async {
    PickedFile? file = await imagePath;
    if (file != null) {
      profileImage.value = file.path;
      hitSendMessageApiCall(1, files: profileImage.value);
    }
  }



  hitSendMessageApiCall(type, {String? files}) async {
    try {
      var reqBody = {
        "Chat[message]": type == 0 ? chatTextController.text.trim() : await convertToMultipart(files ?? ""),
        "Chat[to_id]": toID,
        "Chat[type_id]": type,
        "Chat[booking_id]": bookingId,
      };
      final response = DioClient().post(
        "/api/chat/send-message",
        data: FormData.fromMap(reqBody),
        skipAuth: false,
      );
      sendMessageResponse = SendMessageResponse.fromJson(await response);
      chatList.insert(0, sendMessageResponse.detail!);
      chatTextController.clear();
      docMessage = "";
      profileImage.value = "";
      profileImage.refresh();
      scroll();
    } catch (e, str) {
      print("====eeee====$e\n$str");
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/chat/send-message"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  void scroll() {
    scrollController.animateTo(0.0, duration: Duration(milliseconds: 500), curve: Curves.easeIn);
  }

  RxList<ChatDataModel> chatList = <ChatDataModel>[].obs;
  getNewMessage() async {
    try {
      final response = DioClient().post(
        "/api/chat/load-new-message",
        queryParameters: {
          "with_id": toID,
          "page": page,
          "booking_id": bookingId,
        },
        skipAuth: false,
      );
      chatMessageResponse = ChatMessageResponse.fromJson(await response);
      if (chatMessageResponse.list!.isNotEmpty) {
        chatMessageResponse.list!.forEach(
          (element) {
            chatList.insert(0, element);
            scroll();
          },
        );
      }
    } catch (e, str) {
      Future.error(NetworkExceptions.getDioException(e, str, "/api/chat/load-new-message"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  loadChatList() async {
    chatList.clear();
    isLoadingMsg.value = true;
    try {
      final response = DioClient().post(
        "/api/chat/load-chat",
        queryParameters: {
          "user_id": toID,
          "date": "",
          "booking_id": bookingId,
        },
        skipAuth: false,
      );
      chatMessageResponse = ChatMessageResponse.fromJson(await response);
      chatList.addAll((chatMessageResponse.list ?? []).reversed);
      chatList.refresh();
      isLoadingMsg.value = false;
    } catch (e, str) {
      isLoadingMsg.value = false;
      Future.error(NetworkExceptions.getDioException(e, str, "/api/chat/load-chat"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  File? idImage;
  String docMessage = "";

  Future<void> openFilePicker() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['pdf', 'doc', 'docx', 'xls']);
    if (result != null) {
      idImage = File(result.files.single.path.toString());
      docMessage = idImage!.path;
      debugPrint("file:::$docMessage");
      hitSendMessageApiCall(1, files: docMessage);
    } else {
      toast("No document selected");
    }
  }

  Future<MultipartFile?> convertToMultipart(String image) async {
    debugPrint(":::::::$image");
    MultipartFile? profileMultipartImage;
    if (image != "" && !image.contains("http")) {
      profileMultipartImage = await MultipartFile.fromFile(image, filename: image);
    }
    debugPrint("profileMultipartImage ${profileMultipartImage.toString()}");
    return profileMultipartImage;
  }

  Future<String?> downloadAndShow({String? url}) async {
    await Permission.storage.request();
    File file;
    String filePath = '';
    String myUrl = '';
    // final dir = await getTemporaryDirectory();
    String dir = "/storage/emulated/0/Download";
    String fileName = "$dir/fitness-${url!.split("=").last}";
    if (await File('$fileName').exists()) {
      openFile(path: "$fileName");
    } else {
      try {
        customLoader.show(Get.overlayContext);
        myUrl = url;
        var response = await http.get(Uri.parse(myUrl));
        if (response.statusCode == 200) {
          var bytes = response.bodyBytes;
          filePath = '$fileName';
          file = File(filePath);
          await file.writeAsBytes(bytes);
          customLoader.hide();
          // toast("File downloaded successfully");
          Future.delayed(Duration(seconds: 1)).then((value) {
            openFile(path: filePath);
          });
        } else {
          customLoader.hide();
          launchUrl(Uri.parse(url));
          // toast("No App Found To Open This File");
          // toast("Something went wrong");
          filePath = 'Error code: ' + response.statusCode.toString();
        }
      } catch (ex) {
        customLoader.hide();
        launchUrl(Uri.parse(url));
        // toast("No App Found To Open This File");
        filePath = 'Can not fetch url';
      }
      return filePath;
    }
    return null;
  }

  /*==========================================openFile function===================================================*/

  Future<void> openFile({path, controller}) async {
    final filePath = path;
    final result = await OpenFilex.open(filePath);
    var openResult = "type= ${result.type}  message= ${result.message}";
    debugPrint(' $openResult');
    if (result.type == ResultType.noAppToOpen) {
      toast("No app found to open this docs");
    }
  }

  saveNetworkImage(String path) async {
    if (path.trim().isEmpty) {
      return;
    }
    var response = await Dio().get(path, options: Options(responseType: ResponseType.bytes));
    final result = await ImageGallerySaver.saveImage(Uint8List.fromList(response.data), quality: 60, name: "hello");
    if (result != null) {
      toast("Image downloaded");
    }
  }

  String getDateHeader(int index, List<ChatDataModel> chatList) {
    var messageDate = DateTime.parse(utcToLocalLatest(chatList[index].sendOn.toString(), "yyyy-MM-dd hh:mm:ss"));
    DateTime now = DateTime.now();
    if (messageDate.day == now.day && messageDate.month == now.month && messageDate.year == now.year) {
      return "Today, ${DateFormat('MMM d').format(messageDate)}";
    } else if (now.difference(messageDate).inDays == 1) {
      return "Yesterday";
    } else if (now.difference(messageDate).inDays > 1 && now.difference(messageDate).inDays < 2) {
      return DateFormat('MMM d').format(messageDate);
    } else {
      return DateFormat('MMM d').format(messageDate);
    }
  }
}
