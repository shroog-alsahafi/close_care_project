import 'dart:convert';

import 'data_model/message_list_data_model.dart';

MessageListResponseModel messageListScreenFromJson(String str) => MessageListResponseModel.fromJson(json.decode(str));

String messageListScreenToJson(MessageListResponseModel data) => json.encode(data.toJson());

class MessageListResponseModel {
  List<MessageListDataModel>? list;
  Meta? meta;
  DateTime? datecheck;
  String? copyrights;

  MessageListResponseModel({
    this.list,
    this.meta,
    this.datecheck,
    this.copyrights,
  });

  factory MessageListResponseModel.fromJson(Map<String, dynamic> json) => MessageListResponseModel(
        list: json["list"] == null ? [] : List<MessageListDataModel>.from(json["list"]!.map((x) => MessageListDataModel.fromJson(x))),
        meta: json["_meta"] == null ? null : Meta.fromJson(json["_meta"]),
        datecheck: json["datecheck"] == null ? null : DateTime.parse(json["datecheck"]),
        copyrights: json["copyrights"],
      );

  Map<String, dynamic> toJson() => {
        "list": list == null ? [] : List<dynamic>.from(list!.map((x) => x.toJson())),
        "_meta": meta?.toJson(),
        "datecheck": "${datecheck!.year.toString().padLeft(4, '0')}-${datecheck!.month.toString().padLeft(2, '0')}-${datecheck!.day.toString().padLeft(2, '0')}",
        "copyrights": copyrights,
      };
}

class Meta {
  int? totalCount;
  int? pageCount;
  int? currentPage;
  int? perPage;

  Meta({
    this.totalCount,
    this.pageCount,
    this.currentPage,
    this.perPage,
  });

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
        totalCount: json["totalCount"],
        pageCount: json["pageCount"],
        currentPage: json["currentPage"],
        perPage: json["perPage"],
      );

  Map<String, dynamic> toJson() => {
        "totalCount": totalCount,
        "pageCount": pageCount,
        "currentPage": currentPage,
        "perPage": perPage,
      };
}
