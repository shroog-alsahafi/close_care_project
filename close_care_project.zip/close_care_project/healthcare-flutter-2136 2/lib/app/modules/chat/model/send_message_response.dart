import 'dart:convert';

import 'data_model/chat_data_model.dart';

SendMessageResponse sendMessageResponseFromJson(String str) => SendMessageResponse.fromJson(json.decode(str));

String sendMessageResponseToJson(SendMessageResponse data) => json.encode(data.toJson());

class SendMessageResponse {
  ChatDataModel? detail;
  String? message;
  String? copyrights;

  SendMessageResponse({
    this.detail,
    this.message,
    this.copyrights,
  });

  factory SendMessageResponse.fromJson(Map<String, dynamic> json) => SendMessageResponse(
        detail: json["detail"] == null ? ChatDataModel.fromJson(json["list"]) : ChatDataModel.fromJson(json["detail"]),
        message: json["message"],
        copyrights: json["copyrights"],
      );

  Map<String, dynamic> toJson() => {
        "detail": detail?.toJson(),
        "list": detail?.toJson(),
        "message": message,
        "copyrights": copyrights,
      };
}
