import '../../../../export.dart';
import '../controller/chat_controller.dart';

class ChatScreen extends GetView<ChatController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [

              ],
            ),
            Obx(
              () => controller.messageList.isEmpty
                  ? Center(
                      child: noDataToShow(inputText: controller.noShowData.value),
                    ).marginSymmetric(vertical: Get.height * .3)
                  : ListView.builder(
                      controller: controller.scrollController,
                      physics: NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemCount: controller.messageList.length,
                      itemBuilder: (BuildContext context, int index) {
                        final messageData = controller.messageList[index];
                        return InkWell(
                            onTap: () {

                            },
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Stack(
                                      children: [
                                        Container(
                                          decoration: BoxDecoration(shape: BoxShape.circle),
                                          height: height_35,
                                          width: 50,
                                          child: NetworkImageWidget(
                                            imageurl: messageData.profileFile ?? "",
                                            imageHeight: height_50,
                                            imageWidth: width_50,
                                            radiusAll: radius_40,
                                          ).paddingOnly(),
                                        ),
                                        messageData.isOnline == true
                                            ? Positioned(bottom: height_5, left: width_33, child: Icon(Icons.circle, size: 14, color: colorAppColors))
                                            : SizedBox(),
                                      ],
                                    ),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        TextView(text: messageData.fullName ?? "", textStyle: textStyleBody1()).paddingOnly(bottom: margin_0),
                                        SizedBox(
                                          width: Get.width * .3,
                                          child: TextView(
                                              textAlign: TextAlign.start,
                                              maxLine: 1,
                                              text: "${messageData.lastMessage ?? ""}${messageData.lastMessage!.length > 30 ? '........' : ''}",
                                              textStyle: textStyleBody1().copyWith(
                                                  color: Colors.grey.shade500,
                                                  overflow: TextOverflow.ellipsis,
                                                  fontSize: font_14,
                                                  fontWeight: FontWeight.w400)),
                                        ),
                                      ],
                                    ).paddingOnly(left: margin_8),
                                    Spacer(),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        TextView(
                                                text: controller.formatLastMessageTime(messageData.lastMessageTime.toString()),
                                                textStyle: textStyleBody1().copyWith(fontSize: font_15, color: Colors.grey.shade400))
                                            .marginOnly(bottom: int.parse(messageData.unreadMessageCount.toString()) == 0 ? margin_15 : margin_0),
                                        int.parse(messageData.unreadMessageCount.toString()) == 0
                                            ? SizedBox()
                                            : Container(
                                                height: 18,
                                                width: 18,
                                                decoration: BoxDecoration(shape: BoxShape.circle, color: colorAppColors),
                                                child: TextView(
                                                  text: "${messageData.unreadMessageCount}",
                                                  textStyle: textStyleBody1().copyWith(fontSize: font_11, color: colorWhite),
                                                ),
                                              ),
                                      ],
                                    ).paddingOnly(right: margin_8),
                                  ],
                                ),
                                Divider(
                                  color: Colors.grey.shade300,
                                ).paddingOnly(top: margin_15)
                              ],
                            ).paddingOnly(top: margin_20));


                      },
                    ),
            ),
          ],
        ).paddingSymmetric(vertical: margin_0, horizontal: margin_15),
      ),
    );
  }
}
