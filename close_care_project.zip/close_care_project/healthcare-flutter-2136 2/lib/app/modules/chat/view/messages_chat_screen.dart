import 'package:flutter_chat_bubble/chat_bubble.dart';
import 'package:intl/intl.dart';
import '../../../../export.dart';
import '../controller/messages_chat_controller.dart';

class MessagesChatScreen extends GetView<MessagesChatController> {
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Get.back(result: true);
        return Future.value(true);
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: CustomAppBar(
          onTap: () {
            Get.back(result: true);
          },
          centerTitle: true,
          appBarTitleText: controller.userName,

          ///for future use for showing user profile with online icon
          /*  appBarTitleWidget: Row(
            children: [
              Stack(
                children: [
                  Container(
                    decoration: BoxDecoration(shape: BoxShape.circle),
                    height: height_35,
                    width: 50,
                    child: NetworkImageWidget(
                      imageurl: controller.userProfile,
                      imageHeight: height_50,
                      imageWidth: width_50,
                      radiusAll: radius_40,
                    ).paddingOnly(),
                  ),
                  controller.isOnline == true
                      ? Positioned(bottom: height_5, left: width_33, child: Icon(Icons.circle, size: 14, color: colorAppColors))
                      : SizedBox(),
                ],
              ),
              SizedBox(
                width: width_8,
              ),
              TextView(text: controller.userName, textStyle: textStyleBody1().copyWith(fontWeight: FontWeight.w500)),
            ],
          ),*/
        ),
        body: Column(
          children: [
            Divider(
              color: Colors.grey.shade300,
            ).marginSymmetric(horizontal: margin_18),
            chatList(),
            sendMessage()
          ],
        ),
      ),
    );
  }

  Widget chatList() {
    return Obx(
      () => Expanded(
        child: controller.chatList.isNotEmpty
            ? ListView.builder(
                padding: EdgeInsets.only(left: margin_15, right: margin_15, bottom: margin_15),
                controller: controller.scrollController,
                shrinkWrap: true,
                reverse: true,
                itemCount: controller.chatList.value.length,
                itemBuilder: (BuildContext context, int index) {
                  return Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                    _timeDivider(index),
                    controller.chatList[index].fromId != controller.signupResponseModel.detail?.id ? leftSideMessageList(index) : rightSideMessageList(index),
                  ]);
                },
              )
            : controller.isLoadingMsg.value
                ? Center(
                    child: CircularProgressIndicator(
                      color: colorAppColors,
                    ),
                  )
                : noDataToShow(inputText: "No chat found"), // <- Chat list view
      ),
    );
  }

  leftSideMessageList(index) {
    final chatData = controller.chatList[index];
    String createdOn = controller.chatList[index].createdOn;
    DateFormat dateFormat = DateFormat('hh:mm a dd MMM yyyy');
    DateTime createdOnDateTime = dateFormat.parse(createdOn);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        NetworkImageWidget(
          imageurl: chatData.fromUserProfileFile,
          imageHeight: height_25,
          imageWidth: height_25,
          radiusAll: radius_40,
        ).paddingOnly(top: margin_10),
        SizedBox(width: width_5),
        Flexible(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              (controller.chatList[index].message.toString().contains(".pdf") ||
                      controller.chatList[index].message.toString().contains(".doc") ||
                      controller.chatList[index].message.toString().contains(".docx"))
                  ? GestureDetector(
                      onTap: () async {
                        controller.downloadAndShow(url: controller.chatList.value[index].message.toString());
                      },
                      child: ChatBubble(
                        clipper: ChatBubbleClipper10(type: BubbleType.receiverBubble),
                        alignment: Alignment.topLeft,
                        margin: EdgeInsets.only(top: height_15, right: margin_25),
                        backGroundColor: Color(0xffE4E4E4),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            AssetImageWidget(
                              // radiusAll: radius_8,
                              imageHeight: height_100,
                              imageWidth: height_100,
                              imageUrl: iconFile,
                            ),
                            _dateText(createdOnDateTime)
                          ],
                        ),
                      ),
                    )
                  : controller.chatList.value[index].message.toString().contains(".jpg") ||
                          controller.chatList.value[index].message.toString().contains(".jpeg") ||
                          controller.chatList.value[index].message.toString().contains(".png")
                      ? GestureDetector(
                          onTap: () async {
                            controller.downloadAndShow(url: controller.chatList.value[index].message.toString());
                          },
                          child: ChatBubble(
                            clipper: ChatBubbleClipper10(type: BubbleType.receiverBubble),
                            alignment: Alignment.topLeft,
                            margin: EdgeInsets.only(top: height_15, right: margin_25),
                            backGroundColor: Color(0xffE4E4E4),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                NetworkImageWidget(
                                  radiusAll: radius_8,
                                  imageurl: controller.chatList.value[index].message.toString(),
                                  imageFitType: BoxFit.fill,
                                  imageWidth: width_90,
                                  imageHeight: height_80,
                                ),
                                _dateText(createdOnDateTime)
                              ],
                            ),
                          ),
                        )
                      : ChatBubble(
                          clipper: ChatBubbleClipper10(type: BubbleType.receiverBubble),
                          alignment: Alignment.topLeft,
                          margin: EdgeInsets.only(top: height_15, right: margin_25),
                          backGroundColor: Color(0xffE4E4E4),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              _textWidget(chatData.message),
                              _dateText(createdOnDateTime),
                            ],
                          ),
                        ),
            ],
          ),
        ),
      ],
    );
  }

  _dateText(date, {int? isRead = 0, bool? showTick = false}) => IntrinsicWidth(
        child: Row(
          children: [
            TextView(
              // text: DateFormat.jm().format(date),
              text: utcToLocalLatest(DateTime.parse(date.toString()), "hh:mm a"),
              textStyle: TextStyle(
                fontSize: font_10,
                color: Colors.black,
              ),
            ),
            SizedBox(width: width_5),
            if (showTick!)
              AssetImageWidget(
                imageUrl: iconCheckMark,
                color: isRead == 0 ? Colors.grey : colorAppColors,
                imageHeight: height_13,
                imageWidth: height_13,
              )
          ],
        ),
      );
  rightSideMessageList(index) {
    final chatData = controller.chatList[index];
    String createdOn = controller.chatList[index].createdOn;
    DateFormat dateFormat = DateFormat('hh:mm a dd MMM yyyy');
    DateTime createdOnDateTime = dateFormat.parse(createdOn);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        (controller.chatList[index].message.toString().contains(".pdf") ||
                controller.chatList[index].message.toString().contains(".doc") ||
                controller.chatList[index].message.toString().contains(".docx"))
            ? GestureDetector(
                onTap: () async {
                  if (controller.chatList[index].message.toString().contains(".doc") ||
                      controller.chatList[index].message.toString().contains(".docx"))
                    launchUrl(Uri.parse(controller.chatList.value[index].message.toString()));
                  else
                    controller.downloadAndShow(url: controller.chatList.value[index].message.toString());
                },
                child: ChatBubble(
                  clipper: ChatBubbleClipper10(type: BubbleType.sendBubble),
                  alignment: Alignment.topRight,
                  margin: EdgeInsets.only(top: height_15, left: margin_25),
                  backGroundColor: Color(0xffDDDEF5),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      AssetImageWidget(
                        // radiusAll: radius_8,
                        imageHeight: height_100,
                        imageWidth: height_100,
                        imageUrl: iconFile,
                      ),
                      _dateText(createdOnDateTime, isRead: chatData.isRead, showTick: true)
                    ],
                  ),
                ),
              )
            : GetUtils.isImage(controller.chatList.value[index].message.toString())
                ? GestureDetector(
                    onTap: () async {
                      controller.downloadAndShow(url: controller.chatList.value[index].message.toString());
                    },
                    child: ChatBubble(
                      clipper: ChatBubbleClipper10(type: BubbleType.sendBubble),
                      alignment: Alignment.topRight,
                      margin: EdgeInsets.only(top: height_15, left: margin_25),
                      backGroundColor: Color(0xffDDDEF5),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          NetworkImageWidget(
                            radiusAll: radius_8,
                            imageurl: controller.chatList.value[index].message.toString(),
                            imageFitType: BoxFit.fill,
                            imageWidth: width_100,
                            imageHeight: height_100,
                          ),
                          _dateText(createdOnDateTime, isRead: chatData.isRead, showTick: true)
                        ],
                      ),
                    ),
                  )
                : ChatBubble(
                    clipper: ChatBubbleClipper10(type: BubbleType.sendBubble),
                    alignment: Alignment.topRight,
                    margin: EdgeInsets.only(top: height_15, left: margin_25),
                    backGroundColor: Color(0xffDDDEF5),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        _textWidget(chatData.message),
                        _dateText(createdOnDateTime, isRead: chatData.isRead, showTick: true),
                      ],
                    ),
                  ),
      ],
    );
  }

  Widget _textWidget(text) => GestureDetector(
        onTap: text.toString().contains("http")
            ? () {
                launchUrl(Uri.parse(text));
              }
            : null,
        child: ReadMoreTextWidget(
          text,
          trimLines: 5,
          style: textStyleBody1().copyWith(
            decoration: text.toString().contains("http") ? TextDecoration.underline : null,
            decorationColor: Colors.blue,
            fontWeight: text.toString().contains("http") ? FontWeight.bold : FontWeight.w400,
            fontSize: font_15,
            color: text.toString().contains("http") ? Colors.blue : Colors.black,
          ),
        ),
      );

  _timeDivider(int index) {
    print("Start Date=====${controller.chatList[index].sendOn.toString()}");
    print("End Date=====${controller.chatList[index].sendOn.toString()}");
    return index == controller.chatList.length - 1
        ? _timeHeader(index)
        : index < controller.chatList.length &&
                DateFormat().add_MEd().format(DateTime.parse(controller.chatList[index].sendOn.toString())) !=
                    DateFormat().add_MEd().format(DateTime.parse(controller.chatList[index + 1].sendOn.toString()))
            ? _timeHeader(index)
            : SizedBox();
  }

  Widget _timeHeader(index) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Expanded(
          child: Container(
            height: 1.3,
            margin: EdgeInsets.only(right: 15),
            color: Colors.grey.shade200,
          ),
        ),
        TextView(
          text: controller.getDateHeader(index, controller.chatList),
          textStyle: textStyleBody1().copyWith(
            fontWeight: FontWeight.w500,
            fontSize: font_14,
            color: Colors.grey.shade500,
          ),
        ),
        Expanded(
          child: Container(
            height: 1.3,
            margin: EdgeInsets.only(left: 15),
            color: Colors.grey.shade200,
          ),
        ),
      ],
    ).paddingOnly(top: margin_20);
  }

  sendMessage() {
    return Container(
      margin: EdgeInsets.all(margin_10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius_10),
        border: Border.all(
          color: Colors.black26,
        ),
      ),
      child: Row(
        children: [
          Expanded(
              child: TextFormField(
            // minLines: 1,
            maxLines: 1,
            onChanged: (value) {
              if (value == " ") {
                controller.chatTextController.text = "";
              }
            },
            controller: controller.chatTextController,
            decoration: InputDecoration(
              contentPadding: EdgeInsets.all(margin_12),
              hintText: "Enter here...",
              border: InputBorder.none,
              focusedBorder: InputBorder.none,
              enabledBorder: InputBorder.none,
              errorBorder: InputBorder.none,
              disabledBorder: InputBorder.none,
            ),
          )),

          ///for future use to send img
          /* InkWell(
            onTap: () {
              controller.updateImageFile(
                imageFromGallery(),
              );
            },
            child: Icon(
              Icons.photo,
              size: 25,
              color: Colors.grey.shade400,
            ).paddingOnly(right: margin_8),
          ),*/

          ///for send docs
          GestureDetector(
            onTap: () {
              controller.openFilePicker();
            },
            child: AssetImageWidget(
              imageUrl: iconAttach,
              imageHeight: height_18,
              imageWidth: height_18,
            ),
          ),
          SizedBox(width: width_15),

          ///for send btn
          GestureDetector(
            onTap: () {
              if (controller.chatTextController.text.isNotEmpty) {
                controller.hitSendMessageApiCall(0);
                controller.chatList.refresh();
              } else {
                toast("Message cannot be empty");
              }
            },
            child: AssetImageWidget(
              imageUrl: iconSend,
              imageHeight: height_18,
              imageWidth: height_18,
            ),
          ),

          SizedBox(width: width_15)
        ],
      ),
    );
  }
}
