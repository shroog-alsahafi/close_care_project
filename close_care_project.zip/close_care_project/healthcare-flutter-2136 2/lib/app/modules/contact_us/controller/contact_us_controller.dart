import 'package:healthcare/export.dart';

class ContactUsController extends GetxController {
  @override
  void onInit() {
    getContactUs();
    super.onInit();
  }

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController msgController = TextEditingController();

  FocusNode nameFocusNode = FocusNode();
  FocusNode emailFocusNode = FocusNode();
  FocusNode msgFocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  SignupResponseModel signUpResponseModel = SignupResponseModel();
  final PreferenceManger preferenceManger = Get.put(PreferenceManger());
  getContactUs() {
    preferenceManger.getSavedLoginData().then((value) {
      if (value != null) {
        signUpResponseModel = value;
        nameController.text = signUpResponseModel.detail?.fullName ?? "";
        emailController.text = signUpResponseModel.detail?.email ?? "";
        update();
      }
      update();
    });
  }

  hitContactUsApi() async {
    customLoader.show(Get.overlayContext!);
    var requestModal = {
      "Information[full_name]": nameController.text.trim(),
      "Information[description]": msgController.text.trim().toString(),
      "Information[email]": emailController.text.trim().toString(),
    };
    try {
      final response = DioClient().post(
        "/api/user/contact-us",
        skipAuth: false,
        data: FormData.fromMap(requestModal),
      );
      MessageResponseModel messageResponseModel = MessageResponseModel.fromJson(await response);
      customLoader.hide();
      showInSnackBar(message: messageResponseModel.message!);
      if (signUpResponseModel.detail?.roleId == ROLE_CUSTOMER) {
        Get.offAllNamed(AppRoutes.home);
      } else {
        Get.offAllNamed(AppRoutes.mainScreenProvider);
      }
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/user/contact-us"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}
