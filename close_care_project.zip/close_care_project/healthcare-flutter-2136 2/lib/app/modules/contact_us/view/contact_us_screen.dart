import 'package:healthcare/export.dart';

class ContactUsScreen extends GetView<ContactUsController> {
  ContactUsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        centerTitle: true,
        iconWhite: true,
        bgColor: Colors.white,
        appBarTitleText: keyContactUs.tr,
      ),
      body: bodyWidget(),
    );
  }

  Widget bodyWidget() {
    return ListView(
      children: [textFormWidget(), _submitButton()],
    ).paddingSymmetric(horizontal: margin_10, vertical: margin_0);
  }

  textFormWidget() {
    return Form(
      key: controller.formKey,
      child: Column(
        children: [
          _name(),
          _email(),
          _message(),
        ],
      ).paddingSymmetric(horizontal: margin_5),
    );
  }

  _name() {
    return TextFieldWidget(
            radius: radius_5,
            contentPadding: EdgeInsets.only(top: margin_13, bottom: margin_13, left: margin_15),
            tvHeading: keyName.tr,
            textController: controller.nameController,
            validate: (value) => Validator.fieldChecker(value, keyName.tr),
            courserColor: colorAppColor,
            focusNode: controller.nameFocusNode)
        .marginOnly(top: margin_15);
  }

  _email() {
    return TextFieldWidget(
            radius: radius_5,
            contentPadding: EdgeInsets.only(top: margin_13, bottom: margin_13, left: margin_15),
            tvHeading: keyEmailAddress.tr,
            textController: controller.emailController,
            validate: (value) {
              if (value!.isEmpty)
                return keyEmailEmpty.tr;
              else if (!GetUtils.isEmail(value.trim()))
                return keyInvalidEmail.tr;
              else
                return null;
            },
            courserColor: colorAppColor,
            focusNode: controller.emailFocusNode)
        .marginOnly(top: margin_15);
  }

  _message() {
    return TextFieldWidget(
            minLine: 1,
            maxline: 5,
            radius: radius_5,
            contentPadding: EdgeInsets.only(top: margin_13, bottom: margin_13, left: margin_15),
            tvHeading: keyMessage.tr,
            textController: controller.msgController,
            validate: (value) {
              if (value!.isEmpty) {
                return keyMessageCannotBeEmpty.tr;
              } else if (value != value.toString().trim()) {
                return keyRemoveExtraSpaces.tr;
              } else if (countWords(string: value) < 5) {
                return keyEnterMinimumFive.tr;
              } else {
                return null;
              }
            },
            courserColor: colorAppColor,
            focusNode: controller.msgFocusNode)
        .marginOnly(top: margin_15);
  }

  _submitButton() {
    return MaterialButtonWidget(
      padding: margin_12,
      buttonRadius: radius_5,
      buttonText: keySave.tr,
      onPressed: () {
        if (controller.formKey.currentState!.validate()) {
          controller.hitContactUsApi();
        }
      },
    ).paddingSymmetric(vertical: margin_30, horizontal: margin_5);
  }
}
