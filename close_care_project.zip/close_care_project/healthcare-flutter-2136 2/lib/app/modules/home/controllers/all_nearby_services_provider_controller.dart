import 'package:healthcare/export.dart';

class AllNearByServiceProviderController extends GetxController {
  RxList<ProviderDataModel> servicesProviderListing = <ProviderDataModel>[].obs;
  RxInt selectedFilterIndex = 0.obs;
  RxList<CategoryDataModel> categoriesList = <CategoryDataModel>[].obs;
  int page = 0;
  CategoryListResponseModel categoryListResponseModel =
      CategoryListResponseModel();
  ScrollController scrollController = ScrollController();

  onReady() {
    hitCategoryListingApi();
    Timer(Duration(milliseconds: 400), () {
      hitServiceListingApi();
    });
    super.onReady();
  }

  paginateItemsList() {
    scrollController.addListener(() {
      if (scrollController.position.pixels ==
          scrollController.position.maxScrollExtent) {
        if (categoryListResponseModel.mMeta!.pageCount! <= page) {
          page++;
          hitServiceListingApi();
        }
      }
    });
  }

  hitCategoryListingApi() async {
    customLoader.show(Get.overlayContext);
    try {
      final response =
          DioClient().get("/api/service/service-category", skipAuth: false);
      categoryListResponseModel =
          CategoryListResponseModel.fromJson(await response);
      customLoader.hide();
      categoriesList.insert(0, CategoryDataModel(title: "All"));
      categoriesList.addAll(categoryListResponseModel.list ?? []);
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(
          e, str, "/service/service-category"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  hitServiceListingApi() async {
    customLoader.show(Get.overlayContext);
    try {
      final response = DioClient().get("/api/service/near-by-service",
          queryParameters: {
            "page": page,
            "lat": "$currentLatitude",
            "long": "$currentLongitude",
            "id": categoriesList[selectedFilterIndex.value].id ?? ''
          },
          skipAuth: false);
      ProviderListResponseModel providerListResponseModel =
          ProviderListResponseModel.fromJson(await response);
      customLoader.hide();
      if (page == 0) {
        servicesProviderListing.value = providerListResponseModel.list ?? [];
      } else {
        servicesProviderListing.addAll(providerListResponseModel.list ?? []);
      }
      servicesProviderListing.refresh();
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(
          e, str, "/service/near-by-service"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}
