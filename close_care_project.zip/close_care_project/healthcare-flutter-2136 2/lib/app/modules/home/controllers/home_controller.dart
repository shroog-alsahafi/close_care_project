/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:healthcare/app/core/location_details.dart';
import '../../../../../export.dart';
import '../../services/models/data_model/service_provider_response_model.dart';

class HomeController extends GetxController {
  RxInt selectedFilterIndex = 0.obs;
  final preferenceManager = Get.find<PreferenceManger>();

  Rx<SignupResponseModel> signupResponseModel = SignupResponseModel().obs;
  int page = 0;

  ServicesProviderResponseModel servicesProviderResponseModel = ServicesProviderResponseModel();

  onReady() {
    _getSavedLoginData();
    hitServiceListingApi();
    hitNurseListingApi();
    super.onReady();
  }

  Future<void> getCurrentLocation() async {
    try {
      LocationDetails locationDetails = await LocationServices.getInstance().getCurrentLocation();
      currentLongitude = locationDetails.longitude;
      currentLatitude = locationDetails.latitude;
    } catch (e) {}
  }

  _getSavedLoginData() async {
    await preferenceManager.getSavedLoginData().then((value) {
      try {
        signupResponseModel.value = value;
      } catch (e) {
        signupResponseModel.value = SignupResponseModel.fromJson(value);
      }
      signupResponseModel.refresh();
    });
  }

  hitLogoutApiCall() async {
    customLoader.show(Get.overlayContext);
    try {
      final response = DioClient().get("/api/user/logout", skipAuth: false);
      ErrorMessageResponseModel messageModel = ErrorMessageResponseModel.fromJson(await response);
      customLoader.hide();
      preferenceManager.clearLoginData();
      Get.offAllNamed(AppRoutes.chooseRole);
      showInSnackBar(message: messageModel.message!);
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/user/logout"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  ScrollController scrollController = ScrollController();
  RxList<ServicesProviderList> servicesProviderList = <ServicesProviderList>[].obs;
  RxList<ServicesProviderList> nurseList = <ServicesProviderList>[].obs;
  hitServiceListingApi({bool hideLoader = false}) async {
    if (!hideLoader) {
      customLoader.show(Get.overlayContext);
    }
    try {
      final response = DioClient().get("/api/service/near-by-provider",
          queryParameters: {
            "page": page,
            "type_id": PHYSIOTHERAPIST,
          },
          skipAuth: false);
      servicesProviderResponseModel = ServicesProviderResponseModel.fromJson(await response);
      customLoader.hide();
      if (page == 0) {
        servicesProviderList.clear();
      }
      servicesProviderList.addAll(servicesProviderResponseModel.list ?? []);
    } catch (e, str) {
      print("eeee$e\n$str");
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/service/near-by-service"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  hitNurseListingApi({bool hideLoader = false}) async {
    try {
      final response = DioClient().get("/api/service/near-by-provider",
          queryParameters: {
            "page": page,
            "type_id": NURSE,
          },
          skipAuth: false);
      servicesProviderResponseModel = ServicesProviderResponseModel.fromJson(await response);
      if (page == 0) {
        nurseList.clear();
      }
      nurseList.addAll(servicesProviderResponseModel.list ?? []);
    } catch (e, str) {
      Future.error(NetworkExceptions.getDioException(e, str, "/service/near-by-service"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  ///location

  Future getGeoLocationPosition() async {
    bool serviceEnabled;
    LocationPermission permission;
    customLoader.show(Get.overlayContext);
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      await Geolocator.openLocationSettings();
      customLoader.hide();

      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();

      if (permission == LocationPermission.denied) {
        customLoader.hide();

        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      customLoader.hide();
      return Future.error('Location permissions are permanently denied, we cannot request permissions.');
    }
    return await Geolocator.getCurrentPosition();
  }

  var latitude;
  var longitude;
  var location;

  Future getAddressFromLatLong(Position position) async {
    List placemarks = await placemarkFromCoordinates(position.latitude, position.longitude);
    Placemark place = placemarks[0];
    location = '${place.locality}, ${place.postalCode}, ${place.country}';
    latitude = position.latitude.toString();
    longitude = position.longitude.toString();
    updateLocationApiCall();
    customLoader.hide();
    update();
  }

  updateLocationApiCall() async {
    try {
      final response = DioClient().post(
        "/api/user/update-user-location",
        skipAuth: false,
        data: FormData.fromMap({
          "User[latitude]": latitude,
          "User[longitude]": longitude,
          "User[location]": location,
        }),
      );
      SignupResponseModel signUpResModel = SignupResponseModel.fromJson(await response);
      saveDataToLocalStorage(signUpResModel);
      _getSavedLoginData();
      showInSnackBar(message: signUpResModel.message.toString());
    } catch (e, str) {
      Future.error(NetworkExceptions.getDioException(e, str, "/api/user/update-user-location"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  final PreferenceManger _preferenceManger = PreferenceManger();
  saveDataToLocalStorage(SignupResponseModel? signUpResponseModel) async {
    await _preferenceManger.saveAuthToken(signUpResponseModel?.accessToken ?? "");
    await _preferenceManger.setLoginData(signUpResponseModel);
  }
}
