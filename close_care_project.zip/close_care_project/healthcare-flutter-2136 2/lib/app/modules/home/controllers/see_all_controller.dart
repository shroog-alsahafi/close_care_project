import '../../../../export.dart';
import '../../services/models/data_model/service_provider_response_model.dart';

class SeeAllController extends GetxController {
  @override
  void onInit() {
    _getArg();
    super.onInit();
  }

  RxBool comingFromNurse = false.obs;
  _getArg() {
    if (Get.arguments != null) {
      comingFromNurse.value = Get.arguments["comingFromNurse"];
    }
  }

  @override
  onReady() {
    paginateItemsList();
    hitServiceListingApi();
    super.onReady();
  }

  RxList<ServicesProviderList> servicesProviderList = <ServicesProviderList>[].obs;
  RxInt page = 0.obs;
  ServicesProviderResponseModel servicesProviderResponseModel = ServicesProviderResponseModel();

  hitServiceListingApi() async {
    if (page.value == 0) {
      customLoader.show(Get.overlayContext);
    }
    try {
      final response = DioClient().get("/api/service/near-by-provider",
          queryParameters: {
            "page": page.value,
            "type_id": comingFromNurse.value ? NURSE : PHYSIOTHERAPIST,
          },
          skipAuth: false);
      servicesProviderResponseModel = ServicesProviderResponseModel.fromJson(await response);
      if (page.value == 0) {
        servicesProviderList.clear();
      }
      servicesProviderList.addAll(servicesProviderResponseModel.list ?? []);
      customLoader.hide();
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/service/near-by-service"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  ScrollController scrollController = ScrollController();
  paginateItemsList() {
    scrollController.addListener(() {
      if (scrollController.position.pixels == scrollController.position.maxScrollExtent) {
        if (page.value < servicesProviderResponseModel.meta!.pageCount!) {
          page.value++;
          hitServiceListingApi();
        }
      }
    });
  }
}
