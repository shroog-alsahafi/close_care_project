import 'package:healthcare/app/modules/home/controllers/all_nearby_services_provider_controller.dart';
import 'package:healthcare/export.dart';

class AllNearByServiceProviderView
    extends GetView<AllNearByServiceProviderController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        appBarTitleText: keyNearByLocation.tr,
        centerTitle: true,
      ),
      body: _bodyView(),
    );
  }

  _bodyView() {
    return Column(
      children: [_filterRow(), _serviceList()],
    ).paddingSymmetric(horizontal: margin_15);
  }

  _serviceList() {
    return Obx(() => controller.servicesProviderListing.length == 0
        ? Center(child: noDataToShow()).paddingOnly(top: Get.height * .1)
        : ListView.builder(
            shrinkWrap: true,
            controller: controller.scrollController,
            physics: NeverScrollableScrollPhysics(),
            itemCount: controller.servicesProviderListing.length,
            itemBuilder: (context, index) {
              return _serviceView(index);
            }).marginSymmetric(vertical: margin_15));
  }

  _serviceView(int index) {
    return InkWell(
      splashColor: Colors.transparent,
      onTap: () {
        Get.toNamed(AppRoutes.serviceDetailsScreenRoute, arguments: {
          argServiceID: controller.servicesProviderListing[index].id
        });
      },
      child: Container(
        padding: EdgeInsets.all(margin_8),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius_10), color: colorGrey),
        child: Stack(
          children: [
            Row(
              children: [
                controller.servicesProviderListing[index].uploadFiles?.length ==
                        0
                    ? SizedBox()
                    : NetworkImageWidget(
                        imageurl: controller.servicesProviderListing[index]
                                .uploadFiles?.first.url ??
                            "",
                        imageWidth: height_70,
                        radiusAll: radius_10,
                        imageHeight: height_70,
                      ),
                _detailsView(index),
              ],
            ),
            _ratingsView(index)
          ],
        ),
      ).paddingOnly(top: margin_15),
    );
  }

  _ratingsView(int index) {
    return Align(
      alignment: Alignment.topRight,
      child: RichText(
          textAlign: TextAlign.start,
          text: TextSpan(children: [
            WidgetSpan(
                child: Icon(
              Icons.star,
              color: Colors.yellow,
              size: font_15,
            )),
            TextSpan(
                text: controller.servicesProviderListing[index].ratings ?? '')
          ])).paddingAll(margin_5),
    );
  }

  _detailsView(int index) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: Get.width * .64,
          child: TextView(
              maxLine: 1,
              textAlign: TextAlign.start,
              text: controller.servicesProviderListing[index].title ?? '',
              textStyle: textStyleBodyMedium()
                  .copyWith(color: Colors.white, fontSize: font_16)),
        ),
        SizedBox(
          width: Get.width * .64,
          child: TextView(
                  maxLine: 1,
                  textAlign: TextAlign.start,
                  text:
                      controller.servicesProviderListing[index].providerName ??
                          "",
                  textStyle: textStyleBodyMedium()
                      .copyWith(color: Colors.white, fontSize: font_13))
              .paddingSymmetric(vertical: margin_4),
        ),
        SizedBox(
          width: Get.width * .64,
          child: RichText(
              maxLines: 1,
              textAlign: TextAlign.start,
              text: TextSpan(children: [
                WidgetSpan(
                    child: Icon(
                  Icons.location_on_rounded,
                  color: colorAppColors,
                  size: font_15,
                )),
                TextSpan(
                    text:
                        " ${controller.servicesProviderListing[index].providerAddress ?? ""}")
              ])),
        )
      ],
    ).paddingOnly(left: margin_10);
  }

  _filterRow() {
    return SizedBox(
      height: height_30,
      child: Obx(() => controller.categoriesList.length == 0
          ? noDataToShow()
          : ListView.builder(
              scrollDirection: Axis.horizontal,
              shrinkWrap: true,
              itemCount: controller.categoriesList.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: EdgeInsets.only(right: margin_10),
                  child: Obx(
                    () => GestureDetector(
                      onTap: () {
                        controller.selectedFilterIndex.value = index;
                        controller.page = 0;
                        controller.hitServiceListingApi();
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(
                            horizontal: margin_12, vertical: margin_3),
                        height: height_20,
                        decoration: BoxDecoration(
                            color: controller.selectedFilterIndex.value == index
                                ? colorAppColors
                                : Colors.black,
                            border: Border.all(
                                color: controller.selectedFilterIndex.value ==
                                        index
                                    ? colorAppColors
                                    : Colors.white),
                            borderRadius: BorderRadius.circular(radius_20)),
                        child: Center(
                          child: Text(
                            controller.categoriesList[index].title ?? '',
                            style: TextStyle(
                                color: controller.selectedFilterIndex.value ==
                                        index
                                    ? Colors.black
                                    : Colors.white,
                                fontWeight: FontWeight.w400,
                                fontSize: font_13),
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              })),
    ).marginOnly(top: margin_10);
  }
}
