/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import 'dart:math';
import 'package:geolocator/geolocator.dart';
import 'package:healthcare/app/core/widgets/common_widget.dart';

import '../../../../../export.dart';

class HomeScreen extends GetView<HomeController> {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  final controller = Get.put(HomeController());

  @override
  Widget build(BuildContext context) {
    return DoubleBackButtonWidget(
      child: Scaffold(
        backgroundColor: Colors.white,
        key: scaffoldKey,
        appBar: _appBar(),
        drawer: customDrawer(),
        body: _body(),
      ),
    );
  }

  customDrawer() {
    return Drawer(
      backgroundColor: colorAppColors,
      shape: RoundedRectangleBorder(),
      child: Column(
        children: [
          SizedBox(
            height: height_120,
            child: Row(
              children: [
                Obx(() => Container(
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.white),
                        borderRadius: BorderRadius.circular(radius_12),
                      ),
                      child: NetworkImageWidget(
                        imageurl: controller.signupResponseModel.value.detail?.profileFile ?? "",
                        imageHeight: width_50,
                        imageWidth: width_50,
                        imageFitType: BoxFit.cover,
                        radiusAll: width_12,
                      ),
                    )).marginOnly(right: margin_10),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Obx(() => TextView(
                            maxLine: 2,
                            text: controller.signupResponseModel.value.detail?.fullName.toString().capitalize ?? "",
                            textStyle: textStyleBody1().copyWith(color: Colors.white),
                          )),
                      InkWell(
                        onTap: () {
                          scaffoldKey.currentState?.closeDrawer();
                          Get.toNamed(
                            AppRoutes.profileViewScreenRoute,
                          );
                        },
                        child: Row(
                          children: [
                            TextView(
                              text: keyViewProfile.tr,
                              textStyle: TextStyle(color: Colors.white, fontSize: font_13),
                            ),
                            AssetImageWidget(
                              imageUrl: iconNext,
                              imageWidth: width_13,
                              imageHeight: height_13,
                              color: Colors.white,
                            ).paddingOnly(left: margin_12)
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ).paddingSymmetric(horizontal: margin_15),
          ),
          _tilesView()
        ],
      ),
    );
  }

  _tilesView() {
    return Expanded(
      child: Container(
        color: Colors.white,
        child: Column(
          children: [
            customListTile(iconHome, keyHome.tr, () {
              scaffoldKey.currentState?.closeDrawer();
            }),
            customListTile(iconMyBookings, keyMyBookings.tr, () {
              scaffoldKey.currentState?.closeDrawer();
              Get.toNamed(AppRoutes.bookingViewScreenRoute);
            }),
            customListTile(iconCall, keyContactUs.tr, () {
              scaffoldKey.currentState?.closeDrawer();
              Get.toNamed(AppRoutes.contactScreen);
            }),
            customListTile(iconRefund, keyRefund.tr, () {
              Get.back();
              Get.toNamed(AppRoutes.transactionScreenRoute);
            }),
            customListTile(iconGrowth, keyTransactions.tr, () {
              Get.back();
              Get.toNamed(AppRoutes.transactionListScreen);
            }),
            customListTile(iconRatingReview, keyRatingReview.tr, () {
              Get.back();
              Get.toNamed(AppRoutes.ratingsReviewsScreenRoute);
            }),
            customListTile(iconSettings, keySettings.tr, () {
              scaffoldKey.currentState?.closeDrawer();
              Get.toNamed(AppRoutes.settingScreen);
            }),
            customListTile(iconAboutUs, keyAboutUs.tr, () {
              scaffoldKey.currentState?.closeDrawer();

              Get.to(AboutUsScreen());
            }),
            customListTile(iconLogout, keyLogout.tr, () {
              scaffoldKey.currentState?.closeDrawer();
              _logoutAccountDialog();
            }),
          ],
        ),
      ),
    );
  }

  _logoutAccountDialog() {
    return Get.dialog(AlertDialogWidget(
      title: keyLogout.tr,
      descrption: keyLogoutDesc.tr,
      voidCallback: (data) {},
      recordId: 0,
      action: keyLogout.tr,
    ));
  }

  Widget _body() {
    return RefreshIndicator(
      color: colorAppColors,
      onRefresh: () async {
        controller.hitServiceListingApi(hideLoader: true);
        controller.hitNurseListingApi(hideLoader: true);
      },
      child: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: margin_15),
        child: Column(
          children: [
            _searchField(),
            SizedBox(height: height_10),
            _banner(),
            Obx(() {
              return controller.servicesProviderList.isNotEmpty
                  ? Column(
                      children: [
                        SizedBox(height: height_10),
                        Divider(
                          color: Colors.grey.shade300,
                        ),
                        SizedBox(height: height_30),
                        _seeAllRow(
                            showSeeAll: controller.servicesProviderList.length > 5 ? true : false,
                            text: keyTopPhysioTherapists.tr,
                            onTap: () {
                              Get.toNamed(AppRoutes.seeAll);
                            }),
                        ListView.separated(
                          itemCount: min(controller.servicesProviderList.length, 5),
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemBuilder: (BuildContext context, int index) {
                            return CommonWidget(
                              itemIndex: index,
                              controller: controller,
                            );
                          },
                          separatorBuilder: (BuildContext context, int index) {
                            return SizedBox();
                          },
                        ),
                      ],
                    )
                  : noDataToShow().paddingOnly(top: margin_25);
            }),
            Obx(() {
              return controller.nurseList.isNotEmpty
                  ? Column(
                      children: [
                        SizedBox(height: height_20),
                        Divider(
                          color: Colors.grey.shade300,
                        ),
                        SizedBox(height: height_30),
                        _seeAllRow(
                            showSeeAll: controller.nurseList.length > 5 ? true : false,
                            text: keyTopNurses.tr,
                            onTap: () {
                              Get.toNamed(AppRoutes.seeAll, arguments: {"comingFromNurse": true});
                            }),
                        ListView.separated(
                          itemCount: min(controller.nurseList.length, 5),
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemBuilder: (BuildContext context, int index) {
                            return CommonWidget(
                              itemIndex: index,
                              controller: controller,
                              otherData: controller.nurseList,
                            );
                          },
                          separatorBuilder: (BuildContext context, int index) {
                            return SizedBox();
                          },
                        ),
                      ],
                    )
                  : SizedBox();
            }),
            SizedBox(height: height_50)
          ],
        ),
      ),
    );
  }

  _appBar() {
    return CustomAppBar(
      actionWidget: [
        InkWell(
          splashColor: Colors.transparent,
          onTap: () {
             Get.toNamed(AppRoutes.notificationScreenRoute);
          },
          child: AssetImageWidget(
            imageUrl: iconNotify,
            imageHeight: height_35,
          ).paddingOnly(right: margin_10),
        )
      ],
      appBarTitleWidget: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextView(
            text: keyWelcome.tr,
            textStyle: textStyleBodySmall().copyWith(
              color: Colors.black,
              fontSize: font_13,
              fontWeight: FontWeight.w500,
            ),
          ).paddingOnly(left: margin_2),
          GestureDetector(
            onTap: () async {
              Position position = await controller.getGeoLocationPosition();
              controller.getAddressFromLatLong(position);
            },
            child: IntrinsicWidth(
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.location_on_rounded, size: height_14),
                  Obx(
                    () => Flexible(
                      child: TextView(
                          textAlign: TextAlign.start,
                          maxLine: 1,
                          text: controller.signupResponseModel.value.detail?.location ?? controller.signupResponseModel.value.detail?.address ?? "",
                          textStyle: textStyleBody1().copyWith(color: Colors.black, fontSize: font_12)),
                    ),
                  ),
                  Icon(
                    Icons.keyboard_arrow_down_sharp,
                    color: Colors.black,
                    size: height_20,
                  )
                ],
              ),
            ),
          ),
        ],
      ),
      isDrawerIcon: true,
      onTap: () {
        scaffoldKey.currentState?.openDrawer();
      },
    );
  }

  _searchField() {
    return Row(
      children: [
        Expanded(
          child: TextFieldWidget(
            prefixIconConstraints: BoxConstraints(maxHeight: 25),
            prefixIcon: Padding(
              padding: EdgeInsets.only(right: 15),
              child: AssetImageWidget(
                imageUrl: iconSearch,
                imageHeight: height_18,
              ).paddingOnly(left: margin_10),
            ),
            shadow: true,
            readOnly: true,
            decoration: OutlineInputBorder(
              borderSide: BorderSide(color: colorAppColor),
              borderRadius: BorderRadius.circular(radius_5),
            ),
            onTap: () {
              Get.toNamed(AppRoutes.searches);
            },
            contentPadding: EdgeInsets.symmetric(
              vertical: margin_12,
              horizontal: margin_10,
            ),
            hint: keySearch.tr,
            hintStyle: TextStyle(
              color: Colors.grey.shade500,
              fontSize: font_14,
              fontWeight: FontWeight.w400,
            ),
            hideBorder: false,
            color: Colors.white,
            radius: radius_3,
          ),
        ),
        GestureDetector(
          onTap: () {
            Get.toNamed(AppRoutes.searches);
          },
          child: AssetImageWidget(
            imageUrl: iconFilter,
            imageHeight: height_38,
          ).paddingOnly(left: margin_10),
        )
      ],
    ).paddingOnly(top: margin_10);
  }

  customListTile(imageUrl, text, VoidCallback? onTap) {
    return ListTile(
      onTap: onTap,
      leading: AssetImageWidget(
        imageUrl: imageUrl,
        imageHeight: height_18,
        color: colorAppColor,
      ),
      title: TextView(
        text: text,
        textStyle: textStyleBodyMedium().copyWith(
          fontWeight: FontWeight.w500,
          fontSize: font_16,
          color: Colors.black,
        ),
        textAlign: TextAlign.start,
      ),
    );
  }

  _seeAllRow({required String text, required void Function()? onTap, bool showSeeAll = true}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        TextView(
          text: text,
          textStyle: TextStyle(
            fontSize: font_17,
            color: Colors.black,
            fontWeight: FontWeight.w500,
          ),
        ),
        if (showSeeAll)
          GestureDetector(
            onTap: onTap,
            child: TextView(
              text: keySeeAll.tr,
              textStyle: TextStyle(
                  decoration: TextDecoration.underline,
                  color: Colors.transparent,
                  decorationColor: colorAppColors,
                  fontSize: font_14,
                  shadows: [
                    Shadow(color: colorAppColor, offset: Offset(0, -3)),
                  ],
                  fontWeight: FontWeight.w400),
            ),
          )
      ],
    );
  }

  _banner() {
    return Stack(
      children: [
        AssetImageWidget(imageUrl: iconBanner),
        Container(
          margin: EdgeInsets.only(right: width_150, top: margin_25, left: margin_10),
          child: Container(
            height: height_140,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextView(
                  textAlign: TextAlign.start,
                  text: keyNurseContact.tr,
                  textStyle: textStyleBody1().copyWith(
                    color: Colors.black,
                    fontSize: font_15,
                  ),
                ),
                MaterialButtonWidget(
                  buttonColor: colorAppColor,
                  minWidth: width_120,
                  onPressed: () {
                    Get.toNamed(AppRoutes.selectService);
                  },
                  buttonText: keySelectServices.tr,
                  textColor: Colors.white,
                  padding: margin_10,
                  buttonRadius: radius_5,
                  elevation: margin_0,
                  fontsize: font_13,
                ).paddingOnly(top: margin_15)
              ],
            ),
          ),
        ),
      ],
    );
  }
}
