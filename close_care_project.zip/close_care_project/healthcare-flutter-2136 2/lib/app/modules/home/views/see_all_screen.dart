import '../../../../export.dart';
import '../../../core/widgets/common_widget.dart';
import '../controllers/see_all_controller.dart';

class SeeAllScreen extends GetView<SeeAllController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        appBarTitleWidget: Obx(
          () => TextView(
            text: controller.comingFromNurse.value ? keyTopNurses.tr : keyTopPhysioTherapists.tr,
            textStyle: textStyleTitle().copyWith(color: Colors.black),
          ),
        ),
        centerTitle: true,
        isBackIcon: true,
      ),
      body: Obx(() {
        return ListView.separated(
          padding: EdgeInsets.symmetric(horizontal: margin_15),
          controller: controller.scrollController,
          itemCount: controller.servicesProviderList.length,
          shrinkWrap: true,
          itemBuilder: (BuildContext context, int index) {
            return CommonWidget(
              itemIndex: index,
              controller: controller,
            );
          },
          separatorBuilder: (BuildContext context, int index) {
            return SizedBox();
          },
        );
      }),
    );
  }
}
