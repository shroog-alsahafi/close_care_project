/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import '../../../../export.dart';

class SelectLanguageController extends GetxController {
  int selectedRole = -1;
  LanguageTypeModel? selectedLanguage;
  RxInt selectedIndex = 0.obs;
  final PreferenceManger preferenceManager = Get.find<PreferenceManger>();
  List<LanguageTypeModel> languageList = [
    LanguageTypeModel(
        languageTitle: keyEnglish.tr,
        languageType: LANGUAGE_ENGLISH,
        image: iconEnglish),
    LanguageTypeModel(
        languageTitle: keyArabic.tr,
        languageType: LANGUAGE_ARABIC,
        image: iconArabicIcon),
  ];

  onReady() {
    getLanguageData();
    super.onReady();
  }

  getLanguageData() {
    preferenceManager.getLocalLanguageData().then((value) {
      if (value != null) {
        try {
          selectedLanguage = value as LanguageTypeModel;
        } catch (e) {
          selectedLanguage = LanguageTypeModel.fromJson(value);
        }
      }
    });
    selectedIndex.refresh();
  }

  applyLanguage() {
    selectedLanguage = languageList[selectedIndex.value];
    if (selectedLanguage?.languageType == LANGUAGE_ENGLISH) {
      Get.updateLocale(Locale('en', 'US'));
    } else {
      Get.updateLocale(Locale('ar', 'AR'));
    }
    preferenceManager.saveLocalLanguageData(selectedLanguage!);
    Get.toNamed(AppRoutes.chooseRole);
  }
}
