/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import '../../../../export.dart';

class SelectLanguageScreen extends GetView<SelectLanguageController> {
  final controller = Get.put(SelectLanguageController());

  @override
  Widget build(BuildContext context) {
    return DoubleBackButtonWidget(
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: CustomAppBar(
          appBarTitleText: keySelectLanguage.tr,
          centerTitle: true,
          isBackIcon: false,
          iconWhite: false,
          bgColor: Colors.transparent,
        ),
        body: _bodyWidget(),
      ),
    );
  }

  Widget _bodyWidget() => Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(height: height_50),
          TextView(
              text:   keyChooseYourLanguage.tr,

              textStyle: textStyleBody1()
                  .copyWith(fontSize: font_22, fontWeight: FontWeight.w500)),
          _chooseLanguage(),
          SizedBox(height: height_150, child: _selectLangSection()),
          _continueButton()
        ],
      ).marginOnly(top: margin_20);

  _chooseLanguage() {
    return TextView(
        text: keyChooseLanguage.tr,
        textStyle: textStyleBodyLarge().copyWith(
            fontWeight: FontWeight.w500,
            fontSize: font_25,
            fontFamily: FontFamily.monteHeading,
            color: Colors.white));
  }

  Widget _selectLangSection() => ListView.builder(
        shrinkWrap: true,
        padding: EdgeInsets.zero,
        scrollDirection: Axis.horizontal,
        itemBuilder: (BuildContext context, int index) => InkWell(
          splashColor: Colors.transparent,
          onTap: () {
            controller.selectedIndex.value = index;

           
          },
          child: Column(
            children: [
              Obx(
                () => Container(
                  width: Get.width * .4,
                  margin: EdgeInsets.symmetric(horizontal: margin_10),
                  padding: EdgeInsets.symmetric(vertical: margin_5),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(radius_12),
                      border: Border.all(
                          color: controller.selectedIndex.value == index
                              ? colorAppColors
                              : Colors.grey.shade500,
                          width: width_2),
                      color: controller.selectedIndex.value == index
                          ? colorAppColors
                          : Colors.white),
                  child: Column(
                    children: [
                      AssetImageWidget(
                        imageUrl: controller.languageList[index].image,
                        imageFitType: BoxFit.contain,
                        imageHeight: height_30,
                      ).paddingOnly(top: margin_5),
                      Obx(
                        () => TextView(
                                text: controller
                                    .languageList[index].languageTitle
                                    .toString(),
                                textStyle: textStyleBodyMedium().copyWith(
                                    fontWeight: FontWeight.w500,
                                    fontSize: font_15,
                                    color:
                                        controller.selectedIndex.value != index
                                            ? Colors.grey.shade500
                                            : Colors.white))
                            .marginOnly(bottom: margin_5, top: margin_10),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        itemCount: controller.languageList.length,
      ).marginOnly(top: margin_20);

  _continueButton() {
    return MaterialButtonWidget(
      buttonRadius: radius_5,
      padding: margin_14,
      buttonText: keyContinue.tr,
      onPressed: () {
        controller.applyLanguage();
      },
    ).paddingSymmetric(vertical: margin_40, horizontal: margin_20);
  }
}
