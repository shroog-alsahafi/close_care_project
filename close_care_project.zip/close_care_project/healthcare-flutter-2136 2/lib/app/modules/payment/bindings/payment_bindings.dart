import 'package:healthcare/app/modules/payment/controller/transaction_controller.dart';
import 'package:healthcare/export.dart';

class PaymentBindings extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => AddCardDetailController());
    Get.lazyPut(() => CardListController());
    Get.lazyPut(() => PaymentSuccessController());
    Get.lazyPut(() => TransactionController());
  }
}
