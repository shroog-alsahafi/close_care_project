import '../../../../export.dart';

class AddCardDetailController extends GetxController {
  final GlobalKey<FormState> formGlobalKey = GlobalKey<FormState>();

  TextEditingController cardHolderNameController = TextEditingController();
  TextEditingController cardNumberController = TextEditingController();
  TextEditingController cardExpiryController = TextEditingController();
  TextEditingController cardCvvController = TextEditingController();
  RxBool isSelect = false.obs;

  @override
  void onInit() {
    super.onInit();
  }



}
