import 'package:healthcare/app/modules/payment/model/cardlist_response_model.dart';

import '../../../../export.dart';
import '../../bookings/controller/select_date_time_controller.dart';

class CardListController extends GetxController {
  RxBool indexValue = false.obs;
  RxString appBarTitle = "Wallet".obs;
  RxString selectedCardIndex = "".obs;
  List<CardList> cardList = <CardList>[];

  bool isLoaded = false;
  String cardID = "";
  var amount, planId;

  RxInt selectValue = 1.obs;
  RxList<String> options = [
    'Option 1',
    'Option 2',
  ].obs;
  RxString selectedOption = ''.obs;
  @override
  void onInit() {
    getArgs();
    super.onInit();
  }

  void getArgs() {}
  @override
  onReady() {
    super.onReady();
  }

  shimmerViewCheck() async {
    await Future.delayed(Duration(milliseconds: 3000));
    isLoaded = true;
    update();
  }

  var controller = Get.find<SelectDateTimeController>();

  hitAddBookingApi() async {
    customLoader.show(Get.overlayContext);
    try {
      var requestBody = {
        "Booking[day_ids]": controller.selectedFormattedWeekDay.toString() ?? '',
        "Booking[service_id]": controller.servicesProviderList.id.toString() ?? '',
        "Booking[date]": controller.selectedFormattedDate.toString() ?? '',
        "Booking[start_time]": controller.slotsList[int.parse(controller.selectedTimeIndex.value)].startTime.toString().split(" ")[1] ?? '',
        "Booking[end_time]": controller.slotsList[int.parse(controller.selectedTimeIndex.value)].endTime.toString().split(" ")[1] ?? '',
        "File[key]": controller.selectedImages,
        "Booking[provider_id]": controller.servicesProviderList.providerDetail?.createdById
      };
      var response = DioClient().post(
        "/api/booking/add",
        data: FormData.fromMap(requestBody),
        skipAuth: false,
      );
      ErrorMessageResponseModel errorMessageResponseModel = ErrorMessageResponseModel.fromJson(await response);
      Get.offAllNamed(AppRoutes.home);
      showInSnackBar(message: errorMessageResponseModel.message.toString());
      customLoader.hide();
      update();
    } catch (e, str) {
      customLoader.hide();

      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/add"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}
