import '../../../../export.dart';

class PaymentSuccessController extends GetxController {
  var type;

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }
}
