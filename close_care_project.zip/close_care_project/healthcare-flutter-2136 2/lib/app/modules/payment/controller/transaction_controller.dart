import 'package:healthcare/export.dart';

import '../model/refund_list_response_model.dart';

class TransactionController extends GetxController {
  int page = 0;
  RefundListResponseModel refundListResponseModel = RefundListResponseModel();
  RxList<RefundDataModel> refundList = <RefundDataModel>[].obs;
  ScrollController scrollController = ScrollController();

  paginateItemsList() {
    scrollController.addListener(() {
      if (scrollController.position.pixels == scrollController.position.maxScrollExtent) {
        if  (page < refundListResponseModel.mMeta!.pageCount!) {
          page++;
          callGetRefundApi();
        }
      }
    });
  }



  callGetRefundApi() async {
    try {
      await DioClient().get('/api/booking/get-refund', skipAuth: false, queryParameters: {'page': page}).then((value) {
        if (value != null) {
          refundListResponseModel = RefundListResponseModel.fromJson(value);
          if (page == 0) {
            refundList.clear();
            refundList.value = refundListResponseModel.list ?? [];
          } else {
            refundList.addAll(refundListResponseModel.list ?? []);
          }
          refundList.refresh();
        }
      }).onError((error, stackTrace) {
        return Future.error(NetworkExceptions.getDioException(error, stackTrace, '/booking/get-refund'));
      });
    } catch (e, st) {
      print('Error---$e');
      print('Stacktrace---$st');
    }
  }


  @override
  void onInit() {
    getRole();
    paginateItemsList();

    super.onInit();
  }
  @override
  void onReady() {
    callGetRefundApi();
    super.onReady();
  }
  var role;
  getRole()async{
     role=await PreferenceManger().getRole();
  }
}
