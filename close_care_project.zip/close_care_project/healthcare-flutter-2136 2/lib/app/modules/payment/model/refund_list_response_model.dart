class RefundListResponseModel {
  List<RefundDataModel>? list;
  Links? lLinks;
  Meta? mMeta;
  String? copyrights;

  RefundListResponseModel(
      {this.list, this.lLinks, this.mMeta, this.copyrights});

  RefundListResponseModel.fromJson(Map<String, dynamic> json) {
    if (json['list'] != null) {
      list = <RefundDataModel>[];
      json['list'].forEach((v) {
        list!.add(new RefundDataModel.fromJson(v));
      });
    }
    lLinks = json['_links'] != null ? new Links.fromJson(json['_links']) : null;
    mMeta = json['_meta'] != null ? new Meta.fromJson(json['_meta']) : null;
    copyrights = json['copyrights'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.list != null) {
      data['list'] = this.list!.map((v) => v.toJson()).toList();
    }
    if (this.lLinks != null) {
      data['_links'] = this.lLinks!.toJson();
    }
    if (this.mMeta != null) {
      data['_meta'] = this.mMeta!.toJson();
    }
    data['copyrights'] = this.copyrights;
    return data;
  }
}

class RefundDataModel {
  dynamic id;
  dynamic transactionId;
  dynamic refundId;
  dynamic response;
  dynamic stateId;
  dynamic typeId;
  dynamic bookingId;
  dynamic amount;
  dynamic user;
  dynamic provider;
  dynamic dateTime;

  RefundDataModel(
      {this.id,
        this.transactionId,
        this.refundId,
        this.response,
        this.stateId,
        this.typeId,
        this.bookingId,
        this.amount,
        this.user,
        this.provider,
      this.dateTime});

  RefundDataModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    transactionId = json['transaction_id'];
    refundId = json['refund_id'];
    response = json['response'];
    stateId = json['state_id'];
    typeId = json['type_id'];
    bookingId = json['booking_id'];
    amount = json['amount'];
    user = json['user'];
    provider = json['provider'];
    dateTime = json['date_time'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['transaction_id'] = this.transactionId;
    data['refund_id'] = this.refundId;
    data['response'] = this.response;
    data['state_id'] = this.stateId;
    data['type_id'] = this.typeId;
    data['booking_id'] = this.bookingId;
    data['amount'] = this.amount;
    data['user'] = this.user;
    data['provider'] = this.provider;
    data['date_time'] = this.dateTime;
    return data;
  }
}
class Links {
  Self? self;
  Self? first;
  Self? last;

  Links({this.self, this.first, this.last});

  Links.fromJson(Map<String, dynamic> json) {
    self = json['self'] != null ? new Self.fromJson(json['self']) : null;
    first = json['first'] != null ? new Self.fromJson(json['first']) : null;
    last = json['last'] != null ? new Self.fromJson(json['last']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.self != null) {
      data['self'] = this.self!.toJson();
    }
    if (this.first != null) {
      data['first'] = this.first!.toJson();
    }
    if (this.last != null) {
      data['last'] = this.last!.toJson();
    }
    return data;
  }
}

class Self {
  dynamic href;

  Self({this.href});

  Self.fromJson(Map<String, dynamic> json) {
    href = json['href'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['href'] = this.href;
    return data;
  }
}

class Meta {
  dynamic totalCount;
  dynamic pageCount;
  dynamic currentPage;
  dynamic perPage;

  Meta({this.totalCount, this.pageCount, this.currentPage, this.perPage});

  Meta.fromJson(Map<String, dynamic> json) {
    totalCount = json['totalCount'];
    pageCount = json['pageCount'];
    currentPage = json['currentPage'];
    perPage = json['perPage'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['totalCount'] = this.totalCount;
    data['pageCount'] = this.pageCount;
    data['currentPage'] = this.currentPage;
    data['perPage'] = this.perPage;
    return data;
  }
}
