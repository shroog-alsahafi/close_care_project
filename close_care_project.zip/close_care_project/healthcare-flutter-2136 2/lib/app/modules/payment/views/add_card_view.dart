import '../../../../export.dart';

class AddCardDetailsScreen extends StatelessWidget {
  final controller = Get.put(AddCardDetailController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      appBar:
          CustomAppBar(centerTitle: true, appBarTitleText: keyAddNewCard.tr),
      body: Column(
        children: [
          SizedBox(
            height: height_20,
          ),
          formWidget(),
          MaterialButtonWidget(
            buttonRadius: radius_7,
            padding: margin_15,
            fontWeight: FontWeight.w600,
            buttonText: keyAddCard.tr,
            onPressed: () {
              if (controller.formGlobalKey.currentState!.validate()) {
                Get.dialog(PaymentSuccessScreen(), barrierDismissible: false);
              }
            },
          ).marginSymmetric(horizontal: width_15, vertical: height_30)
        ],
      ),
    );
  }

  formWidget() {
    return Form(
        key: controller.formGlobalKey,
        child: Column(
          children: [
            cardNumberWidget(),
            cardExpiryAndCvvWidget(),
            _holderNameWidget(),
          ],
        ));
  }

  cardExpiryAndCvvWidget() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: width_170,
              child: TextFieldWidget(
                contentPadding: EdgeInsets.symmetric(
                    vertical: margin_15, horizontal: margin_15),
                tvHeading: keyCardExpiryDate.tr,
                decoration: DecoratedInputBorder(
                  child: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(radius_8),
                      borderSide:
                          BorderSide(color: Colors.grey.shade400, width: 0.5)),
                  shadow: BoxShadow(
                    blurRadius: 0,
                    spreadRadius: 0,
                  ),
                ),
                color: Colors.white,
                textController: controller.cardExpiryController,
                maxLength: 5,
                inputAction: TextInputAction.next,
                inputType: TextInputType.number,
                inputFormatter: [
                  FilteringTextInputFormatter.digitsOnly,
                  CardMonthInputFormatter(),
                ],
                validate: (val) {
                  if (val == '') {
                    return keyExpiryDateNotEmpty.tr;
                  }
                  return CardUtils.validateDate(val);
                },
              ),
            ),
          ],
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
                width: width_150,
                child: TextFieldWidget(
                  contentPadding: EdgeInsets.symmetric(
                      vertical: margin_15, horizontal: margin_15),
                  tvHeading: keyCVV.tr,
                  decoration: DecoratedInputBorder(
                    child: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(radius_8),
                        borderSide: BorderSide(
                            color: Colors.grey.shade400, width: 0.5)),
                    shadow: BoxShadow(
                      blurRadius: 0,
                      spreadRadius: 0,
                    ),
                  ),
                  color: Colors.white,
                  inputFormatter: [
                    LengthLimitingTextInputFormatter(3),
                    FilteringTextInputFormatter.digitsOnly,
                    CardNumberFormatter(),
                  ],
                  textController: controller.cardCvvController,
                  inputAction: TextInputAction.next,
                  inputType: TextInputType.number,
                  validate: (value) => FieldChecker.fieldCvvChecker(
                      value: value?.trim() ?? "", message: keyCVV.tr),
                )),
          ],
        )
      ],
    ).paddingSymmetric(horizontal: margin_15, vertical: margin_25);
  }

  _holderNameWidget() {
    return TextFieldWidget(
      tvHeading: keyCardHolderName.tr,
      textController: controller.cardHolderNameController,
      inputAction: TextInputAction.next,
      color: Colors.white,
      inputType: TextInputType.text,
      contentPadding:
          EdgeInsets.symmetric(vertical: margin_15, horizontal: margin_15),
      decoration: DecoratedInputBorder(
        child: OutlineInputBorder(
            borderRadius: BorderRadius.circular(radius_8),
            borderSide: BorderSide(color: Colors.grey.shade400, width: 0.5)),
        shadow: BoxShadow(
          blurRadius: margin_0,
          spreadRadius: margin_0,
        ),
      ),
      maxLength: 16,
      inputFormatter: [
        FilteringTextInputFormatter.allow(RegExp('[a-z A-Z]')),
      ],
      validate: (value) => FieldChecker.fieldChecker(
          value: value?.trim() ?? "", message: keyCardHolderName.tr),
    ).marginOnly(bottom: margin_10, left: width_15, right: 15);
  }

  cardNumberWidget() {
    return TextFieldWidget(
      tvHeading: keyCardNumber.tr,
      decoration: DecoratedInputBorder(
        child: OutlineInputBorder(
            borderRadius: BorderRadius.circular(radius_8),
            borderSide: BorderSide(color: Colors.grey.shade400, width: 0.5)),
        shadow: BoxShadow(
          blurRadius: 0,
          spreadRadius: 0,
        ),
      ),
      contentPadding:
          EdgeInsets.symmetric(vertical: margin_15, horizontal: margin_15),
      inputFormatter: [
        LengthLimitingTextInputFormatter(19),
        FilteringTextInputFormatter.digitsOnly,
        CardNumberFormatter(),
      ],
      textController: controller.cardNumberController,
      validate: (value) => FieldChecker.fieldChecker(
          value: value?.trim() ?? "", message: keyCardNumber.tr),
      inputAction: TextInputAction.next,
      inputType: TextInputType.number,
      color: Colors.white,
    ).marginOnly(left: width_15, right: width_15);
  }
}
