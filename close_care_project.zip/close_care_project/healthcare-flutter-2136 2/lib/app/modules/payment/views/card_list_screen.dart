import '../../../../export.dart';

class CardListScreen extends GetView<CardListController> {
  CardListScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        appBarTitleText: keyPayment.tr,
        centerTitle: true,
      ),
      body: bodyWidget(),
    );
  }

  Widget bodyWidget() {
    return SingleChildScrollView(
      child: Column(
        children: [
          ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: controller.options.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                        onTap: () {}, child: _slidableButtonListView(index))
                    .paddingSymmetric(vertical: margin_5);
              }),
          SizedBox(height: height_50),
          SizedBox(
              width: Get.width,
              height: height_50,
              child: MaterialButtonWidget(
                onPressed: () async {
                  // Get.toNamed(AppRoutes.giveRating);
                  controller.hitAddBookingApi();
                },
                buttonText: keyPayNow.tr,
                buttonRadius: radius_5,
                textColor: Colors.white,
                fontWeight: FontWeight.bold,
                buttonColor: colorAppColors,
              )).paddingSymmetric(vertical: margin_10),
          SizedBox(
              width: Get.width,
              height: height_50,
              child: MaterialButtonWidget(
                onPressed: () async {
                  Get.toNamed(AppRoutes.addCardDetailsScreenRoute);
                },
                buttonText: keyAddCard.tr,
                buttonRadius: radius_5,
                borderColor: colorAppColors,
                textColor: colorAppColors,
                buttonColor: Colors.white,
              )).paddingOnly(top: margin_15),
        ],
      ).paddingOnly(
          left: margin_15, right: margin_15, top: margin_15, bottom: margin_8),
    );
  }

  _slidableButtonListView(int index) {
    return GestureDetector(
      onLongPress: () {},
      child: Container(
        width: Get.width,
        padding:
            EdgeInsets.symmetric(horizontal: margin_10, vertical: margin_12),
        decoration: BoxDecoration(
            color: /*controller.selectedCardIndex.value == index.toString()
                  ? Colors.green.shade100
                  :*/
                greyColor,
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(radius_9)),
        child: Row(
          children: [
            Obx(() {
              return Radio(
                activeColor: colorAppColor,
                value: controller.options[index],
                onChanged: (value) {
                  controller.selectedOption.value = value.toString();
                  controller.update();
                },
                groupValue: controller.selectedOption.value,
              );
            }),
            Container(
              padding: EdgeInsets.symmetric(
                  horizontal: margin_10, vertical: margin_2),
              margin: EdgeInsets.only(right: margin_10),
              decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(radius_10)),
              child: AssetImageWidget(
                imageUrl: iconGoogle,
                imageHeight: height_50,
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("**** **** **** ${4555}" ?? ""),
                SizedBox(height: height_5),
                TextView(
                    text: "${keyExpires.tr} 09/25",
                    textStyle: textStyleBody1().copyWith(
                        fontSize: font_13, fontWeight: FontWeight.w400))
              ],
            )
          ],
        ),
      ),
    );
  }
}


