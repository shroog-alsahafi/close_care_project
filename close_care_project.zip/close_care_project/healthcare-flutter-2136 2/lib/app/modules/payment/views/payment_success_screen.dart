import '../../../../export.dart';

class PaymentSuccessScreen extends StatelessWidget {
  final controller = Get.find<PaymentSuccessController>();
  final GlobalKey<FormState> addCardGlobalKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return _bodyWidget();
  }

  _bodyWidget() => _columnWidget();

  _columnWidget() => Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: Get.width,
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(radius_15)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                AssetImageWidget(
                  imageUrl: iconsIcDone,
                  imageHeight: height_75,
                ).paddingOnly(bottom: margin_10),
                TextView(
                        text: keySuccessfullyDone.tr,
                        textStyle:
                            textStyleHeading2().copyWith(color: colorAppColors))
                    .paddingOnly(bottom: margin_10),
                TextView(
                        text: keyYourBookingIsConfirmedSuccessfully.tr,
                        textStyle: textStyleBody1().copyWith(
                            color: Colors.black, fontWeight: FontWeight.w400))
                    .paddingOnly(bottom: margin_15),
                MaterialButtonWidget(
                  buttonRadius: radius_7,
                  padding: margin_12,
                  fontWeight: FontWeight.w600,
                  buttonText: keyGoToHome.tr,
                  onPressed: () {
                    Get.back();
                  },
                ).marginSymmetric(horizontal: width_10),
              ],
            ).paddingSymmetric(horizontal: margin_15, vertical: margin_25),
          ).paddingAll(margin_15),
        ],
      );
}
