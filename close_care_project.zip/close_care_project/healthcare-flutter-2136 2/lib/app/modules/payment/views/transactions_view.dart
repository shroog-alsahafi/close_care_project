import 'package:healthcare/app/modules/payment/controller/transaction_controller.dart';
import 'package:healthcare/export.dart';

class TransactionsView extends GetView<TransactionController> {
  final controller = Get.put(TransactionController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        appBarTitleText: keyRefund.tr,
        centerTitle: true,
      ),
      body: _bodyView(),
    );
  }

  _bodyView() {
    return Obx(() => controller.refundList.isEmpty?noDataToShow():ListView.builder(
      controller: controller.scrollController,
        itemCount: controller.refundList.length,
        itemBuilder: (context, index) {
          return Container(
            decoration: BoxDecoration(color: Colors.white,border: Border.all(),borderRadius: BorderRadius.circular(10)),
            width: Get.width,
            child: Row(
              children: [
                Icon(
                  Icons.monetization_on,
                  color: colorAppColors,
                  size: height_50,
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextView(
                        text:controller.role==ROLE_CUSTOMER? controller.refundList[index].provider.toString(): controller.refundList[index].user.toString(),
                        textStyle: textStyleBodyMedium()
                            .copyWith(color: Colors.black)),
                    TextView(
                        text: "Booking Id: ${controller.refundList[index].bookingId}",
                        textStyle: textStyleBodyMedium()
                            .copyWith(color: Colors.black, fontSize: font_12)),
                    TextView(
                        text: utcToLocalLatest(controller.refundList[index].dateTime, "dd MMM,yyyy hh:mm a"),
                        textStyle: textStyleBodyMedium()
                            .copyWith(color: Colors.black, fontSize: font_12)),
                  ],
                ).paddingSymmetric(horizontal: margin_10),
                Spacer(),
                TextView(
                    text: "\$${controller.refundList[index].amount}",
                    textStyle: textStyleBodyMedium()
                        .copyWith(color: colorAppColors, fontSize: font_18)),
              ],
            ).paddingAll(margin_10),
          ).paddingSymmetric(horizontal: margin_15, vertical: margin_10);
        }));
  }
}
