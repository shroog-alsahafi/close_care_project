import '../../../../export.dart';
import '../../../service_provider_app/bookings/controllers/booking_detail_controller_provider.dart';

class AddRatingController extends GetxController {
  BookingsDetailControllerProvider bookingsDetailController = Get.find();

  TextEditingController commentText = TextEditingController();
  FocusNode commentFocusNode = FocusNode();
  double rating = 0.0;
  var id;
  // Rx<BookingDataModel> bookingDataModel = BookingDataModel().obs;

  onReady() {
    // getArguments();
    super.onReady();
  }

  // getArguments() {
  //   if (Get.arguments != null) {
  //     id = Get.arguments[argProviderId] ?? "";
  //     // bookingDataModel.value = Get.arguments["dataModel"] ?? "";
  //   }
  // }

  hitAddRatingApi() async {
    customLoader.show(Get.overlayContext!);
    var requestModal = {
      "Rating[rating]": rating,
      "Rating[comment]": commentText.text,
      "Rating[title]": bookingsDetailController.bookingDetail.createdBy?.id,
    };
    try {
      final response = DioClient().post(
        "/api/booking/add-rating",
        data: FormData.fromMap(requestModal),
        skipAuth: false,
        queryParameters: {
          "booking_id": bookingsDetailController.bookingDetail.id,
        },
      );
      MessageResponseModel messageResponseModel = MessageResponseModel.fromJson(await response);
      bookingsDetailController.hitBookingDetailsApi();
      Get.back();
      showInSnackBar(message: messageResponseModel.message ?? '');
      customLoader.hide();
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/add-rating"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}
