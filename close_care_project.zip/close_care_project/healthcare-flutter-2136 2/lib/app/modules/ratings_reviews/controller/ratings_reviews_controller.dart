import 'package:healthcare/export.dart';

import '../model/ratings_list_response_model.dart';

class RatingsReviewsController extends GetxController {
  RxList<RatingDataModel> ratingsList = <RatingDataModel>[].obs;
  RxBool isDataLoading = true.obs;

  onReady() {
    hitRatingsDetailsApi();
    super.onReady();
  }

  int page = 0;
  hitRatingsDetailsApi() async {
    try {
      final response = DioClient().post(
        "/api/booking/rating-list",
        skipAuth: false,
        queryParameters: {"page": page},
      );
      RatingsListResponseModel ratingsListResponseModel = RatingsListResponseModel.fromJson(await response);
      ratingsList.value = ratingsListResponseModel.list ?? [];
      customLoader.hide();
      isDataLoading.value = false;
    } catch (e, str) {
      customLoader.hide();
      isDataLoading.value = false;
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/rating-list"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}
