/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import '../../../../export.dart';

class ChooseRoleController extends GetxController {
  RxInt selectedIndex = 0.obs;
  ChooseRoleModel selectedRoleModel = ChooseRoleModel();
  final PreferenceManger preferenceManager = Get.find<PreferenceManger>();
  List roleList = [
    ChooseRoleModel(image: iconCustomer, roleType: ROLE_CUSTOMER, roleTitle: keyPatient.tr),
    ChooseRoleModel(image: iconServiceProvider, roleType: ROLE_SERVICE_PROVIDER, roleTitle: keyServiceProvider.tr),
  ];

  applyRole() {
    selectedRoleModel = roleList[selectedIndex.value];
    preferenceManager.saveRole(selectedRoleModel);
    Get.toNamed(AppRoutes.logIn);
  }
}

class ChooseRoleModel {
  dynamic image;
  dynamic roleType;
  dynamic roleTitle;

  ChooseRoleModel({this.image, this.roleType, this.roleTitle});

  factory ChooseRoleModel.fromJson(Map<String, dynamic> json) {
    return ChooseRoleModel(
      image: json['image'],
      roleType: json['roleType'],
      roleTitle: json['roleTitle'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'roleTitle': roleTitle,
      'image': image,
      'roleType': roleType,
    };
  }
}
