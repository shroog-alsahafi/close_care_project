/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import '../../../../export.dart';

class ChooseRoleScreen extends GetView<ChooseRoleController> {
  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (value) {
        Get.offAllNamed(AppRoutes.selectLanguage);
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: CustomAppBar(
          appBarTitleText: keySelectRole.tr,
          centerTitle: true,
          bgColor: Colors.transparent,
          onTap: () {
            Get.offAllNamed(AppRoutes.selectLanguage);
          },
        ),
        body: _bodyWidget(),
      ),
    );
  }

  Widget _bodyWidget() => Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          _chooseLanguage(),
          _selectLangSection(),
          _continueButton(),
        ],
      ).marginOnly(top: margin_20);

  _chooseLanguage() {
    return TextView(
      text: keyChooseRole.tr,
      textStyle: textStyleBodyLarge().copyWith(
        fontWeight: FontWeight.w500,
        fontSize: font_22,
        color: Colors.black,
      ),
    ).marginOnly(top: margin_60);
  }

  _selectLangSection() => SizedBox(
        height: height_150,
        child: ListView.builder(
          shrinkWrap: true,
          padding: EdgeInsets.zero,
          physics: NeverScrollableScrollPhysics(),
          scrollDirection: Axis.horizontal,
          itemBuilder: (BuildContext context, int index) {
            ChooseRoleModel role = controller.roleList[index];
            return InkWell(
              splashColor: Colors.transparent,
              onTap: () {
                controller.selectedIndex.value = index;
              },
              child: Obx(() => Container(
                    margin: EdgeInsets.symmetric(vertical: margin_40, horizontal: margin_5),
                    width: width_140,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(radius_10),
                      color: controller.selectedIndex.value == index ? colorAppColors : Colors.white,
                      border: Border.all(
                        color: controller.selectedIndex.value == index ? colorAppColor : Colors.grey.shade500,
                        width: width_1,
                      ),
                    ),
                    child: Obx(() => Center(
                          child: TextView(
                            text: role.roleTitle,
                            textStyle: textStyleBodyMedium().copyWith(
                              fontWeight: FontWeight.w500,
                              fontSize: font_15,
                              color: controller.selectedIndex.value == index ? Colors.white : Colors.grey.shade500,
                            ),
                          ),
                        )),
                  )),
            );
          },
          itemCount: controller.roleList.length,
        ),
      ).marginOnly(top: margin_20);

  _continueButton() {
    return MaterialButtonWidget(
      buttonRadius: radius_5,
      buttonText: keyContinue.tr,
      padding: 15,
      onPressed: () {
        controller.applyRole();
      },
    ).paddingSymmetric(vertical: margin_25, horizontal: margin_30);
  }
}
