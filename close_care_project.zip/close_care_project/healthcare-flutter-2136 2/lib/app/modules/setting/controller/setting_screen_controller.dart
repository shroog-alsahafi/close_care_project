import 'package:healthcare/export.dart';

import '../model/notification_model.dart';

class SettingScreenController extends GetxController {
  final PreferenceManger _preferenceManger = Get.put(PreferenceManger());
  NotificationModel notificationModel = NotificationModel();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  SignupResponseModel signupResponseModel = SignupResponseModel();
  RxBool notificationState = false.obs;

  void onClick(bool value) {
    value = !value;
  }

  hitNotificationOnOff() async {
    await DioClient().get('/api/user/notification', skipAuth: false).then((value) {
      if (value != null) {
        signupResponseModel = SignupResponseModel.fromJson(value);
        notificationState.value = signupResponseModel.detail?.isNotify == NOTIFICATION_STATE_INACTIVE ? false : true;
        saveDataToLocalStorage(signupResponseModel);
        notificationState.refresh();
        showInSnackBar(message: signupResponseModel.message.toString());
      }
    }).onError((error, stackTrace) {
      Future.error(NetworkExceptions.getDioException(error, stackTrace, "/api/user/notification"));
    });
  }
  saveDataToLocalStorage(SignupResponseModel? signUpResponseModel) async {
    await _preferenceManger.setLoginData(signUpResponseModel);

  }

  hitDeleteAccountApiCall() async {
    customLoader.show(Get.overlayContext);
    await DioClient().get('/api/user/delete-account', skipAuth: false).then((value) async {
      if (value != null) {
        customLoader.hide();
        ResponseModel _loginResponseModel = ResponseModel.fromJson(value);
        _preferenceManger.clearLoginData();
        Get.offAllNamed(AppRoutes.chooseRole);
        showInSnackBar(message: _loginResponseModel.message ?? "");
      }
    }).onError((error, stackTrace) {
      customLoader.hide();
      showInSnackBar(message: error.toString());
      Future.error(NetworkExceptions.getDioException(error, stackTrace, "/api/user/delete-account"));
    });
  }

  changePass() async {
    var requestModal = {
      "User[password]": passwordController.text,
      "User[confirm_password]": confirmPasswordController.text,
    };
    await DioClient().post('/api/user/change-password', data: FormData.fromMap(requestModal)).then((value) async {
      if (value != null) {
        customLoader.hide();
        ResponseModel _loginResponseModel = ResponseModel.fromJson(value);
        _preferenceManger.clearLoginData();
        Get.offAllNamed(AppRoutes.logIn);
        showInSnackBar(message: _loginResponseModel.message ?? "");
      }
    }).onError((error, stackTrace) {
      customLoader.hide();
      showInSnackBar(message: error.toString());
      Future.error(NetworkExceptions.getDioException(error, stackTrace, "/api/user/change-password"));
    });
  }

  void getProfileData() async {
    signupResponseModel = await _preferenceManger.getSavedLoginData();
    print('signupResponseModel.value------${signupResponseModel.detail?.isNotify}');
    notificationState.value = signupResponseModel.detail?.isNotify == 1 ? true : false;
    print('notificationState.value------${notificationState.value}');
  }

  @override
  void onInit() {
    getProfileData();
    super.onInit();
  }
}
