import 'dart:convert';

NotificationModel notificationModelFromJson(String str) =>
    NotificationModel.fromJson(json.decode(str));

String notificationModelToJson(NotificationModel data) =>
    json.encode(data.toJson());

class NotificationModel {
  String? message;
  Detail? detail;
  String? copyrights;

  NotificationModel({
    this.message,
    this.detail,
    this.copyrights,
  });

  factory NotificationModel.fromJson(Map<String, dynamic> json) =>
      NotificationModel(
        message: json["message"],
        detail: json["detail"] == null ? null : Detail.fromJson(json["detail"]),
        copyrights: json["copyrights"],
      );

  Map<String, dynamic> toJson() => {
        "message": message,
        "detail": detail?.toJson(),
        "copyrights": copyrights,
      };
}

class Detail {
  int? id;
  String? firstName;
  String? lastName;
  String? fullName;
  String? email;
  String? countryCode;
  String? contactNo;
  dynamic trade;
  String? tradeTitle;
  String? profileFile;
  bool? profileComplete;
  dynamic reference;
  dynamic experience;
  dynamic otp;
  int? otpVerified;
  String? timezone;
  DateTime? createdOn;
  int? roleId;
  int? stateId;
  dynamic avgRating;
  String? ratingCounts;
  int? isNotify;
  List<dynamic>? uploadFiles;
  List<dynamic>? certificationFiles;

  Detail({
    this.id,
    this.firstName,
    this.lastName,
    this.fullName,
    this.email,
    this.countryCode,
    this.contactNo,
    this.trade,
    this.tradeTitle,
    this.profileFile,
    this.profileComplete,
    this.reference,
    this.experience,
    this.otp,
    this.otpVerified,
    this.timezone,
    this.createdOn,
    this.roleId,
    this.stateId,
    this.avgRating,
    this.ratingCounts,
    this.isNotify,
    this.uploadFiles,
    this.certificationFiles,
  });

  factory Detail.fromJson(Map<String, dynamic> json) => Detail(
        id: json["id"],
        firstName: json["first_name"],
        lastName: json["last_name"],
        fullName: json["full_name"],
        email: json["email"],
        countryCode: json["country_code"],
        contactNo: json["contact_no"],
        trade: json["trade"],
        tradeTitle: json["trade_title"],
        profileFile: json["profile_file"],
        profileComplete: json["profile_complete"],
        reference: json["reference"],
        experience: json["experience"],
        otp: json["otp"],
        otpVerified: json["otp_verified"],
        timezone: json["timezone"],
        createdOn: json["created_on"] == null
            ? null
            : DateTime.parse(json["created_on"]),
        roleId: json["role_id"],
        stateId: json["state_id"],
        avgRating: json["avg_rating"],
        ratingCounts: json["rating_counts"],
        isNotify: json["is_notify"],
        uploadFiles: json["uploadFiles"] == null
            ? []
            : List<dynamic>.from(json["uploadFiles"]!.map((x) => x)),
        certificationFiles: json["certificationFiles"] == null
            ? []
            : List<dynamic>.from(json["certificationFiles"]!.map((x) => x)),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "first_name": firstName,
        "last_name": lastName,
        "full_name": fullName,
        "email": email,
        "country_code": countryCode,
        "contact_no": contactNo,
        "trade": trade,
        "trade_title": tradeTitle,
        "profile_file": profileFile,
        "profile_complete": profileComplete,
        "reference": reference,
        "experience": experience,
        "otp": otp,
        "otp_verified": otpVerified,
        "timezone": timezone,
        "created_on": createdOn?.toIso8601String(),
        "role_id": roleId,
        "state_id": stateId,
        "avg_rating": avgRating,
        "rating_counts": ratingCounts,
        "is_notify": isNotify,
        "uploadFiles": uploadFiles == null
            ? []
            : List<dynamic>.from(uploadFiles!.map((x) => x)),
        "certificationFiles": certificationFiles == null
            ? []
            : List<dynamic>.from(certificationFiles!.map((x) => x)),
      };
}
