import '../../../../export.dart';
import '../controller/setting_screen_controller.dart';

class SettingScreen extends GetView<SettingScreenController> {
  const SettingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        iconWhite: true,
        centerTitle: true,
        bgColor: Colors.transparent,
        appBarTitleText: keySettings.tr,
      ),
      body: _bodyWidget(),
    );
  }

  Widget _settingNotification() => ListTile(
      contentPadding: EdgeInsets.only(left: margin_3),
      leading: AssetImageWidget(
        imageUrl: iconNotification,
        imageHeight: height_18,
        color: colorAppColor,
      ),
      title: TextView(
        text: keyNotification.tr,
        textStyle: TextStyle(color: Colors.black, fontWeight: FontWeight.w600),
        textAlign: TextAlign.start,
      ),
      trailing: Container(
        height: height_50,
        width: height_50,
        child: Obx(
          () => Switch(
            inactiveTrackColor: greyColor,
            activeTrackColor: colorAppColor,
            trackOutlineColor: MaterialStateProperty.resolveWith<Color?>((Set<MaterialState> states) {
              if (states.contains(MaterialState.disabled)) {
                return greyColor;
              }
              return Colors.transparent; // Use the default color.
            }),
            thumbColor: MaterialStatePropertyAll(Colors.white),
            value: controller.notificationState.value,
            onChanged: (val) {
              controller.notificationState.value = val;
              controller.hitNotificationOnOff();

            },
          ),
        ),
      ));

  _bodyWidget() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _settingNotification(),
        Divider(color: Colors.grey.shade100, thickness: 0.5),
        _settingView(
            img: iconKey,
            text: keyChangePassword.tr,
            onTap: () async {
              Get.toNamed(AppRoutes.changePassword, arguments: {
                "id": await PreferenceManger().getAuthToken(),
              });
            }),
        Divider(color: Colors.grey.shade100, thickness: 0.5),
        _settingView(
            img: iconAboutUs,
            text: keyAboutUs.tr,
            onTap: () {
              Get.toNamed(AppRoutes.staticPagesScreen, arguments: {argStaticPageType: pageTypeAboutUs});
            }),
        Divider(color: Colors.grey.shade100, thickness: 0.5),
        _settingView(
            img: iconPrivacy,
            text: keyPrivacyPolicy.tr,
            onTap: () {
              Get.toNamed(AppRoutes.staticPagesScreen, arguments: {argStaticPageType: pageTypePrivacyPolicy});
            }),
        Divider(color: Colors.grey.shade100, thickness: 0.5),
        _settingView(
            img: iconMyBookings,
            text: keyTermsAndConditions.tr,
            onTap: () {
              Get.toNamed(AppRoutes.staticPagesScreen, arguments: {argStaticPageType: pageTypeTerms});
            }),
        Divider(color: Colors.grey.shade100, thickness: 0.5),
        _settingView(
            img: iconDeleteAccount,
            text: keyDeleteAccount.tr,
            onTap: () {
              _deleteAccountDialog();
            }),
      ],
    ).paddingSymmetric(horizontal: margin_10, vertical: margin_10);
  }
}

_deleteAccountDialog() {
  return Get.dialog(AlertDialogWidget(
    title: keyDeleteAccount.tr,
    descrption: keyAreYouSure.tr,
    voidCallback: (data) {},
    recordId: 0,
    action: keyDeleteAccount.tr,
  ));
}

_settingView({img, text, VoidCallback? onTap}) => ListTile(
      splashColor: Colors.transparent,
      contentPadding: EdgeInsets.only(left: margin_3),
      leading: AssetImageWidget(
        imageUrl: img,
        imageHeight: height_18,
        color: colorAppColor,
      ),
      onTap: onTap,
      title: TextView(
        text: text,
        textStyle: TextStyle(color: Colors.black, fontSize: font_15, fontWeight: FontWeight.w600),
        textAlign: TextAlign.start,
      ),
      trailing: IconButton(
        icon: Icon(
          Icons.arrow_forward_ios,
          size: font_15,
          color: colorAppColor,
        ),
        onPressed: null,
      ),
    );
