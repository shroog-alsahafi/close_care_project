/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import 'package:healthcare/export.dart';

class SplashController extends GetxController {
  @override
  void onInit() {
    Get.put(NetworkController());
    SystemChannels.textInput.invokeMethod('TextInput.hide');
    checkInternetAvailable();
    super.onInit();
  }

  void checkInternetAvailable() async {
    final connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.none) {
      Get.to(
        NoInternetConnectionScreen(
          screenType: 0,
        ),
      )?.then((value) {
        checkInternetAvailable();
      });
    } else {
      _navigateToNextScreen();
    }
  }

  _navigateToNextScreen() => Timer(Duration(milliseconds: 3500), () async {
        if (appExpirationDateCheck()) {
          appExpirationDialog();
        } else {
          if (await PreferenceManger().getStatusFirstLaunch() == null) {
            Get.offAllNamed(AppRoutes.onBoarding);
          } else {
            if (await PreferenceManger().getAuthToken() != null) {
              if (isNotified == false) {
                hitUserCheck();
              }
            } else {
              Get.offAllNamed(AppRoutes.selectLanguage);
            }
          }
        }
      });

  bool appExpirationDateCheck() {
    return DateTime.now().isAfter(
      DateTime(2024, 11, 20).add(
        Duration(days: 15),
      ),
    );
  }

  hitUserCheck() async {
    try {
      final response = DioClient().get("/api/user/check", skipAuth: false);
      SignupResponseModel signUpResModel = SignupResponseModel.fromJson(await response);

      _navigateScreen(signUpResModel);
    } catch (e, str) {
      Get.offAllNamed(AppRoutes.selectLanguage);
      Future.error(NetworkExceptions.getDioException(e, str, "/api/user/check"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  saveDataToLocalStorage(SignupResponseModel value) {
    PreferenceManger().saveAuthToken(value.accessToken ?? "");
    PreferenceManger().setLoginData(value);
  }

  _navigateScreen(SignupResponseModel signUpResModel) {
    if (signUpResModel.detail?.isProfileSetup == 1) {
      if (signUpResModel.detail?.roleId == ROLE_CUSTOMER) {
        Get.offAllNamed(AppRoutes.home);
      } else {
        if (signUpResModel.detail?.isApproved == 1) {
          Get.offAllNamed(AppRoutes.mainScreenProvider);
        } else if (signUpResModel.detail?.isApproved == 3) {
          Get.offAllNamed(AppRoutes.profileSetupProvider, arguments: {
            "loginDataModel": signUpResModel,
            "argFromProfileSetup": true,
            "code": "+" "${signUpResModel.detail?.countryCode}",
          });
        } else {
          underReviewDialog();
        }
      }
    } else {
      Get.offAllNamed(AppRoutes.logIn);
    }
  }
}
