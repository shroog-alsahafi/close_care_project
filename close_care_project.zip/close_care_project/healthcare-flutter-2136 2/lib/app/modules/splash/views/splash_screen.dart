/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import '../../../../../export.dart';

class SplashScreen extends GetView<SplashController> {
  final controller = Get.put(SplashController());

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegionWidget(
      statusBarColor: colorAppColor,
      statusBarBrightness: Brightness.dark,
      child: Scaffold(
        backgroundColor: colorAppColor,
        body: _bodyView(),
      ),
    );
  }

  _bodyView() {
    return Center(
        child: AssetImageWidget(
      imageUrl: iconAppLogo,
      imageHeight: height_100,
    ));
  }
}
