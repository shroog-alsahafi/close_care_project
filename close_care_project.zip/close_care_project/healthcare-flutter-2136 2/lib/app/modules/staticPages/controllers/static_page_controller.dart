/*
 * @copyright : 'Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 *  All Rights Reserved.
 *  Proprietary and confidential :  All information contained herein is, and remains
 *  the property of Toxsl Technologies Pvt. Ltd. and its partners.
 *  Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */

import 'package:healthcare/export.dart';

import '../model/static_page_respose_model.dart';

class StaticPageController extends GetxController {
  int pageType = 0;
  RxBool isTablet = false.obs;
  Rx<StaticPagesResponseModel> staticPagesResponseModel = StaticPagesResponseModel().obs;
  RxString content = "".obs;

  @override
  void onInit() {
    getArguments();
    super.onInit();
  }

  getArguments() {
    if (Get.arguments != null) {
      if (Get.arguments[argStaticPageType] != null) {
        pageType = Get.arguments[argStaticPageType];
        hitGetPagesApiCall();
      }
    }
  }

  RxBool isLoading = false.obs;
  hitGetPagesApiCall() async {
    isLoading.value = true;
    await DioClient().get('/api/user/get-page', queryParameters: {paramType: pageType}).then((value) async {
      if (value != null) {
        staticPagesResponseModel.value = StaticPagesResponseModel.fromJson(value);
        content.value = staticPagesResponseModel.value.detail?.description ?? "";
        staticPagesResponseModel.refresh();
        isLoading.value = false;
      }
    }).onError((error, stackTrace) {
      isLoading.value = false;
      Future.error(NetworkExceptions.getDioException(error, stackTrace, "/api/user/get-page"));
      showInSnackBar(message: NetworkExceptions.messageData);
    });
  }
}
