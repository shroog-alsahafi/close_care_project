/*
 * @copyright : 'Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 *  All Rights Reserved.
 *  Proprietary and confidential :  All information contained herein is, and remains
 *  the property of Toxsl Technologies Pvt. Ltd. and its partners.
 *  Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */

import 'package:healthcare/app/modules/staticPages/model/static_page_data_model.dart';

class StaticPagesResponseModel {
  String? message;
  StaticPagesDataModel? detail;
  String? copyrights;

  StaticPagesResponseModel({this.message, this.detail, this.copyrights});

  StaticPagesResponseModel.fromJson(Map<String, dynamic> json) {
    message = json['message'];
    detail = json['detail'] != null
        ? new StaticPagesDataModel.fromJson(json['detail'])
        : null;
    copyrights = json['copyrights'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['message'] = this.message;
    if (this.detail != null) {
      data['detail'] = this.detail!.toJson();
    }
    data['copyrights'] = this.copyrights;
    return data;
  }
}
