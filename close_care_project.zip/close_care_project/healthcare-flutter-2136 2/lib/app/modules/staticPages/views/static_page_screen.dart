/*
 * @copyright : 'Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 *  All Rights Reserved.
 *  Proprietary and confidential :  All information contained herein is, and remains
 *  the property of Toxsl Technologies Pvt. Ltd. and its partners.
 *  Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */

import 'package:healthcare/export.dart';
import 'package:simple_html_css/simple_html_css.dart';

class StaticPageScreen extends GetView<StaticPageController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        bgColor: Colors.white,
        centerTitle: true,
        iconWhite: true,
        appBarTitleText: controller.pageType == pageTypePrivacyPolicy
            ? keyPrivacyPolicy.tr
            : controller.pageType == pageTypeTerms
                ? keyTermsAndConditions.tr
                : controller.pageType == pageTypeAboutUs
                    ? keyAboutUs.tr
                    : "",
      ),
      body: Obx(() => controller.isLoading.value
          ? Center(
              child: CircularProgressIndicator(
              color: colorAppColors,
            ))
          : SingleChildScrollView(
              padding: EdgeInsets.only(left: margin_12, right: margin_12, bottom: margin_20),
              child: RichText(
                  textAlign: TextAlign.justify,
                  text: HTML.toTextSpan(
                    context,
                    controller.staticPagesResponseModel.value.detail?.description ?? keyNoData.tr,
                    linksCallback: (dynamic link) {
                      launchUrl(Uri.parse(link));
                    },
                    defaultTextStyle: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.w400,
                    ),
                    overrideStyle: <String, TextStyle>{
                      "body": TextStyle(
                        color: Colors.black,
                        fontSize: font_13,
                      )
                    },
                  )),
            )),
    );
  }
}
