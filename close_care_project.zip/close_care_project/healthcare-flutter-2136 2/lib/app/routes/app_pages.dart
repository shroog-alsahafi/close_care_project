/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */
import 'package:healthcare/app/modules/chat/binding/chat_binding.dart';
import 'package:healthcare/app/modules/chat/binding/messages_chat_binding.dart';
import 'package:healthcare/app/modules/chat/view/chat_screen.dart';
import 'package:healthcare/app/modules/chat/view/messages_chat_screen.dart';
import 'package:healthcare/app/modules/refund/views/transaction_list_screen.dart';
import 'package:healthcare/app/service_provider_app/bookings/views/patients_screen_provider.dart';
import 'package:healthcare/app/service_provider_app/services/views/add_un_availability.dart';

import '../../export.dart';
import '../modules/bookings/views/book_service_screen.dart';
import '../modules/bookings/views/bookings_list_view.dart';
import '../modules/bookings/views/give_rating_screen.dart';
import '../modules/bookings/views/select_service_detail_screen.dart';
import '../modules/bookings/views/select_service_view.dart';
import '../modules/bookings/views/service_detail_screen.dart';
import '../modules/home/views/see_all_screen.dart';
import '../modules/refund/binding/transaction_binding.dart';
import '../service_provider_app/bank/bindings/bank_details_binding.dart';
import '../service_provider_app/bank/view/add_bank_screen.dart';
import '../service_provider_app/bank/view/bank_list_screen.dart';
import '../service_provider_app/bank/view/revenue_management_screen.dart';
import '../service_provider_app/bookings/views/submit_report_screen.dart';

class AppPages {
  static const INITIAL = AppRoutes.splash;

  static final routes = [
    GetPage(
      name: AppRoutes.splash,
      page: () => SplashScreen(),
      bindings: [SplashBinding()],
    ),
    GetPage(
      name: AppRoutes.selectLanguage,
      page: () => SelectLanguageScreen(),
      binding: SelectLanguageBinding(),
    ),
    GetPage(
      name: AppRoutes.onBoarding,
      page: () => OnboardingScreen(),
      binding: OnBoardingBinding(),
    ),
    GetPage(
      name: AppRoutes.logIn,
      page: () => LoginScreen(),
      bindings: [AuthenticationBinding()],
    ),
    GetPage(
      name: AppRoutes.signUp,
      page: () => RegisterScreen(),
      bindings: [AuthenticationBinding()],
    ),
    GetPage(
      name: AppRoutes.forgotPassword,
      page: () => ForgetPasswordScreen(),
      bindings: [AuthenticationBinding()],
    ),
    GetPage(
      name: AppRoutes.mainScreen,
      page: () => MainScreen(),
      bindings: [HomeBinding()],
    ),
    GetPage(
      name: AppRoutes.home,
      page: () => HomeScreen(),
      bindings: [HomeBinding()],
    ),
    GetPage(
      name: AppRoutes.profile,
      page: () => ProfileScreen(),
      bindings: [AuthenticationBinding()],
    ),
    GetPage(
      name: AppRoutes.profileSetupProvider,
      page: () => ProfileSetupProviderScreen(),
      bindings: [AuthenticationBinding()],
    ),
    GetPage(
      name: AppRoutes.chooseRole,
      page: () => ChooseRoleScreen(),
      binding: ChooseRoleBinding(),
    ),
    GetPage(
      name: AppRoutes.otpScreen,
      page: () => OtpScreen(),
      binding: AuthenticationBinding(),
    ),
    GetPage(
      name: AppRoutes.contactScreen,
      page: () => ContactUsScreen(),
      binding: ContactUsBinding(),
    ),
    GetPage(
      name: AppRoutes.settingScreen,
      page: () => SettingScreen(),
      binding: SettingScreenBinding(),
    ),
    GetPage(
      name: AppRoutes.staticPagesScreen,
      page: () => StaticPageScreen(),
      bindings: [StaticPageBinding()],
    ),
    GetPage(
      name: AppRoutes.categoriesScreenRoute,
      page: () => CategoriesScreen(),
      bindings: [ServicesBindings()],
    ),
    GetPage(
      name: AppRoutes.searches,
      page: () => SearchView(),
      bindings: [ServicesBindings()],
    ),

    GetPage(
      name: AppRoutes.serviceDetailsScreenRoute,
      page: () => ServiceDetailsView(),
      bindings: [ServicesBindings()],
    ),
    GetPage(
      name: AppRoutes.ratingsReviewsScreenRoute,
      page: () => RatingsReviewsScreen(),
      bindings: [RatingsBindings()],
    ),
    GetPage(
      name: AppRoutes.profileViewScreenRoute,
      page: () => ProfileViewScreen(),
      bindings: [AuthenticationBinding()],
    ),
    GetPage(
      name: AppRoutes.mainScreenProvider,
      page: () => MainScreenProvider(),
      bindings: [MainScreenBindingsProvider()],
    ),
    GetPage(
      name: AppRoutes.serviceDetailProvider,
      page: () => ServiceDetailsProvider(),
      bindings: [ServicesBindingsProvider()],
    ),
    GetPage(
      name: AppRoutes.bookingDetailScreenProvider,
      page: () => BookingDetailProvider(),
      bindings: [BookingDetailBindingProvider()],
    ),
    GetPage(
      name: AppRoutes.addServiceScreenProvider,
      page: () => AddServiceScreenProvider(),
      bindings: [ServicesBindingsProvider()],
    ),
    GetPage(
      name: AppRoutes.addAvailabilityProvider,
      page: () => AddAvailabilityProvider(),
      bindings: [MainScreenBindingsProvider()],
    ),
    GetPage(
      name: AppRoutes.addUnAvailability,
      page: () => AddUnAvailability(),
      bindings: [MainScreenBindingsProvider()],
    ),
    GetPage(
      name: AppRoutes.patientsScreen,
      page: () => PatientsScreenProvider(),
      bindings: [MainScreenBindingsProvider()],
    ),
    GetPage(
      name: AppRoutes.addCardDetailsScreenRoute,
      page: () => AddCardDetailsScreen(),
      bindings: [PaymentBindings()],
    ),
    GetPage(
      name: AppRoutes.cardListScreenRoute,
      page: () => CardListScreen(),
      bindings: [PaymentBindings()],
    ),
    GetPage(
      name: AppRoutes.paymentSuccessScreenRoute,
      page: () => PaymentSuccessScreen(),
      bindings: [PaymentBindings()],
    ),
    GetPage(
      name: AppRoutes.confirmBookingScreenRoute,
      page: () => ConfirmBookingScreen(),
      bindings: [BookingBindings()],
    ),
    GetPage(
      name: AppRoutes.selectDateTimeScreenRoute,
      page: () => SelectDateTimeScreen(),
      bindings: [BookingBindings()],
    ),
    GetPage(
      name: AppRoutes.bookingViewScreenRoute,
      page: () => BookingsView(),
      bindings: [BookingBindings()],
    ),
    GetPage(
      name: AppRoutes.bookingDetailsScreenRouteCustomerSide,
      page: () => BookingDetailsScreen(),
      bindings: [BookingBindings()],
    ),
    GetPage(
      name: AppRoutes.addRatingsScreenRoute,
      page: () => AddRatingScreen(),
      bindings: [RatingsBindings()],
    ),
    GetPage(
      name: AppRoutes.transactionScreenRoute,
      page: () => TransactionsView(),
      bindings: [PaymentBindings()],
    ),
    GetPage(
      name: AppRoutes.allNearByServiceProviderScreenRoute,
      page: () => AllNearByServiceProviderView(),
      bindings: [HomeBinding()],
    ),
    GetPage(
      name: AppRoutes.notificationScreenRoute,
      page: () => NotificationScreen(),
      bindings: [NotificationBindings()],
    ),
    GetPage(
      name: AppRoutes.changePassword,
      page: () => ChangePasswordScreen(),
      bindings: [AuthenticationBinding()],
    ),
    GetPage(
      name: AppRoutes.bookService,
      page: () => BookServiceScreen(),
      bindings: [BookingBindings()],
    ),
    GetPage(
      name: AppRoutes.selectService,
      page: () => SelectServiceView(),
      bindings: [BookingBindings()],
    ),
    GetPage(
      name: AppRoutes.giveRating,
      page: () => GiveRatingScreen(),
      bindings: [BookingBindings()],
    ),
    GetPage(
      name: AppRoutes.selectServiceDetail,
      page: () => SelectServiceDetailScreen(),
      bindings: [BookingBindings()],
    ),
    GetPage(
      name: AppRoutes.submitReport,
      page: () => SubmitReportScreen(),
      bindings: [BookingDetailBindingProvider()],
    ),
    GetPage(
      name: AppRoutes.revenueManagement,
      page: () => RevenueManagementScreen(),
      bindings: [BankDetailsBinding()],
    ),
    GetPage(
      name: AppRoutes.seeAll,
      page: () => SeeAllScreen(),
      bindings: [HomeBinding()],
    ),
    GetPage(
      name: AppRoutes.bankDetails,
      page: () => AddBankDetailsScreen(),
      bindings: [BankDetailsBinding()],
    ),
    GetPage(
      name: AppRoutes.bankList,
      page: () => BankListScreen(),
      bindings: [BankDetailsBinding()],
    ),
    GetPage(
      name: AppRoutes.chatScreen,
      page: () => ChatScreen(),
      bindings: [ChatBinding()],
    ),
    GetPage(
      name: AppRoutes.msgChatScreen,
      page: () => MessagesChatScreen(),
      bindings: [MessagesChatBinding()],
    ),
    GetPage(
      name: AppRoutes.serviceDetail,
      page: () => ServiceDetailScreen(),
      bindings: [BookingBindings()],
    ),
    GetPage(
      name: AppRoutes.transactionListScreen,
      page: () => TransactionListScreen(),
      binding: TransactionBinding(),
    ),
  ];
}
