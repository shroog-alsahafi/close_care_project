/*import 'package:flutter/src/widgets/framework.dart';
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

abstract class AppRoutes {
  static const splash = '/splash';
  static const onBoarding = '/onBoarding';
  static const selectLanguage = '/selectLanguage';
  static const logIn = '/logIn';
  static const signUp = '/signUp';
  static const forgotPassword = '/forgotPassword';
  static const mainScreen = '/mainScreen';
  static const home = '/home';
  static const itemView = '/itemView';
  static const profile = '/profile';
  static const profileSetupProvider = '/profileSetupProvider';
  static const editProfile = '/editProfile';
  static const videoCallScreen = '/videoCallScreen';
  static const newSignIn = '/videoCallScreen';
  static const chooseRole = '/chooseRole';
  static const otpScreen = '/otpScreen';
  static const contactScreen = '/contactScreen';
  static const notificationScreenRoute = '/notificationScreenRoute';
  static const settingScreen = '/settingScreen';
  static const staticPagesScreen = '/staticPagesScreen';
  static const categoriesScreenRoute = '/categoriesScreenRoute';
  static const searches = '/searches';
  static const serviceDetailsScreenRoute = '/serviceDetailsScreenRoute';
  static const ratingsReviewsScreenRoute = '/ratingsReviewsScreenRoute';
  static const profileViewScreenRoute = '/profileViewScreenRoute';
  static const addCardDetailsScreenRoute = '/addCardDetailsScreenRoute';
  static const cardListScreenRoute = '/cardListScreenRoute';
  static const mainScreenProvider = '/mainScreenProvider';
  static const bookingDetailScreenProvider = '/bookingDetailScreenProvider';
  static const addServiceScreenProvider = '/addServiceScreenProvider';
  static const addAvailabilityProvider = '/addAvailabilityProvider';
  static const bookingScreenProvider = '/bookingScreenProvider';
  static const addUnAvailability = '/addUnAvailability';
  static const patientsScreen = '/patientsScreen';
  static const serviceDetailProvider = '/serviceDetailProvider';

  static const paymentSuccessScreenRoute = '/paymentSuccessScreenRoute';
  static const confirmBookingScreenRoute = '/confirmBookingScreenRoute';
  static const selectDateTimeScreenRoute = '/selectDateTimeScreenRoute';
  static const bookingViewScreenRoute = '/bookingViewScreenRoute';
  static const bookingDetailsScreenRouteCustomerSide = '/bookingDetailsScreenRouteCustomerSide';
  static const addRatingsScreenRoute = '/addRatingsScreenRoute';
  static const transactionScreenRoute = '/transactionScreenRoute';
  static const allNearByServiceProviderScreenRoute = '/allNearByServiceProviderScreenRoute';
  static const changePassword = '/changePassword';
  static const bookService = '/bookService';
  static const selectService = '/selectService';
  static const giveRating = '/giveRating';
  static const selectServiceDetail = '/selectServiceDetail';
  static const submitReport = '/submitReport';
  static const revenueManagement = '/revenueManagement';
  static const chatScreen = '/chatScreen';
  static const msgChatScreen = '/msgChatScreen';
  static const seeAll = '/seeAll';
  static const bankDetails = '/bankDetails';
  static const bankList = '/bankList';
  static const serviceDetail = '/serviceDetail';
  static const transactionListScreen = '/transactionListScreen';
}
