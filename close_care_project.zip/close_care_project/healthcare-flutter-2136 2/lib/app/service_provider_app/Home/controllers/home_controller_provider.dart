import 'package:healthcare/app/service_provider_app/Home/models/booking_provider_res_model.dart';

import '../../../../export.dart';

class HomeControllerProvider extends GetxController {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  Rx<UserDetailDataModel> userDetailDataModel = UserDetailDataModel().obs;
  final preferenceManager = Get.find<PreferenceManger>();
  onReady() {
    hitPatientRequestApi();
    hitBookingListApi();
    _getSavedLoginData();
    super.onReady();
  }

  Rx<SignupResponseModel> signupResponseModel = SignupResponseModel().obs;
  _getSavedLoginData() async {
    await preferenceManager.getSavedLoginData().then((value) {
      try {
        signupResponseModel.value = value;
        userDetailDataModel.value = signupResponseModel.value.detail!;
      } catch (e) {
        signupResponseModel.value = SignupResponseModel.fromJson(value);
        userDetailDataModel.value = signupResponseModel.value.detail!;
      }
      signupResponseModel.refresh();
      update();
    });
  }

  int? page = 0;
  BookingProviderResModel bookingProviderResModel = BookingProviderResModel();
  RxList<BookingListProvider> pendingList = <BookingListProvider>[].obs;
  hitPatientRequestApi() async {
    try {
      final response = DioClient().get(
        "/api/booking/pending-list",
        skipAuth: false,
        queryParameters: {"page": page??'0'},
      );
      bookingProviderResModel = BookingProviderResModel.fromJson(await response);
      if (page == 0) {
        pendingList.clear();
      }
      pendingList.addAll(bookingProviderResModel.list ?? []);
      pendingList.refresh();
    } catch (e, str) {
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/pending-list"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  RxList<BookingListProvider> bookingList = <BookingListProvider>[].obs;
  hitBookingListApi() async {
    try {
      final response = DioClient().get(
        "/api/booking/list",
        skipAuth: false,
        queryParameters: {"page": page, "type": BOOKING_TYPE_ONLY_TODAY},
      );
      bookingProviderResModel = BookingProviderResModel.fromJson(await response);
      if (page == 0) {
        bookingList.clear();
      }
      bookingList.addAll(bookingProviderResModel.list ?? []);
      bookingList.refresh();
    } catch (e, str) {
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/list"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  hitAcceptRejectApi({required bookingId, required stateId, autoReject = false}) async {
    if (!autoReject) {
      customLoader.show(Get.overlayContext!);
    }
    try {
      final response = DioClient().post(
        "/api/booking/change-state",
        queryParameters: {"id": bookingId, "state_id": stateId},
        skipAuth: false,
      );
      MessageResponseModel messageResponseModel = MessageResponseModel.fromJson(await response);
      if (autoReject) {
        showInSnackBar(message: "This order has been auto rejected!");
      } else {
        showInSnackBar(message: messageResponseModel.message ?? "");
      }
      hitPatientRequestApi();
      hitBookingListApi();
      customLoader.hide();
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/change-state"));
      // showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}
