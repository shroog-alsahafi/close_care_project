import 'dart:convert';

import '../../../modules/services/models/data_model/service_provider_response_model.dart';

BookingProviderResModel bookingProviderResModelFromJson(String str) =>
    BookingProviderResModel.fromJson(json.decode(str));

String bookingProviderResModelToJson(BookingProviderResModel data) =>
    json.encode(data.toJson());

class BookingProviderResModel {
  List<BookingListProvider>? list;
  Links? links;
  Meta? meta;
  String? copyrights;

  BookingProviderResModel({
    this.list,
    this.links,
    this.meta,
    this.copyrights,
  });

  factory BookingProviderResModel.fromJson(Map<String, dynamic> json) =>
      BookingProviderResModel(
        list: json["list"] == null
            ? []
            : List<BookingListProvider>.from(
                json["list"]!.map((x) => BookingListProvider.fromJson(x))),
        links: json["_links"] == null ? null : Links.fromJson(json["_links"]),
        meta: json["_meta"] == null ? null : Meta.fromJson(json["_meta"]),
        copyrights: json["copyrights"],
      );

  Map<String, dynamic> toJson() => {
        "list": list == null
            ? []
            : List<dynamic>.from(list!.map((x) => x.toJson())),
        "_links": links?.toJson(),
        "_meta": meta?.toJson(),
        "copyrights": copyrights,
      };
}

class BookingListProvider {
  int? id;
  String? title;
  String? serviceId;
  int? providerId;
  String? startTime;
  String? endTime;
  DateTime? date;
  String? fullName;
  String? profileFile;
  String? address;
  String? city;
  String? country;
  String? latitude;
  String? longitude;
  dynamic description;
  String? price;
  String? totalPrice;
  int? stateId;
  int? typeId;
  DateTime? createdOn;
  int? createdById;
  bool? isRating;
  Service? service;
  bool? isMsg;

  BookingListProvider({
    this.id,
    this.title,
    this.serviceId,
    this.providerId,
    this.startTime,
    this.endTime,
    this.date,
    this.fullName,
    this.profileFile,
    this.address,
    this.city,
    this.country,
    this.latitude,
    this.longitude,
    this.description,
    this.price,
    this.totalPrice,
    this.stateId,
    this.typeId,
    this.createdOn,
    this.createdById,
    this.isRating,
    this.service,
    this.isMsg,
  });

  factory BookingListProvider.fromJson(Map<String, dynamic> json) =>
      BookingListProvider(
        id: json["id"],
        title: json["title"],
        serviceId: json["service_id"],
        providerId: json["provider_id"],
        startTime: json["start_time"],
        endTime: json["end_time"],
        date: json["date"] == null ? null : DateTime.parse(json["date"]),
        fullName: json["full_name"],
        profileFile: json["profile_file"],
        address: json["address"],
        city: json["city"],
        country: json["country"],
        latitude: json["latitude"],
        longitude: json["longitude"],
        description: json["description"],
        price: json["price"],
        totalPrice: json["total_price"],
        stateId: json["state_id"],
        typeId: json["type_id"],
        createdOn: json["created_on"] == null
            ? null
            : DateTime.parse(json["created_on"]),
        createdById: json["created_by_id"],
        isRating: json["is_rating"],
        service:
            json["service"] == null ? null : Service.fromJson(json["service"]),
        isMsg: json["is_message"] ?? false,
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "service_id": serviceId,
        "provider_id": providerId,
        "start_time": startTime,
        "end_time": endTime,
        "date": date?.toIso8601String(),
        "full_name": fullName,
        "profile_file": profileFile,
        "address": address,
        "city": city,
        "country": country,
        "latitude": latitude,
        "longitude": longitude,
        "description": description,
        "price": price,
        "total_price": totalPrice,
        "state_id": stateId,
        "type_id": typeId,
        "created_on": createdOn?.toIso8601String(),
        "created_by_id": createdById,
        "is_rating": isRating,
        "service": service?.toJson(),
        "is_message": isMsg,
      };
}

class Service {
  int? id;
  String? title;
  dynamic description;
  String? price;
  String? discountPrice;
  String? additionFee;
  dynamic imageId;
  int? stateId;
  int? typeId;
  DateTime? createdOn;
  int? createdById;

  Service({
    this.id,
    this.title,
    this.description,
    this.price,
    this.discountPrice,
    this.additionFee,
    this.imageId,
    this.stateId,
    this.typeId,
    this.createdOn,
    this.createdById,
  });

  factory Service.fromJson(Map<String, dynamic> json) => Service(
        id: json["id"],
        title: json["title"],
        description: json["description"],
        price: json["price"],
        discountPrice: json["discount_price"],
        additionFee: json["addition_fee"],
        imageId: json["image_id"],
        stateId: json["state_id"],
        typeId: json["type_id"],
        createdOn: json["created_on"] == null
            ? null
            : DateTime.parse(json["created_on"]),
        createdById: json["created_by_id"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "description": description,
        "price": price,
        "discount_price": discountPrice,
        "addition_fee": additionFee,
        "image_id": imageId,
        "state_id": stateId,
        "type_id": typeId,
        "created_on": createdOn?.toIso8601String(),
        "created_by_id": createdById,
      };
}
