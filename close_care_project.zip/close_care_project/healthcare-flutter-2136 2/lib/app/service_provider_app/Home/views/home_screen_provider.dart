import 'dart:math';

import 'package:flutter/cupertino.dart';
import 'package:healthcare/app/service_provider_app/Home/views/see_all_patient_request.dart';
import 'package:healthcare/app/service_provider_app/bookings/views/bookings_screen_provider.dart';
import 'package:intl/intl.dart';
import '../../../../export.dart';
import '../../../core/widgets/drawer_widget.dart';
import '../../../core/widgets/time_formatter.dart';
import '../controllers/home_controller_provider.dart';

class HomeScreenProvider extends GetView<HomeControllerProvider> {
  HomeScreenProvider({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      key: controller.scaffoldKey,
      appBar: CustomAppBar(
        isDrawerIcon: true,
        onTap: () {
          controller.scaffoldKey.currentState?.openDrawer();
        },
        appBarTitleWidget: Obx(
          () => TextView(
            text: "${controller.userDetailDataModel.value.fullName.toString().capitalizeFirst ?? ""}",
            textStyle: textStyleTitle().copyWith(color: Colors.black),
          ),
        ),
        actionWidget: [
          IconButton(
              onPressed: () {
                controller.hitPatientRequestApi();
                controller.hitBookingListApi();
              },
              icon: Icon(Icons.refresh)),
          InkWell(
            onTap: () {
              Get.toNamed(AppRoutes.notificationScreenRoute);
            },
            child: AssetImageWidget(
              imageUrl: iconNotification2,
              imageWidth: width_35,
              imageHeight: width_35,
            ),
          ),
          SizedBox(
            width: width_8,
          )
        ],
      ),
      drawer: customDrawer(),
      body: _body(),
    );
  }

  _body() {
    return Obx(
      () => controller.bookingList.length == 0 && controller.pendingList.length == 0
          ? noDataToShow(inputText: keyNoBookingsFountYet.tr)
          : ListView(
              padding: EdgeInsets.symmetric(horizontal: margin_15),
              children: [
                _patientReqList(),
                _myBookingList(),
              ],
            ),
    );
  }

  Widget _myBookingList() => Obx(
        () => controller.bookingList.length == 0
            ? SizedBox()
            : Column(
                children: [
                  titleAndSeeAllWidget(
                      showSeeAll: controller.pendingList.length > 4 ? true : false,
                      title: "${keyMyBookings.tr}",
                      seeAllOnTap: () {
                        Get.to(() => BookingsScreenProvider());
                      }),
                  ListView.separated(
                    itemCount: min(controller.bookingList.length, 4),
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      var booking = controller.bookingList[index];
                      return GestureDetector(
                        onTap: () {
                          Get.toNamed(AppRoutes.bookingDetailScreenProvider, arguments: {"booking": booking});
                        },
                        child: Container(
                          padding: EdgeInsets.all(margin_15),
                          decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(radius_10)),
                          child: commonListTitle(
                              leadingImg: booking.profileFile,
                              title: booking.fullName ?? "",
                              subtitle: utcToLocalLatestNewsDate(booking.date.toString()) ?? "",
                              shift: getShift(DateTime.parse(
                                  utcToLocalLatest(DateFormat("yyyy-MM-dd ").format(booking.date!) + booking.startTime!, "yyyy-MM-dd hh:mm:ss") ??
                                      '')),
                              trailingWidget: GestureDetector(
                                onTap: () async {
                                  var result = await Get.toNamed(AppRoutes.msgChatScreen, arguments: {
                                    "toId": booking.createdById,
                                    "toName": booking.fullName,
                                    "toProfile": booking.profileFile,
                                    "bookingId": booking.id,
                                  });
                                  if (result) {
                                    controller.hitPatientRequestApi();
                                    controller.hitBookingListApi();
                                  }
                                },
                                child: msgWithIndicator(showIndicator: booking.isMsg),
                              )),
                        ),
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) {
                      return SizedBox(
                        height: height_10,
                      );
                    },
                  ),
                ],
              ),
      );

  Widget _patientReqList() => Obx(
        () => controller.pendingList.length == 0
            ? SizedBox()
            : Column(
                children: [
                  titleAndSeeAllWidget(
                      showSeeAll: controller.pendingList.length > 4 ? true : false,
                      title: "${keyPatientRequest.tr}",
                      seeAllOnTap: () {
                        Get.to(() => SeeAllPatientRequest());
                      }),
                  ListView.separated(
                    itemCount: min(controller.pendingList.length, 4),
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      var booking = controller.pendingList[index];
                      return Container(
                        padding: EdgeInsets.all(margin_15),
                        decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(radius_10)),
                        child: commonListTitle(
                          leadingImg: booking.profileFile,
                          title: booking.fullName ?? "",
                          subtitle: utcToLocalLatestNewsDate(booking.date.toString()) ?? "",
                          shift: getShift(DateTime.parse(
                              utcToLocalLatest(DateFormat("yyyy-MM-dd ").format(DateTime.now()) + booking.startTime!, "yyyy-MM-dd hh:mm:ss") ?? '')),
                          trailingWidget: GestureDetector(
                            onTap: () {
                              var utcTime = booking.createdOn!.add(Duration(minutes: 5));
                              var localTime = DateTime.now();

                              var diff = DateTime.parse(utcToLocalLatest(utcTime, "yyyy-MM-dd HH:mm:ss").toString()).difference(localTime);

                              if (diff.inSeconds < 1) {
                                controller.hitAcceptRejectApi(bookingId: booking.id, stateId: STATE_REJECTED, autoReject: true);
                              } else {
                                orderDialog(controller: controller, time: diff.inSeconds, booking: booking);
                              }
                            },
                            child: AssetImageWidget(
                              imageUrl: iconEye,
                              imageWidth: height_35,
                              imageHeight: height_35,
                            ),
                          ),
                        ),
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) {
                      return SizedBox(
                        height: height_10,
                      );
                    },
                  ),
                ],
              ),
      );

  Widget _trailingWidget() => Column(
        children: [
          InkWell(
            onTap: () {},
            child: Icon(CupertinoIcons.checkmark_alt_circle_fill),
          ),
          SizedBox(
            height: height_5,
          ),
          InkWell(
            onTap: () {},
            child: Container(
              alignment: Alignment.center,
              padding: EdgeInsets.all(margin_2),
              decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle),
              child: Icon(
                CupertinoIcons.multiply,
                size: height_20,
                color: Colors.black,
              ),
            ),
          )
        ],
      );
}

Widget msgWithIndicator({showIndicator = false}) => Stack(
      children: [
        AssetImageWidget(
          imageUrl: iconChat,
          imageWidth: height_35,
          imageHeight: height_35,
        ).marginAll(margin_5),
        if (showIndicator)
          Positioned(
              top: 0,
              right: 0,
              child: Icon(
                Icons.circle,
                color: Colors.green,
                size: height_15,
              )),
      ],
    );
