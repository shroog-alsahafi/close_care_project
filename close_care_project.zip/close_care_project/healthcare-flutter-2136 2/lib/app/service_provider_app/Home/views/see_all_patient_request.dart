import 'package:healthcare/app/service_provider_app/Home/controllers/home_controller_provider.dart';
import 'package:intl/intl.dart';

import '../../../../export.dart';
import '../../../core/widgets/time_formatter.dart';

class SeeAllPatientRequest extends GetView<HomeControllerProvider> {
  const SeeAllPatientRequest({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        centerTitle: true,
        appBarTitleText: keyPatientRequest.tr,
        isBackIcon: true,
      ),
      body: Obx(
        () => ListView.separated(
          padding: EdgeInsets.symmetric(horizontal: margin_12),
          itemCount: controller.pendingList.length,
          physics: NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemBuilder: (context, index) {
            var booking = controller.pendingList[index];
            return Container(
              padding: EdgeInsets.all(margin_15),
              decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(radius_10)),
              child: commonListTitle(
                leadingImg: booking.profileFile,
                title: booking.fullName ?? "",
                subtitle: utcToLocalLatestNewsDate(booking.date.toString()) ?? "",
                shift: getShift(DateTime.parse(
                    utcToLocalLatest(DateFormat(dayFormatters).format(DateTime.now()) + booking.startTime!, "yyyy-MM-dd hh:mm:ss") ?? '')),
                trailingWidget: GestureDetector(
                  onTap: () {
                    var utcTime = booking.createdOn!.add(Duration(minutes: 5));
                    var localTime = DateTime.now();

                    // var diff = utcTime.toLocal().difference(localTime);
                    var diff = DateTime.parse(utcToLocalLatest(utcTime, "yyyy-MM-dd HH:mm:ss").toString()).difference(localTime);
                    if (diff.inSeconds < 1) {
                      controller.hitAcceptRejectApi(bookingId: booking.id, stateId: STATE_REJECTED, autoReject: true);
                    } else {
                      orderDialog(controller: controller, time: diff.inSeconds, booking: booking);
                    }
                  },
                  child: AssetImageWidget(
                    imageUrl: iconEye,
                    imageWidth: height_35,
                    imageHeight: height_35,
                  ),
                ),
              ),
            );
          },
          separatorBuilder: (BuildContext context, int index) {
            return SizedBox(
              height: height_10,
            );
          },
        ),
      ),
    );
  }
}
