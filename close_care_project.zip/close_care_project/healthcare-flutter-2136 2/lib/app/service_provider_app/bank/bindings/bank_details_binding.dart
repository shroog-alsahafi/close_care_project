import 'package:get/get.dart';

import '../controller/add_bank_controller.dart';
import '../controller/bank_list_controller.dart';
import '../controller/revenue_management_controller.dart';

class BankDetailsBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => RevenueManagementController());
    Get.lazyPut(() => AddBankController());
    Get.lazyPut(() => BankListController());
  }
}
