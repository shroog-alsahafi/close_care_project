import 'package:healthcare/app/service_provider_app/bank/controller/bank_list_controller.dart';

import '../../../../export.dart';
import '../model/bank_list_model_response.dart';

class AddBankController extends GetxController {
  final formGlobalKey = GlobalKey<FormState>();

  TextEditingController accountName = TextEditingController();
  TextEditingController accountNumber = TextEditingController();
  TextEditingController accountConfirmNumber = TextEditingController();
  TextEditingController ibanNumber = TextEditingController();
  TextEditingController confirmIbanNumber = TextEditingController();

  @override
  void onInit() {
    _getArg();
    super.onInit();
  }

  RxBool forEdit = false.obs;
  BankList bankDetail = BankList();
  _getArg() {
    if (Get.arguments != null) {
      forEdit.value = Get.arguments["forEdit"] ?? false;
      bankDetail = Get.arguments["bankDetail"];
      _setData();
    }
  }

  _setData() {
    accountName.text = bankDetail.accHolderName ?? "";
    accountNumber.text = bankDetail.accountNo ?? "";
    accountConfirmNumber.text = bankDetail.accountNo ?? "";
    ibanNumber.text = bankDetail.ibanNo ?? "";
    confirmIbanNumber.text = bankDetail.ibanNo ?? "";
  }

  void validateSubmitButton() {
    if (formGlobalKey.currentState!.validate()) {
      hitAddBankApi();
    }
  }

  hitAddBankApi() async {
    customLoader.show(Get.overlayContext);
    var requestModel = {
      "BankDetail[acc_holder_name]": accountName.text.trim(),
      "BankDetail[account_no]": accountNumber.text,
      "BankDetail[iban_no]": ibanNumber.text
    };
    try {
      final response = DioClient().post(
        forEdit.value ? "/api/user/update-bank" : "/api/user/add-bank-details",
        data: FormData.fromMap(requestModel),
        queryParameters: {"id": forEdit.value ? bankDetail.id : ""},
        skipAuth: false,
      );
      MessageResponseModel messageResponseModel = MessageResponseModel.fromJson(await response);
      customLoader.hide();
      Get.find<BankListController>().hitBankListApi();
      Get.back();
      showInSnackBar(message: messageResponseModel.message.toString());
    } catch (e, str) {
      customLoader.hide();
      Future.error(
        NetworkExceptions.getDioException(e, str, forEdit.value ? "/api/user/update-bank" : "/api/user/add-bank-details"),
      );
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  @override
  void onClose() {
    customLoader.hide();
    super.onClose();
  }
}
