import '../../../../export.dart';
import '../model/bank_list_model_response.dart';

class BankListController extends GetxController {
  onReady() {
    hitBankListApi();
    super.onReady();
  }

  RxList<BankList> bankList = <BankList>[].obs;
  int page = 0;
  BankListResponseModel bankListResponseModel = BankListResponseModel();

  RxBool isLoading = false.obs;
  hitBankListApi() async {
    isLoading.value = true;
    try {
      final response = DioClient().get(
        "/api/user/bank-list",
        queryParameters: {"page": page},
        skipAuth: false,
      );
      bankListResponseModel = BankListResponseModel.fromJson(await response);
      if (page == 0) {
        bankList.clear();
      }
      isLoading.value = false;
      bankList.addAll(bankListResponseModel.list ?? []);
    } catch (e, str) {
      isLoading.value = false;
      Future.error(NetworkExceptions.getDioException(e, str, "/service/user/bank-list"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  hitDeleteBankApi({id}) async {
    customLoader.show(Get.overlayContext);
    try {
      final response = DioClient().get(
        "/api/user/delete-bank",
        queryParameters: {"id": id},
        skipAuth: false,
      );
      MessageResponseModel messageResponseModel = MessageResponseModel.fromJson(await response);

      showInSnackBar(message: messageResponseModel.message ?? "");
      customLoader.hide();
      hitBankListApi();
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/user/delete-bank"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  @override
  void onClose() {
    customLoader.hide();
    super.onClose();
  }
}
