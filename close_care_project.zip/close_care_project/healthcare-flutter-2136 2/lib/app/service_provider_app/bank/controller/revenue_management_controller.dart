import '../../../../export.dart';
import '../model/revenue_res_model.dart';

class RevenueManagementController extends GetxController {
  RxInt selectTab = 0.obs;

  @override
  void onInit() {
    _getArg();
    super.onInit();
  }

  RxBool comingFromNurse = false.obs;
  _getArg() {
    if (Get.arguments != null) {
      comingFromNurse.value = Get.arguments["comingFromNurse"];
    }
  }

  @override
  onReady() {
    paginateItemList();
    hitApi();
    super.onReady();
  }

  int page = 0;

  hitApi() {
    if (selectTab.value == 0) {
      hitBookingListApi(type: WEEKLY);
    } else if (selectTab.value == 1) {
      hitBookingListApi(type: MONTHLY);
    } else if (selectTab.value == 2) {
      hitBookingListApi(type: YEARLY);
    } else {
      hitBookingListApi();
    }
  }

  RxList<RevenueList> revenueList = <RevenueList>[].obs;
  Rx<RevenueResModel> revenueResModel = RevenueResModel().obs;

  RxBool isLoading = false.obs;
  hitBookingListApi({type}) async {
    isLoading.value = true;
    try {
      final response = DioClient().get(
        "/api/booking/revenue",
        skipAuth: false,
        queryParameters: {"page": page, "type": type ?? ""},
      );
      revenueResModel.value = RevenueResModel.fromJson(await response);
      if (page == 0) {
        revenueList.clear();
      }
      revenueList.addAll(revenueResModel.value.list ?? []);
      isLoading.value = false;
    } catch (e, str) {
      isLoading.value = false;
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/revenue"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  ScrollController scrollController = ScrollController();
  paginateItemList() {
    scrollController.addListener(() {
      if (scrollController.position.pixels == scrollController.position.maxScrollExtent) {
        if (page < revenueResModel.value.meta!.pageCount!) {
          page++;
          hitApi();
        }
      }
    });
  }
}
