// To parse this JSON data, do
//
//     final bankListResponseModel = bankListResponseModelFromJson(jsonString);

import 'dart:convert';

BankListResponseModel bankListResponseModelFromJson(String str) => BankListResponseModel.fromJson(json.decode(str));

String bankListResponseModelToJson(BankListResponseModel data) => json.encode(data.toJson());

class BankListResponseModel {
  List<BankList>? list;

  Meta? meta;
  String? copyrights;

  BankListResponseModel({
    this.list,

    this.meta,
    this.copyrights,
  });

  factory BankListResponseModel.fromJson(Map<String, dynamic> json) => BankListResponseModel(
    list: List<BankList>.from(json["list"].map((x) => BankList.fromJson(x))),

    meta: Meta.fromJson(json["_meta"]),
    copyrights: json["copyrights"],
  );

  Map<String, dynamic> toJson() => {
    "list": List<dynamic>.from(list!.map((x) => x.toJson())),

    "_meta": meta!.toJson(),
    "copyrights": copyrights,
  };
}



class BankList {
  int? id;
  String? accHolderName;
  String? accountNo;
  String? ibanNo;
  int? stateId;
  int? typeId;
  DateTime? createdOn;
  int? createdById;

  BankList({
    this.id,
    this.accHolderName,
    this.accountNo,
    this.ibanNo,
    this.stateId,
    this.typeId,
    this.createdOn,
    this.createdById,
  });

  factory BankList.fromJson(Map<String, dynamic> json) => BankList(
    id: json["id"],
    accHolderName: json["acc_holder_name"],
    accountNo: json["account_no"],
    ibanNo: json["iban_no"],
    stateId: json["state_id"],
    typeId: json["type_id"],
    createdOn: DateTime.parse(json["created_on"]),
    createdById: json["created_by_id"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "acc_holder_name": accHolderName,
    "account_no": accountNo,
    "iban_no": ibanNo,
    "state_id": stateId,
    "type_id": typeId,
    "created_on": createdOn!.toIso8601String(),
    "created_by_id": createdById,
  };
}

class Meta {
  int? totalCount;
  int? pageCount;
  int? currentPage;
  int? perPage;

  Meta({
    this.totalCount,
    this.pageCount,
    this.currentPage,
    this.perPage,
  });

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
    totalCount: json["totalCount"],
    pageCount: json["pageCount"],
    currentPage: json["currentPage"],
    perPage: json["perPage"],
  );

  Map<String, dynamic> toJson() => {
    "totalCount": totalCount,
    "pageCount": pageCount,
    "currentPage": currentPage,
    "perPage": perPage,
  };
}
