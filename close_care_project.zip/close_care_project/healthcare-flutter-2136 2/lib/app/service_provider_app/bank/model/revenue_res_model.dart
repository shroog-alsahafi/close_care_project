import 'dart:convert';

import '../../../core/model/meta.dart';

RevenueResModel revenueResModelFromJson(String str) => RevenueResModel.fromJson(json.decode(str));

String revenueResModelToJson(RevenueResModel data) => json.encode(data.toJson());

class RevenueResModel {
  List<RevenueList>? list;
  Links? links;
  Meta? meta;
  double? totalRevenue;

  RevenueResModel({
    this.list,
    this.links,
    this.meta,
    this.totalRevenue,
  });

  factory RevenueResModel.fromJson(Map<String, dynamic> json) => RevenueResModel(
        list: json["list"] == null ? [] : List<RevenueList>.from(json["list"]!.map((x) => RevenueList.fromJson(x))),
        links: json["_links"] == null ? null : Links.fromJson(json["_links"]),
        meta: json["_meta"] == null ? null : Meta.fromJson(json["_meta"]),
        totalRevenue: json["total_revenue"]?.toDouble(),
      );

  Map<String, dynamic> toJson() => {
        "list": list == null ? [] : List<dynamic>.from(list!.map((x) => x.toJson())),
        "_links": links?.toJson(),
        "_meta": meta?.toJson(),
        "total_revenue": totalRevenue,
      };
}

class RevenueList {
  int? id;
  int? bookingId;
  String? finalAmount;
  String? adminAmount;
  String? providerAmount;
  int? stateId;
  int? typeId;
  DateTime? createdOn;
  int? createdById;
  int? providerId;
  String? createdByImage;
  String? createdByName;

  RevenueList({
    this.id,
    this.bookingId,
    this.finalAmount,
    this.adminAmount,
    this.providerAmount,
    this.stateId,
    this.typeId,
    this.createdOn,
    this.createdById,
    this.providerId,
    this.createdByImage,
    this.createdByName,
  });

  factory RevenueList.fromJson(Map<String, dynamic> json) => RevenueList(
        id: json["id"],
        bookingId: json["booking_id"],
        finalAmount: json["final_amount"],
        adminAmount: json["admin_amount"],
        providerAmount: json["provider_amount"],
        stateId: json["state_id"],
        typeId: json["type_id"],
        createdOn: json["created_on"] == null ? null : DateTime.parse(json["created_on"]),
        createdById: json["created_by_id"],
        providerId: json["provider_id"],
        createdByImage: json["created_by_image"],
        createdByName: json["created_by_name"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "booking_id": bookingId,
        "final_amount": finalAmount,
        "admin_amount": adminAmount,
        "provider_amount": providerAmount,
        "state_id": stateId,
        "type_id": typeId,
        "created_on": createdOn?.toIso8601String(),
        "created_by_id": createdById,
        "provider_id": providerId,
        "created_by_image": createdByImage,
        "created_by_name": createdByName,
      };
}
