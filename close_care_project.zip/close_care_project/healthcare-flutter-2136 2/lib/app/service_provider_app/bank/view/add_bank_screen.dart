import '../../../../export.dart';
import '../../../core/utils/validator.dart';
import '../controller/add_bank_controller.dart';

class AddBankDetailsScreen extends GetView<AddBankController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        appBarTitleText: keyBankDetail.tr,
        centerTitle: true,
        isBackIcon: true,
      ),
      body: Form(
        key: controller.formGlobalKey,
        child: SingleChildScrollView(
          child: Column(
            children: [
              inputField(
                  tvHeading: keyAccountHolderName.tr,
                  maxLine: 1,
                  controller: controller.accountName,
                  validate: (value) => Validator.fieldChecker(value, keyAccountHolderNameMatch.tr),
                  type: TextInputType.name),
              inputField(
                  tvHeading: keyAccountNumber.tr,
                  maxLine: 1,
                  maxLength: 16,
                  controller: controller.accountNumber,
                  inputFormatter: [
                    FilteringTextInputFormatter.allow(RegExp("[0-9\u0660-\u0669]")),
                    new FilteringTextInputFormatter.deny(RegExp(r'^0+(?=.)')),
                  ],
                  validate: (value) => PasswordFormValidator.accountNo(value),
                  type: TextInputType.number),
              inputField(
                  tvHeading: keyConfirmAccountNumber.tr,
                  maxLine: 1,
                  maxLength: 16,
                  controller: controller.accountConfirmNumber,
                  inputFormatter: [
                    FilteringTextInputFormatter.allow(
                      RegExp(r'[0-9]'),
                    ),
                    FilteringTextInputFormatter.deny(
                      RegExp(r'^0+'),
                    ),
                  ],
                  validate: (value) {
                    return PasswordFormValidator.confirmAccountNo(
                        value: value,
                        valueMessage: keyConfirmAccountNumberEmpty.tr,
                        repeatMatch: keyConfirmAccountNumberMatch.tr,
                        password: controller.accountNumber.text);
                  },
                  type: TextInputType.number),
              inputField(
                  tvHeading: keyIBANNumber.tr,
                  maxLine: 1,
                  maxLength: 34,
                  inputFormatter: [
                    FilteringTextInputFormatter.allow(
                      RegExp(r'[0-9]'),
                    ),
                    FilteringTextInputFormatter.deny(
                      RegExp(r'^0+'),
                    ),
                  ],
                  validate: (value) => PasswordFormValidator.ibanNumber(value),
                  controller: controller.ibanNumber,
                  type: TextInputType.number),
              inputField(
                  tvHeading: keyConfirmIBANNumber.tr,
                  maxLine: 1,
                  maxLength: 34,
                  controller: controller.confirmIbanNumber,
                  validate: (value) {
                    return PasswordFormValidator.confirmAccountNo(
                        value: value,
                        valueMessage: keyConfirmationIbanNumber.tr,
                        repeatMatch: keyConfirmIBANNumberMatch.tr,
                        password: controller.ibanNumber.text);
                  },
                  type: TextInputType.number),
              saveButton()
            ],
          ).paddingSymmetric(horizontal: margin_15),
        ),
      ),
    );
  }

  inputField({tvHeading, validate, controller, focusNode, maxLength, maxLine, type, inputFormatter}) {
    return TextFieldWidget(
      radius: radius_10,
      maxLength: maxLength,
      textController: controller,
      maxline: maxLine ?? 15,
      tvHeadingFont: font_14,

      inputFormatter: inputFormatter,
      minLine: maxLine,
      inputType: type,
      decoration: DecoratedInputBorder(
        child: OutlineInputBorder(
            borderRadius: BorderRadius.circular(margin_10),
            borderSide: BorderSide(color: Colors.grey.shade400, style: BorderStyle.solid, width: width_1)),
        shadow: BoxShadow(
          color: Colors.transparent,
          blurRadius: 1,
          spreadRadius: 1,
        ),
      ),
      contentPadding: EdgeInsets.symmetric(vertical: margin_17, horizontal: margin_15),
      tvHeading: tvHeading,

      tvHeadingFontWeight: FontWeight.w400,
      // textController: controller.emailController,
      validate: validate, /* focusNode: controller.emailFocusNode*/
    ).paddingSymmetric(vertical: margin_10);
  }

  saveButton() {
    return MaterialButtonWidget(
      buttonRadius: radius_5,
      padding: margin_14,
      buttonText: keySave.tr,
      onPressed: () {
        controller.validateSubmitButton();
      },
    ).paddingSymmetric(vertical: margin_20);
  }
}
