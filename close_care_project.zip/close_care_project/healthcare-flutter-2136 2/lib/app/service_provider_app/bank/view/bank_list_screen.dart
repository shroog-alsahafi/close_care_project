import 'package:healthcare/app/service_provider_app/bank/controller/bank_list_controller.dart';

import '../../../../export.dart';

class BankListScreen extends GetView<BankListController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: CustomAppBar(
          centerTitle: true,
          appBarTitleText: keyBankList.tr,
          isBackIcon: true,
          actionWidget: [
            Obx(
              () => Visibility(
                visible: controller.bankList.length < 3,
                child: IconButton(
                    onPressed: () {
                      Get.toNamed(AppRoutes.bankDetails);
                    },
                    icon: Icon(
                      Icons.add,
                      size: height_30,
                    )),
              ),
            ),
            SizedBox(
              width: width_8,
            ),
          ],
        ),
        body: Obx(() {
          return controller.isLoading.value
              ? Center(
                  child: CircularProgressIndicator(
                  color: colorAppColors,
                ))
              : controller.bankList.isNotEmpty
                  ? ListView.separated(
                      itemCount: controller.bankList.length,
                      shrinkWrap: true,
                      padding: EdgeInsets.symmetric(horizontal: margin_15),
                      itemBuilder: (BuildContext context, int index) {
                        return Container(
                          decoration: BoxDecoration(color: greyColor, borderRadius: BorderRadius.circular(radius_10)),
                          child: IntrinsicHeight(
                            child: Row(
                              children: [
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      customRow(
                                        title: "${keyAccountHolderName.tr}",
                                        value: "   ${controller.bankList[index].accHolderName}",
                                        verticalPadding: margin_0,
                                      ),
                                      customRow(
                                        title: "${keyAccountNumber.tr}",
                                        value: "   ${controller.bankList[index].accountNo}",
                                        verticalPadding: margin_2,
                                      ),
                                      customRow(
                                        title: "${keyIBANNumber.tr}",
                                        value: "   ${controller.bankList[index].ibanNo}",
                                        verticalPadding: margin_0,
                                      ),
                                    ],
                                  ).paddingOnly(top: margin_10, bottom: margin_10),
                                ),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    IconButton(
                                        onPressed: () {
                                          controller.hitDeleteBankApi(id: controller.bankList[index].id);
                                        },
                                        icon: Icon(Icons.delete_forever_outlined)),
                                    GestureDetector(
                                      onTap: () {
                                        Get.toNamed(
                                          AppRoutes.bankDetails,
                                          arguments: {
                                            "forEdit": true,
                                            "bankDetail": controller.bankList[index],
                                          },
                                        );
                                      },
                                      child: AssetImageWidget(
                                        imageUrl: iconEdit,
                                        imageHeight: height_20,
                                        imageWidth: height_20,
                                      ),
                                    ),
                                  ],
                                ).paddingOnly(bottom: margin_10)
                              ],
                            ),
                          ),
                        );
                      },
                      separatorBuilder: (BuildContext context, int index) {
                        return SizedBox(height: height_5);
                      },
                    )
                  : noDataToShow(inputText: keyNoBankAddedYet.tr);
        }).paddingOnly(bottom: height_10));
  }
}
