import 'package:healthcare/app/service_provider_app/bank/controller/revenue_management_controller.dart';

import '../../../../export.dart';

class RevenueManagementScreen extends GetView<RevenueManagementController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        appBarTitleText: keyRevenueManagement.tr,
        isBackIcon: true,
        centerTitle: true,
      ),
      body: Column(
        children: [
          totalRevenue(),
          _tabWidget(),
          SizedBox(height: height_10),
          revenueList(),
        ],
      ).paddingSymmetric(horizontal: margin_12),
    );
  }

  totalRevenue() {
    return Container(
      padding: EdgeInsets.symmetric(vertical: margin_35, horizontal: margin_20),
      margin: EdgeInsets.only(bottom: margin_20),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(radius_8), color: colorAppColor),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          TextView(text: keyTotalRevenue.tr, textStyle: textStyle(fontSize: font_16, color: Colors.white)),
          Obx(
            () => TextView(
              text: "\$ " + "${controller.revenueResModel.value.totalRevenue ?? "0"}",
              textStyle: textStyle(fontSize: font_28, color: Colors.white),
            ),
          )
        ],
      ),
    );
  }

  textStyle({fontSize, color, fontWeight}) {
    return textStyleBody1().copyWith(fontSize: fontSize ?? font_15, color: color ?? colorAppColor, fontWeight: fontWeight ?? null);
  }

  revenueList() => Expanded(
        child: Obx(
          () => controller.isLoading.value
              ? Center(child: CircularProgressIndicator(color: colorAppColors))
              : controller.revenueList.length == 0
                  ? noDataToShow()
                  : ListView.builder(
                      itemCount: controller.revenueList.length,
                      itemBuilder: (context, index) {
                        var revenue = controller.revenueList[index];
                        return Container(
                          padding: EdgeInsets.symmetric(vertical: margin_10, horizontal: margin_8),
                          margin: EdgeInsets.symmetric(vertical: margin_10),
                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(radius_8), color: greyColor),
                          child: Row(
                            children: [
                              NetworkImageWidget(
                                imageurl: revenue.createdByImage,
                                imageHeight: height_60,
                                imageWidth: height_60,
                                radiusAll: radius_10,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  TextView(text: revenue.createdByName ?? "", textStyle: textStyle(color: Colors.black, fontWeight: FontWeight.w400)),
                                  TextView(text: keyCredit.tr, textStyle: textStyle(fontSize: font_14, color: Colors.green, fontWeight: FontWeight.w500))
                                      .paddingOnly(top: margin_3),
                                ],
                              ).paddingOnly(left: margin_15),
                              Spacer(),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  TextView(
                                    text: '\$${revenue.providerAmount ?? ""}',
                                    textStyle: textStyle(
                                      fontSize: font_18,
                                      color: Colors.green,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      TextView(
                                        text: utcToLocalLatest(revenue.createdOn, "dd MMM,yyyy"),
                                        textStyle: textStyle(
                                          fontSize: font_12,
                                          color: Colors.grey.shade700,
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ),
                                      Container(
                                        width: 2,
                                        color: Colors.grey.shade400,
                                        height: height_10,
                                        margin: EdgeInsets.symmetric(horizontal: margin_8),
                                      ),
                                      TextView(
                                        text: utcToLocalLatest(revenue.createdOn, "hh:mm a"),
                                        textStyle: textStyle(
                                          fontSize: font_12,
                                          color: Colors.grey.shade700,
                                          fontWeight: FontWeight.w400,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ).paddingOnly(
                                left: margin_5,
                              )
                            ],
                          ),
                        );
                      }),
        ),
      );

  _tabWidget() => SizedBox(
        height: height_30,
        child: IntrinsicHeight(
          child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: 3,
              itemBuilder: (context, index) {
                return Obx(() => GestureDetector(
                      onTap: () {
                        controller.selectTab.value = index;
                        controller.hitApi();
                      },
                      child: Container(
                        alignment: Alignment.center,
                        padding: EdgeInsets.symmetric(horizontal: margin_15),
                        margin: EdgeInsets.only(right: margin_10),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(radius_6),
                            border: Border.all(color: colorAppColor),
                            color: controller.selectTab.value == index ? colorAppColor : Colors.white),
                        child: TextView(
                            text: [keyWeekly.tr, keyMonthly.tr, keyYearly.tr][index],
                            textStyle: textStyleBodyMedium().copyWith(
                              fontSize: font_16,
                              fontWeight: FontWeight.w400,
                              color: controller.selectTab.value == index ? Colors.white : colorAppColor,
                            )),
                      ),
                    ));
              }),
        ),
      );
}
