import '../../../modules/bookings/controller/bookings_view_list_controller.dart';
import '../controllers/booking_detail_controller_provider.dart';
import '../../../../export.dart';
import '../controllers/submit_report_controller.dart';

class BookingDetailBindingProvider extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => BookingsDetailControllerProvider());
    Get.lazyPut(() => BookingsViewController());
    Get.lazyPut(() => SubmitReportController());
  }
}
