import 'package:healthcare/app/service_provider_app/Home/models/booking_provider_res_model.dart';
import 'package:healthcare/app/service_provider_app/bookings/model/response_model/booking_detail_res_model.dart';

import '../../../../export.dart';

class BookingsDetailControllerProvider extends GetxController {
  var bookingId;
  RxBool isFromNotification = false.obs;

  @override
  void onInit() {
    _getArgs();
    super.onInit();
  }

  BookingListProvider bookingListProvider = BookingListProvider();

  _getArgs() {
    if (Get.arguments != null) {
      if(Get.arguments["booking"]!=null) {
        bookingListProvider = Get.arguments["booking"];
      }
      if (Get.arguments[argBookingID] != null) {
        bookingId = Get.arguments[argBookingID] ?? '';
        isFromNotification.value = Get.arguments['argIsFromNotification'] ?? false;
      }
    }
  }

  @override
  void onReady() {
    hitBookingDetailsApi();
    super.onReady();
  }

  BookingDetailResModel bookingDetailResModel = BookingDetailResModel();
  BookingDetail bookingDetail = BookingDetail();
  RxBool isLoading = false.obs;

  hitBookingDetailsApi() async {
    isLoading.value = true;
    try {
      final response = DioClient().get(
        "/api/booking/patient-info",
        queryParameters: {
          "id": bookingListProvider.id ?? bookingId,
        },
        skipAuth: false,
      );
      bookingDetailResModel = BookingDetailResModel.fromJson(await response);
      if (bookingDetailResModel.detail != null) {
        bookingDetail = bookingDetailResModel.detail!;
        isLoading.value = false;
        update();
      }
    } catch (e, str) {
      print("eeeeeee$e\n$str");
      isLoading.value = false;
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/patient-info"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  hitAcceptRejectApi({stateID}) async {
    customLoader.show(Get.overlayContext!);
    try {
      final response = DioClient().post(
        "/api/booking/change-state",
        queryParameters: {"id": bookingDetail.id, "state_id": stateID},
        skipAuth: false,
      );
      MessageResponseModel messageResponseModel = MessageResponseModel.fromJson(await response);
      hitBookingDetailsApi();
      showInSnackBar(message: messageResponseModel.message ?? "");

      customLoader.hide();
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/change-state"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}
