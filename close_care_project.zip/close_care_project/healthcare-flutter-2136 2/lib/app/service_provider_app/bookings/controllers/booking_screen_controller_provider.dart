import '../../../../export.dart';
import '../../Home/models/booking_provider_res_model.dart';

class BookingsScreenControllerProvider extends GetxController {
  int page = 0;
  var id;

  @override
  void onReady() {
    if (id != null) {
      hitUserBookingListApi();
    } else {
      hitBookingListApi();
    }
    super.onReady();
  }

  BookingProviderResModel bookingProviderResModel = BookingProviderResModel();
  RxList<BookingListProvider> bookingList = <BookingListProvider>[].obs;

  RxBool isLoading = false.obs;

  hitBookingListApi() async {
    isLoading.value = true;
    try {
      final response = DioClient().get(
        "/api/booking/list",
        skipAuth: false,
        queryParameters: {"page": page, "type": ""},
      );
      bookingProviderResModel = BookingProviderResModel.fromJson(await response);
      if (page == 0) {
        bookingList.clear();
      }
      isLoading.value = false;
      bookingList.addAll(bookingProviderResModel.list ?? []);
      bookingList.refresh();
    } catch (e, str) {
      isLoading.value = false;
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/list"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  hitUserBookingListApi() async {
    isLoading.value = true;
    try {
      final response = DioClient().get(
        "/api/booking/patient-booking",
        skipAuth: false,
        queryParameters: {"page": page, "id": id ?? ""},
      );
      bookingProviderResModel = BookingProviderResModel.fromJson(await response);
      if (page == 0) {
        bookingList.clear();
      }
      isLoading.value = false;
      bookingList.addAll(bookingProviderResModel.list ?? []);
      bookingList.refresh();
    } catch (e, str) {
      isLoading.value = false;
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/patient-booking"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  @override
  void onInit() {
    getArgument();
    super.onInit();
  }

  getArgument() {
    if (Get.arguments != null) {
      id = Get.arguments['id'] ?? '';
    }
  }
}
