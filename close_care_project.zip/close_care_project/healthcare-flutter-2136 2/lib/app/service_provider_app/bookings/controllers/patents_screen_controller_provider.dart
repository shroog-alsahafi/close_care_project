import 'package:healthcare/app/service_provider_app/bookings/model/data_model/booking_data_model.dart';
import 'package:healthcare/app/service_provider_app/bookings/model/response_model/booking_list_response_model.dart';

import '../../../../export.dart';
import '../../../modules/bookings/model/patient_list_response_model.dart';
import '../../Home/models/booking_provider_res_model.dart';

class PatientsScreenControllerProvider extends GetxController {
  var selectedType = BOOKING_TYPE_TODAY;
  RxInt selectedIndex = 0.obs;
  int page = 0;

  RxList<String> tabBarListing = <String>[
    keyToday.tr,
    keyUpcoming.tr,
    keyPast.tr,
  ].obs;

  @override
  void onReady() {
    paginateItemsList();
    hitBookingListingApiCall();
    super.onReady();
  }

  // BookingProviderResModel bookingProviderResModel = BookingProviderResModel();
  PatientListResponseModel bookingProviderResModel = PatientListResponseModel();
  // RxList<BookingListProvider> bookingList = <BookingListProvider>[].obs;
  RxList<PatientDataModel> bookingList = <PatientDataModel>[].obs;

  RxBool isLoading = false.obs;

  hitBookingListingApiCall() async {
    if (page == 0) {
      isLoading.value = true;
      bookingList.clear();
    }
    try {
      final response = DioClient().get(
        "/api/booking/patient-list",
        queryParameters: {
          "page": page,
          "type": '',
        },
        skipAuth: false,
      );
      bookingProviderResModel = PatientListResponseModel.fromJson(await response);
      bookingList.addAll(bookingProviderResModel.list ?? []);
      bookingList.refresh();
      isLoading.value = false;
    } catch (e, str) {
      isLoading.value = false;
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/list"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  ScrollController scrollController = ScrollController();
  paginateItemsList() {
    scrollController.addListener(() {
      if (scrollController.position.pixels == scrollController.position.maxScrollExtent) {
        if (page < bookingProviderResModel.mMeta!.pageCount!) {
          page++;
          hitBookingListingApiCall();
        }
      }
    });
  }
}
