import 'package:healthcare/app/service_provider_app/bookings/controllers/booking_detail_controller_provider.dart';
import 'package:healthcare/app/service_provider_app/bookings/model/response_model/booking_detail_res_model.dart';

import '../../../../export.dart';

class SubmitReportController extends GetxController {
  final formGlobalKey = GlobalKey<FormState>();

  TextEditingController patientNameController = TextEditingController();
  TextEditingController dobController = TextEditingController();
  TextEditingController ageController = TextEditingController();
  TextEditingController nationalityController = TextEditingController();
  TextEditingController bloodPressureController = TextEditingController();
  TextEditingController pulseController = TextEditingController();
  TextEditingController tempController = TextEditingController();
  TextEditingController skinController = TextEditingController();
  TextEditingController conclusionController = TextEditingController();

  void validateSubmitButton() {
    if (formGlobalKey.currentState!.validate()) {
      _hitSubmitReportApi();
    }
  }

  @override
  void onInit() {
    _getArgs();
    super.onInit();
  }

  BookingDetail bookingDetail = BookingDetail();
  _getArgs() {
    if (Get.arguments != null) {
      bookingDetail = Get.arguments["bookingDetail"];
      _setData();
    }
  }

  _setData() {
    patientNameController..text = bookingDetail.createdBy?.fullName ?? "";
    dobController..text = bookingDetail.createdBy?.dateOfBirth ?? "";
    ageController..text = calculateAge(bookingDetail.createdBy!.dateOfBirth!).toString();
    ageController..text = calculateAge(bookingDetail.createdBy!.dateOfBirth!).toString();
  }

  _hitSubmitReportApi() async {
    customLoader.show(Get.overlayContext!);
    try {
      var requestData = {
        "Report[name]": patientNameController.text,
        "Report[patient_id]": bookingDetail.createdBy?.id ?? "",
        "Report[provider_id]": bookingDetail.providerId ?? "",
        "Report[booking_id]": bookingDetail.id,
        "Report[date_of_birth]": dobController.text,
        "Report[age]": ageController.text,
        "Report[nationality]": nationalityController.text,
        "Report[blood_pressure]": bloodPressureController.text,
        "Report[pulse]": pulseController.text,
        "Report[temperature]": tempController.text,
        "Report[skin]": skinController.text,
        "Report[conclusion]": conclusionController.text,
      };

      final response = DioClient().post(
        "/api/booking/report",
        data: FormData.fromMap(requestData),
        skipAuth: false,
      );
      MsgResModel msgResModel = MsgResModel.fromJson(await response);
      customLoader.hide();
      Get.find<BookingsDetailControllerProvider>().hitBookingDetailsApi();
      Get.back();
      showInSnackBar(message: msgResModel.message ?? "");
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/booking/report"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}

MsgResModel msgResModelFromJson(String str) => MsgResModel.fromJson(json.decode(str));

String msgResModelToJson(MsgResModel data) => json.encode(data.toJson());

class MsgResModel {
  String? message;
  Details? details;
  String? copyrights;

  MsgResModel({
    this.message,
    this.details,
    this.copyrights,
  });

  factory MsgResModel.fromJson(Map<String, dynamic> json) => MsgResModel(
        message: json["message"],
        details: json["details"] == null ? null : Details.fromJson(json["details"]),
        copyrights: json["copyrights"],
      );

  Map<String, dynamic> toJson() => {
        "message": message,
        "details": details?.toJson(),
        "copyrights": copyrights,
      };
}

class Details {
  int? id;
  String? name;
  String? patientId;
  String? bookingId;
  DateTime? dateOfBirth;
  String? age;
  String? nationality;
  String? bloodPressure;
  String? pulse;
  String? temperature;
  String? skin;
  String? conclusion;
  int? stateId;
  dynamic typeId;

  Details({
    this.id,
    this.name,
    this.patientId,
    this.bookingId,
    this.dateOfBirth,
    this.age,
    this.nationality,
    this.bloodPressure,
    this.pulse,
    this.temperature,
    this.skin,
    this.conclusion,
    this.stateId,
    this.typeId,
  });

  factory Details.fromJson(Map<String, dynamic> json) => Details(
        id: json["id"],
        name: json["name"],
        patientId: json["patient_id"],
        bookingId: json["booking_id"],
        dateOfBirth: json["date_of_birth"] == null ? null : DateTime.parse(json["date_of_birth"]),
        age: json["age"],
        nationality: json["nationality"],
        bloodPressure: json["blood_pressure"],
        pulse: json["pulse"],
        temperature: json["temperature"],
        skin: json["skin"],
        conclusion: json["conclusion"],
        stateId: json["state_id"],
        typeId: json["type_id"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "patient_id": patientId,
        "booking_id": bookingId,
        "date_of_birth":
            "${dateOfBirth!.year.toString().padLeft(4, '0')}-${dateOfBirth!.month.toString().padLeft(2, '0')}-${dateOfBirth!.day.toString().padLeft(2, '0')}",
        "age": age,
        "nationality": nationality,
        "blood_pressure": bloodPressure,
        "pulse": pulse,
        "temperature": temperature,
        "skin": skin,
        "conclusion": conclusion,
        "state_id": stateId,
        "type_id": typeId,
      };
}
