import 'package:flutter/cupertino.dart';
import 'package:healthcare/app/service_provider_app/Home/controllers/home_controller_provider.dart';
import 'package:healthcare/app/service_provider_app/bookings/controllers/booking_detail_controller_provider.dart';
import 'package:intl/intl.dart';

import '../../../../export.dart';
import '../../../core/widgets/time_formatter.dart';

class BookingDetailProvider extends GetView<BookingsDetailControllerProvider> {
  const BookingDetailProvider({super.key});

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (controller.isFromNotification.value == true) {
          isNotified = false;
          Get.offAllNamed(AppRoutes.mainScreenProvider);
        } else {
          Get.back();
        }
        return true;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: CustomAppBar(
          leadingIcon:InkWell(
            onTap:() {
              if (controller.isFromNotification.value == true) {
                isNotified = false;
                Get.offAllNamed(AppRoutes.mainScreenProvider);
              } else {
                Get.back();
              }
            },
            child: Icon(
              Icons.arrow_back_ios,
              size: height_22,
              color: colorAppColor,
            ).paddingOnly(top: margin_20, left: margin_10),
          ),
          centerTitle: true,
          appBarTitleText: keyPatientDetails.tr,
        ),
        body: Obx(
          () => controller.isLoading.value
              ? Center(
                  child: CircularProgressIndicator(
                    color: colorAppColors,
                  ),
                )
              : ListView(
                  padding: EdgeInsets.symmetric(horizontal: margin_16),
                  children: [
                    SizedBox(
                      height: height_15,
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: NetworkImageWidget(
                        imageurl: controller.bookingDetail.createdBy?.profileFile ?? "",
                        imageWidth: height_70,
                        imageHeight: height_70,
                        imageFitType: BoxFit.cover,
                        radiusAll: radius_10,
                      ),
                    ),
                    TextView(text: controller.bookingDetail.createdBy?.fullName ?? "", textStyle: textStyleBody1()),
                    TextView(text: "${keyAppointmentNO.tr}: ${controller.bookingDetail.appointmentNo}", textStyle: textStyleTitle().copyWith(color: Colors.grey)),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        titleTxt(title: keyAppointmentStatus.tr),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: margin_3, horizontal: margin_8),
                          margin: EdgeInsets.symmetric(horizontal: margin_8),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(radius_5),
                            color: statusTextColor(stateId: controller.bookingDetail.stateId),
                          ),
                          child: TextView(
                            text: statusTxt(stateId: controller.bookingDetail.stateId),
                            textStyle: textStyleBody1().copyWith(fontSize: font_12, color: Colors.white),
                          ),
                        ),
                      ],
                    ),

                    Container(
                      padding: EdgeInsets.all(margin_5),
                      decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(radius_10)),
                      child: Column(
                        children: [
                          customRow(leadingIcon: iconCalender, title: "${keyDayAndDate.tr}:  ", value: "${utcToLocalLatestNewsDate("${controller.bookingDetail.date}")}"),
                          customRow(
                            leadingIcon: iconVector,
                            title: "${keyShitAndTime.tr}:  ",
                            value:
                                "${getShift(DateTime.parse(utcToLocalLatest(DateFormat(dayFormatters).format(DateTime.now()) + controller.bookingDetail.startTime!, "yyyy-MM-dd hh:mm:ss") ?? ''))},"
                                "${utcToLocalLatest(DateFormat(dayFormatters).format(DateTime.now()) + controller.bookingDetail.startTime!, "hh:mm a") ?? ''}",
                          ),
                          customRow(leadingIcon: iconCreditCard, title: "${keyPaymentMode.tr}:  ", value: "Online"),
                          customRow(leadingIcon: iconMap, title: "${keyLocation.tr}:  ", value: controller.bookingDetail.createdBy?.location ?? ""),
                        ],
                      ),
                    ),
                    titleTxt(title: keyAboutPatient.tr),
                    Container(
                      padding: EdgeInsets.all(margin_5),
                      decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(radius_10)),
                      child: Column(
                        children: [
                          customRow(title: "${keyAge.tr}:  ", value: "${calculateAge(controller.bookingDetail.createdBy!.dateOfBirth!)}"),
                          customRow(title: "${keyGender.tr}:  ", value: getGender(id: controller.bookingDetail.createdBy!.gender!)),
                          customRow(title: "${keyWeight.tr}:  ", value: "${controller.bookingDetail.createdBy!.weight!}Kg"),
                          customRow(title: "${keyBloodGroup.tr}:  ", value: "${controller.bookingDetail.createdBy!.bloodGroup!}"),
                        ],
                      ),
                    ),

                    ///for future use
                    /*   titleTxt(title: "Additional Details"),
                TextView(
                    textAlign: TextAlign.start,
                    text: "I want my list somewhere in the background, and during a session, you can" * 2,
                    textStyle: textStyleTitle().copyWith(
                      fontSize: font_12,
                    )),*/
                    titleTxt(title: keyServicesNeeded.tr),
                    neededServicesList(),
                    titleTxt(title: keyPrice.tr),
                    Container(
                      padding: EdgeInsets.symmetric(vertical: margin_5),
                      decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(radius_10)),
                      child: Column(
                        children: [
                          customRow(title: "${keyServiceFee.tr}:  ", value: "\$${controller.bookingDetail.price}", space: true),
                          Divider(height: height_1, color: Colors.grey.shade400),
                          customRow(title: "${keyBookingFee.tr}:  ", value: "\$${controller.bookingDetail.commission ?? 0}", space: true),
                          Divider(height: height_1, color: Colors.grey.shade400),
                          customRow(
                              title: "${keyTotalPrice.tr}:  ",
                              value: "\$${double.parse(controller.bookingDetail.totalPrice ?? "0")}",
                              space: true),
                        ],
                      ),
                    ),
                    if (controller.bookingDetail.uploadReport!.length > 0) _upLoadedReport(),

                    SizedBox(height: height_10),
                    if (controller.bookingDetail.stateId == STATE_COMPLETED)
                      controller.bookingDetail.isReportSubmit == false
                          ? GestureDetector(
                              onTap: () {
                                Get.toNamed(AppRoutes.submitReport, arguments: {"bookingDetail": controller.bookingDetail});
                              },
                              child: Text(
                                keySubmitReport.tr,
                                style: TextStyle(
                                  decoration: TextDecoration.underline,
                                  decorationColor: colorAppColors,
                                  color: colorAppColors,
                                  fontSize: font_16,
                                ),
                              ),
                            )
                          : submitReport(),

                    SizedBox(height: height_10),
                    controller.bookingDetail.stateId == STATE_ACCEPTED
                        ? _startServiceBtn()
                        : controller.bookingDetail.stateId == STATE_INPROGRESS
                            ? _markAsCompletedBtn()
                            : controller.bookingDetail.stateId == STATE_COMPLETED && controller.bookingDetail.isRating == false
                                ? _giveRatingsBtn()
                                : SizedBox(),
                    SizedBox(height: height_10),
                  ],
                ),
        ),
      ),
    );
  }
  submitReport(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextView(text: 'Submitted Report', textStyle: textStyleBodyMedium().copyWith(fontWeight: FontWeight.bold)),
        SizedBox(height: 10.h,),
        rowWidget(title: 'Name',subtitle: controller.bookingDetail.submitReport?.name),
        rowWidget(title: 'Nationality',subtitle: controller.bookingDetail.submitReport?.nationality.toString()),
        rowWidget(title: 'Blood pressure',subtitle: controller.bookingDetail.submitReport?.bloodPressure.toString()),
        rowWidget(title: 'Pulse',subtitle: controller.bookingDetail.submitReport?.pulse.toString()),
        rowWidget(title: 'Temperature',subtitle: controller.bookingDetail.submitReport?.temperature.toString()),
        rowWidget(title: 'Skin',subtitle: controller.bookingDetail.submitReport?.skin.toString()),
        rowWidget(title: 'Conclusion',subtitle: controller.bookingDetail.submitReport?.conclusion.toString()),
      ],
    );
  }
  rowWidget({title,subtitle}){
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        TextView(text: '${title??""}:', textStyle: textStyleBodyMedium()),

        TextView(text: subtitle??"", textStyle: textStyleBodyMedium()),
      ],
    );
  }

  _upLoadedReport() => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          titleTxt(title: keyUploadedReport.tr),
          SizedBox(
            height: height_100,
            child: ListView.separated(
              itemCount: controller.bookingDetail.uploadReport!.length,
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () {
                    Get.dialog(
                        barrierColor: Colors.white.withOpacity(1),
                        Stack(
                          children: [
                            NetworkImageWidget(
                              imageHeight: double.infinity,
                              imageWidth: double.infinity,
                              radiusAll: radius_5,
                              imageFitType: BoxFit.contain,
                              imageurl: controller.bookingDetail.uploadReport?[index].url,
                            ).paddingAll(margin_20),
                            Positioned(
                                left: 0,
                                top: margin_15,
                                child: IconButton(
                                    onPressed: () {
                                      Get.back();
                                    },
                                    icon: Icon(Icons.arrow_back_ios, color: colorAppColors))),
                          ],
                        ));
                  },
                  child: NetworkImageWidget(
                    imageHeight: height_100,
                    imageWidth: height_100,
                    radiusAll: radius_5,
                    imageurl: controller.bookingDetail.uploadReport?[index].url,
                  ),
                );
              },
              separatorBuilder: (BuildContext context, int index) {
                return SizedBox(width: width_10);
              },
            ),
          ),
        ],
      );

  Widget neededServicesList() {
    return Wrap(
      runSpacing: margin_8,
      spacing: margin_10,
      children: List.generate(1, (index) {
        return Chip(
            padding: EdgeInsets.all(margin_5),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(radius_20),
            ),
            side: BorderSide(color: colorAppColors),
            label: TextView(
              text: "${controller.bookingDetail.serviceName!}",
              textStyle: textStyleTitle().copyWith(color: colorAppColors),
            ));
      }),
    );
  }

  _startServiceBtn() => MaterialButtonWidget(
        onPressed: () {
          controller.hitAcceptRejectApi(stateID: STATE_INPROGRESS);
        },
        buttonText: keyStartService.tr,
        textColor: Colors.white,
        padding: margin_13,
        buttonRadius: radius_5,
      );

  _markAsCompletedBtn() => MaterialButtonWidget(
        onPressed: () {
          controller.hitAcceptRejectApi(stateID: STATE_COMPLETED);
        },
        buttonText: keyMarkAsCompleted.tr,
        textColor: Colors.white,
        padding: margin_13,
        buttonRadius: radius_5,
      );

  _giveRatingsBtn() => MaterialButtonWidget(
        onPressed: () {
          Get.toNamed(AppRoutes.addRatingsScreenRoute, arguments: {"dataModel": controller.bookingListProvider});

        },
        buttonText: keyGiveReview.tr,
        textColor: Colors.white,
        padding: margin_13,
        buttonColor: Colors.green,
        buttonRadius: radius_5,
      );
}

Widget customRow({leadingIcon, title, value, bool space = false, verticalPadding}) => Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (leadingIcon != null)
          AssetImageWidget(
            imageUrl: leadingIcon ?? iconAccount_info,
            imageHeight: height_12,
            imageWidth: height_12,
          ).paddingOnly(top: margin_4),
        SizedBox(
          width: width_5,
        ),
        TextView(
          text: "${title ?? ""}",
          textStyle: textStyleTitle().copyWith(color: Colors.grey.shade800, fontWeight: FontWeight.bold),
        ),
        // if (space) Spacer(),
        Expanded(
          child: TextView(
            textAlign: space ? TextAlign.end : TextAlign.start,
            text: "${value ?? ""}",
            textStyle: textStyleTitle().copyWith(color: Colors.grey, fontWeight: FontWeight.bold),
          ),
        ),
      ],
    ).paddingSymmetric(horizontal: margin_5, vertical: verticalPadding ?? margin_5);
