import 'dart:math';

import 'package:healthcare/app/service_provider_app/Home/controllers/home_controller_provider.dart';
import 'package:intl/intl.dart';

import '../../../../export.dart';
import '../controllers/booking_screen_controller_provider.dart';

class BookingsScreenProvider extends GetView<BookingsScreenControllerProvider> {
  final controller = Get.put(BookingsScreenControllerProvider());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        centerTitle: true,
        appBarTitleText: keyMyBookings.tr,
        isBackIcon: true,
      ),
      body: Obx(
        () => controller.isLoading.value
            ? Center(
                child: CircularProgressIndicator(
                color: colorAppColors,
              ))
            : controller.bookingList.length == 0
                ? noDataToShow(inputText: keyNoBookingsFountYet.tr)
                : ListView.separated(
                    padding: EdgeInsets.only(left: margin_12, right: margin_12, bottom: margin_30),
                    itemCount: controller.bookingList.length,
                    itemBuilder: (context, index) {
                      var booking = controller.bookingList[index];
                      return GestureDetector(
                        onTap: () {
                          Get.toNamed(AppRoutes.bookingDetailScreenProvider, arguments: {"booking": booking});
                        },
                        child: Container(
                          padding: EdgeInsets.only(left: margin_12, top: margin_12, bottom: margin_12),
                          decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(radius_10)),
                          child: commonListTitle(
                            leadingImg: booking.profileFile,
                            title: booking.fullName ?? "",
                            subtitle: utcToLocalLatestNewsDate(booking.date.toString()) ?? "",
                            shift: getShift(DateTime.parse(
                                utcToLocalLatest(DateFormat("yyyy-MM-dd ").format(DateTime.now()) + booking.startTime!, "yyyy-MM-dd hh:mm:ss") ??
                                    '')),
                            trailingWidget: Container(
                              padding: EdgeInsets.symmetric(vertical: margin_3, horizontal: margin_8),
                              margin: EdgeInsets.symmetric(horizontal: margin_8),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(radius_5),
                                color: statusTextColor(stateId: booking.stateId),
                              ),
                              child: TextView(
                                text: statusTxt(stateId: booking.stateId),
                                textStyle: textStyleBody1().copyWith(fontSize: font_12, color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) {
                      return SizedBox(
                        height: height_10,
                      );
                    },
                  ),
      ),
    );
  }
}
