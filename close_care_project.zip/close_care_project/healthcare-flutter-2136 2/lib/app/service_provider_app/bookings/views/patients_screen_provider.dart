import 'package:healthcare/app/service_provider_app/Home/views/home_screen_provider.dart';
import 'package:healthcare/app/service_provider_app/bookings/controllers/patents_screen_controller_provider.dart';
import 'package:healthcare/app/service_provider_app/bookings/views/bookings_screen_provider.dart';
import 'package:intl/intl.dart';
import '../../../../export.dart';

class PatientsScreenProvider extends GetView<PatientsScreenControllerProvider> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        centerTitle: true,
        appBarTitleText: keyMyPatients.tr,
        isBackIcon: true,
      ),
      body: _bodyWidget(),
    );
  }

  _bodyWidget() => Obx(
        () => controller.isLoading.value
            ? Center(
                child: CircularProgressIndicator(
                color: colorAppColors,
              ))
            : controller.bookingList.length == 0
                ? noDataToShow(inputText: keyNoPatientFound.tr)
                : ListView.separated(
                    controller: controller.scrollController,
                    padding: EdgeInsets.symmetric(horizontal: margin_12),
                    itemCount: controller.bookingList.length,
                    itemBuilder: (context, index) {
                      var booking = controller.bookingList[index];
                      return GestureDetector(
                        onTap: () {
                          // Get.toNamed(AppRoutes.bookingScreenProvider, arguments: {"id": booking.id});
                          Get.to(() => BookingsScreenProvider(), arguments: {"id": booking.id});
                        },
                        child: Container(
                          padding: EdgeInsets.all(margin_15),
                          decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(radius_10)),
                          child: commonListTitle(
                            leadingImg: booking.profileFile,
                            title: booking.fullName ?? "",
                            subtitle:utcToLocalLatestNewsDate(booking.createdOn.toString()) ??  "",//
                              trailingWidget:SizedBox()
                            // shift:/* getShift(DateTime.parse(
                            //     utcToLocalLatest(DateFormat("yyyy-MM-dd ").format(DateTime.now()) + booking.startTime!, "yyyy-MM-dd hh:mm:ss") ??
                            //         '')),*/
                            // '',
                            // trailingWidget: GestureDetector(
                            //   onTap: () async {
                            //     // var result = await Get.toNamed(AppRoutes.msgChatScreen, arguments: {
                            //     //   "toId": booking.createdById,
                            //     //   "toName": booking.fullName,
                            //     //   "toProfile": booking.profileFile,
                            //     //   "bookingId": booking.id,
                            //     // });
                            //     // if (result) {
                            //     //   controller.hitBookingListingApiCall();
                            //     // }
                            //   },
                            //   child: SizedBox(),
                            // ),
                          ),
                        ),
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) {
                      return SizedBox(
                        height: height_10,
                      );
                    },
                  ),
      );
}
