import 'package:healthcare/app/service_provider_app/bookings/controllers/submit_report_controller.dart';
import '../../../../export.dart';

class SubmitReportScreen extends GetView<SubmitReportController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: CustomAppBar(
          appBarTitleText: keySubmitReport.tr,
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Form(
            key: controller.formGlobalKey,
            child: Column(
              children: [
                inputField(
                  tvHeading: keyPatientName.tr,
                  maxLine: 1,
                  controller: controller.patientNameController,
                  validate: keyPatientName.tr,
                ),
                inputField(
                  tvHeading: keyDateOfBirth.tr,
                  maxLine: 1,
                  controller: controller.dobController,
                  validate: keyDateOfBirth.tr,
                ),
                inputField(
                  tvHeading: keyAge.tr,
                  maxLine: 1,
                  validate: keyAge.tr,
                  controller: controller.ageController,
                  type: TextInputType.number,
                ),
                inputField(
                    tvHeading: keyNationality.tr,
                    maxLine: 1,
                    validate: keyNationality.tr,
                    controller: controller.nationalityController,
                    type: TextInputType.text),
                inputField(
                    tvHeading: keyBloodPressure.tr,
                    maxLength: 3,
                    maxLine: 1,
                    validate: keyBloodPressure.tr,
                    controller: controller.bloodPressureController,
                    type: TextInputType.number),
                inputField(
                  tvHeading: keyPulse.tr,
                  maxLength: 3,
                  maxLine: 1,
                  validate: keyPulse.tr,
                  controller: controller.pulseController,
                  type: TextInputType.number,
                ),
                inputField(
                    maxLength: 5,
                    tvHeading: keyTemperature.tr,
                    maxLine: 1,
                    validate: keyTemperature.tr,
                    controller: controller.tempController,
                    type: TextInputType.number),
                inputField(
                  tvHeading: keySkin.tr,
                  maxLine: 1,
                  validate: keySkin.tr,
                  controller: controller.skinController,
                  type: TextInputType.text,
                ),
                inputField(
                    tvHeading: keyConclusion.tr,
                    maxLine: 3,
                    validate: keyConclusion.tr,
                    controller: controller.conclusionController,
                    type: TextInputType.text),
                submitButton()
              ],
            ).paddingSymmetric(horizontal: margin_12),
          ),
        ));
  }

  submitButton() {
    return MaterialButtonWidget(
      buttonRadius: radius_5,
      padding: margin_14,
      buttonText: keySubmit.tr,
      onPressed: () {
        controller.validateSubmitButton();
      },
    ).paddingSymmetric(vertical: margin_20);
  }

  inputField({tvHeading, validate, controller, focusNode, maxLine, type, maxLength}) {
    return TextFieldWidget(
      radius: radius_10,
      maxLength: maxLength ?? 50,
      maxline: maxLine,
      textController: controller,
      minLine: maxLine,
      inputType: type,
      decoration: DecoratedInputBorder(
        child: OutlineInputBorder(
            borderRadius: BorderRadius.circular(margin_7),
            borderSide: BorderSide(color: Colors.grey.shade400, style: BorderStyle.solid, width: width_1)),
        shadow: BoxShadow(
          color: Colors.transparent,
          blurRadius: 1,
          spreadRadius: 1,
        ),
      ),
      contentPadding: EdgeInsets.symmetric(vertical: margin_17, horizontal: margin_15),
      tvHeading: tvHeading,
      tvHeadingStyle: font_15,
      tvHeadingFontWeight: FontWeight.w600,
      // textController: controller.emailController,
      validate: (value) => Validator.fieldChecker(value, validate), /* focusNode: controller.emailFocusNode*/
    ).paddingSymmetric(vertical: margin_10);
  }
}
