/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import 'package:healthcare/app/service_provider_app/bookings/controllers/patents_screen_controller_provider.dart';
import 'package:healthcare/app/service_provider_app/services/controllers/add_availability_controller_provider.dart';
import 'package:healthcare/app/service_provider_app/services/views/add_un_availability.dart';
import 'package:healthcare/export.dart';

import '../../Home/controllers/home_controller_provider.dart';
import '../../bookings/controllers/booking_screen_controller_provider.dart';
import '../../services/controllers/service_screen_controller_provider.dart';
import '../controllers/main_screen_controller_provider.dart';

class MainScreenBindingsProvider extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => MainScreenControllerProvider());
    Get.lazyPut(() => HomeControllerProvider());
    Get.lazyPut(() => BookingsScreenControllerProvider());
    Get.lazyPut(() => PatientsScreenControllerProvider());
    Get.lazyPut(() => ServiceScreenControllerProvider());
    Get.lazyPut(() => ProfileViewController());
    Get.lazyPut(() => AddAvailabilityController());
    Get.lazyPut(() => AddUnAvailability());
    // Get.lazyPut(() => HomeController());
  }
}
