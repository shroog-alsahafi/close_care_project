/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

import '../../../modules/authentication/views/view_profile_screen.dart';
import '../../Home/views/home_screen_provider.dart';
import '../../bookings/views/bookings_screen_provider.dart';
import '../../services/views/service_screen_provider.dart';

class MainScreenControllerProvider extends GetxController {
  RxInt currentIndex = 0.obs;

  hitBottomNavApi(index) {
    currentIndex.value = index;
  }

  List<Widget> tabList = [
    HomeScreenProvider(),
    // BookingsScreenProvider(),
    ServiceScreenProvider(),
    ProfileViewScreen(showBackIcon: false),
  ];
}
