/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import '../../../../export.dart';
import '../controllers/main_screen_controller_provider.dart';

class MainScreenProvider extends GetView<MainScreenControllerProvider> {
  MainScreenProvider({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      // bottomSheet: _bottomNav(),
      body: Obx(() => controller.tabList[controller.currentIndex.value]),
    );
  }

  _bottomNav() {
    return Container(
      decoration: BoxDecoration(borderRadius: BorderRadius.vertical(top: Radius.circular(radius_22))),
      clipBehavior: Clip.hardEdge,
      child: Obx(
        () => BottomNavigationBar(
          currentIndex: controller.currentIndex.value,
          type: BottomNavigationBarType.fixed,
          enableFeedback: false,
          backgroundColor: colorGrey,
          showUnselectedLabels: true,
          onTap: (index) {
            controller.hitBottomNavApi(index);
          },
          selectedItemColor: colorAppColor,
          unselectedItemColor: Colors.white,
          selectedLabelStyle: textStyleBody1().copyWith(fontSize: font_13),
          unselectedLabelStyle: textStyleBody1().copyWith(fontSize: font_13),
          items: <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: icons(imageUrl: iconsHomeUnfilled ?? iconsHomeFilled, index: 0),
              label: keyHome.tr,
            ),
            BottomNavigationBarItem(
              icon: icons(imageUrl: iconsBookingUnFilled ?? iconsBookingFilled, index: 1),
              label: keyBookings.tr,
            ),
            BottomNavigationBarItem(
              icon: icons(imageUrl: iconsServiceUnFilled ?? iconsServiceFilled, index: 2),
              label: keyServices.tr,
            ),
            BottomNavigationBarItem(
              icon: icons(imageUrl: iconsProfileUnFilled ?? iconsProfileFilled, index: 3),
              label: keyProfile.tr,
            ),
          ],
        ),
      ),
    );
  }

/*==================================================for bottom navigation icon============================================*/

  Widget icons({imageUrl, index}) {
    return AssetImageWidget(
      imageUrl: imageUrl,
      imageHeight: height_20,
      color: index == controller.currentIndex.value ? colorAppColor : Colors.white,
    ).marginOnly(bottom: margin_7, top: margin_8);
  }
}
