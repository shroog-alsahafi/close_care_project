import 'package:get/get.dart';
import 'package:healthcare/app/service_provider_app/services/controllers/add_availability_controller_provider.dart';
import 'package:healthcare/app/service_provider_app/services/controllers/service_details_controller_provider.dart';

import '../controllers/add_service_controller_provider.dart';

class ServicesBindingsProvider extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => AddServiceControllerProvider());
    Get.lazyPut(() => ServiceDetailControllerProvider());
    // Get.lazyPut(() => AddAvailabilityController());
  }
}
