import 'package:intl/intl.dart';
import 'package:healthcare/app/service_provider_app/services/controllers/service_details_controller_provider.dart';
import 'package:healthcare/app/service_provider_app/services/models/service_list_res_model.dart';

import '../../../../export.dart';
import '../models/availability_list_res_model.dart';

class AddAvailabilityController extends GetxController {
  RxInt selectedDay = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }

  RxBool readOnly = false.obs;
  @override
  void onReady() {
    hitAvailabilityApi();
    hitUnAvailabilityApi();
    super.onReady();
  }

  void dispose() {
    customLoader.hide();
    super.dispose();
  }

  int? serviceId;
  bool forEdit = false;

  final formKey = GlobalKey<FormState>();
  DateTime? selectedStartTime;
  DateTime? selectedEndTime;

  FocusNode startTimeFocusNode = FocusNode();
  RxList<SlotModel> slotsList = [
    SlotModel(dayID: 1, startTime: TextEditingController(), endTime: TextEditingController(), serverStartTime: '', serverEndTime: ''),
    SlotModel(dayID: 2, startTime: TextEditingController(), endTime: TextEditingController(), serverStartTime: '', serverEndTime: ''),
    SlotModel(dayID: 3, startTime: TextEditingController(), endTime: TextEditingController(), serverStartTime: '', serverEndTime: ''),
    SlotModel(dayID: 4, startTime: TextEditingController(), endTime: TextEditingController(), serverStartTime: '', serverEndTime: ''),
    SlotModel(dayID: 5, startTime: TextEditingController(), endTime: TextEditingController(), serverStartTime: '', serverEndTime: ''),
    SlotModel(dayID: 6, startTime: TextEditingController(), endTime: TextEditingController(), serverStartTime: '', serverEndTime: ''),
    SlotModel(dayID: 7, startTime: TextEditingController(), endTime: TextEditingController(), serverStartTime: '', serverEndTime: ''),
  ].obs;

  addAvailabilityApi() async {
    customLoader.show(Get.overlayContext);

    List<Map> slotlist = [];
    for (int i = 0; i < slotsList.length; i++) {
      slotlist.add(slotsList[i].getRequestJson());
    }
    var reqBody = {
      "Availability[slots]": jsonEncode(slotlist),
    };
    print(reqBody);
    try {
      final response = DioClient().post("/api/user/add-availability", data: FormData.fromMap(reqBody), skipAuth: false);
      MessageResponseModel messageResponseModel = MessageResponseModel.fromJson(await response);
      customLoader.hide();
      hitAvailabilityApi();
      update();
      showInSnackBar(message: messageResponseModel.message!);
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/user/add-availability"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  List<Availability> availability = [];
  AvailabilityListResModel availabilityListResModel = AvailabilityListResModel();
  RxBool showUnAvailabilityBtn = false.obs;
  hitAvailabilityApi() async {
    customLoader.show(Get.overlayContext);
    availability.clear();
    try {
      final response = DioClient().get(
        "/api/user/availability-list",
        skipAuth: false,
      );
      availabilityListResModel = AvailabilityListResModel.fromJson(await response);
      availability.addAll(availabilityListResModel.list ?? []);
      if (availability.length != 0) {
        showUnAvailabilityBtn.value = true;
        readOnly.value = true;
        _setDataArg();
      }
      customLoader.hide();
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/user/availability-list"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  UnAvailabilityResModel unAvailabilityResModel = UnAvailabilityResModel();
  RxList<UnAvailableList> unAvailableList = <UnAvailableList>[].obs;
  hitUnAvailabilityApi() async {
    try {
      final response = DioClient().get(
        "/api/user/un-availability-list",
        skipAuth: false,
      );
      customLoader.hide();
      unAvailabilityResModel = UnAvailabilityResModel.fromJson(await response);
      unAvailableList.clear();
      unAvailableList.addAll(unAvailabilityResModel.list ?? []);
      unAvailableList.refresh();
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/user/un-availability-list"));
    }
  }

  deleteUnAvailabilityApi({id}) async {
    customLoader.show(Get.overlayContext);
    try {
      final response = DioClient().get(
        "/api/user/delete-un-availability",
        queryParameters: {"id": id},
        skipAuth: false,
      );
      MessageResponseModel messageResponseModel = MessageResponseModel.fromJson(await response);
      toast("${messageResponseModel.message}");
      hitUnAvailabilityApi();
      customLoader.hide();
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/user/delete-un-availability"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  _setDataArg() {
    try {
      if (availability.length != 0) {
        slotsList.clear();
        for (int i = 0; i < availability.length; i++) {
          if (availability[i].startTime != null && availability[i].endTime != null) {
            var formattedStartTime = "${DateFormat("yyyy-MM-dd ").format(DateTime.now())}${availability[i].startTime}";
            var formattedEndTime = "${DateFormat("yyyy-MM-dd ").format(DateTime.now())}${availability[i].endTime}";

            slotsList.add(
              SlotModel(
                dayID: availability[i].dayId,
                startTime: TextEditingController()..text = utcToLocalLatest(formattedStartTime.toString(), "hh:mm a"),
                endTime: TextEditingController()..text = utcToLocalLatest(formattedEndTime.toString(), "hh:mm a"),
                serverStartTime: "${availability[i].startTime}",
                serverEndTime: "${availability[i].endTime}",
              ),
            );
          } else {
            slotsList.add(SlotModel(
              dayID: availability[i].dayId,
              startTime: TextEditingController(),
              endTime: TextEditingController(),
              serverStartTime: "",
              serverEndTime: "",
            ));
          }
        }
      }
    } catch (e, str) {}
  }

  RxList<WeekDaysModel> weedDaysList = <WeekDaysModel>[
    WeekDaysModel(id: 1, day: "Mon"),
    WeekDaysModel(id: 2, day: "Tue"),
    WeekDaysModel(id: 3, day: "Wed"),
    WeekDaysModel(id: 4, day: "Thu"),
    WeekDaysModel(id: 5, day: "Fri"),
    WeekDaysModel(id: 6, day: "Sat"),
    WeekDaysModel(id: 7, day: "Sun"),
  ].obs;

  @override
  void onClose() {
    customLoader.hide();
    super.onClose();
  }
}

class SlotModel {
  int? dayID;
  TextEditingController? startTime;
  TextEditingController? endTime;
  String? serverStartTime;
  String? serverEndTime;

  SlotModel({
    this.dayID,
    this.startTime,
    this.endTime,
    this.serverStartTime,
    this.serverEndTime,
  });

  factory SlotModel.fromJson(Map<String, dynamic> json) => SlotModel(
        dayID: json["dayId"],
        serverStartTime: json["startTime"],
        serverEndTime: json["endTime"],
      );

  Map<String, dynamic> toJson() {
    var formattedStartTime;
    var formattedEndTime;
    if (serverStartTime != "" && serverEndTime != "") {
      var s1 = serverStartTime!.split(":")[0];
      var s2 = serverStartTime!.split(":")[1].split(" ").first;

      var e1 = serverEndTime?.split(":")[0];
      var e2 = serverEndTime?.split(":")[1].split(" ").first;
      var selectedUtcStartTime = DateTime(
        DateTime.now().year,
        DateTime.now().month,
        DateTime.now().day,
        int.parse(s1),
        int.parse(s2),
        00,
      ).toUtc();

      var selectedUtcEndTime = DateTime(
        DateTime.now().year,
        DateTime.now().month,
        DateTime.now().day,
        int.parse(e1!),
        int.parse(e2!),
        00,
      ).toUtc();
      formattedStartTime = DateFormat("HH:mm:ss").format(selectedUtcStartTime);
      formattedEndTime = DateFormat("HH:mm:ss").format(selectedUtcEndTime);
    }
    Map<String, dynamic> mapData = Map();
    mapData["dayId"] = "${dayID ?? ""}";
    mapData["startTime"] = formattedStartTime ?? "";
    mapData["endTime"] = formattedEndTime ?? "";
    return mapData;
  }

  getRequestJson() {
    Map<String, dynamic> mapData = Map();
    mapData["dayId"] = "${dayID ?? ""}";
    mapData["startTime"] = this.serverStartTime ?? "";
    mapData["endTime"] = this.serverEndTime ?? "";
    return mapData;
  }
}
