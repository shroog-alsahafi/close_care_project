import 'package:healthcare/app/service_provider_app/services/controllers/service_screen_controller_provider.dart';
import 'package:healthcare/app/service_provider_app/services/models/service_list_res_model.dart';
import 'package:healthcare/app/service_provider_app/services/models/service_type_list_res_model.dart';

import '../../../../export.dart';

class AddServiceControllerProvider extends GetxController {
  @override
  void onInit() {
    _getArg();
    super.onInit();
  }

  @override
  void onReady() {
    _hitServiceTypeListApi();
    super.onReady();
  }

  String? selectedOption;
  Rx<ServiceList> serviceDetail = ServiceList().obs;

  _getArg() {
    if (Get.arguments != null) {
      serviceDetail.value = Get.arguments["serviceDetail"];
      serviceTimeTxtController.text = serviceDetail.value.serviceTime;
      servicePriceTxtController.text = serviceDetail.value.price ?? "";
      descriptionTxtController.text = serviceDetail.value.description ?? "";
      selectedOption = serviceDetail.value.title ?? "";
    }
  }

  final formKey = GlobalKey<FormState>();
  TextEditingController serviceTimeTxtController = TextEditingController();
  TextEditingController servicePriceTxtController = TextEditingController();
  TextEditingController descriptionTxtController = TextEditingController();
  ServiceTypeList serviceTypeList = ServiceTypeList();
  FocusNode serviceTimeTxtFocusNode = FocusNode();
  FocusNode servicePriceTxtFocusNode = FocusNode();
  FocusNode descriptionTxtFocusNode = FocusNode();
  RxInt? serviceTypeId;
  RxList<ServiceTypeList> serviceList = <ServiceTypeList>[].obs;

  addServiceApi() async {
    customLoader.show(Get.overlayContext);
    var reqBody = {
      "Service[service_type_id]": serviceTypeList.id.toString(),
      "Service[price]": servicePriceTxtController.text,
      "Service[service_time]": serviceTimeTxtController.text,
      "Service[description]": descriptionTxtController.text,
    };
    try {
      final response = DioClient().post("/api/service/add", data: FormData.fromMap(reqBody), skipAuth: false);
      MessageResponseModel messageResponseModel = MessageResponseModel.fromJson(await response);
      Get.back();
      Get.find<ServiceScreenControllerProvider>().hitServiceListApi();
      customLoader.hide();
      showInSnackBar(message: messageResponseModel.message!);
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/service/add"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  _hitServiceTypeListApi() async {
    try {
      final response = DioClient().get("/api/service/type-list", skipAuth: false);
      ServiceTypeListResModel serviceTypeListResModel = ServiceTypeListResModel.fromJson(await response);
      serviceList.value = serviceTypeListResModel.list ?? [];
      for (int i = 0; i < serviceList.length; i++) {
        if (serviceList[i].title.toString() == serviceDetail.value.title.toString()) {
          selectedOption = serviceList[i].title;
          serviceTypeList = serviceList[i];
        }
      }
    } catch (e, str) {
      Future.error(NetworkExceptions.getDioException(e, str, "/api/service/type-list"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}
