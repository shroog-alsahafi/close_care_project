import 'package:healthcare/app/service_provider_app/services/controllers/add_availability_controller_provider.dart';
import 'package:intl/intl.dart';
import 'package:healthcare/app/service_provider_app/services/controllers/service_details_controller_provider.dart';
import 'package:healthcare/app/service_provider_app/services/models/service_list_res_model.dart';

import '../../../../export.dart';
import '../models/availability_list_res_model.dart';

class AddUnAvailabilityController extends GetxController {
  TextEditingController dateController = TextEditingController();
  FocusNode dateFocusNode = FocusNode();
  DateTime selectedDate = DateTime.now();
  RxString day = "".obs;
  RxBool selectForAllDay = false.obs;


  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {

    super.onReady();
  }

  int? serviceId;
  bool forEdit = false;


  final formKey = GlobalKey<FormState>();
  DateTime? selectedStartTime;
  DateTime? selectedEndTime;

  FocusNode startTimeFocusNode = FocusNode();
  RxList<SlotModel> slotsList = <SlotModel>[
    SlotModel(startTime: TextEditingController(), endTime: TextEditingController(), serverStartTime: '', serverEndTime: ''),
  ].obs;

  addUnAvailabilityApi() async {
    customLoader.show(Get.overlayContext);
    List<Map> slotlist = [];
    for (int i = 0; i < slotsList.length; i++) {
      // if(slotsList[i].serverEndTime?.isNotEmpty) {
      slotlist.add(slotsList[i].getRequestJson());
      // }
    }

    var reqBody = {
      "Availability[type_id]": selectForAllDay.value ? 1 : 0,
      "Availability[day_id]": getDayIdWithDayName(day: day.value),
      "Availability[date]": DateFormat("yyyy-MM-dd").format(selectedDate),
      "Availability[slots]": jsonEncode(slotlist),
    };
    try {
      final response = DioClient().post(
        "/api/user/add-unavailability",
        data: FormData.fromMap(reqBody),
        skipAuth: false,
      );
      MessageResponseModel messageResponseModel = MessageResponseModel.fromJson(await response);
      customLoader.hide();
      Get.find<AddAvailabilityController>().hitUnAvailabilityApi();
      Get.back();
      showInSnackBar(message: messageResponseModel.message!);
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/user/add-unavailability"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  List<Availability> availability = [];
  AvailabilityListResModel availabilityListResModel = AvailabilityListResModel();

  RxList<WeekDaysModel> weedDaysList = <WeekDaysModel>[
    WeekDaysModel(id: 1, day: "Mon"),
    WeekDaysModel(id: 2, day: "Tue"),
    WeekDaysModel(id: 3, day: "Wed"),
    WeekDaysModel(id: 4, day: "Thu"),
    WeekDaysModel(id: 5, day: "Fri"),
    WeekDaysModel(id: 6, day: "Sat"),
    WeekDaysModel(id: 7, day: "Sun"),
  ].obs;

  @override
  void onClose() {
    customLoader.hide();
    super.onClose();
  }
}
