import 'package:healthcare/app/service_provider_app/services/models/availability_list_res_model.dart';

import '../../../../export.dart';
import '../models/service_list_res_model.dart';

class ServiceDetailControllerProvider extends GetxController {
  @override
  void onInit() {
    _getArg();
    super.onInit();
  }

  @override
  void onReady() {
    hitServiceAvailabilityApi();
    super.onReady();
  }

  ServiceList serviceDetail = ServiceList();
  _getArg() {
    if (Get.arguments != null) {
      serviceDetail = Get.arguments["serviceDetail"];
    }
  }

  RxInt selectedDay = 1.obs;

  RxList<WeekDaysModel> weedDaysList = <WeekDaysModel>[
    WeekDaysModel(id: 1, day: "Mon"),
    WeekDaysModel(id: 2, day: "Tue"),
    WeekDaysModel(id: 3, day: "Wed"),
    WeekDaysModel(id: 4, day: "Thu"),
    WeekDaysModel(id: 5, day: "Fri"),
    WeekDaysModel(id: 6, day: "Sat"),
    WeekDaysModel(id: 7, day: "Sun"),
  ].obs;

  int page = 0;
  AvailabilityListResModel availabilityListResModel = AvailabilityListResModel();
  RxList<Availability> availabilityList = <Availability>[].obs;
  CustomLoader customLoader = CustomLoader();

  hitServiceAvailabilityApi() async {
    customLoader.show(Get.overlayContext);
    if (page == 0) {
      availabilityList.clear();
    }
    try {
      final response = DioClient().get(
        "/api/service/availability-list",
        queryParameters: {
          "service_id": serviceDetail.id,
          "day_ids": selectedDay.value,
        },
        skipAuth: false,
      );
      availabilityListResModel = AvailabilityListResModel.fromJson(await response);
      availabilityList.addAll(availabilityListResModel.list ?? []);
      customLoader.hide();
    } catch (e, str) {
      customLoader.hide();
      Future.error(NetworkExceptions.getDioException(e, str, "/api/service/availability-list"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }
}

class WeekDaysModel {
  int? id;
  String? day;
  bool isSelected;

  WeekDaysModel({
    this.id,
    this.day,
    this.isSelected = false,
  });

  factory WeekDaysModel.fromJson(Map<String, dynamic> json) => WeekDaysModel(
        id: json["id"],
        day: json["day"],
        isSelected: json["isSelected"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "day": day,
        "isSelected": isSelected,
      };
}
