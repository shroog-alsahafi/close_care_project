import 'package:healthcare/app/service_provider_app/services/models/service_list_res_model.dart';

import '../../../../export.dart';

class ServiceScreenControllerProvider extends GetxController {
  @override
  void onInit() {
    paginateItemList();
    super.onInit();
  }

  @override
  void onReady() {
    hitServiceListApi();
    super.onReady();
  }

  int page = 0;
  RxList<ServiceList> serviceList = <ServiceList>[].obs;

  ServiceListResModel serviceListResModel = ServiceListResModel();

  hitServiceListApi() async {
    try {
      final response = DioClient().get(
        "/api/service/list",
        skipAuth: false,
        queryParameters: {"page": page},
      );
      serviceListResModel = ServiceListResModel.fromJson(await response);
      if (page == 0) {
        serviceList.clear();
      }
      serviceList.addAll(serviceListResModel.list ?? []);
    } catch (e, str) {
      Future.error(
          NetworkExceptions.getDioException(e, str, "/api/service/list"));
      showInSnackBar(message: NetworkExceptions.messageData);
    }
  }

  ScrollController scrollController = ScrollController();

  paginateItemList() {
    scrollController.addListener(() async {
      if (scrollController.position.pixels ==
          scrollController.position.maxScrollExtent) {
        if (page < serviceListResModel.meta!.pageCount! - 1) {
          page++;
          hitServiceListApi();
        }
      }
    });
  }
}
