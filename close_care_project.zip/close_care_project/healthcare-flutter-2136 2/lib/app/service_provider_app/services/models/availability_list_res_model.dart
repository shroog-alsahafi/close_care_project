import 'dart:convert';

import 'package:healthcare/app/core/model/meta.dart';
import 'package:healthcare/app/service_provider_app/services/models/service_list_res_model.dart';

AvailabilityListResModel availabilityListResModelFromJson(String str) => AvailabilityListResModel.fromJson(json.decode(str));

String availabilityListResModelToJson(AvailabilityListResModel data) => json.encode(data.toJson());

class AvailabilityListResModel {
  List<Availability>? list;
  Links? links;
  Meta? meta;
  String? copyrights;

  AvailabilityListResModel({
    this.list,
    this.links,
    this.meta,
    this.copyrights,
  });

  factory AvailabilityListResModel.fromJson(Map<String, dynamic> json) => AvailabilityListResModel(
        list: json["list"] == null ? [] : List<Availability>.from(json["list"]!.map((x) => Availability.fromJson(x))),
        links: json["_links"] == null ? null : Links.fromJson(json["_links"]),
        meta: json["_meta"] == null ? null : Meta.fromJson(json["_meta"]),
        copyrights: json["copyrights"],
      );

  Map<String, dynamic> toJson() => {
        "list": list == null ? [] : List<dynamic>.from(list!.map((x) => x.toJson())),
        "_links": links?.toJson(),
        "_meta": meta?.toJson(),
        "copyrights": copyrights,
      };
}

UnAvailabilityResModel unAvailabilityResModelFromJson(String str) => UnAvailabilityResModel.fromJson(json.decode(str));

String unAvailabilityResModelToJson(UnAvailabilityResModel data) => json.encode(data.toJson());

class UnAvailabilityResModel {
  List<UnAvailableList>? list;
  Links? links;
  Meta? meta;
  String? copyrights;

  UnAvailabilityResModel({
    this.list,
    this.links,
    this.meta,
    this.copyrights,
  });

  factory UnAvailabilityResModel.fromJson(Map<String, dynamic> json) => UnAvailabilityResModel(
        list: json["list"] == null ? [] : List<UnAvailableList>.from(json["list"]!.map((x) => UnAvailableList.fromJson(x))),
        links: json["_links"] == null ? null : Links.fromJson(json["_links"]),
        meta: json["_meta"] == null ? null : Meta.fromJson(json["_meta"]),
        copyrights: json["copyrights"],
      );

  Map<String, dynamic> toJson() => {
        "list": list == null ? [] : List<dynamic>.from(list!.map((x) => x.toJson())),
        "_links": links?.toJson(),
        "_meta": meta?.toJson(),
        "copyrights": copyrights,
      };
}

class UnAvailableList {
  int? id;
  int? dayId;
  int? stateId;
  int? typeId;
  DateTime? createdOn;
  int? createdById;
  String? date;
  List<Availability>? availability;

  UnAvailableList({
    this.id,
    this.dayId,
    this.stateId,
    this.typeId,
    this.createdOn,
    this.createdById,
    this.date,
    this.availability,
  });

  factory UnAvailableList.fromJson(Map<String, dynamic> json) => UnAvailableList(
        id: json["id"],
        dayId: json["day_id"],
        stateId: json["state_id"],
        typeId: json["type_id"],
        createdOn: json["created_on"] == null ? null : DateTime.parse(json["created_on"]),
        createdById: json["created_by_id"],
        date: json["date"] == null ? null : json["date"],
        availability: json["availability"] == null ? [] : List<Availability>.from(json["availability"]!.map((x) => Availability.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "day_id": dayId,
        "state_id": stateId,
        "type_id": typeId,
        "created_on": createdOn?.toIso8601String(),
        "created_by_id": createdById,
        "date": date,
        "availability": availability == null ? [] : List<dynamic>.from(availability!.map((x) => x.toJson())),
      };
}
