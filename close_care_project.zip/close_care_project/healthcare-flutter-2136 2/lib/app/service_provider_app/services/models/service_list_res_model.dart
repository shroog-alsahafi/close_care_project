import 'dart:convert';

import 'package:healthcare/app/core/model/meta.dart';

ServiceListResModel serviceListResModelFromJson(String str) =>
    ServiceListResModel.fromJson(json.decode(str));

String serviceListResModelToJson(ServiceListResModel data) =>
    json.encode(data.toJson());

class ServiceListResModel {
  List<ServiceList>? list;
  Links? links;
  Meta? meta;
  String? copyrights;

  ServiceListResModel({
    this.list,
    this.links,
    this.meta,
    this.copyrights,
  });

  factory ServiceListResModel.fromJson(Map<String, dynamic> json) =>
      ServiceListResModel(
        list: json["list"] == null
            ? []
            : List<ServiceList>.from(
                json["list"]!.map((x) => ServiceList.fromJson(x))),
        links: json["_links"] == null ? null : Links.fromJson(json["_links"]),
        meta: json["_meta"] == null ? null : Meta.fromJson(json["_meta"]),
        copyrights: json["copyrights"],
      );

  Map<String, dynamic> toJson() => {
        "list": list == null
            ? []
            : List<dynamic>.from(list!.map((x) => x.toJson())),
        "_links": links?.toJson(),
        "_meta": meta?.toJson(),
        "copyrights": copyrights,
      };
}

class ServiceList {
  int? id;
  String? serviceTypeId;
  String? title;
  String? description;
  String? price;
  String? discountPrice;
  String? additionFee;
  dynamic serviceTime;
  dynamic imageId;
  int? stateId;
  int? typeId;
  DateTime? createdOn;
  int? createdById;
  List<Availability>? availability;

  ServiceList({
    this.id,
    this.serviceTypeId,
    this.title,
    this.description,
    this.price,
    this.discountPrice,
    this.additionFee,
    this.serviceTime,
    this.imageId,
    this.stateId,
    this.typeId,
    this.createdOn,
    this.createdById,
    this.availability,
  });

  factory ServiceList.fromJson(Map<String, dynamic> json) => ServiceList(
        id: json["id"],
        serviceTypeId: json["service_type_id"],
        title: json["title"],
        description: json["description"],
        price: json["price"],
        discountPrice: json["discount_price"],
        additionFee: json["addition_fee"],
        serviceTime: json["service_time"],
        imageId: json["image_id"],
        stateId: json["state_id"],
        typeId: json["type_id"],
        createdOn: json["created_on"] == null
            ? null
            : DateTime.parse(json["created_on"]),
        createdById: json["created_by_id"],
        availability: json["availability"] == null ? [] : List<Availability>.from(json["availability"]!.map((x) => Availability.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "service_type_id": serviceTypeId,
        "title": title,
        "description": description,
        "price": price,
        "discount_price": discountPrice,
        "addition_fee": additionFee,
        "service_time": serviceTime,
        "image_id": imageId,
        "state_id": stateId,
        "type_id": typeId,
        "created_on": createdOn?.toIso8601String(),
        "created_by_id": createdById,
        "availability": availability == null ? [] : List<dynamic>.from(availability!.map((x) => x.toJson())),
      };
}

class Availability {
  int? id;
  int? serviceId;
  int? dayId;
  String? startTime;
  String? endTime;
  int? stateId;
  int? typeId;
  DateTime? createdOn;
  int? createdById;

  Availability({
    this.id,
    this.serviceId,
    this.dayId,
    this.startTime,
    this.endTime,
    this.stateId,
    this.typeId,
    this.createdOn,
    this.createdById,
  });

  factory Availability.fromJson(Map<String, dynamic> json) => Availability(
        id: json["id"],
        serviceId: json["service_id"],
        dayId: json["day_id"],
        startTime: json["start_time"],
        endTime: json["end_time"],
        stateId: json["state_id"],
        typeId: json["type_id"],
        createdOn: json["created_on"] == null ? null : DateTime.parse(json["created_on"]),
        createdById: json["created_by_id"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "service_id": serviceId,
        "day_id": dayId,
        "start_time": startTime,
        "end_time": endTime,
        "state_id": stateId,
        "type_id": typeId,
        "created_on": createdOn?.toIso8601String(),
        "created_by_id": createdById,
      };
}
