import 'dart:convert';

import 'package:healthcare/app/core/model/meta.dart';

ServiceTypeListResModel serviceTypeListResModelFromJson(String str) =>
    ServiceTypeListResModel.fromJson(json.decode(str));

String serviceTypeListResModelToJson(ServiceTypeListResModel data) =>
    json.encode(data.toJson());

class ServiceTypeListResModel {
  List<ServiceTypeList>? list;
  Links? links;
  Meta? meta;
  String? copyrights;

  ServiceTypeListResModel({
    this.list,
    this.links,
    this.meta,
    this.copyrights,
  });

  factory ServiceTypeListResModel.fromJson(Map<String, dynamic> json) =>
      ServiceTypeListResModel(
        list: json["list"] == null
            ? []
            : List<ServiceTypeList>.from(
                json["list"]!.map((x) => ServiceTypeList.fromJson(x))),
        links: json["_links"] == null ? null : Links.fromJson(json["_links"]),
        meta: json["_meta"] == null ? null : Meta.fromJson(json["_meta"]),
        copyrights: json["copyrights"],
      );

  Map<String, dynamic> toJson() => {
        "list": list == null
            ? []
            : List<dynamic>.from(list!.map((x) => x.toJson())),
        "_links": links?.toJson(),
        "_meta": meta?.toJson(),
        "copyrights": copyrights,
      };
}

class First {
  String? href;

  First({
    this.href,
  });

  factory First.fromJson(Map<String, dynamic> json) => First(
        href: json["href"],
      );

  Map<String, dynamic> toJson() => {
        "href": href,
      };
}

class ServiceTypeList {
  int? id;
  String? title;
  dynamic description;
  dynamic imageId;
  int? stateId;
  int? typeId;
  DateTime? createdOn;
  int? createdById;

  ServiceTypeList({
    this.id,
    this.title,
    this.description,
    this.imageId,
    this.stateId,
    this.typeId,
    this.createdOn,
    this.createdById,
  });

  factory ServiceTypeList.fromJson(Map<String, dynamic> json) =>
      ServiceTypeList(
        id: json["id"],
        title: json["title"],
        description: json["description"],
        imageId: json["image_id"],
        stateId: json["state_id"],
        typeId: json["type_id"],
        createdOn: json["created_on"] == null
            ? null
            : DateTime.parse(json["created_on"]),
        createdById: json["created_by_id"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "title": title,
        "description": description,
        "image_id": imageId,
        "state_id": stateId,
        "type_id": typeId,
        "created_on": createdOn?.toIso8601String(),
        "created_by_id": createdById,
      };
}
