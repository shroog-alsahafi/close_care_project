import 'package:flutter/cupertino.dart';
import 'package:intl/intl.dart';
import 'package:healthcare/app/service_provider_app/services/controllers/add_availability_controller_provider.dart';

import '../../../../export.dart';
import '../../../core/widgets/time_formatter.dart';

class AddAvailabilityProvider extends GetView<AddAvailabilityController> {
  final controller = Get.put(AddAvailabilityController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        centerTitle: true,
        appBarTitleText: keyAddAvailability.tr,
        actionWidget: [
          Obx(
            () => Visibility(
              visible: controller.showUnAvailabilityBtn.value,
              child: GestureDetector(
                onTap: () {
                  controller.readOnly.value = false;
                },
                child: AssetImageWidget(
                  imageUrl: iconEdit,
                  imageWidth: height_28,
                  imageHeight: height_28,
                ),
              ),
            ),
          ),
          SizedBox(
            width: width_10,
          )
        ],
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: margin_15),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  titleTxt(title: keyAddTiming.tr),
                  SizedBox(width: width_50),
                  Expanded(
                      child: Obx(
                    () => Visibility(visible: controller.showUnAvailabilityBtn.value, child: _addUnAvailability()),
                  )),
                ],
              ),
              Padding(
                padding: EdgeInsets.only(left: margin_10, right: margin_20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _titleTxt(text: "Day"),
                    _titleTxt(text: keyStartTime.tr),
                    _titleTxt(text: keyEndTime.tr),
                  ],
                ),
              ),
              _listView(),
              Obx(
                () => Visibility(
                  visible: !controller.readOnly.value,
                  child: _saveButton(),
                ),
              ),
              _unAvailability(),
              SizedBox(
                height: height_50,
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _unAvailability() => Obx(
        () => Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (controller.unAvailableList.length != 0) titleTxt(title: keyUnAvailable.tr),
            ListView.separated(
              itemCount: controller.unAvailableList.length,
              physics: NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemBuilder: (context, index) {
                var unAvailable = controller.unAvailableList[index];
                return Container(
                  padding: EdgeInsets.symmetric(vertical: margin_5),
                  decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(radius_10)),
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.centerRight,
                        child: GestureDetector(
                            onTap: () {
                              controller.deleteUnAvailabilityApi(id: unAvailable.dayId);
                            },
                            child: Icon(
                              Icons.delete_forever_sharp,
                              size: height_20,
                              color: Colors.red,
                            )),
                      ).paddingOnly(right: margin_5),
                      customRow(
                          title: "Date:  ",
                          value: DateFormat("dd-MM-yyyy").format(DateTime.parse(unAvailable.date.toString())).toString(),
                          space: true),
                      Divider(height: height_1, color: Colors.grey.shade400),
                      customRow(
                          title: "Day:  ",
                          value: "${unAvailable.typeId == 1 ? "Unavailable for all " : ""} ${dayWithId(dayId: unAvailable.dayId ?? 0)}",
                          space: true),
                      Divider(height: height_1, color: Colors.grey.shade400),
                      customRow(title: "Timing:  "),
                      ListView.builder(
                          padding: EdgeInsets.symmetric(horizontal: margin_10),
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: unAvailable.availability!.length,
                          itemBuilder: (context, index1) {
                            return Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                unAvailable.availability![index1].startTime == null
                                    ? SizedBox()
                                    : textFieldTitle(
                                        "${utcToLocalLatest(DateFormat("yyyy-MM-dd ").format(DateTime.now()) + unAvailable.availability![index1].startTime!, "hh:mm a") ?? ''}  - "
                                        "${utcToLocalLatest(DateFormat("yyyy-MM-dd ").format(DateTime.now()) + unAvailable.availability![index1].endTime!, "hh:mm a") ?? ''}",
                                      ),
                              ],
                            );
                          })
                    ],
                  ),
                );
              },
              separatorBuilder: (BuildContext context, int index) {
                return SizedBox(height: height_10);
              },
            ),
          ],
        ),
      );

  Widget _titleTxt({required String text, Color? color}) => TextView(
        text: text,
        textStyle: textStyleTitle().copyWith(fontSize: font_12, color: color ?? colorAppColors, fontWeight: FontWeight.bold),
      );

  _listView() {
    return Obx(
      () => Form(
        key: controller.formKey,
        child: ListView.separated(
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          itemCount: controller.slotsList.length,
          itemBuilder: (context, index) {
            return Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: width_30,
                  child: _titleTxt(
                    text: dayWithId(dayId: controller.slotsList[index].dayID ?? 0),
                    color: Colors.black,
                  ),
                ),
                SizedBox(width: width_25),
                Expanded(child: _startTime(controller.slotsList[index].startTime!, controller.slotsList[index].endTime!, index)),
                SizedBox(width: width_25),
                Expanded(child: _endTime(controller.slotsList[index].endTime!, controller.slotsList[index].startTime!, index)),
              ],
            );
          },
          separatorBuilder: (BuildContext context, int index) {
            return SizedBox(
              height: height_15,
            );
          },
        ),
      ),
    );
  }

  Widget _startTime(TextEditingController txtController, TextEditingController txtController2, int index) {
    return Obx(
      () => TextFieldWidget(
        radius: radius_5,
        inputFormatter: [FilteringTextInputFormatter.digitsOnly],
        contentPadding: EdgeInsets.only(top: margin_13, bottom: margin_13, left: margin_18),
        // tvHeading: keyStartTime.tr,
        decoration: DecoratedInputBorder(
          child: OutlineInputBorder(
            borderRadius: BorderRadius.circular(radius_5),
            borderSide: BorderSide(
              color: colorAppColors,
              style: BorderStyle.solid,
              width: width_1,
            ),
          ),
          shadow: BoxShadow(color: Colors.grey.shade300, blurRadius: 1, spreadRadius: 1),
        ),
        hintStyle: TextStyle(fontWeight: FontWeight.w300, fontSize: font_13, color: Colors.white),
        textController: txtController,
        readOnly: true,
        onTap: controller.readOnly.value
            ? null
            : () async {
                var pickedTime;
                var formattedTimeOfDay;
                pickedTime = await showTimePicker(context: Get.context!, initialTime: formattedTimeOfDay ?? TimeOfDay.now());
                if (pickedTime != null) {
                  controller.slotsList[index].serverStartTime = DateFormat("HH:mm").format(DateTime(
                    DateTime.now().year,
                    DateTime.now().month,
                    DateTime.now().day,
                    pickedTime.hour,
                    pickedTime.minute,
                    00,
                  ).toUtc());
                  txtController.text = DateFormat("hh:mm a").format(DateTime(
                    DateTime.now().year,
                    DateTime.now().month,
                    DateTime.now().day,
                    pickedTime.hour,
                    pickedTime.minute,
                    00,
                  ));
                }
              },
        suffixIcon: Icon(
          CupertinoIcons.clock_solid,
          color: colorAppColors,
          size: height_14,
        ),
        validate: (value) => Validator.time(value, txtController2.text),
        courserColor: Colors.white,
      ),
    );
  }

  Widget _endTime(TextEditingController txtController, TextEditingController txtController2, int index) {
    return Obx(
      () => TextFieldWidget(
        decoration: DecoratedInputBorder(
          child: OutlineInputBorder(
            borderRadius: BorderRadius.circular(radius_5),
            borderSide: BorderSide(
              color: colorAppColors,
              style: BorderStyle.solid,
              width: width_1,
            ),
          ),
          shadow: BoxShadow(color: Colors.grey.shade300, blurRadius: 1, spreadRadius: 1),
        ),
        inputFormatter: [FilteringTextInputFormatter.digitsOnly],
        contentPadding: EdgeInsets.only(top: margin_13, bottom: margin_13, left: margin_18),
        // tvHeading: keyEndTime.tr,
        hintStyle: TextStyle(fontWeight: FontWeight.w300, fontSize: font_13, color: Colors.white),
        textController: txtController,
        readOnly: true,
        onTap: controller.readOnly.value
            ? null
            : () async {
                var formattedTimeOfDay;
                var pickedTime = await showTimePicker(context: Get.context!, initialTime: formattedTimeOfDay ?? TimeOfDay.now());
                // var pickedTime = await showTimePicker(context: Get.context!, initialTime: formattedTimeOfDay ?? TimeOfDay.now());

                if (pickedTime != null) {
                  controller.slotsList[index].serverEndTime = DateFormat("HH:mm").format(DateTime(
                    DateTime.now().year,
                    DateTime.now().month,
                    DateTime.now().day,
                    pickedTime.hour,
                    pickedTime.minute,
                    00,
                  ).toUtc());
                  txtController.text = DateFormat("hh:mm a").format(DateTime(
                    DateTime.now().year,
                    DateTime.now().month,
                    DateTime.now().day,
                    pickedTime.hour,
                    pickedTime.minute,
                    00,
                  ));
                  // controller.slotsList[index].serverEndTime=
                }
              },
        suffixIcon: Icon(
          CupertinoIcons.clock_solid,
          color: colorAppColors,
          size: height_14,
        ),
        validate: (value) => Validator.time2(txtController2.text, value),
        courserColor: Colors.white,
      ),
    );
  }

  Widget _saveButton() {
    return MaterialButtonWidget(
      padding: 10,
      buttonRadius: radius_5,
      buttonText: keySave.tr,
      onPressed: () {
        if (controller.formKey.currentState!.validate()) {
          if (controller.slotsList.any((e) => e.startTime?.text != "")) {
            controller.addAvailabilityApi();
          } else {
            toast("Please Add Timing");
          }
        }
      },
    ).paddingSymmetric(
      vertical: margin_30,
    );
  }

  Widget _addUnAvailability() {
    return MaterialButtonWidget(
      padding: margin_5,
      buttonRadius: radius_5,
      buttonColor: Colors.red,
      buttonText: keyAddUnAvailability.tr,
      onPressed: () {
        Get.toNamed(AppRoutes.addUnAvailability);
      },
    ).paddingSymmetric(
      vertical: margin_30,
    );
  }

  _horizontalCalender() => SizedBox(
        height: height_50,
        child: ListView.separated(
          itemCount: controller.weedDaysList.length,
          shrinkWrap: true,
          scrollDirection: Axis.horizontal,
          itemBuilder: (context, index) {
            var weekDays = controller.weedDaysList[index];
            return Obx(
              () => GestureDetector(
                onTap: () {
                  // controller.selectedDay.value = weekDays.id!;
                },
                child: Container(
                  width: width_50,
                  alignment: Alignment.center,
                  padding: EdgeInsets.symmetric(horizontal: margin_12, vertical: margin_20),
                  decoration: BoxDecoration(
                    color: controller.selectedDay.value == weekDays.id! ? colorAppColors : colorGrey,
                    borderRadius: BorderRadius.circular(radius_10),
                  ),
                  child: TextView(
                    textAlign: TextAlign.start,
                    text: weekDays.day ?? "",
                    textStyle: textStyleTitle().copyWith(
                      color: controller.selectedDay.value == weekDays.id! ? Colors.black : Colors.grey.shade500,
                      fontSize: font_12,
                    ),
                  ),
                ),
              ),
            );
          },
          separatorBuilder: (BuildContext context, int index) {
            return SizedBox(
              width: width_10,
            );
          },
        ),
      );

  _customText({required text}) => TextView(
        textAlign: TextAlign.start,
        text: text,
        textStyle: textStyleTitle().copyWith(color: Colors.grey.shade300, fontSize: font_13),
      );
}
