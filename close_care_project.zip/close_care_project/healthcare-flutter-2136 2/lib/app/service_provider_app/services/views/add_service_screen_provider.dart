import 'package:flutter/cupertino.dart';
import '../../../../export.dart';
import '../../../core/widgets/drop_down_widget.dart';
import '../controllers/add_service_controller_provider.dart';
import '../models/service_type_list_res_model.dart';

class AddServiceScreenProvider extends GetView<AddServiceControllerProvider> {
  const AddServiceScreenProvider({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: CustomAppBar(appBarTitleText: "${keyAddServices.tr}",centerTitle: true,),
      body: Form(
        key: controller.formKey,
        child: ListView(
          padding: EdgeInsets.all(margin_17),
          children: [
            _serviceDropDown(),
            SizedBox(height: height_10),
            _serviceTime(),
            SizedBox(height: height_10),
            _servicePrice(),
            SizedBox(height: height_10),
            _description(),
            SizedBox(height: height_10),
            _saveButton(),
          ],
        ),
      ),
    );
  }

  _serviceDropDown() {
    return Obx(
      () => DropDownWidget(
        tvHeading: "${keyServiceType.tr}",
        hint: controller.selectedOption ?? "",
        radius: radius_5,
        dropdownMenuItems: controller.serviceDetail.value.id != null
            ? []
            : controller.serviceList.map((selectedType) {
                return DropdownMenuItem(
                  child: Text(
                    selectedType.title ?? "",
                  ),
                  value: selectedType,
                );
              }).toList(),
        onChanged: (value) {
          controller.selectedOption = null;
          controller.serviceTypeList = value as ServiceTypeList;
          controller.selectedOption = controller.serviceTypeList.title;
        },
        validate: (value) => Validator.fieldChecker(controller.selectedOption ?? "", keyServiceType.tr),
      ),
    );
  }

  _serviceTime() {
    return TextFieldWidget(
      maxLength: 180,
      radius: radius_5,
      inputFormatter: [FilteringTextInputFormatter.digitsOnly],
      contentPadding: EdgeInsets.only(top: margin_13, bottom: margin_13, left: margin_18),
      tvHeading: keyServiceTime.tr,
      textController: controller.serviceTimeTxtController,
      focusNode: controller.serviceTimeTxtFocusNode,
      inputType: TextInputType.number,
      suffixIcon: IntrinsicWidth(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            TextView(text: "${keyInMin.tr}   ", textStyle: textStyleTitle().copyWith(color: Colors.white)),
            Icon(
              CupertinoIcons.clock_solid,
              color: colorAppColors,
              size: height_14,
            ),
            SizedBox(
              width: width_10,
            )
          ],
        ),
      ),
      validate: (value) => Validator.timeChecker(value, keyServiceTime.tr),
      courserColor: Colors.white,
      shadow: true,
    );
  }

  _servicePrice() {
    return TextFieldWidget(
      inputType: TextInputType.number,
      inputFormatter: [FilteringTextInputFormatter.digitsOnly],
      maxLength: 180,
      radius: radius_5,
      contentPadding: EdgeInsets.only(top: margin_13, bottom: margin_13, left: margin_18),
      tvHeading: keyServicePrice.tr,
      textController: controller.servicePriceTxtController,
      focusNode: controller.servicePriceTxtFocusNode,
      validate: (value) => Validator.priceChecker(value, keyServicePrice.tr),
      courserColor: Colors.white,
      shadow: true,
    );
  }

  _description() {
    return TextFieldWidget(
      minLine: 5,
      maxline: 5,
      maxLength: 180,
      radius: radius_5,
      contentPadding: EdgeInsets.only(top: margin_13, bottom: margin_13, left: margin_18),
      tvHeading: keyDescription.tr,
      textController: controller.descriptionTxtController,
      focusNode: controller.descriptionTxtFocusNode,
      validate: (value) => Validator.fieldChecker(value, keyDescription.tr),
      courserColor: Colors.white,
      shadow: true,
    );
  }

  _saveButton() {
    return MaterialButtonWidget(
      padding: 10,
      buttonRadius: radius_5,
      buttonText: keySave.tr,
      onPressed: () {
        if (controller.formKey.currentState!.validate()) {
          controller.addServiceApi();
        }
      },
    ).paddingSymmetric(
      vertical: margin_30,
    );
  }
}
