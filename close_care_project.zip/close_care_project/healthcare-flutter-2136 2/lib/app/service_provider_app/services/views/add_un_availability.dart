import 'dart:ffi';

import 'package:flutter/cupertino.dart';
import 'package:healthcare/app/service_provider_app/services/controllers/add_un_availability_controller.dart';
import 'package:intl/intl.dart';
import 'package:healthcare/app/service_provider_app/services/controllers/add_availability_controller_provider.dart';

import '../../../../export.dart';

class AddUnAvailability extends GetView<AddUnAvailabilityController> {
  final controller = Get.put(AddUnAvailabilityController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        centerTitle: true,
        appBarTitleText: keyAddUnAvailability.tr,
      ),
      body: Form(
        key: controller.formKey,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: margin_15),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _dateField(),
                SizedBox(height: height_10),
                Obx(
                  () => Visibility(
                    visible: controller.day.value.isNotEmpty,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: TextView(
                            textAlign: TextAlign.start,
                            text: "Select this unavailability for all ${controller.day.value}",
                            textStyle: textStyleTitle().copyWith(color: colorAppColors, fontSize: font_15),
                          ),
                        ),
                        Switch(
                          inactiveTrackColor: Colors.grey.shade400,
                          activeTrackColor: colorAppColor,
                          trackOutlineColor: MaterialStateProperty.resolveWith(
                            (final Set<MaterialState> states) {
                              return Colors.white;
                            },
                          ),
                          thumbColor: MaterialStatePropertyAll(Colors.white),
                          value: controller.selectForAllDay.value,
                          onChanged: (val) {
                            controller.selectForAllDay.value = val;
                          },
                        ),
                      ],
                    ),
                  ),
                ),
                Row(
                  children: [
                    titleTxt(title: keyUnAvailable.tr),
                    Spacer(),
                    Obx(
                      () => Visibility(
                        visible: controller.slotsList.length != 3,
                        child: IconButton(
                          onPressed: () {
                            controller.slotsList.add(SlotModel(
                                startTime: TextEditingController(), endTime: TextEditingController(), serverStartTime: "", serverEndTime: ""));
                          },
                          icon: Icon(Icons.add),
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: EdgeInsets.only(left: margin_70, right: margin_60, bottom: margin_10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _titleTxt(text: keyStartTime.tr),
                      _titleTxt(text: keyEndTime.tr),
                    ],
                  ),
                ),
                _listView(),
                _saveButton(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _dateField() {
    return TextFieldWidget(
        readOnly: true,
        textController: controller.dateController,
        hint: keySelectDate.tr,
        decoration: DecoratedInputBorder(
          child: OutlineInputBorder(
            borderRadius: BorderRadius.circular(radius_5),
            borderSide: BorderSide(
              color: colorAppColors,
              style: BorderStyle.solid,
              width: width_1,
            ),
          ),
          shadow: BoxShadow(color: Colors.grey.shade300, blurRadius: 1, spreadRadius: 1),
        ),
        radius: radius_7,
        inputAction: TextInputAction.next,
        inputType: TextInputType.text,
        onTap: () {
          _selectDate();
        },
        suffixIcon: AssetImageWidget(
          imageUrl: iconCalendar,
          imageHeight: height_10,
        ).marginAll(margin_10),
        validate: (value) => FieldChecker.fieldChecker(value: value.toString().trim(), message: keySelectDate.tr),
        focusNode: controller.dateFocusNode);
  }

  _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: Get.context!,
      initialDate: controller.selectedDate,
      initialDatePickerMode: DatePickerMode.day,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 30)),
    );
    if (picked != null) controller.selectedDate = picked;
    controller.dateController.text = DateFormat("dd-MM-yyyy").format(controller.selectedDate);
    controller.day.value = DateFormat("EEEE").format(controller.selectedDate);
  }

  Widget _titleTxt({required String text, Color? color}) => TextView(
        text: text,
        textStyle: textStyleTitle().copyWith(fontSize: font_12, color: color ?? colorAppColors, fontWeight: FontWeight.bold),
      );
  _listView() {
    return Obx(
      () => ListView.separated(
        shrinkWrap: true,
        physics: NeverScrollableScrollPhysics(),
        itemCount: controller.slotsList.length,
        itemBuilder: (context, index) {
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(width: width_25),
              Expanded(child: _startTime(controller.slotsList[index].startTime!, controller.slotsList[index].endTime!, index)),
              SizedBox(width: width_25),
              Expanded(child: _endTime(controller.slotsList[index].endTime!, controller.slotsList[index].startTime!, index)),
              index == 0
                  ? SizedBox(width: width_40)
                  : IconButton(
                      onPressed: () {
                        controller.slotsList.removeAt(index);
                      },
                      icon: Icon(Icons.remove),
                    ),
            ],
          );
        },
        separatorBuilder: (BuildContext context, int index) {
          return SizedBox(
            height: height_15,
          );
        },
      ),
    );
  }

  Widget _startTime(TextEditingController txtController, TextEditingController txtController2, index) {
    return TextFieldWidget(
      radius: radius_5,
      inputFormatter: [FilteringTextInputFormatter.digitsOnly],
      contentPadding: EdgeInsets.only(top: margin_13, bottom: margin_13, left: margin_18),
      // tvHeading: keyStartTime.tr,
      decoration: DecoratedInputBorder(
        child: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radius_5),
          borderSide: BorderSide(
            color: colorAppColors,
            style: BorderStyle.solid,
            width: width_1,
          ),
        ),
        shadow: BoxShadow(color: Colors.grey.shade300, blurRadius: 1, spreadRadius: 1),
      ),
      hintStyle: TextStyle(fontWeight: FontWeight.w300, fontSize: font_13, color: Colors.white),
      textController: txtController,
      readOnly: true,
      onTap: () async {
        var pickedTime;
        var formattedTimeOfDay;
        pickedTime = await showTimePicker(context: Get.context!, initialTime: formattedTimeOfDay ?? TimeOfDay.now());
        if (pickedTime != null) {
          txtController.text = DateFormat("hh:mm a").format(
            DateTime(
              DateTime.now().year,
              DateTime.now().month,
              DateTime.now().day,
              pickedTime.hour,
              pickedTime.minute,
              00,
            ),
          );
          controller.slotsList[index].serverStartTime = DateFormat("HH:mm").format(DateTime(
            DateTime.now().year,
            DateTime.now().month,
            DateTime.now().day,
            pickedTime.hour,
            pickedTime.minute,
            00,
          ).toUtc());
        }
      },
      suffixIcon: Icon(
        CupertinoIcons.clock_solid,
        color: colorAppColors,
        size: height_14,
      ),
      validate: (value) => Validator.time(value, txtController2.text),
      courserColor: Colors.white,
    );
  }

  Widget _endTime(TextEditingController txtController, TextEditingController txtController2, index) {
    return TextFieldWidget(
      decoration: DecoratedInputBorder(
        child: OutlineInputBorder(
          borderRadius: BorderRadius.circular(radius_5),
          borderSide: BorderSide(
            color: colorAppColors,
            style: BorderStyle.solid,
            width: width_1,
          ),
        ),
        shadow: BoxShadow(color: Colors.grey.shade300, blurRadius: 1, spreadRadius: 1),
      ),
      inputFormatter: [FilteringTextInputFormatter.digitsOnly],
      contentPadding: EdgeInsets.only(top: margin_13, bottom: margin_13, left: margin_18),
      // tvHeading: keyEndTime.tr,
      hintStyle: TextStyle(fontWeight: FontWeight.w300, fontSize: font_13, color: Colors.white),
      textController: txtController,
      readOnly: true,
      onTap: () async {
        var formattedTimeOfDay;
        var pickedTime = await showTimePicker(context: Get.context!, initialTime: formattedTimeOfDay ?? TimeOfDay.now());
        if (pickedTime != null) {
          txtController.text = DateFormat("hh:mm a").format(DateTime(
            DateTime.now().year,
            DateTime.now().month,
            DateTime.now().day,
            pickedTime.hour,
            pickedTime.minute,
            00,
          ));

          controller.slotsList[index].serverEndTime = DateFormat("HH:mm").format(DateTime(
            DateTime.now().year,
            DateTime.now().month,
            DateTime.now().day,
            pickedTime.hour,
            pickedTime.minute,
            00,
          ).toUtc());
        }
      },
      suffixIcon: Icon(
        CupertinoIcons.clock_solid,
        color: colorAppColors,
        size: height_14,
      ),
      validate: (value) => Validator.time2(txtController2.text, value),
      courserColor: Colors.white,
    );
  }

  _saveButton() {
    return MaterialButtonWidget(
      padding: 10,
      buttonRadius: radius_5,
      buttonText: keySave.tr,
      onPressed: () {
        if (controller.formKey.currentState!.validate()) {
          if (controller.slotsList.any((e) => e.startTime?.text != "")) {
            controller.addUnAvailabilityApi();
          } else {
            toast("Please Add Timing");
          }
        }
      },
    ).paddingSymmetric(vertical: margin_30);
  }
}
