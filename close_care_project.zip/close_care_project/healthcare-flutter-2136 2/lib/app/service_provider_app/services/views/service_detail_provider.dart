import 'package:intl/intl.dart';
import 'package:healthcare/app/service_provider_app/services/controllers/service_details_controller_provider.dart';
import 'package:healthcare/export.dart';

class ServiceDetailsProvider extends GetView<ServiceDetailControllerProvider> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        centerTitle: true,
        appBarTitleText: keyServiceDetail.tr,
        actionWidget: [
          _editWidget(onTap: () {
            Get.offNamed(
              AppRoutes.addServiceScreenProvider,
              arguments: {"serviceDetail": controller.serviceDetail},
            );
          }),
          SizedBox(width: width_10),
        ],
      ),
      body: ListView(
        padding: EdgeInsets.symmetric(horizontal: margin_16),
        children: [
          Row(
            children: [
              titleTxt(title: controller.serviceDetail.title ?? ""),
              Spacer(),
              TextView(
                text: "\$${controller.serviceDetail.price}",
                textStyle: textStyleTitle().copyWith(color: colorAppColors, fontSize: font_15),
              ),
            ],
          ),
          Row(
            children: [
              Icon(
                Icons.access_time_filled_sharp,
                color: Colors.white,
                size: height_15,
              ),
              TextView(
                text: "  ${controller.serviceDetail.serviceTime} ${keyMin.tr}",
                textStyle: textStyleTitle().copyWith(color: Colors.white, fontSize: font_14),
              ),
            ],
          ),
          Divider(height: height_15, color: Colors.grey.shade800),
          titleTxt(title: keyAvailability.tr),
          _availabilityAndSlots(),
          Obx(
            () => Visibility(
              visible: controller.availabilityList.length == 0,
              child: _addAvailabilityBtn(),
            ),
          ),
          titleTxt(title: keyIncluded.tr),
          TextView(
            textAlign: TextAlign.start,
            text: controller.serviceDetail.description ?? "",
            textStyle: textStyleTitle()
                .copyWith(color: Colors.grey.shade500, fontSize: font_10),
          ),
        ],
      ),
    );
  }

  Widget _addAvailabilityBtn() => GestureDetector(
        onTap: () {
          Get.toNamed(AppRoutes.addAvailabilityProvider,
              arguments: {"serviceDetail": controller.serviceDetail});
        },
        child: Container(
          padding: EdgeInsets.all(margin_10),
          decoration: BoxDecoration(
            border: Border.all(color: colorAppColors),
            borderRadius: BorderRadius.circular(radius_4),
          ),
          child: TextView(
            text: keyAddAvailability.tr,
            textStyle: textStyleTitle().copyWith(color: Colors.white, fontSize: font_14),
          ),
        ),
      );

  Widget _availabilityAndSlots() {
    return Column(
      children: [
        SizedBox(
          height: height_50,
          child: ListView.separated(
            itemCount: controller.weedDaysList.length,
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) {
              var weekDays = controller.weedDaysList[index];
              return GestureDetector(
                onTap: () {
                  if (controller.selectedDay.value != weekDays.id!) {
                    controller.selectedDay.value = weekDays.id!;
                    controller.hitServiceAvailabilityApi();
                  }
                },
                child: Obx(
                  () => Container(
                    width: width_50,
                    alignment: Alignment.center,
                    padding: EdgeInsets.symmetric(
                        horizontal: margin_12, vertical: margin_20),
                    decoration: BoxDecoration(
                      color: controller.selectedDay.value == weekDays.id!
                          ? colorAppColors
                          : colorGrey,
                      borderRadius: BorderRadius.circular(radius_10),
                    ),
                    child: TextView(
                      textAlign: TextAlign.start,
                      text: weekDays.day ?? "",
                      textStyle: textStyleTitle().copyWith(
                        color: controller.selectedDay.value == weekDays.id!
                            ? Colors.black
                            : Colors.grey.shade500,
                        fontSize: font_12,
                      ),
                    ),
                  ),
                ),
              );
            },
            separatorBuilder: (BuildContext context, int index) {
              return SizedBox(
                width: width_10,
              );
            },
          ),
        ),
        SizedBox(height: height_15),
        Row(
          children: [
            /*GestureDetector(
              onTap: () {
              },
              child: IntrinsicWidth(
                child: Row(
                  children: [
                    _customText(text: "Feb,2024"),
                    Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white),
                  ],
                ),
              ),
            ),*/
            Spacer(),
            Obx(
              () => Visibility(
                visible: controller.availabilityList.length != 0,
                child: _editWidget(onTap: () {
                  controller.serviceDetail.availability =
                      controller.availabilityList ?? [];
                  Get.toNamed(AppRoutes.addAvailabilityProvider, arguments: {
                    "serviceDetail": controller.serviceDetail,
                    "id": controller.availabilityList.first.serviceId ?? ""
                  });
                }),
              ),
            ),
          ],
        ),
        SizedBox(height: height_5),
        Obx(
          () => Visibility(
            visible: controller.availabilityList.length != 0,
            child: Row(
              children: [
                Expanded(child: _customText(text: keyStartTime.tr)),
                SizedBox(
                  width: width_15,
                ),
                Expanded(child: _customText(text: keyEndTime.tr)),
              ],
            ),
          ),
        ),
        SizedBox(
          height: height_5,
        ),
        _slots(),
      ],
    );
  }

  _slots() => Obx(
        () => ListView.separated(
          itemCount: controller.availabilityList.length,
          shrinkWrap: true,
          physics: NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            var avail = controller.availabilityList[index];
            return SizedBox(
              width: Get.width,
              child: Row(
                children: [
                  _customContainer(text: avail.startTime ?? ""),
                  SizedBox(
                    width: width_15,
                  ),
                  _customContainer(text: avail.endTime ?? ""),
                ],
              ),
            );
          },
          separatorBuilder: (BuildContext context, int index) {
            return SizedBox(
              height: height_10,
            );
          },
        ),
      );

  Widget _customContainer({required text, EdgeInsetsGeometry? padding}) {
    var splittedHour = text.toString().split(":")[0];
    var splittedMinute = text.toString().split(":")[1];
    var dateTime = DateTime(
            DateTime.now().year,
            DateTime.now().month,
            DateTime.now().day,
            int.parse(splittedHour),
            int.parse(splittedMinute),
            00)
        .toLocal();

    return Expanded(
      child: Container(
        padding: padding ??
            EdgeInsets.symmetric(horizontal: margin_12, vertical: margin_14),
        decoration: BoxDecoration(
          color: colorGrey,
          borderRadius: BorderRadius.circular(radius_4),
        ),
        child: TextView(
          textAlign: TextAlign.start,
          text: utcToLocalLatest(dateTime.toString(), "hh:mm a"),
          textStyle: textStyleTitle()
              .copyWith(color: Colors.grey.shade300, fontSize: font_12),
        ),
      ),
    );
  }

  _customText({required text}) => TextView(
        textAlign: TextAlign.start,
        text: text,
        textStyle: textStyleTitle()
            .copyWith(color: Colors.grey.shade300, fontSize: font_13),
      );

  Widget _editWidget({required onTap}) => GestureDetector(
        onTap: onTap,
        child: IntrinsicWidth(
          child: Row(
            children: [
              Icon(
                Icons.edit,
                size: height_15,
              ),
              TextView(
                textAlign: TextAlign.start,
                text: keyEdit.tr,
                textStyle: textStyleTitle().copyWith(color: colorAppColors, fontSize: font_13),
              )
            ],
          ),
        ),
      );
}
