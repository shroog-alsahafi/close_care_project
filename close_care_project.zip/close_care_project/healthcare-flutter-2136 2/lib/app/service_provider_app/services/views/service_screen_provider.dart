import '../../../../export.dart';
import '../controllers/service_screen_controller_provider.dart';

class ServiceScreenProvider extends GetView<ServiceScreenControllerProvider> {
  const ServiceScreenProvider({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        centerTitle: true,
        appBarTitleText: keyServices.tr,
        isBackIcon: false,
      ),
      body: Obx(
        () => controller.serviceList.isEmpty
            ? noDataToShow(inputText: keyNoServiceAddYet.tr)
            : ListView.separated(
                controller: controller.scrollController,
                padding: EdgeInsets.only(left: margin_15, right: margin_15, bottom: height_150),
                itemCount: controller.serviceList.length,
                itemBuilder: (context, index) {
                  var service = controller.serviceList[index];
                  return GestureDetector(
                    onTap: () {
                      Get.toNamed(AppRoutes.serviceDetailProvider, arguments: {"serviceDetail": service});
                    },
                    child: Container(
                      padding: EdgeInsets.all(margin_15),
                      decoration: BoxDecoration(color: colorGrey, borderRadius: BorderRadius.circular(radius_10)),
                      child: Row(
                        children: [
                          Expanded(
                              child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              titleTxt(title: service.title ?? "", verticalMargin: margin_0),
                              Row(
                                children: [
                                  Icon(
                                    Icons.access_time_rounded,
                                    size: height_13,
                                  ),
                                  TextView(
                                    text: " ${service.serviceTime ?? ""} ${keyMin.tr}",
                                    textStyle: textStyleTitle().copyWith(
                                      color: Colors.white,
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ),
                                  SizedBox(
                                    width: width_20,
                                  ),
                                  TextView(
                                    text: "\$${service.price ?? ""}",
                                    textStyle: textStyleTitle().copyWith(
                                      color: colorAppColors,
                                    ),
                                  )
                                ],
                              )
                            ],
                          )),
                          Icon(Icons.navigate_next)
                        ],
                      ),
                    ),
                  );
                },
                separatorBuilder: (BuildContext context, int index) {
                  return SizedBox(
                    height: height_15,
                  );
                },
              ),
      ),
      floatingActionButton: _floatingBtn(),
    );
  }

  _floatingBtn() => GestureDetector(
        onTap: () {
          Get.toNamed(AppRoutes.addServiceScreenProvider);
        },
        child: Container(
          decoration: BoxDecoration(
            color: colorAppColors,
            borderRadius: BorderRadius.circular(radius_4),
          ),
          margin: EdgeInsets.only(bottom: margin_70),
          height: height_50,
          width: height_50,
          child: Icon(Icons.add, color: Colors.black),
        ),
      );
}
