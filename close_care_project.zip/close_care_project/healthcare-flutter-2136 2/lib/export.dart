/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

export 'dart:async';
export 'dart:convert';
// dart package
export 'dart:io';
export 'dart:typed_data';

export 'package:cached_network_image/cached_network_image.dart';
export 'package:connectivity_plus/connectivity_plus.dart';
export 'package:dio/dio.dart' hide VoidCallback;
export 'package:file_picker/file_picker.dart';
export 'package:firebase_auth/firebase_auth.dart';
export 'package:firebase_core/firebase_core.dart';
export 'package:firebase_messaging/firebase_messaging.dart' hide AuthorizationStatus;
export 'package:flutter/gestures.dart';
// flutter package
export 'package:flutter/material.dart';
export 'package:flutter/services.dart';
export 'package:flutter_easyloading/flutter_easyloading.dart';
export 'package:flutter_facebook_auth/flutter_facebook_auth.dart';
export 'package:flutter_local_notifications/flutter_local_notifications.dart';

///logger
export 'package:flutter_screenutil/flutter_screenutil.dart';
export 'package:flutter_share/flutter_share.dart';
export 'package:get/get.dart' hide Response, HeaderValue, MultipartFile, FormData;
export 'package:get_storage/get_storage.dart';
export 'package:google_sign_in/google_sign_in.dart';

/// languages
export 'package:healthcare/app/core/translations/languages/en_Us.dart';
export 'package:healthcare/app/core/translations/languages/pt_BR.dart';
export 'package:healthcare/app/core/translations/local_keys.dart';
export 'package:healthcare/app/core/translations/translation_service.dart';
export 'package:healthcare/app/core/utils/field_checker.dart';
export 'package:healthcare/app/core/utils/helper_widget.dart';
export 'package:healthcare/app/core/utils/image_picker_and_cropper.dart';
// components
export 'package:healthcare/app/core/utils/projectutils/base_constant.dart';
export 'package:healthcare/app/core/values/app_assets.dart';
export 'package:healthcare/app/core/values/app_colors.dart';

/// constants
export 'package:healthcare/app/core/values/app_constant.dart';
export 'package:healthcare/app/core/values/app_strings.dart';
export 'package:healthcare/app/core/values/app_theme.dart';
export 'package:healthcare/app/core/values/dimens.dart';
export 'package:healthcare/app/core/values/font_family.dart';
export 'package:healthcare/app/core/values/route_arguments.dart';
export 'package:healthcare/app/core/values/text_styles.dart';
export 'package:healthcare/app/core/widgets/alert_dialogue_widget.dart';
export 'package:healthcare/app/core/widgets/annotated_region_widget.dart';
export 'package:healthcare/app/core/widgets/asset_image.dart';
export 'package:healthcare/app/core/widgets/button_widget.dart';
export 'package:healthcare/app/core/widgets/country_picker.dart';
export 'package:healthcare/app/core/widgets/custom_appbar.dart';
export 'package:healthcare/app/core/widgets/custom_expension_tile.dart';
export 'package:healthcare/app/core/widgets/custom_flashbar.dart';
export 'package:healthcare/app/core/widgets/custom_image.dart';

///main
export 'package:healthcare/app/core/widgets/custom_loader.dart';
export 'package:healthcare/app/core/widgets/custom_textfield.dart';
export 'package:healthcare/app/core/widgets/dialogs.dart';
export 'package:healthcare/app/core/widgets/doubleback_widget.dart';
export 'package:healthcare/app/core/widgets/image_picker_dialog.dart';
export 'package:healthcare/app/core/widgets/network_image.dart';
export 'package:healthcare/app/core/widgets/other_screen_heading.dart';
export 'package:healthcare/app/core/widgets/read_more_widget.dart';
export 'package:healthcare/app/core/widgets/screen_heading.dart';
export 'package:healthcare/app/core/widgets/text_view.dart';
export 'package:healthcare/app/core/widgets/validator.dart';

/// models
export 'package:healthcare/app/data/common_models/error_response_model.dart';
export 'package:healthcare/app/data/common_models/message_response_model.dart';

///connection Check
export 'package:healthcare/app/data/internet_check/dependency.dart';
export 'package:healthcare/app/data/internet_check/network_controller.dart';
export 'package:healthcare/app/data/internet_check/no_internet_screen.dart';
export 'package:healthcare/app/data/local_service/local_keys.dart';
export 'package:healthcare/app/data/local_service/preference/preference_manager.dart';
export 'package:healthcare/app/data/remote_service/entity/request_model/auth_reuest_model.dart';
export 'package:healthcare/app/data/remote_service/network/api_provider.dart';
export 'package:healthcare/app/data/remote_service/network/dio_client.dart';
export 'package:healthcare/app/data/remote_service/network/endpoint.dart';
export 'package:healthcare/app/data/remote_service/network/network_exceptions.dart';

///shared
export 'package:healthcare/app/logger/logger_utils.dart';
export 'package:healthcare/app/modules/about/controllers/about_us_controller.dart';
export 'package:healthcare/app/modules/about/views/about_us_screen.dart';
export 'package:healthcare/app/modules/authentication/binding/binding.dart';
export 'package:healthcare/app/modules/authentication/controllers/login_controller.dart';
export 'package:healthcare/app/modules/authentication/controllers/otp_controller.dart';
export 'package:healthcare/app/modules/authentication/controllers/profile_controller.dart';
export 'package:healthcare/app/modules/authentication/controllers/profile_view_controller.dart';
export 'package:healthcare/app/modules/authentication/controllers/register_controller.dart';

///data models
export 'package:healthcare/app/modules/authentication/model/data_model/user_details_data_model.dart';
export 'package:healthcare/app/modules/authentication/model/response_model/otp_response_model.dart';

///response models
export 'package:healthcare/app/modules/authentication/model/response_model/signup_reponse_model.dart';
export 'package:healthcare/app/modules/authentication/views/change_password.dart';

/// views
export 'package:healthcare/app/modules/authentication/views/forget_screen.dart';
export 'package:healthcare/app/modules/authentication/views/login_screen.dart';
export 'package:healthcare/app/modules/authentication/views/otp_verification_screen.dart';
export 'package:healthcare/app/modules/authentication/views/profile_screen.dart';
export 'package:healthcare/app/modules/authentication/views/profile_setup_provider.dart';
export 'package:healthcare/app/modules/authentication/views/register_screen.dart';
export 'package:healthcare/app/modules/authentication/views/view_profile_screen.dart';
export 'package:healthcare/app/modules/bookings/bindings/bookings_bindings.dart';
export 'package:healthcare/app/modules/bookings/views/booking_details_screen.dart';
export 'package:healthcare/app/modules/bookings/views/confirm_booking_screen.dart';
export 'package:healthcare/app/modules/bookings/views/select_date_time_screen.dart';
export 'package:healthcare/app/modules/contact_us/binding/contact_us_binding.dart';
export 'package:healthcare/app/modules/contact_us/controller/contact_us_controller.dart';
export 'package:healthcare/app/modules/contact_us/view/contact_us_screen.dart';
export 'package:healthcare/app/modules/home/binding/binding.dart';
export 'package:healthcare/app/modules/home/controllers/home_controller.dart';
export 'package:healthcare/app/modules/home/controllers/main_view_controller.dart';
export 'package:healthcare/app/modules/home/views/all_nearby_services.dart';
export 'package:healthcare/app/modules/home/views/home_screen.dart';
export 'package:healthcare/app/modules/home/views/main_screen.dart';
export 'package:healthcare/app/modules/language/bindings/select_language_binding.dart';
export 'package:healthcare/app/modules/language/controllers/select_language_controller.dart';
export 'package:healthcare/app/modules/language/model/language_model.dart';
export 'package:healthcare/app/modules/language/views/select_language_screen.dart';
export 'package:healthcare/app/modules/notifications/bindings/notification_bindings.dart';
export 'package:healthcare/app/modules/notifications/views/notification_view.dart';
export 'package:healthcare/app/modules/onboarding/binding/binding.dart';
export 'package:healthcare/app/modules/onboarding/controllers/onboarding_controller.dart';

///onboarding
export 'package:healthcare/app/modules/onboarding/entity/pageview_model.dart';
export 'package:healthcare/app/modules/onboarding/views/onboarding_screen.dart';
export 'package:healthcare/app/modules/payment/bindings/payment_bindings.dart';
export 'package:healthcare/app/modules/payment/controller/add_card_controller.dart';
export 'package:healthcare/app/modules/payment/controller/card_list_controller.dart';
export 'package:healthcare/app/modules/payment/controller/payment_success_controller.dart';
export 'package:healthcare/app/modules/payment/views/add_card_view.dart';
export 'package:healthcare/app/modules/payment/views/card_list_screen.dart';
export 'package:healthcare/app/modules/payment/views/payment_success_screen.dart';
export 'package:healthcare/app/modules/payment/views/transactions_view.dart';
export 'package:healthcare/app/modules/payment/widget/card_number_formatter.dart';
export 'package:healthcare/app/modules/payment/widget/card_utils_widget.dart';
export 'package:healthcare/app/modules/payment/widget/card_validation_widget.dart';
export 'package:healthcare/app/modules/ratings_reviews/bindings/ratings_reviews_bindings.dart';
export 'package:healthcare/app/modules/ratings_reviews/views/add_ratings_screen.dart';
export 'package:healthcare/app/modules/ratings_reviews/views/ratings_reviews.dart';
export 'package:healthcare/app/modules/role/binding/choose_role_binding.dart';
export 'package:healthcare/app/modules/role/controller/choose_role_controller.dart';
export 'package:healthcare/app/modules/role/view/choose_role_screen.dart';
export 'package:healthcare/app/modules/services/bindings/services_bindings.dart';
export 'package:healthcare/app/modules/services/controller/category_controller.dart';
export 'package:healthcare/app/modules/services/models/data_model/category_data_model.dart';
export 'package:healthcare/app/modules/services/models/data_model/provider_data_model.dart';
export 'package:healthcare/app/modules/services/models/response_model/category_list_response_model.dart';
export 'package:healthcare/app/modules/services/models/response_model/provider_list_response_model.dart';
export 'package:healthcare/app/modules/services/views/categories_screen.dart';
export 'package:healthcare/app/modules/services/views/search_view.dart';
export 'package:healthcare/app/modules/services/views/service_details_view.dart';

/// custom widgets
export 'package:healthcare/app/modules/services/widgets/category_view_widget.dart';

///Bindings
export 'package:healthcare/app/modules/setting/binding/setting_screen_binding.dart';
export 'package:healthcare/app/modules/setting/view/setting_screen.dart';
export 'package:healthcare/app/modules/splash/binding/binding.dart';

///Controllers
export 'package:healthcare/app/modules/splash/controllers/splash_controller.dart';
export 'package:healthcare/app/modules/splash/views/splash_screen.dart';
export 'package:healthcare/app/modules/staticPages/binding/binding.dart';
export 'package:healthcare/app/modules/staticPages/controllers/static_page_controller.dart';
export 'package:healthcare/app/modules/staticPages/views/static_page_screen.dart';

///routes
export 'package:healthcare/app/routes/app_pages.dart';
export 'package:healthcare/app/routes/app_routes.dart';
export 'package:healthcare/app/service_provider_app/bookings/bindings/booking_detail_binding_provider.dart';
export 'package:healthcare/app/service_provider_app/bookings/views/booking_details_provider.dart';
export 'package:healthcare/app/service_provider_app/bottomNavBar/bindings/main_screen_bindings_provider.dart';
export 'package:healthcare/app/service_provider_app/bottomNavBar/views/main_screen_provider.dart';
export 'package:healthcare/app/service_provider_app/services/bindings/service_bindings_provider.dart';
export 'package:healthcare/app/service_provider_app/services/views/add_availability_provider.dart';
export 'package:healthcare/app/service_provider_app/services/views/add_service_screen_provider.dart';
export 'package:healthcare/app/service_provider_app/services/views/service_detail_provider.dart';
export 'package:healthcare/main.dart';
export 'package:healthcare/model/error_response_model.dart';
export 'package:in_app_review/in_app_review.dart';
// dependencies
export 'package:logger/logger.dart';
export 'package:package_info_plus/package_info_plus.dart';
export 'package:path_provider/path_provider.dart';
export 'package:pinput/pinput.dart';
export 'package:the_apple_sign_in/the_apple_sign_in.dart' hide ButtonStyle;
export 'package:url_launcher/url_launcher.dart';
