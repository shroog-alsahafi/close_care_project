/*
 * @copyright : Toxsl Technologies Pvt. Ltd. < www.toxsl.com >
 * @author     : Shiv Charan Panjeta < shiv@toxsl.com >
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */

import 'package:device_info_plus/device_info_plus.dart';
import 'package:healthcare/app/core/location_details.dart';

import '../../export.dart';
import 'app/data/push_notification_manager.dart';

var log = Logger();
GetStorage storage = GetStorage();
CustomLoader customLoader = CustomLoader();
SignupResponseModel? signUpData;
var tempDir;
var deviceName, deviceType, deviceID, deviceVersion, deviceToken;
var currentLatitude, currentLongitude;
bool isNotified=false;
class GlobalVariable {
  static final GlobalKey<ScaffoldMessengerState> navState = GlobalKey<ScaffoldMessengerState>();
}

Future<void> main() async {
  initApp();
  getDeviceData();
  WidgetsFlutterBinding.ensureInitialized();
 try{
   await Firebase.initializeApp();
   await PushNotificationsManager().init();
   await Future.delayed(Duration(seconds: 2), ()async {
     deviceToken =await FirebaseMessaging.instance.getToken();
     print('deviceToken-----$deviceToken');
   });
 }catch(e,st){
   print('Error----$e');
   print('Stacktrace----$st');
 }
  DependencyInjection.init();
  getCurrentLocation();
  await GetStorage.init();
  // await _getDeviceToken();
  tempDir = await getTemporaryDirectory();
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
    statusBarColor: colorLightGray,
  ));
}

_getDeviceToken() async {
  // await Firebase.initializeApp(options: FirebaseOptions(apiKey: apiKey, appId: appId, messagingSenderId: messagingSenderId, projectId: projectId));
  await Firebase.initializeApp();
  await FirebaseMessaging.instance.getToken().then((value) {
    deviceToken = value;
    debugPrint("Firebase Messaging token====>>$value");
  });
}

initApp() async {
  runApp(MyApp());
}

Future<void> getCurrentLocation() async {
  try {
    LocationDetails locationDetails = await LocationServices.getInstance().getCurrentLocation();
    currentLongitude = locationDetails.longitude;
    currentLatitude = locationDetails.latitude;
  } catch (e, str) {}
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        FocusScopeNode currentFocus = FocusScope.of(context);
        if (!currentFocus.hasPrimaryFocus && currentFocus.focusedChild != null) {
          FocusManager.instance.primaryFocus!.unfocus();
        }
      },
      child: ScreenUtilInit(
        builder: (context, widget) => GetMaterialApp(
          theme: ThemeConfig.lightTheme,
          initialBinding: SplashBinding(),
          initialRoute: AppPages.INITIAL,
          getPages: AppPages.routes,
          scaffoldMessengerKey: GlobalVariable.navState,
          debugShowCheckedModeBanner: false,
          enableLog: true,
          logWriterCallback: LoggerX.write,
          locale: TranslationService.locale,
          fallbackLocale: TranslationService.fallbackLocale,
          translations: TranslationService(),
          builder: EasyLoading.init(),
          defaultTransition: Transition.cupertino,
        ),
      ),
    );
  }
}

getDeviceData() async {
  DeviceInfoPlugin info = DeviceInfoPlugin();
  if (Platform.isAndroid) {
    AndroidDeviceInfo androidDeviceInfo = await info.androidInfo;
    deviceName = androidDeviceInfo.model;
    deviceID = androidDeviceInfo.id;
    deviceVersion = androidDeviceInfo.version.release;
    deviceType = "1";
  } else if (Platform.isIOS) {
    IosDeviceInfo iosDeviceInfo = await info.iosInfo;
    deviceName = iosDeviceInfo.model;
    deviceID = iosDeviceInfo.identifierForVendor;
    deviceVersion = iosDeviceInfo.systemVersion;
    deviceType = "2";
  }
}
