 Exotic Evergreen

[![pipeline status](http://192.168.10.23/yii2/healthcare-yii2-2136/badges/master/pipeline.svg)](http://192.168.10.23/yii2/healthcare-yii2-2136/commits/master)

#### About 
Develop a comprehensive healthcare platform, accessible via iOS, Android, and web-based Admin Panel, connecting patients with service providers (doctors and nurses) for online consultations and home services.

### Reusability 

1. page Module.
2. notification Module.
3. FAQ Module.
4. Rating Module.
5. Sitemap Module.
6. Installer Module.
7. Comment Module.
8. SMTP Module.
9. Setting Module.
10. Backup Module.
11. Contact Module.
12. Logger Module.
13. Notification Module.
14. Rbac Module.
15. Scheduler Module.
16. Storage Module.


### INSTALLATION

- The minimum required PHP version of Yii is PHP 8
- [Follow the Installation Guide](http://192.168.10.23/yii2/healthcare-yii2-2136/blob/master/docs/installation.md)
in order to get step by step instructions.

### Documentation

- A [Definitive Guide](https://www.yiiframework.com/doc/guide/2.0). 

### Directory Structure

```
config/              all modules paths and application configuration 
docs/                documentation
protected/           core framework code
```

### RUN PROJECT


Create an admin account. I recommend you to use email as admin@toxsl.in and password as admin@123


**In projects**

If you are using Yii 2 base as part of your project there are some important points that you need to takecare throught out of your whole development phase . 

### Reusability base module
> Modules :

- api
- backup
- comment
- contact
- logger
- notification
- Page
- Rating
- scheduler
- storage
- seo 
- setting
- sitemap
- payment

### Risk Factor

> Payment Gateway 

Some UseFull Modules :-
-----------------------

Existing Modules:
-----------------

- api
- notification
- rating



### CheckList

> NOTE: Refer the [CheckList](http://192.168.10.23/yii2/healthcare-yii2-2136/-/blob/master/docs/checklist.md) for details on all the security concerns and other important parameters of the project before its actual releasing.

### Coding Guidelines

> NOTE: Refer the [Coding Guidelines](http://192.168.10.23/yii2/healthcare-yii2-2136/-/blob/master/docs/coding-guidelines.md) for details on all the security concerns and other important parameters of the project before its actual releasing.

### Installation Commands based on local setup

If you have composer.json

>composer install

To install database run this command

>php console.php module/migrate 

Install default data using :

>php console.php clear/default


### Installation Commands through docker


Run below command


### Install the composer packages

> composer install

> rename default.env to .env

> docker-compose -f docker-compose.yml up -d (for production)
 
> docker-compose -f docker-compose-dev.yml up -d (for development)

### Microservices

> NOTE: This Project is  based on  the Microservices which is  Docker based platform and it is an opensource for developing, shipping, and running applications. 
it enables you to separate your applications from your infrastructure so you can deliver software quickly. 
With Docker, you can manage your infrastructure in the same ways you manage your applications. 

### Cache

> for docker based cache (Memcache will be used)

- For speed up the query for data retrieving we use mem cache (yii\caching\MemCache).

 Goto url: https://www.yiiframework.com/doc/guide/2.0/en/caching-data#cache-components (for more detail)
 
 Configure in -: protected/config/web.php
        // 'cache' => require 'memcache.php',
 
 'components' => [
    'cache' => [
       'class' => 'yii\caching\MemCache',
    'servers' => [
        [
            'host' => 'localhost',
            'port' => 11211
        ]
    ],
    'useMemcached' => true
    ],
],

> for development setup file cache will be used

 'cache' => [
            'class' => (YII_ENV == 'dev') ? 'yii\caching\DummyCache' : 'yii\caching\FileCache',
            'defaultDuration' => 60
        ],

