# GUDELINES FOR SCREENSHOTS FOLDER IN YOUR PROJECT

#### Please keep the eye on following points while creating and using screenshots folder.

1. The naming convention  of the folder should be `screenshots` not anything else like (screen_short or screenshot).

2. You must have the image files of your project front view with png extension in screenshots folder.

3. Keep in mind that do not have the screenshot of that images in which debugger mode is shown. It does not looks good.

4. You must create screenshot of your project in full browser mode so that the screenshot will come up in enhanced way.

5. The screenshot of home page will be named as `index.png` . 

