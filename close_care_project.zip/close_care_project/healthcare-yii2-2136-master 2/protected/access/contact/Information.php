<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\access\contact;

use app\models\User;

class Information
{

    public static function getAccessFilters()
    {
        return [
            [
                'actions' => [
                    'delete',
                    'mass',
                    'clear'
                ],
                'allow' => true,
                'matchCallback' => function () {
                    return User::isAdmin();
                }
            ],
            [
                'actions' => [
                    'add',
                    'update',
                    'clone',
                    'index',
                    'view',
                    'ajax',
                    'image'
                ],
                'allow' => true,
                'matchCallback' => function () {
                    return User::isManager();
                }
            ],
            [
                'actions' => [
                    'view',
                    'image'
                ],
                'allow' => true,
                'matchCallback' => function () {
                    return User::isUser() || User::isGuest();
                }
            ]
        ];
    }
}
