<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of Toxsl Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\access\storage;

use app\models\User;

class File
{

    public static function getAccessFilters()
    {
        return [
            [
                'actions' => [
                    'clear',
                    'update',
                    'delete',
                    'index',
                    'add',
                    'view',
                    'update',
                    'ajax',
                    'upload',
                    'project',
                    'ckeditor',
                    'input',
                    'connector',
                    'image'
                ],
                'allow' => true,
                'matchCallback' => function () {
                    return User::isAdmin();
                }
            ],
            [
                'actions' => [
                    'image',
                    'view'
                ],
                'allow' => true,
                'matchCallback' => function () {
                    return (User::isGuest() || User::isUser() || User::isProvider());
                }
            ]
        ];
    }
}
