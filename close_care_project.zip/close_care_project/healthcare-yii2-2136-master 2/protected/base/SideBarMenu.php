<?php

/**
 *
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author     : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 */
namespace app\base;

use app\models\User;
use Yii;

trait SideBarMenu
{

    public function getItems()
    {
        if (YII_ENV == 'dev') {
            return $this->renderNavUpdate();
        }
        return Yii::$app->cache->getOrSet('menu_user_id_' . Yii::$app->user->id, function () {
            return $this->renderNavUpdate();
        });
    }

    public function renderNavUpdate()
    {
        $nav_left = [

            self::addMenu(Yii::t('app', 'Dashboard'), '//', 'tachometer', (! User::isGuest())),
            self::adddivider(),
            'User Managment' => self::addMenu(Yii::t('app', 'User Managment'), '#', 'tasks', User::isManager(), [

                self::addMenu(Yii::t('app', 'Patient'), '//user', 'user', (User::isAdmin())),
                self::addMenu(Yii::t('app', 'Provider'), '//user/provider', 'user', (User::isAdmin()))
            ], true),
            self::adddivider(),
            'Manage' => self::addMenu(Yii::t('app', 'Manage'), '#', 'tasks', User::isManager(), [

                self::addMenu(Yii::t('app', 'Activities'), '//feed/index/', 'tasks', User::isAdmin()),
                self::addMenu(Yii::t('app', 'Files'), '//file/index/', 'tasks', User::isAdmin()),
                self::addMenu(Yii::t('app', 'Page'), '//page/', 'key', User::isAdmin()),
                self::addMenu(Yii::t('app', 'Logger'), '//logger/', 'key', User::isAdmin()),
                self::addMenu(Yii::t('app', 'Login History'), '//login-history/', 'history', User::isAdmin()),
                self::addMenu(Yii::t('app', 'Backup'), '//backup/', 'download', User::isAdmin()),
                self::adddivider(),
                self::addModule('settings'),
                self::adddivider(),
                self::addModule('storage'),
                self::adddivider(),
                self::addModule('scheduler')
            ], true),
            self::adddivider(),
            self::addModule('notification'),
            self::adddivider(),
            'Communications' => self::addMenu(Yii::t('app', 'Communications'), '#', 'signal', User::isManager(), [
                self::addModule('smtp')
            ], true),

            // self::adddivider(),
            // 'Content Management' => self::addMenu(Yii::t('app', 'Content Management'), '#', 'folder', User::isManager(), [
            // self::addModule('feature')
            // ], true),
            self::adddivider(),
            self::addModule('service'),
            self::adddivider(),
            self::addMenu(Yii::t('app', 'Qualifications'), '//provider/qualification/', 'tasks', User::isAdmin()),
            self::adddivider(),
            self::addMenu(Yii::t('app', 'Contact'), '//contact/information/', 'tasks', User::isAdmin()),
            self::adddivider(),

            'booking' => self::addMenu(Yii::t('app', 'Booking'), '#', 'signal', User::isManager(), [
                self::addMenu(\Yii::t('app', 'Bookings'), '//booking', 'list-alt', User::isAdmin()),
                self::addMenu(\Yii::t('app', 'Transaction'), '/payment/transaction', 'list-alt', User::isAdmin())
            ], true),
            self::adddivider(),
            self::addMenu(Yii::t('app', 'Payment'), '#', 'cc-paypal', User::isManager(), [
                self::addModule('payment'),
                self::adddivider()
            ], true)
        ];

        $this->nav_left = $nav_left;
        return $this->nav_left;
    }

    public static function addmenu($label, $link, $icon, $visible = null, $list = null, $submenu = false)
    {
        if (! $visible)
            return null;
        $item = [

            'label' => '<i class="fa fa-' . $icon . '"></i> <span>' . $label . '</span>',
            'url' => [
                $link
            ]
        ];
        if ($list != null) {
            $item['options'] = [
                'class' => 'menu-list nav-item'
            ];

            $item['items'] = $list;
        }

        if ($submenu) {
            $item['options'] = [
                'class' => 'sub-menu-list nav-item'
            ];

            $item['items'] = $list;
        }
        return $item;
    }

    public static function addModule($m, $list = null, $setting = true)
    {
        if (! \Yii::$app->hasModule($m)) {
            return null;
        }
        if ($list == null) {
            $class = "\\app\\modules\\$m\\Module";
            if (class_exists($class) && method_exists($class, 'subNav')) {
                $list = $class::subNav();
            }
        }
        if ($list != null) {
            $list['items'][] = self::addMenu(\Yii::t('app', 'Settings'), '//settings/variable?m=' . $m, 'lock', User::isAdmin());
            return $nav_left[$m] = $list;
        }
    }

    public static function adddivider($visible = true)
    {
        $item = [];
        if ($visible) {
            $item = [
                'label' => '<div class="sidebar-divider"></div>'
            ];
        }
        return $item;
    }
}