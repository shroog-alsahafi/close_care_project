<?php
namespace app\base;

use yii\helpers\ArrayHelper;
use yii\helpers\Html;
use yii\helpers\Json;
use borales\extensions\phoneInput\PhoneInput;
use borales\extensions\phoneInput\PhoneInputAsset;
use yii\widgets\InputWidget;

/**
 * Widget of the phone input
 *
 * @package borales\extensions\phoneInput
 */
class TPhoneInput extends InputWidget
{

    /** @var string HTML tag type of the widget input ("tel" by default) */
    public $htmlTagType = 'tel';

    /** @var array Default widget options of the HTML tag */
    public $defaultOptions = [
        'autocomplete' => "off",
        'class' => 'form-control'
    ];

    /**
     *
     * @link https://github.com/jackocnr/intl-tel-input#options More information about JS-widget options.
     * @var array Options of the JS-widget
     */
    public $jsOptions = [];

    public function init()
    {
        parent::init();
        PhoneInputAsset::register($this->view);
        $id = ArrayHelper::getValue($this->options, 'id');
        $jsOptions = $this->jsOptions ? Json::encode($this->jsOptions) : "";
        $jsInit = <<<JS
        (function ($) {
            "use strict";
            $('#$id').intlTelInput($jsOptions);
        })(jQuery);
        JS;
        $this->view->registerJs($jsInit);
        if ($this->hasModel()) {
            $js = <<<JS
            (function ($) {
                "use strict";
                $('#$id')
                .parents('form')
                .on('submit', function() {
                    $('#$id')
                    .val($('#$id')
                     .intlTelInput('getNumber'));
                });
            })(jQuery);
            JS;
            $this->view->registerJs($js);
        }
    }

    /**
     *
     * @return string
     */
    public function run()
    {
        $options = ArrayHelper::merge($this->defaultOptions, $this->options);
        if ($this->hasModel()) {
            return Html::activeInput($this->htmlTagType, $this->model, $this->attribute, $options);
        }
        return Html::input($this->htmlTagType, $this->name, $this->value, $options);
    }
    
    public static function countryCodeLength()
    {
        return [
            "91" => "10",
            "93" => "9",
            "355" => "9",
            "213" => "9",
            "1684" => "10",
            "376" => "9",
            "244" => "9",
            "672" => "10",
            "26" => "9",
            "673" => "9",
            "359" => "9",
            "226" => "9",
            "257" => "9",
            "855" => "9",
            "237" => "9",
            "1" => "10",
            "238" => "9",
            "599" => "10",
            "61" => "10",
            "43" => "10",
            "994" => "9",
            "973" => "9",
            "880" => "10",
            "375" => "9",
            "32" => "10",
            "501" => "9",
            "229" => "9",
            "1441" => "10",
            "975" => "8",
            "591" => "9",
            "387" => "9",
            "267" => "9",
            "55" => "11",
            "86" => "11",
            "57" => "10",
            "269" => "9",
            "682" => "9",
            "506" => "8",
            "225" => "9",
            "385" => "9",
            "53" => "9",
            "357" => "9",
            "420" => "9",
            "45" => "8",
            "253" => "9",
            "670" => "9",
            "593" => "9",
            "20" => "11",
            "503" => "9",
            "240" => "9",
            "291" => "9",
            "372" => "9",
            "251" => "9",
            "500" => "10",
            "298" => "9",
            "679" => "9",
            "358" => "10",
            "33" => "10",
            "241" => "9",
            "220" => "9",
            "995" => "9",
            "49" => "11",
            "233" => "9",
            "350" => "9",
            "30" => "10",
            "502" => "8",
            "594" => "9",
            "509" => "9",
            "224" => "9",
            "371" => "8",
            "962" => "10",
            "81" => "11",
            "7" => "10",
            "254" => "9",
            "686" => "9",
            "850" => "12",
            "82" => "11",
            "383" => "9",
            "965" => "9",
            "996" => "9",
            "856" => "9",
            "961" => "9",
            "266" => "9",
            "231" => "9",
            "218" => "9",
            "423" => "10",
            "370" => "9",
            "352" => "9",
            "389" => "9",
            "261" => "9",
            "265" => "9",
            "60" => "10",
            "960" => "9",
            "223" => "9",
            "356" => "9",
            "692" => "9",
            "222" => "9",
            "230" => "9",
            "262" => "9",
            "52" => "10",
            "691" => "9",
            "373" => "9",
            "377" => "9",
            "976" => "9",
            "382" => "9",
            "1664" => "10",
            "212" => "9",
            "258" => "9",
            "95" => "10",
            "264" => "9",
            "674" => "9",
            "977" => "10",
            "31" => "10",
            "687" => "9",
            "64" => "10",
            "505" => "8",
            "227" => "9",
            "234" => "10",
            "683" => "9",
            "675" => "9",
            "948" => "9"
        ];
    }
    
}
