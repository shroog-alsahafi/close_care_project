<?php
$modules = [];

if (! is_file(DB_CONFIG_FILE_PATH)) {
    $modules['installer'] = [
        'class' => 'app\modules\installer\Module',
        'sqlfile' => [
            DB_BACKUP_FILE_PATH . '/install.sql'
        ]
    ];
}

// Add extra if you have to
$modules['backup'] = [
    'class' => 'app\modules\backup\Module'
];

$modules['smtp'] = [
    'class' => 'app\modules\smtp\Module'
];
$modules['settings'] = [
    'class' => 'app\modules\settings\Module'
];

$modules['scheduler'] = [
    'class' => 'app\modules\scheduler\Module'
];

$modules['storage'] = [
    'class' => 'app\modules\storage\Module',
    'viewPath' => '@app/views/storage/views'
];

foreach (glob(__DIR__ . "/common/*.php") as $file) {

    $modules = array_merge($modules, require $file);
}

return $modules;