<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 */
return [

    'class' => 'app\components\TUrlManager',
    'forceSSL' => (YII_ENV == 'dev') ? false : true,
    'rules' => [

        [
            'pattern' => 'features',
            'route' => 'feature'
        ],
        [
            'pattern' => 'aboutus',
            'route' => 'site/about'
        ],
        [
            'pattern' => 'contactus',
            'route' => 'site/contact'
        ],
        [
            'pattern' => 'page',
            'route' => 'page/page'
        ],
        [
            'pattern' => 'signup',
            'route' => 'user/signup'
        ],
        [
            'pattern' => 'login',
            'route' => 'user/login'
        ],
        '<controller:file>/<action:files>/<file>' => '<controller>/<action>',
        '<controller:[A-Za-z-]+>/<id:\d+>/<title>' => '<controller>/view',
        '<controller:[A-Za-z-]+>/<id:\d+>' => '<controller>/view',
        '<controller:[A-Za-z-]+>/<action:[A-Za-z-]+>/<id:\d+>/<title>' => '<controller>/<action>',
        '<controller:[A-Za-z-]+>/<action:[A-Za-z-]+>/<id:\d+>' => '<controller>/<action>',
        '<action:about|contact|privacy|guidelines|copyright|notice|faq|terms|pricing>' => 'site/<action>'
    ]
];