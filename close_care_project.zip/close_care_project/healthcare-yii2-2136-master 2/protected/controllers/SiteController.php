<?php

/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
namespace app\controllers;

use app\components\TController;
use app\components\filters\AccessControl;
use app\components\filters\AccessRule;
use app\models\User;
use Yii;
use app\modules\page\models\Page;
use app\modules\booking\models\Booking;
use app\modules\payment\models\Transaction;
use app\models\Information;
use Sentry\Response;
use app\components\TActiveForm;
use app\models\EmailQueue;

class SiteController extends TController
{

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [
                    [
                        'actions' => [
                            'index',
                            'contact',
                            'about',
                            'error',
                            'demo',
                            'pricing',
                            'privacy',
                            'terms',
                            'paypal',
                            'captcha'
                        ],
                        'allow' => true,
                        'roles' => [
                            '*',
                            '?',
                            '@'
                        ]
                    ]
                ]
            ]
        ];
    }

    public function actions()
    {
        return [

            'error' => [
                'class' => 'yii\web\ErrorAction'
            ],

            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction'
            ]
        ];
    }

    public function actionError()
    {
        $exception = \Yii::$app->errorHandler->exception;
        return $this->render('error', [
            'message' => $exception->getMessage(),
            'name' => 'Error'
        ]);
    }

    public function actionIndex()
    {
        $this->updateMenuItems();
        if (! \Yii::$app->user->isGuest) {
            return $this->redirect('dashboard/index');
        } else {
            return $this->redirect([
                '/user/login'
            ]);
        }
    }

    public function actionContact()
    {
        $model = new Information();

        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }
        if ($model->load(Yii::$app->request->post())) {
            $sub = 'New Contact: ' . $model->subject;
            $from = $model->email;
            $message = \yii::$app->view->renderFile('@app/mail/contact.php', [
                'user' => $model
            ]);

            if ($model->save()) {

                EmailQueue::sendEmailToAdmins([
                    'from' => $from,
                    'subject' => $sub,
                    'html' => $message
                ], true);
                \Yii::$app->getSession()->setFlash('success', \Yii::t('app', 'Thank you for contacting us. We have received your request. Our representative will contact you soon.'));
                return $this->refresh();

                // return $this->redirect([
                // 'contact'
                // ]);
            } else {
                \Yii::$app->getSession()->setFlash('error', "Error !!" . $model->getErrorsString());
            }
        }
        return $this->render('contact', [
            'model' => $model
        ]);
    }

    public function actionAbout()
    {
        $about = Page::getPageDetails(Page::TYPE_ABOUT_US);

        return $this->render('about', [
            'about' => $about
        ]);
    }

    public function actionFeatures()
    {
        return $this->render('features');
    }

    public function actionPricing()
    {
        return $this->render('pricing');
    }

    public function actionPrivacy()
    {
        $privacy = Page::getPageDetails(Page::TYPE_PRIVACY);

        return $this->render('privacy', [
            'privacy' => $privacy
        ]);
    }

    public function actionTerms()
    {
        $terms = Page::getPageDetails(Page::TYPE_TERM_CONDITION);

        return $this->render('terms', [
            'terms' => $terms
        ]);
    }

    public function actionPaypal($id)
    {
        $this->layout = "guest-main";
        $model = Transaction::findOne($id);
        return $this->render('paypal', [
            'model' => $model
        ]);
    }

    protected function updateMenuItems($model = null)
    {
        // create static model if model is null
        switch ($this->action->id) {
            case 'add':
                {
                    $this->menu[] = array(
                        'label' => Yii::t('app', 'Manage'),
                        'url' => array(
                            'index'
                        ),
                        'visible' => User::isAdmin()
                    );
                }
                break;
            default:
            case 'view':
                {
                    $this->menu[] = array(
                        'label' => '<span class="glyphicon glyphicon-list"></span> Manage',
                        'title' => 'Manage',
                        'url' => array(
                            'index'
                        ),
                        'visible' => User::isAdmin()
                    );

                    if ($model != null)
                        $this->menu[] = array(
                            'label' => Yii::t('app', 'Update'),
                            'url' => array(
                                'update',
                                'id' => $model->id
                            ),
                            'visible' => ! User::isAdmin()
                        );
                }
                break;
        }
    }
}
