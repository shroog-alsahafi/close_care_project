<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\controllers;

use Imagine\Image\ManipulatorInterface;
use app\components\TActiveForm;
use app\components\TController;
use app\components\helpers\TEmailTemplateHelper;
use app\models\EmailQueue;
use app\models\LoginForm;
use app\models\User;
use app\models\search\User as UserSearch;
use Yii;
use yii\filters\AccessControl;
use yii\filters\AccessRule;
use yii\imagine\Image;
use yii\web\HttpException;
use yii\web\NotFoundHttpException;
use yii\web\Response;
use yii\web\UploadedFile;
use http\Url;
use app\modules\notification\models\Notification;

/**
 * UserController implements the CRUD actions for User model.
 */
class UserController extends TController
{

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [
                    [
                        'actions' => [
                            'view',
                            'logout',
                            'changepassword',
                            'profileImage',
                            'toggle',
                            'download',
                            'dashboard',
                            'recover',
                            'image-manager',
                            'image-upload',
                            'theme-param',
                            'update',
                            'email-resend',
                            'image'
                        ],
                        'allow' => true,
                        'roles' => [
                            '@'
                        ]
                    ],
                    [
                        'actions' => [
                            'index',
                            'add',
                            'shadow',
                            'view',
                            'update',
                            'delete',
                            'profileImage',
                            'clear',
                            'final-delete',
                            'approve',
                            'provider',
                            'reject',
                            'add-provider'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isAdmin();
                        }
                    ],
                    [
                        'actions' => [
                            'index',
                            'add',
                            'view',
                            'update',
                            'changepassword'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isManager();
                        }
                    ],
                    [
                        'actions' => [
                            'signup',
                            'image'
                        ],
                        'allow' => (! defined('ENABLE_ERP')) ? true : false,
                        'roles' => [
                            '?',
                            '*'
                        ]
                    ],
                    [
                        'actions' => [
                            'login',
                            'recover',
                            'resetpassword',
                            'profileImage',
                            'download',
                            'add-admin',
                            'captcha',
                            'confirm-email'
                        ],
                        'allow' => true,
                        'roles' => [
                            '?',
                            '*'
                        ]
                    ]
                ]
            ],
            'verbs' => [
                'class' => \yii\filters\VerbFilter::class,
                'actions' => [
                    'delete' => [
                        'post'
                    ]
                ]
            ]
        ];
    }

    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction'
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction'
                // 'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null
            ],
            'image' => [
                'class' => 'app\components\actions\ImageAction',
                'modelClass' => User::class,
                'attribute' => 'profile_file',
                'default' => true
            ]
        ];
    }

    /**
     * Clear runtime and assets
     *
     * @return \yii\web\Response
     */
    public function actionClear()
    {
        $runtime = Yii::getAlias('@runtime');
        $this->cleanRuntimeDir($runtime);

        $this->cleanAssetsDir();
        return $this->goBack();
    }

    /**
     * Lists all User models.
     *
     * @return mixed
     */
    public function actionIndex()
    {
        $role = User::ROLE_USER;
        $searchModel = new UserSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        if (! empty($role)) {
            $dataProvider->query->andWhere([
                'role_id' => $role
            ]);
        }
        $this->updateMenuItems();
        return $this->render('index', [
            'role' => $role,
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider
        ]);
    }

    /**
     * Lists all User models.
     *
     * @return mixed
     */
    public function actionProvider()
    {
        $role = User::ROLE_PROVIDER;
        $searchModel = new UserSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        if (! empty($role)) {
            $dataProvider->query->andWhere([
                'role_id' => $role
            ]);
        }
        $this->updateMenuItems();
        return $this->render('index', [
            'role' => $role,
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider
        ]);
    }

    /**
     * Displays a single User model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $this->updateMenuItems($model);
        return $this->render('view', [
            'model' => $model
        ]);
    }

    public function actionAddAdmin()
    {
        $this->layout = "guest-main";
        $count = User::find()->count();
        if ($count != 0) {
            return $this->redirect([
                '/'
            ]);
        }
        $model = new User();
        $model->scenario = 'add-admin';
        if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {

            Yii::$app->response->format = Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }
        if ($model->load(Yii::$app->request->post())) {
            $model->role_id = User::ROLE_ADMIN;
            $model->state_id = User::STATE_ACTIVE;
            if ($model->validate()) {
                $model->setPassword($model->password);
                $model->generatePasswordResetToken();
                if ($model->save()) {
                    return $this->redirect([
                        'login'
                    ]);
                }
            }
        }
        return $this->render('signup', [
            'model' => $model
        ]);
    }

    /**
     * Creates a new User model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     *
     * @return mixed
     */
    public function actionAdd()
    {
        $model = new User();
        $model->role_id = User::ROLE_USER;
        $model->state_id = User::STATE_ACTIVE;
        $model->scenario = 'add';
        $post = Yii::$app->request->post();
        if (Yii::$app->request->isAjax && $model->load($post)) {

            Yii::$app->response->format = Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }

        if ($model->load($post)) {

            $image = UploadedFile::getInstance($model, 'profile_file');
            if (! empty($image)) {
                $image->saveAs(UPLOAD_PATH . $image->baseName . '.' . $image->extension);
                $model->profile_file = $image->baseName . '.' . $image->extension;

                Yii::$app->getSession()->setFlash('success', 'User Added Successfully.');
            }
            $model->scenario = 'add-validate';
            $count = strlen('+' . $model->country_code);
            $model->contact_no = substr($model->contact_no, ($count));
            $model->country_code = '+' . $model->country_code;
            $model->email_verified = User::EMAIL_VERIFIED;

            $model->full_name = $model->getFullname();
            $password = $model->password;

            $model->generatePasswordResetToken();
            $model->setPassword($model->password);
            $model->email_verified = User::EMAIL_VERIFIED;

            if ($model->save()) {
                $model->sendRegistrationMailtoAdmin();
                $model->sendRegistrationMailtoUser($password);
                Yii::$app->getSession()->setFlash('success', ' User Added Successfully.');
                return $this->redirect([
                    'view',
                    'id' => $model->id
                ]);
            } else {
                \Yii::$app->session->setFlash('error', $model->getErrorsString());
                return $this->redirect(\Yii::$app->request->referrer);
            }
        }
        $this->updateMenuItems($model);
        return $this->render('add', [
            'model' => $model
        ]);
    }

    public function actionAddProvider()
    {
        $model = new User();
        $model->role_id = User::ROLE_PROVIDER;
        $model->state_id = User::STATE_ACTIVE;
        $model->scenario = 'add';
        $post = Yii::$app->request->post();
        if (Yii::$app->request->isAjax && $model->load($post)) {

            Yii::$app->response->format = Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }
        if ($model->load($post)) {

            $image = UploadedFile::getInstance($model, 'profile_file');
            if (! empty($image)) {
                $image->saveAs(UPLOAD_PATH . $image->baseName . '.' . $image->extension);
                $model->profile_file = $image->baseName . '.' . $image->extension;

                Yii::$app->getSession()->setFlash('success', 'User Added Successfully.');
            }
            $model->scenario = 'add-validate';

            $count = strlen('+' . $model->country_code);
            $model->contact_no = substr($model->contact_no, ($count));
            $model->country_code = '+' . $model->country_code;

            $model->full_name = $model->getFullname();
            $password = $model->password;
            $model->email_verified = User::EMAIL_VERIFIED;

            $model->generatePasswordResetToken();
            $model->setPassword($model->password);
            if ($model->save()) {
                $model->sendRegistrationMailtoAdmin();
                $model->sendRegistrationMailtoUser($password);
                Yii::$app->getSession()->setFlash('success', ' Provider Added Successfully.');
                return $this->redirect([
                    'view',
                    'id' => $model->id
                ]);
            } else {
                \Yii::$app->session->setFlash('error', $model->getErrorsString());
                return $this->redirect(\Yii::$app->request->referrer);
            }
        }
        $this->updateMenuItems($model);
        return $this->render('add', [
            'model' => $model
        ]);
    }

    public function actionRecover()
    {
        $this->layout = 'guest-main';
        $model = new User();
        $model->scenario = 'token_request';
        $post = \Yii::$app->request->post();
        if ($model->load($post)) {
            $user = User::findByEmail($model->email);
            if (! empty($user)) {
                $user->scenario = 'token_request';
                $user->generatePasswordResetToken();
                if (! $user->save()) {
                    throw new HttpException("Cant Generate Authentication Key");
                }
                $email = $user->email;
                $sub = "Password Reset";
                EmailQueue::add([
                    'from' => \Yii::$app->params['adminEmail'],
                    'to' => $email,
                    'subject' => $sub,
                    'type_id' => EmailQueue::TYPE_KEEP_AFTER_SEND,
                    'html' => TEmailTemplateHelper::renderFile('@app/mail/passwordResetToken.php', [
                        'user' => $user
                    ])
                ], true);
            }
            return $this->render('thankyou');
        }
        $this->updateMenuItems($model);
        return $this->render('requestPasswordResetToken', [
            'model' => $model
        ]);
    }

    public function actionResetpassword($token)
    {
        $this->layout = 'guest-main';
        $model = User::findByPasswordResetToken($token);
        $newModel = new User([
            'scenario' => 'resetpassword'
        ]);
        if (! ($model)) {
            \Yii::$app->session->setFlash('error', 'This URL is expired.');
            return $this->redirect([
                'user/recover'
            ]);
        }
        if (Yii::$app->request->isAjax && $newModel->load(\Yii::$app->request->post())) {

            Yii::$app->response->format = Response::FORMAT_JSON;
            return TActiveForm::validate($newModel);
        }

        if ($newModel->load(Yii::$app->request->post()) && $newModel->validate()) {
            $model->setPassword($newModel->password);
            $model->removePasswordResetToken();
            $model->generateAuthKey();
            $model->last_password_change = date('Y-m-d H:i:s');

            if ($model->save()) {
                \Yii::$app->session->setFlash('success', 'New password is saved successfully.');
            } else {
                \Yii::$app->session->setFlash('error', 'Error while saving new password.');
            }
            return $this->redirect([
                '/'
            ]);
        }
        $this->updateMenuItems($model);
        return $this->render('resetpassword', [
            'model' => $newModel
        ]);
    }

    /**
     * Admin can Approve
     */
    public function actionApprove($id, $is_approved)
    {
        $model = $this->findModel($id);
        if (! empty($model)) {
            $model->updateAttributes([
                'is_approved' => $is_approved
            ]);

            // Send email to provider
            $model->sendApproveMailtoProvider();

            // Create a notification for the provider
            Notification::create([
                'to_user_id' => $model->id,
                'created_by_id' => \Yii::$app->user->identity->id,
                'title' => 'Profile Approved',
                'description' => 'Your profile has been approved by the admin.',
                'model' => $model
            ], false);

            \Yii::$app->session->setFlash('success', 'Provider Account Approved successfully');
        }
        return $this->redirect($model->getUrl());
    }

    /**
     * Admin can Reject
     */
    public function actionReject($id)
    {
        $model = User::findOne($id);

        $model->scenario = 'add-reject';
        $post = \yii::$app->request->post();
        if (\yii::$app->request->isAjax && $model->load($post)) {
            \yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }
        if ($model->load($post)) {
            $model->is_approved = User::IS_NOT_APPROVED;
            $model->is_profile_setup = User::STATE_INACTIVE;
            if ($model->save()) {
                $model->sendRejectMailtoProvider();

                // Create a notification for the provider
                Notification::create([
                    'to_user_id' => $model->id,
                    'created_by_id' => \Yii::$app->user->identity->id,
                    'title' => 'Profile Rejected',
                    'description' => 'Your profile has been rejected by the admin.',
                    'model' => $model
                ], false);
                return $this->redirect($model->getUrl());
            }
        }
        return $this->render('add_conclusion', [
            'model' => $model
        ]);
    }

    /**
     * Updates an existing User model.
     * If update is successful, the browser will be redirected to the 'view' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $this->layout = 'main';
        $model = $this->findModel($id);
        $model->scenario = 'update';
        $post = \yii::$app->request->post();
        $old_image = $model->profile_file;

        if (Yii::$app->request->isAjax && $model->load($post)) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }

        if ($model->load($post)) {
            if (! empty($model->country_code)) {
                $count = strlen('+' . $model->country_code);
                $model->contact_no = substr($model->contact_no, ($count));
                $model->country_code = '+' . $model->country_code;
            }
            $model->full_name = $model->getFullname();
            $model->profile_file = $old_image;
            $model->saveUploadedFile($model, 'profile_file');
            if ($model->save()) {
                \Yii::$app->getSession()->setFlash('success', 'Profile Updated Successfully!!');
                return $this->redirect($model->getUrl());
            } else {
                \Yii::$app->getSession()->setFlash('danger', $model->getErrorsString());
            }
        }

        $this->updateMenuItems($model);
        return $this->render('update', [
            'model' => $model
        ]);
    }

    /**
     * Deletes an existing User model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $model = $this->findModel($id);
        $this->updateMenuItems($model);

        if (\Yii::$app->user->id == $model->id) {
            \Yii::$app->session->setFlash('user-action-error', 'You are not allowed to perform this operation.');
            return $this->goBack();
        }
        // Disable hard-delete user
        // $model->delete();
        $model->state_id = User::STATE_DELETED;
        $model->save();
        return $this->redirect([
            'index'
        ]);
    }

    /**
     * Deletes an existing User model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionFinalDelete($id)
    {
        $model = $this->findModel($id);
        $this->updateMenuItems($model);
        if (\Yii::$app->request->isPost) {
            $model->delete();
            if (\Yii::$app->request->isAjax) {
                return true;
            }
            \Yii::$app->getSession()->setFlash('success', \Yii::t('app', 'User Deleted Successfully.'));
            return $this->redirect([
                'index'
            ]);
        }
        return $this->render('final-delete', [
            'model' => $model
        ]);
    }

    public function actionMass($action = 'delete')
    {
        \Yii::$app->response->format = 'json';
        $response['status'] = 'NOK';
        $Ids = Yii::$app->request->post('ids');
        foreach ($Ids as $Id) {
            $model = $this->findModel($Id);

            if ($action == 'delete') {
                if (! $model->delete()) {
                    return $response['status'] = 'NOK';
                }
            }
        }

        $response['status'] = 'OK';

        return $response;
    }

    /*
     * public function actionSignup()
     * {
     * $this->layout = "guest-main";
     * $model = new User([
     * 'scenario' => 'signup'
     * ]);
     * if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
     * $model->scenario = 'signup';
     * Yii::$app->response->format = Response::FORMAT_JSON;
     * return TActiveForm::validate($model);
     * }
     * if ($model->load(Yii::$app->request->post())) {
     * $model->state_id = User::STATE_ACTIVE;
     * $model->role_id = User::ROLE_USER;
     * if ($model->validate()) {
     * $model->scenario = 'add';
     * $model->setPassword($model->password);
     * $model->generatePasswordResetToken();
     * if ($model->save()) {
     * $model->sendRegistrationMailtoAdmin();
     * \Yii::$app->user->login($model);
     * return $this->redirect([
     * '/dashboard'
     * ]);
     * }
     * }
     * }
     * return $this->render('signup', [
     * 'model' => $model
     * ]);
     * }
     */
    public function actionLogin()
    {
        $this->layout = "guest-main";

        if (! \Yii::$app->user->isGuest) {
            if (User::isUser()) {
                return $this->goBack([
                    '/dashboard/index'
                ]);
            }
            return $this->goHome();
        }

        $model = new LoginForm();

        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            // TODO: change redirect to return url
            
            if (! User::isAdmin()) {
                return $this->goBack([
                    '/dashboard/index'
                ]);
            } else {
                return $this->goHome();
            }
        }
        return $this->render('login', [
            'model' => $model
        ]);
    }

    public function actionProfileImage()
    {
        return Yii::$app->user->identity->getProfileImage();
    }

    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->redirect([
            '/user/login'
        ]);
    }

    public function actionChangepassword($id)
    {
        $this->layout = 'main';
        $model = $this->findModel($id);
        if (! ($model->isAllowed()))
            throw new \yii\web\HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));

        $newModel = new User([
            'scenario' => 'changepassword'
        ]);
        if (Yii::$app->request->isAjax && $newModel->load(Yii::$app->request->post())) {
            Yii::$app->response->format = 'json';
            return TActiveForm::validate($newModel);
        }
        if ($newModel->load(Yii::$app->request->post()) && $newModel->validate()) {
            $model->setPassword($newModel->password);
            $model->last_password_change = date('Y-m-d H:i:s');
            $model->generateAuthKey();
            if ($model->save()) {
                Yii::$app->getSession()->setFlash('success', 'Password Changed');
                return $this->redirect([
                    'dashboard/index'
                ]);
            } else {
                \Yii::$app->getSession()->setFlash('error', "Error !!" . $model->getErrorsString());
            }
        }
        $this->updateMenuItems($model);
        return $this->render('changepassword', [
            'model' => $newModel
        ]);
    }

    public function actionThemeParam()
    {
        $is_collapsed = Yii::$app->session->get('is_collapsed', 'sidebar-collapsed');
        $is_collapsed = empty($is_collapsed) ? 'sidebar-collapsed' : '';
        Yii::$app->session->set('is_collapsed', $is_collapsed);
    }

    /**
     * Resend verification email to user
     *
     * @return string
     */
    public function actionEmailResend()
    {
        $model = User::find()->where([
            'id' => Yii::$app->user->id
        ])->one();
        $model->sendVerificationMailtoUser(true);
        \Yii::$app->session->setFlash('success', 'Email send successfully');
        return $this->goBack([
            '/dashboard/index'
        ]);
    }

    public function actionConfirmEmail($id)
    {
        $user = User::find()->where([
            'activation_key' => $id
        ])->one();
        if (! empty($user)) {

            $user->email_verified = User::EMAIL_VERIFIED;
            $user->state_id = User::STATE_ACTIVE;
            if ($user->save()) {
                \Yii::$app->cache->flush();
                $user->refresh();
                if (Yii::$app->user->login($user, 3600 * 24 * 30)) {
                    \Yii::$app->getSession()->setFlash('success', 'Congratulations! your email is verified');
                    return $this->goBack([
                        '/dashboard/index'
                    ]);
                }
            }
        }
        \Yii::$app->getSession()->setFlash('expired', 'Token is Expired Please Resend Again');
        return $this->goBack([
            '/dashboard/index'
        ]);
    }

    protected function findModel($id)
    {
        if (($model = User::findOne($id)) !== null) {

            if (! ($model->isAllowed()))
                throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));

            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    protected function updateMenuItems($model = null)
    {
        $controller = \Yii::$app->controller->action->id;
        $action = \Yii::$app->controller->action->id;
        switch (\Yii::$app->controller->action->id) {
            case 'index':
                {
                    $url = 'add';

                    if ($action == 'provider' && $controller == 'user') {
                        // $url = 'add-provider';
                    }

                    $this->menu['add'] = [
                        'label' => '<span class="glyphicon glyphicon-plus"></span>',
                        'title' => Yii::t('app', 'Add'),
                        'url' => [
                            $url
                        ],
                        'visible' => true
                    ];
                }
                break;
            case 'provider':
                {

                    $this->menu['add'] = [
                        'label' => '<span class="glyphicon glyphicon-plus"></span>',
                        'title' => Yii::t('app', 'Add'),
                        'url' => [
                            'add-provider'
                        ],
                        'visible' => true
                    ];
                }
                break;
            case 'add':
                {
                    $this->menu['manage'] = [
                        'label' => '<span class="glyphicon glyphicon-list"></span>',
                        'title' => Yii::t('app', 'Manage'),
                        'url' => [
                            'index'
                        ],
                        'visible' => User::isAdmin()
                    ];
                }
                break;
            default:
            case 'view':

                if ($model != null && $model->id != 1)

                    $this->menu['add'] = [
                        'label' => '<span class="glyphicon glyphicon-plus"></span>',
                        'title' => Yii::t('app', 'Add'),
                        'url' => [
                            'add'
                        ],
                        'visible' => false
                    ];
                if (! empty($model) && $model->role_id != User::ROLE_ADMIN) {
                    $this->menu['changepassword'] = [
                        'label' => '<span class="glyphicon glyphicon-paste"></span>',
                        'title' => Yii::t('app', 'Change Password'),
                        'url' => [
                            'changepassword',
                            'id' => $model->id
                        ],
                        'visible' => false
                    ];
                }
                if ($model != null)
                    $this->menu['update'] = [
                        'label' => '<span class="glyphicon glyphicon-pencil"></span>',
                        'title' => Yii::t('app', 'Update'),
                        'url' => [
                            'update',
                            'id' => $model->id
                        ],

                        'visible' => false
                    ];
                if (! empty($model) && $model->role_id != User::ROLE_ADMIN && $model->role_id != User::ROLE_USER) {
                    $this->menu['manage'] = [
                        'label' => '<span class="glyphicon glyphicon-list"></span>',
                        'title' => Yii::t('app', 'Manage'),
                        'url' => [
                            'user/provider'
                        ]
                    ];
                }
                if (! empty($model) && $model->role_id != User::ROLE_ADMIN && $model->role_id != User::ROLE_PROVIDER) {
                    $this->menu['manage'] = [
                        'label' => '<span class="glyphicon glyphicon-list"></span>',
                        'title' => Yii::t('app', 'Manage'),
                        'url' => [
                            'index'
                        ]
                    ];
                }
                if (! empty($model) && $model->role_id == User::ROLE_PROVIDER) {

                    if ($model->is_approved != User::IS_APPROVED) {
                        $this->menu['Approve'] = [
                            'label' => 'Approve',
                            'title' => Yii::t('app', 'Approve'),
                            'url' => [
                                'approve',
                                'id' => $model->id,
                                'is_approved' => $model->is_approved != User::IS_APPROVED
                            ],
                            'visible' => User::isAdmin()
                        ];
                    }
                    if ($model->is_approved != User::IS_NOT_APPROVED) {
                        $this->menu['reject'] = [
                            'label' => 'Reject',
                            'title' => Yii::t('app', 'Reject'),
                            'url' => $model->getUrl('reject'),
                            'visible' => ($model->is_approved != User::IS_NOT_APPROVED)
                        ];
                    }
                }

                $this->menu['final-delete'] = [
                    'label' => '<span class="glyphicon glyphicon-trash"></span>',
                    'title' => Yii::t('app', 'Final Delete'),
                    'url' => $model->getUrl('final-delete'),
                    'class' => 'btn btn-danger',
                    'visible' => User::isAdmin()
                ];
        }
    }
}
