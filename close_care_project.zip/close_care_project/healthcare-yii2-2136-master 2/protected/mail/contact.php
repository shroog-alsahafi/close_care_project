<?php use yii\helpers\Html;

include('header.php') ?>
<!--- body start-->
<tr align="center">
   <td style="padding: 30px 15px 45px 15px">
      <h3 style="font-size:20px;margin:0px;">Hi
         <?php echo Html::encode($user->full_name) ?>,
      </h3>
      <p style="margin:0;padding:10px 30px 40px 30px;">Thank you for reaching us , we have
         received your request and our
         representative will get back
         to you on following details .
      </p>
      <table style="width: 100%;border-collapse: collapse;" cellpadding="6">
         <tr>
            <td width="50%" style="border: 1px solid #000;">
               <b>User Name</b>
            </td>
            <td width="50%" style="border: 1px solid #000;">
               <?php echo Html::encode($user->full_name) ?>
            </td>
         </tr>
         <tr>
            <td width="50%" style="border: 1px solid #000;">
               <b> Email</b>
            </td>
            <td width="50%" style="border: 1px solid #000;">
               <?php echo Html::encode($user->email) ?>
            </td>
         </tr>
         <tr>
            <td width="50%" style="border: 1px solid #000;">
               <b> Contact No.</b>
            </td>
            <td width="50%" style="border: 1px solid #000;">
               <?php echo Html::encode($user->mobile) ?>
            </td>
         </tr>
         <tr>
            <td style="width: 50%;border: 1px solid #000;">
               <b>Message</b>
            </td>
            <td style="width: 50%;border: 1px solid #000;">
               <p style="margin: 0">
                  <?php echo Html::encode($user->description) ?>
               </p>
            </td>
         </tr>
      </table>
   </td>
</tr>
<!--- body end-->
<?php include('footer.php') ?>