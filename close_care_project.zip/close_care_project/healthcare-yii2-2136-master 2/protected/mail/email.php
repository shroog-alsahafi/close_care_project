<?= $this->render('header.php'); ?>

<!--- body start-->
<tr>
   <td style="padding: 30px 30px 30px 30px;background: #fff;" colspan="2" align="center">
      <p style="margin:  0; font-size: 16px; font-weight: bold; line-height: 1.6;color: #333;">
         Hi Smiles Davis,
      </p>
      <p style="margin:0; font-size: 16px; line-height: 1.6; color: #333; margin:0;padding:10px 30px 0px 30px;">
         <?php echo $content ?> wdded
      </p>


   </td>
</tr>
<!--body end-->
<?= $this->render('footer.php'); ?>