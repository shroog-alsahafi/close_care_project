<!--- footer start-->
<tr>
	<td style="padding: 0px 15px;">
		<table width="100%">

			<tr>
				<td align="center" style="border-top: 1px solid #000;; padding-top: 20px">
					<h4 class="connect" style="margin: 0; font-size: 18px;">Connect
						With US</h4>
				</td>
			</tr>
			<tr>
				<td align="center" style="padding-top: 20px">
					<table border="0" cellspacing="0" cellpadding="0" style="width: auto !important">
						<tbody>
							<tr>
								<td align="center"><a style="text-decoration: none; margin-right: 15px;" href="#0"
										target="_blank"> <svg xmlns:dc="http://purl.org/dc/elements/1.1/"
											xmlns:cc="http://creativecommons.org/ns#"
											xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
											xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg"
											xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
											xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="10mm"
											height="10mm" viewBox="0 0 10 10" version="1.1" id="svg8"
											inkscape:version="0.92.3 (2405546, 2018-03-11)" sodipodi:docname="fb-1.svg">
											<defs id="defs2" />
											<sodipodi:namedview id="base" pagecolor="#ffffff" bordercolor="#666666"
												borderopacity="1.0" inkscape:pageopacity="0.0" inkscape:pageshadow="2"
												inkscape:zoom="0.35" inkscape:cx="-102.57144" inkscape:cy="58.857137"
												inkscape:document-units="mm" inkscape:current-layer="layer1"
												showgrid="false" inkscape:window-width="1680"
												inkscape:window-height="1001" inkscape:window-x="0"
												inkscape:window-y="25" inkscape:window-maximized="1" />
											<metadata id="metadata5">
												<rdf:RDF>
													<cc:Work rdf:about="">
														<dc:format>image/svg+xml</dc:format>
														<dc:type
															rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
														<dc:title></dc:title>
													</cc:Work>
												</rdf:RDF>
											</metadata>
											<g inkscape:label="Layer 1" inkscape:groupmode="layer" id="layer1"
												transform="translate(-14.665479,-157.42976)">
												<g id="g16"
													transform="matrix(0.08912974,0,0,0.08912974,14.665479,157.42976)">
													<g id="g14">
														<circle id="circle10" data-original="#3B5998" r="56.098"
															cy="56.098" cx="56.098" style="fill:#3b5998" />
														<path id="path12" class="active-path" data-original="#FFFFFF"
															d="M 70.201,58.294 H 60.191 V 94.966 H 45.025 V 58.294 H 37.812 V 45.406 h 7.213 v -8.34 c 0,-5.964 2.833,-15.303 15.301,-15.303 L 71.56,21.81 v 12.51 h -8.151 c -1.337,0 -3.217,0.668 -3.217,3.513 v 7.585 h 11.334 z"
															style="fill:#ffffff" inkscape:connector-curvature="0" />
													</g>
												</g>
											</g>
										</svg>
									</a></td>
								<td align="center"><a style="text-decoration: none; margin-right: 15px;" href="#0"
										target="_blank"> <svg xmlns:dc="http://purl.org/dc/elements/1.1/"
											xmlns:cc="http://creativecommons.org/ns#"
											xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
											xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg"
											xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
											xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="10mm"
											height="10mm" viewBox="0 0 10 10" version="1.1" id="svg73"
											inkscape:version="0.92.3 (2405546, 2018-03-11)" sodipodi:docname="tw-1.svg">
											<defs id="defs67" />
											<sodipodi:namedview id="base" pagecolor="#ffffff" bordercolor="#666666"
												borderopacity="1.0" inkscape:pageopacity="0.0" inkscape:pageshadow="2"
												inkscape:zoom="0.35" inkscape:cx="-108.288" inkscape:cy="38.856064"
												inkscape:document-units="mm" inkscape:current-layer="layer1"
												showgrid="false" inkscape:window-width="1680"
												inkscape:window-height="1001" inkscape:window-x="0"
												inkscape:window-y="25" inkscape:window-maximized="1" />
											<metadata id="metadata70">
												<rdf:RDF>
													<cc:Work rdf:about="">
														<dc:format>image/svg+xml</dc:format>
														<dc:type
															rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
														<dc:title></dc:title>
													</cc:Work>
												</rdf:RDF>
											</metadata>
											<g inkscape:label="Layer 1" inkscape:groupmode="layer" id="layer1"
												transform="translate(-13.154175,-149.114)">
												<g id="g83"
													transform="matrix(0.08912974,0,0,0.08912974,13.154086,149.114)">
													<g id="g81">
														<circle id="circle75" class="" data-original="#55ACEE"
															r="56.098" cy="56.098" cx="56.098999"
															style="fill:#55acee" />
														<g id="g79">
															<path id="path77" class="active-path"
																data-original="#F1F2F2"
																d="m 90.461,40.316 c -2.404,1.066 -4.99,1.787 -7.702,2.109 2.769,-1.659 4.894,-4.284 5.897,-7.417 -2.591,1.537 -5.462,2.652 -8.515,3.253 -2.446,-2.605 -5.931,-4.233 -9.79,-4.233 -7.404,0 -13.409,6.005 -13.409,13.409 0,1.051 0.119,2.074 0.349,3.056 -11.144,-0.559 -21.025,-5.897 -27.639,-14.012 -1.154,1.98 -1.816,4.285 -1.816,6.742 0,4.651 2.369,8.757 5.965,11.161 -2.197,-0.069 -4.266,-0.672 -6.073,-1.679 -0.001,0.057 -0.001,0.114 -0.001,0.17 0,6.497 4.624,11.916 10.757,13.147 -1.124,0.308 -2.311,0.471 -3.532,0.471 -0.866,0 -1.705,-0.083 -2.523,-0.239 1.706,5.326 6.657,9.203 12.526,9.312 -4.59,3.597 -10.371,5.74 -16.655,5.74 -1.08,0 -2.15,-0.063 -3.197,-0.188 5.931,3.806 12.981,6.025 20.553,6.025 24.664,0 38.152,-20.432 38.152,-38.153 0,-0.581 -0.013,-1.16 -0.039,-1.734 2.622,-1.89 4.895,-4.251 6.692,-6.94 z"
																style="fill:#f1f2f2" inkscape:connector-curvature="0" />
														</g>
													</g>
												</g>
											</g>
										</svg>
									</a></td>
								<td align="center"><a style="text-decoration: none;" href="#0" target="_blank">
										<svg xmlns:dc="http://purl.org/dc/elements/1.1/"
											xmlns:cc="http://creativecommons.org/ns#"
											xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"
											xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg"
											xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
											xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape" width="10mm"
											height="10mm" viewBox="0 0 10 10" version="1.1" id="svg8"
											inkscape:version="0.92.3 (2405546, 2018-03-11)"
											sodipodi:docname="youtube-1.svg">
											<defs id="defs2" />
											<sodipodi:namedview id="base" pagecolor="#ffffff" bordercolor="#666666"
												borderopacity="1.0" inkscape:pageopacity="0.0" inkscape:pageshadow="2"
												inkscape:zoom="0.35" inkscape:cx="-148.28572" inkscape:cy="87.42855"
												inkscape:document-units="mm" inkscape:current-layer="layer1"
												showgrid="false" inkscape:window-width="1680"
												inkscape:window-height="1001" inkscape:window-x="0"
												inkscape:window-y="25" inkscape:window-maximized="1" />
											<metadata id="metadata5">
												<rdf:RDF>
													<cc:Work rdf:about="">
														<dc:format>image/svg+xml</dc:format>
														<dc:type
															rdf:resource="http://purl.org/dc/dcmitype/StillImage" />
														<dc:title></dc:title>
													</cc:Work>
												</rdf:RDF>
											</metadata>
											<g inkscape:label="Layer 1" inkscape:groupmode="layer" id="layer1"
												transform="translate(-26.760715,-164.98928)">
												<g id="g18"
													transform="matrix(0.01953125,0,0,0.01953125,26.760715,164.98928)">
													<circle id="circle10" data-original="#D22215" r="256" cy="256"
														cx="256" style="fill:#d22215" />
													<path id="path12" data-original="#A81411"
														d="m 384.857,170.339 c -7.677,2.343 -15.682,4.356 -23.699,6.361 -56.889,12.067 -132.741,-20.687 -165.495,32.754 -27.317,42.494 -35.942,95.668 -67.017,133.663 L 294.629,509.1 C 405.099,492.38 492.402,405.064 509.105,294.589 Z"
														style="fill:#a81411" inkscape:connector-curvature="0" />
													<path id="path14" data-original="#FFFFFF"
														d="M 341.649,152.333 H 170.351 c -33.608,0 -60.852,27.245 -60.852,60.852 v 85.632 c 0,33.608 27.245,60.852 60.852,60.852 h 171.298 c 33.608,0 60.852,-27.245 60.852,-60.852 v -85.632 c 0,-33.607 -27.245,-60.852 -60.852,-60.852 z m -41.155,107.834 -80.12,38.212 c -2.136,1.019 -4.603,-0.536 -4.603,-2.901 v -78.814 c 0,-2.4 2.532,-3.955 4.67,-2.87 l 80.12,40.601 c 2.386,1.207 2.343,4.624 -0.067,5.772 z"
														style="fill:#ffffff" inkscape:connector-curvature="0" />
													<path id="path16" class="active-path" data-original="#D1D1D1"
														d="m 341.649,152.333 h -87.373 v 78.605 l 46.287,23.455 c 2.384,1.208 2.341,4.624 -0.069,5.773 l -46.218,22.044 v 77.459 h 87.373 c 33.608,0 60.852,-27.245 60.852,-60.852 v -85.632 c 0,-33.607 -27.245,-60.852 -60.852,-60.852 z"
														style="fill:#d1d1d1" inkscape:connector-curvature="0" />
												</g>
											</g>
										</svg>
									</a></td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
			<tr>
				<td style="padding: 17px 30px 20px 30px; text-align: center;">
					<p style="margin:0">Admin panel rest allows organizations to
						manage their complete talent acquisition process within a single
						platform.</p>
				</td>
			</tr>
		</table>
	</td>
</tr>

<tr>
	<td
		style="color: #fff; font-size: 14px; text-align: center; padding: 15px 0px; background: #5559ce;border-bottom-left-radius:10px;border-bottom-right-radius:10px;">
		&copy;
		<?= date('Y') ?> <a target="_blank" style="color: #fff; text-decoration: none;" href="#0">
			<?php echo \yii::$app->name ?>
		</a>
		All Rights Reserved.
	</td>
</tr>
</table>
</td>
</tr>
</table>
</body>

</html>
<!-- footer end -->