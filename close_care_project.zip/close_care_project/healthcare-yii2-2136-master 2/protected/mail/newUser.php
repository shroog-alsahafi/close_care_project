<?php
use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $user app\models\User */

$Link = $user->getLoginUrl();
?>

<!--- body start-->

<tr>
   <td style="padding: 30px 30px 30px 30px" align="center">
      <h3 style="font-size:20px;margin:0px;">Hi <?php echo Html::encode($user->full_name) ?>,</h3>
      <p style="margin:0;padding:10px 30px 20px 30px;"> Your account has been successfully created. You can login to
         your account using the Application.
      </p>

      
   </td>
</tr>

<table
			style="width: 100%; max-width: 500px; border: 1px solid #3AAFA9; margin-left: auto; margin-right: auto; padding: 18px 0 22px 0px; border-radius: 8px;">
	
			<tr align="center">
				<td
					style="padding-bottom: 10px; font-size: 17px; line-height: 27px;">Email:<?= $user->email ?></td>
					
			</tr>
			<tr align="center">
				<td
					style="padding-bottom: 10px; font-size: 17px; line-height: 27px;">Role:<?= $user->getType() ?></td>
			</tr>
		
	

               
         </table>


<!--body end-->