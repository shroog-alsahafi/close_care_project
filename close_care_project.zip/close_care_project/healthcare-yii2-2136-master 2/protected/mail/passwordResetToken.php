<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $user app\models\User */

$resetLink = $user->getResetUrl();
?>
<!--- body start-->
<tr>
	<td style="padding: 30px 30px 40px 30px;" align="center">
		<h3 style="font-size: 20px; margin: 0px;">Hi
			<?php echo Html::encode($user->full_name) ?>,
		</h3>
		<p style="margin:0;padding:10px 30px 40px 30px;">Follow the link below to reset your password:</p>

		<p style="margin: 0;">

			<a href="<?= Html::encode($resetLink) ?>" style="background-color: #5559ce; border-radius: 3px; color: #fff;
						   font-size: 16px;line-height: 26px; text-decoration: none; border: 1px solid #5559ce;padding: 13px 50px;"
				target="_blank">Reset
				Password</a>
		</p>
	</td>
</tr>
<!--body end-->