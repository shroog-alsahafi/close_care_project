<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
use yii\helpers\Html;
use app\models\User;

/* @var $this yii\web\View */
/* @var $user app\models\User */

?>
<!--- body start-->
<tr>
	<td style="padding: 30px 30px 40px 30px;" align="center">
		<h3 style="font-size: 20px; margin: 0px;">Hi
			<?php echo Html::encode($model->full_name) ?>,
		</h3>
		<p style="margin: 0; padding: 10px 30px 40px 30px;">Your account is <?= $model->is_approved == User::IS_APPROVED ? 'approved' : 'Rejected' ?> </p>
		<?php if($model->is_approved !=  User::IS_APPROVED){?>
			<p style="margin: 0; padding: 10px 30px 40px 30px;">Due to -: <?php echo  $model->conclusion;?> </p>
		
		
		<?php }?>
	</td>
</tr>
<!--body end-->