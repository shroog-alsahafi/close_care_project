<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $user app\models\User */

$Link = $user->getLoginUrl();
?>
<!--- body start-->

<tr>
	<td style="padding: 20px 30px 30px 30px">
		<h3 style="font-size: 20px; margin: 0px;">Hi  <?php echo  Html::encode($user->full_name) ?>,</h3>
		<p><?=Yii::t('app','Thank you for registering with')?> <?php echo Yii::$app->name ?>
                  </p>

		<p><?=Yii::t('app','Below is the credentail for login')?> -:</p>


		<p> <?=Yii::t('app','Email')?> -: <?=$user->email?> </p>

		<p> <?=Yii::t('app','Password')?> -: <?=$password?> </p>

		<p> <?=Yii::t('app','Role')?> -: <?=$user->getType()?> </p>



	</td>
</tr>
<!--body end-->