<?php
use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $user @app\models\User */

$link = $user->getVerified();

?>

<tr>
	<td style="padding: 30px 15px 30px 15px;" align="center">
		<h4 style="font-size: 18px; margin: 0; font-weight: 600; color: rgb(33, 33, 33);font-weight:100;">
			Hi
			<?php echo Html::encode($user->full_name) ?>,
		</h4>
		<p style="margin:0;padding:10px 30px 25px 30px;">Welcome to <?= Yii::$app->name; ?><br>
			Thanks for signing
			up. To continue, please confirm your email address by clicking the
			button below.</p>
		<p style="margin:0;">
			<a style="display: inline-block; text-decoration: none; background-color: #5559ce; padding:13px 50px;border: 1px solid #5559ce; 
						border-radius: 3px; color: #FFF; font-weight: bold;" href="<?= $link ?>" target="_blank">Verify
				Email</a>
		</p>
		<p style="margin:0;padding:20px 30px 25px 30px;">If
			above link isn't working, please copy and paste it directly in you
			browser's URL field to get started.</p>
		<p style="margin: 0px;">
			<a href="<?php echo $link; ?>" style="color: #5559ce; font-size: 14px;">
				<?php echo $link; ?>sdcscs
			</a>
		</p>
	</td>
</tr>