<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
use yii\db\Migration;

/**
 * php console.php module/migrate
 */
class m240729_130754_add_new_columns_tbl_user extends Migration
{

    public function safeUp()
    {
        $table = Yii::$app->db->getTableSchema('{{%user}}');
        if (! isset($table->columns['customer_id'])) {
            $this->addColumn('{{%user}}', 'customer_id', $this->string(255)
                ->defaultValue(null));
        }
        if ($table !== null && ! isset($table->columns['otp'])) {
            $this->addColumn('{{%user}}', 'otp', $this->integer()
                ->defaultValue(null));
        }
        if ($table !== null && ! isset($table->columns['otp_verified'])) {
            $this->addColumn('{{%user}}', 'otp_verified', $this->integer()
                ->defaultValue(null));
        }
        if (! isset($table->columns['is_profile_setup'])) {
            $this->addColumn('{{%user}}', 'is_profile_setup', $this->smallInteger()
                ->defaultValue(0));
        }
        if ($table !== null && ! isset($table->columns['avg_rating'])) {
            $this->addColumn('{{%user}}', 'avg_rating', $this->decimal(3, 2)
                ->defaultValue(0.00)
                ->notNull());
        }
        if ($table !== null && ! isset($table->columns['rating_counts'])) {
            $this->addColumn('{{%user}}', 'rating_counts', $this->bigInteger()
                ->defaultValue(0)
                ->notNull());
        }
        if ($table !== null && ! isset($table->columns['is_notify'])) {
            $this->addColumn('{{%user}}', 'is_notify', $this->tinyInteger(1)
                ->defaultValue(1));
        }
    }

    public function safeDown()
    {
        $table = Yii::$app->db->getTableSchema('{{%user}}');
        $table = Yii::$app->db->getTableSchema('{{%user}}');
        if (! isset($table->columns['customer_id'])) {
            $this->addColumn('{{%user}}', 'customer_id', $this->string(255)
                ->defaultValue(null));
        }
        if ($table !== null && ! isset($table->columns['otp'])) {
            $this->addColumn('{{%user}}', 'otp', $this->integer()
                ->defaultValue(null));
        }
        if ($table !== null && ! isset($table->columns['otp_verified'])) {
            $this->addColumn('{{%user}}', 'otp_verified', $this->integer()
                ->defaultValue(null));
        }
        if (! isset($table->columns['is_profile_setup'])) {
            $this->addColumn('{{%user}}', 'is_profile_setup', $this->smallInteger()
                ->defaultValue(0));
        }
        if ($table !== null && ! isset($table->columns['avg_rating'])) {
            $this->addColumn('{{%user}}', 'avg_rating', $this->decimal(3, 2)
                ->defaultValue(0.00)
                ->notNull());
        }
        if ($table !== null && ! isset($table->columns['rating_counts'])) {
            $this->addColumn('{{%user}}', 'rating_counts', $this->bigInteger()
                ->defaultValue(0)
                ->notNull());
        }
        if ($table !== null && ! isset($table->columns['is_notify'])) {
            $this->addColumn('{{%user}}', 'is_notify', $this->tinyInteger(1)
                ->defaultValue(1));
        }
    }
}