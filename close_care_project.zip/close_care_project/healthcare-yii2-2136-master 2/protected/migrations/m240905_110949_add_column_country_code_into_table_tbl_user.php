<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
use yii\db\Migration;

/**
 * php console.php module/migrate
 */
class m240905_110949_add_column_country_code_into_table_tbl_user extends Migration
{

    public function safeUp()
    {
        $table = Yii::$app->db->getTableSchema('{{%user}}');
        if (! isset($table->columns['country_code'])) {
            $this->addColumn('{{%user}}', 'country_code', $this->string(6)
                ->defaultValue(null));
        }
    }

    public function safeDown()
    {
        $table = Yii::$app->db->getTableSchema('{{%user}}');
        if (! isset($table->columns['country_code'])) {
            $this->addColumn('{{%user}}', 'country_code', $this->string(6)
                ->defaultValue(null));
        }
    }
}