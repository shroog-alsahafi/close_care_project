<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
use yii\db\Migration;

/**
 * php console.php module/migrate
 */
class m240909_100944_add_column_is_papproved_into_table_tbl_user extends Migration
{

    public function safeUp()
    {
        $table = Yii::$app->db->getTableSchema('{{%user}}');
        if (! isset($table->columns['is_approved'])) {
            $this->addColumn('{{%user}}', 'is_approved', $this->integer()
                ->defaultValue(0));
        }
    }

    public function safeDown()
    {
        $table = Yii::$app->db->getTableSchema('{{%user}}');
        if (! isset($table->columns['is_approved'])) {
            $this->addColumn('{{%user}}', 'is_approved', $this->integer()
                ->defaultValue(0));
        }
    }
}