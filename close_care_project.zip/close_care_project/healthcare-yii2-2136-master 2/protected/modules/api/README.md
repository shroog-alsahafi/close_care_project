## api

1. Used for create api's

## INSTALLATION 

## If you need to install single module 

Steps-
1. Go to ***htdocs*** or ***html*** folder.
2. Then, Go to your project->protected->modules and Open your terminal by ***ctrl+alt+t*** . 
3. Type ***git clone  http://192.168.10.21/yii2/modules/api.git*** in your terminal. Wait till installation complete.
4. After clone run (project->protected->modules) this command php console.php installer/install/module -m=api in termianl. Open your terminal by ctrl+alt+t .4. 

> add below code in your .gitmodule file.

        [submodule "protected/modules/api"]
        path = protected/modules/api
        url = http://192.168.10.21/yii2/modules/api.git

> add below code in web.php file, located at protected/config/web.php

        $config['modules']['api'] = [
         'class' => 'app\modules\api\Module'
        ];

> add module in side nav bar, located at protected/base/TBaseController.php

         if (yii::$app->hasModule('api'))
                   $this->nav_left[] = \app\modules\api\Module::subNav();

## During setup new project > you need to use these steps

Steps- 
1. Go to ***htdocs*** or ***html*** > you project .
2. 1st check  .gitmodule file blog module lines ( exists or not)

        [submodule "protected/modules/api"]
        path = protected/modules/api
        url = http://192.168.10.21/yii2/modules/api.git

3. Then, run (in your project root)  ***bash ../scripts/clone-submodules.sh*** in your terminal.
