<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\api\controllers;

use app\components\filters\AccessControl;
use app\components\filters\AccessRule;
use yii\data\ActiveDataProvider;
use app\modules\api\components\ApiBaseController;
use app\models\User;
use app\modules\api\models\Rating;
/**
 * RatingController implements the API actions for Rating model.
 */
class RatingController extends ApiBaseController
{

    public $modelClass = "app\modules\rating\models\Rating";

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [
                    [
                        'actions' => [
                            'add-rating',
                            'rating-list',
                            'review',
                            'rating-details'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                        return User::isUser() | User::isProvider();
                        }
                    ]
                ]
            ]
        ];
    }

    /**
     *
     * @OA\Post(path="/rating/add-rating",
     *   summary="",
     *   tags={"Rating"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *    @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *           required={"Rating[rating]"},
     *              @OA\Property(property="Rating[rating]",type="integer", example="5",description="Rating"),
     *              @OA\Property(property="Rating[comment]",type="string",example="good",description="Reviews"),
     *
     *           ),
     *       ),
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Add rating of the charging space",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionAddRating($id)
    {
        $this->setStatus(400);
        $data = [];
        $ratingModel = new Rating();
        $post = \Yii::$app->request->post();
        $booking = User::findOne($id);

        if (empty($booking)) {
            $data['message'] = \yii::t('app', "Provider not found");
            return $data;
        }

        if ($ratingModel->load($post)) {
            $existingRating = Rating::findActive()->andWhere([
                'model_id' => $id
            ])
                ->my()
                ->one();

            if ($existingRating) {
                $existingRating->updateAttributes([
                    'rating' => $ratingModel->rating,
                    'comment' => $ratingModel->comment
                ]);
                $avgRating = Rating::findActive()->andWhere([
                    'model_id' => $booking->id,
                    'model_type' => User::class
                ])->average('rating');
                if (! empty($avgRating)) {
                    $booking->avg_rating = round($avgRating, 2);
                    $booking->updateAttributes([
                        'avg_rating'
                    ]);
                }
                $this->setStatus(200);
                $data['message'] = \Yii::t('app', 'Rating updated successfully');
                $data['detail'] = $existingRating->asJson(true);
            } else {
                $ratingModel->model_id = $id;
                $ratingModel->model_type = User::class;
                $ratingModel->title = \Yii::t('app', 'Review');
                $ratingModel->state_id = Rating::STATE_ACTIVE;
                if ($ratingModel->save()) {
                    $avgRating = Rating::findActive()->andWhere([
                        'model_id' => $booking->id,
                        'model_type' => User::class
                    ])->average('rating');

                    if (! empty($avgRating)) {

                        $currentRatingCounts = $booking->rating_counts ?? 0;
                        $newRatingCounts = $currentRatingCounts + 1;

                        $booking->avg_rating = round($avgRating, 2);
                        $booking->updateAttributes([
                            'avg_rating' => $avgRating,
                            'rating_counts' => $newRatingCounts
                        ]);
                    }

                    $this->setStatus(200);
                    $data['message'] = \Yii::t('app', 'Rating added successfully');
                    $data['detail'] = $ratingModel->asJson(true);
                } else {
                    $data['message'] = $ratingModel->getErrors();
                }
            }
        } else {
            $data['message'] = \Yii::t('app', 'Data Not Posted');
        }
        return $data;
    }

    /**
     *
     * @OA\Post(path="/rating/review",
     *   summary="",
     *   tags={"Rating"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Rating List of the charging space",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     *
     *
     */
    public function actionReview($page = 0)
    {
        $this->setStatus(400);
        $model = Rating::findActive()->my();

        $dataProvider = new ActiveDataProvider([
            'query' => $model,
            'pagination' => [
                'pageSize' => 10,
                'page' => $page
            ],
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_ASC
                ]
            ]
        ]);
        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     *
     * @OA\Post(path="/rating/rating-list",
     *   summary="",
     *   tags={"Rating"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Rating List of the charging space",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     *
     *
     */
    public function actionRatingList($id, $page = 0)
    {
        $this->setStatus(400);
        $model = Rating::findActive()->andWhere([
            'title' => $id
        ]);

        $dataProvider = new ActiveDataProvider([
            'query' => $model,
            'pagination' => [
                'pageSize' => 10,
                'page' => $page
            ],
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_ASC
                ]
            ]
        ]);
        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     *
     * @OA\Post(path="/rating/rating-details",
     *   summary="",
     *   tags={"Rating"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Rating List of the charging space",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     *
     *
     */
    public function actionRatingDetails($id)
    {
        $data = [];
        $model = Rating::findOne($id);
        if (! empty($model)) {
            $data['detail'] = $model->asJson();
        } else {
            $this->setStatus(400);
            $data['message'] = \Yii::t('app', "Rating not found.");
        }

        return $data;
    }
}
