<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\api\controllers;

use app\models\LoginForm;
use Yii;
use app\models\User;
use app\modules\api\components\ApiBaseController;
use app\modules\api\models\AccessToken;
use app\components\filters\AccessControl;
use app\components\filters\AccessRule;
use app\modules\page\models\Page;
use app\modules\provider\models\Availability;
use yii\data\ActiveDataProvider;
use app\modules\provider\models\Provider;
use yii\web\HttpException;
use app\models\EmailQueue;
use app\modules\contact\models\Information;
use yii\web\UploadedFile;
use app\models\File;
use app\modules\notification\models\Notification;
use app\modules\provider\models\ServiceDetail;
use app\modules\provider\models\Qualification;
use app\modules\provider\models\BankDetail;
use app\models\SearchUser;
use app\modules\payment\models\Transaction;

/**
 * UserController implements the API actions for User model.
 */
class TransactionController extends ApiBaseController
{

    public $modelClass = "app\modules\payment\models\Transaction";

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [

                    [
                        'actions' => [
                            'checkout'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isAdmin() || User::isUser() || User::isGuest();
                        }
                    ]
                ]
            ]
        ];
    }

    /**
     *
     * @OA\Get(path="/transaction/checkout",
     *   summary="",
     *   tags={"Transaction"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Returns user info",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionCheckout($id)
    {
        $transaction = Transaction::findOne($id);

        $data = [];

        if (! empty($transaction)) {
           $data['url'] = \Yii::$app->urlManager->createAbsoluteUrl([
                'site/paypal',
                'id' => $transaction->id
            ],true);
        } else {
            $data['message'] = \Yii::t('app', "Transaction ID not found");
        }

        return $data;
    }
}
