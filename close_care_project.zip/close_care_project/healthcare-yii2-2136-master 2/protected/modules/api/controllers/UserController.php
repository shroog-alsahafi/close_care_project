<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\api\controllers;

use app\models\LoginForm;
use Yii;
use app\models\User;
use app\modules\api\components\ApiBaseController;
use app\modules\api\models\AccessToken;
use app\components\filters\AccessControl;
use app\components\filters\AccessRule;
use app\modules\page\models\Page;
use app\modules\provider\models\Availability;
use yii\data\ActiveDataProvider;
use app\modules\provider\models\Provider;
use yii\web\HttpException;
use app\models\EmailQueue;
use app\modules\contact\models\Information;
use yii\web\UploadedFile;
use app\models\File;
use app\modules\notification\models\Notification;
use app\modules\provider\models\ServiceDetail;
use app\modules\provider\models\Qualification;
use app\modules\provider\models\BankDetail;
use app\models\SearchUser;
use app\modules\chat\models\Chat;

/**
 * UserController implements the API actions for User model.
 */

/**
 *
 * @OA\Info(
 *   version="1.0",
 *   title="Application API",
 *   description="Userimplements the API actions for User model.",
 *   @OA\Contact(
 *     name="Shiv Charan Panjeta",
 *     email="shiv@toxsl.com",
 *   ),
 * ),
 * @OA\SecurityScheme(
 * securityScheme="bearerAuth",
 * in="header",
 * name="bearerAuth",
 * type="http",
 * scheme="bearer",
 * )
 * @OA\Server(
 *   url="http://localhost/healthcare-yii2-2136/api",
 *   description="main server",
 * )
 * @OA\Server(
 *   url="http://192.168.2.189/healthcare-yii2-2136/api",
 *   description="local server",
 * )
 *  @OA\Server(
 *   url="http://192.168.2.147/healthcare-yii2-2136/api",
 *   description="main server",
 * ),
 * @OA\Server(
 *   url="http://192.168.2.140/healthcare-yii2-2136/api",
 *   description="main server",
 * ),
 * @OA\Server(
 *   url="http://192.168.11.153/healthcare-yii2-2136/api",
 *   description="main server",
 * ),
 * @OA\Server(
 *
 *   url="https://mars.toxsl.in/healthcare-yii2-2136/api",
 *   description="live server",
 * )
 * @OA\Server(
 *   url="https://dev.example.com/api",
 *   description="dev server",
 * )
 */
class UserController extends ApiBaseController
{

    public $modelClass = "app\models\User";

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [

                    [
                        'actions' => [
                            'index',
                            'create',
                            'view',
                            'update',
                            'delete',
                            'logout'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isAdmin() || User::isUser();
                        }
                    ],
                    [
                        'actions' => [

                            'get-page',
                            'add-availability',
                            'add-unavailability',
                            'unavailability-list',
                            'availability-list',
                            'update-availability',
                            'get-provider-slot',
                            'service-slot',
                            'provider-search',
                            'logout',
                            'signup',
                            'check',
                            'contact-us',
                            'change-password',
                            'delete-account',
                            'profile-setup',
                            'service-provider-detail',
                            'service-detail',
                            'clear-notification',
                            'notification-detail',
                            'notification-list',
                            'notification',
                            'provider-profile-update',
                            'delete-image',
                            'add-bank-details',
                            'bank-list',
                            'bank-details',
                            'un-availability-list',
                            'delete-un-availability',
                            'search-list',
                            'search-delete',
                            'delete-bank',
                            'update-bank',
                            'add-recent-search',
                            'update-user-location'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isUser() || User::isProvider();
                        }
                    ],

                    [
                        'actions' => [
                            'signup',
                            'login',
                            'verify-otp',
                            'resend-otp',
                            'forgot-password',
                            'image',
                            'degree',
                            'get-page'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isGuest();
                        }
                    ]
                ]
            ]
        ];
    }

    /**
     *
     * @OA\Post(path="/user/signup",
     *   summary="Signup api",
     *   tags={"User"},
     *   @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *              required={"User[contact_no]","User[password]"},
     *              @OA\Property(property="User[country_code]", type="string", format="text", example="+91",description="User Country Code"),
     *              @OA\Property(property="User[contact_no]", type="string", format="text", example="7418529630",description="User Contact Number"),
     *              @OA\Property(property="User[email]", type="string", format="text", example="test@toxsl.in",description="User Email"),
     *              @OA\Property(property="User[role_id]", type="input", example="",description="for user 2 and provider 4"),
     *              @OA\Property(property="User[password]", type="password", example="123456789",description="enter password"),
     *               @OA\Property(property="User[confirm_password]", type="password", example="123456789",description="confirm password must match with password"),
     *           ),
     *       ),
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Create new user",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionSignup()
    {
        $data = [];
        $this->setStatus(400);
        $model = new User();
        $model->loadDefaultValues();
        $model->state_id = User::STATE_ACTIVE;
        $model->scenario = "user-signup";
        if ($model->load(Yii::$app->request->post())) {
            $email_identify = User::findByUsername($model->email);

            $contact_identify = User::findByContact($model->contact_no, $model->country_code);

            if (! empty($email_identify)) {
                $data['message'] = \Yii::t('app', "Email already exists.");
                return $data;
            }
            if (! empty($contact_identify)) {
                $data['message'] = \Yii::t('app', "Contact number already exists.");
                return $data;
            }
            if ($model->password == $model->confirm_password) {

                $model->generateAuthKey();
                $model->last_action_time = date('Y-m-d H:i:s');
                $model->setPassword($model->password);
                $model->otp_verified = User::OTP_VERIFIED_NOT;
                $model->email_verified = User::EMAIL_VERIFIED;
                $model->otp = rand(1111, 9999);
                if ($model->save()) {
                    // $model->sendVerificationOtptoUser();
                    // $model->sendVerificationMailtoUser();
                    $model->sendRegistrationMailtoAdmin();
                    $this->setStatus(200);
                    $data['access-token'] = $model->getAuthKey();
                    $data['message'] = \Yii::t('app', "Account created successfully");
                    $data['detail'] = $model->asJson();
                } else {
                    $data['message'] = $model->getErrors();
                }
            } else {
                $data['message'] = \yii::t('app', "password and confirm password doesn't match");
            }
            // }
        } else {
            $data['message'] = \Yii::t('app', "Data not posted.");
        }
        return $data;
    }

    /**
     *
     * @OA\Get(path="/user/check",
     *   summary="",
     *   tags={"User"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Response(
     *     response=200,
     *     description="Returns user info",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionCheck()
    {
        $data = [];
        $this->setStatus(400);
        if (! \Yii::$app->user->isGuest) {
            $this->setStatus(200);
            $data['detail'] = \Yii::$app->user->identity->asJson();
        } else {
            $data['message'] = \yii::t('app', "User not authenticated. No token found");
        }

        return $data;
    }

    /**
     *
     * @OA\Post(path="/user/login",
     *   summary="Login api",
     *   tags={"User"},
     *   @OA\RequestBody(
     *       @OA\MediaType(
     *       mediaType="multipart/form-data",
     *       @OA\Schema(
     *       required={"LoginForm[username]","LoginForm[password]"},
     *       @OA\Property(property="LoginForm[username]", type="string", example="test@toxsl.in",description="mail of user"),
     *       @OA\Property(property="LoginForm[password]", type="string", example="12345678",description="password"),
     *       @OA\Property(property="LoginForm[role_id]", type="integer", example="1",description="role"),
     *       @OA\Property(property="LoginForm[device_token]", type="string", example="12345678",description="Device Token"),
     *       @OA\Property(property="LoginForm[device_type]", type="string", example="12345678",description="Device Type"),
     *       @OA\Property(property="LoginForm[device_name]", type="string", example="12345678",description="Device Name"),
     *           ),
     *       ),
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Create new user",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionLogin()
    {
        $data = [];
        $this->setStatus(400);

        $model = new LoginForm();
        $post = Yii::$app->request->post();

        if ($model->load($post)) {
            $user = User::findByEmailContact($model->username);
            if ($user) {

                if ($user->role_id == User::ROLE_PROVIDER && $user->is_approved == User::STATE_INACTIVE && $user->is_profile_setup == User::STATE_INACTIVE) {
                    if ($user->state_id == User::STATE_ACTIVE) {
                        if ($user->validatePassword($model->password)) {
                            if ($model->applogin()) {
                                $user->generateAuthKey();
                                $user->updateAttributes([
                                    'activation_key'
                                ]);

                                $this->setStatus(200); // Set success status
                                $data['access-token'] = $user->getAuthKey();
                                AccessToken::add($model, $user->getAuthKey());
                                $data['message'] = Yii::t('app', 'Setup your profile');
                                $data['detail'] = $user->asJson();
                                return $data;
                            } else {
                                $data['message'] = Yii::t('app', 'Error during application login');
                                return $data;
                            }
                        } else {
                            $data['message'] = Yii::t('app', 'Invalid Credentials');
                            return $data;
                        }
                    } else {
                        $data['message'] = Yii::t('app', 'Your account is in ' . $user->getState() . ' state. Please contact admin for account-related queries');
                        return $data;
                    }
                }

                // Check if the user is a provider and their profile is under review
                if ($user->role_id == User::ROLE_PROVIDER && $user->is_approved == User::STATE_INACTIVE && $user->is_profile_setup == User::STATE_ACTIVE) {
                    if ($user->state_id == User::STATE_ACTIVE) {
                        if ($user->validatePassword($model->password)) {
                            if ($model->applogin()) {
                                $user->generateAuthKey();
                                $user->updateAttributes([
                                    'activation_key'
                                ]);

                                $this->setStatus(200); // Set success status
                                $data['access-token'] = $user->getAuthKey();
                                AccessToken::add($model, $user->getAuthKey());
                                $data['message'] = Yii::t('app', 'Your profile is under review');
                                $data['detail'] = $user->asJson();
                                return $data;
                            } else {
                                $data['message'] = Yii::t('app', 'Error during application login');
                                return $data;
                            }
                        } else {
                            $data['message'] = Yii::t('app', 'Invalid Credentials');
                            return $data;
                        }
                    } else {
                        $data['message'] = Yii::t('app', 'Your account is in ' . $user->getState() . ' state. Please contact admin for account-related queries');
                        return $data;
                    }
                }

                if ($user->role_id == User::ROLE_PROVIDER && $user->is_approved == User::IS_NOT_APPROVED && $user->is_profile_setup == User::STATE_INACTIVE) {
                    if ($user->state_id == User::STATE_ACTIVE) {
                        if ($user->validatePassword($model->password)) {
                            if ($model->applogin()) {
                                $user->generateAuthKey();
                                $user->updateAttributes([
                                    'activation_key'
                                ]);

                                $this->setStatus(200); // Set success status
                                $data['access-token'] = $user->getAuthKey();
                                AccessToken::add($model, $user->getAuthKey());
                                $data['message'] = strip_tags(Yii::t('app', $user->conclusion));
                                $data['detail'] = $user->asJson();
                                return $data;
                            } else {
                                $data['message'] = Yii::t('app', 'Error during application login');
                                return $data;
                            }
                        } else {
                            $data['message'] = Yii::t('app', 'Invalid Credentials');
                            return $data;
                        }
                    } else {
                        $data['message'] = Yii::t('app', 'Your account is in ' . $user->getState() . ' state. Please contact admin for account-related queries');
                        return $data;
                    }
                }

                // Handle non-provider roles and other login conditions
                if ($user->role_id == User::ROLE_ADMIN) {
                    $data['message'] = Yii::t('app', 'You are not authorised to login');
                    return $data;
                }

                if ($user->role_id != $model->role_id) {
                    $data['error'] = ($model->role_id == User::ROLE_USER) ? Yii::t('app', 'You are not allowed to login in user section with provider credentials.') : Yii::t('app', 'You are not allowed to login in provider section with user credentials.');
                    return $data;
                }

                if ($user->email_verified == User::EMAIL_NOT_VERIFIED) {
                    $data['message'] = Yii::t('app', 'Email is not verified. Please verify your email to login');
                    return $data;
                }

                if ($user->state_id == User::STATE_ACTIVE) {
                    if ($user->validatePassword($model->password)) {
                        if ($model->applogin()) {
                            $user->generateAuthKey();
                            $user->updateAttributes([
                                'activation_key'
                            ]);

                            $this->setStatus(200);
                            $data['access-token'] = $user->getAuthKey();
                            AccessToken::add($model, $user->getAuthKey());
                            $data['message'] = Yii::t('app', 'Login successfully');
                            $data['detail'] = $user->asJson();
                        } else {
                            $data['message'] = Yii::t('app', 'Error during application login');
                        }
                    } else {
                        $data['message'] = Yii::t('app', 'Invalid Credentials');
                    }
                } else {
                    $data['message'] = Yii::t('app', 'Your account is in ' . $user->getState() . ' state. Please contact admin for account-related queries');
                }
            } else {
                $data['message'] = Yii::t('app', 'User not registered');
            }
        } else {
            $data['message'] = Yii::t('app', 'No data posted');
        }

        return $data;
    }

    /**
     *
     * @OA\Post(path="/user/forgot-password",
     *   summary="User",
     *   tags={"User"},
     * @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *
     *              @OA\Property(property="User[email]", type="email", example="test@toxsl.in",description="email"),
     *              @OA\Property(property="User[contact_no]", type="input", example="9876543210",description="Contact"),
     *               @OA\Property(property="User[country_code]", type="input", example="+91",description="Country code"),
     *           ),
     *       ),
     *   ),
     *
     *   @OA\Response(
     *     response=200,
     *     description="Recover Password",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionForgotPassword()
    {
        $data = [];
        $this->setStatus(400);
        $model = new User();

        $post = \Yii::$app->request->post();
        if ($model->load($post)) {
            if (! empty($model->email)) {
                $email = trim($model->email);
                $user = User::findByUsername($model->email);
            } else {

                $user = User::findByContact($model->contact_no, $model->country_code);
            }

            if ($user) {
                $user->generatePasswordResetToken();
                $this->setStatus(200);
                if (! empty($email)) {
                    $user->otp = "";
                    if (! $user->save()) {
                        $data['message'] = \yii::t('app', $user->getErrorsString());
                        return $data;
                    }
                    $data['token'] = $user->activation_key;
                    $data['detail'] = $user->asJson();
                    $user->sendForgotPasswordMailtoAdmin();
                    $data['message'] = \Yii::t('app', "Please check your email to reset your password.");
                    return $data;
                }
                if (! empty($model->contact_no)) {
                    $user->otp = rand(1000, 9999);
                    // $user->otp_verified = User::STATE_INACTIVE;
                    if (! $user->save()) {
                        $data['message'] = \yii::t('app', $user->getErrorsString());
                        return $data;
                    }

                    $data['message'] = \Yii::t('app', "OTP sent to your contact no to reset your password.");
                    $data['token'] = $user->activation_key;
                    $data['detail'] = $user->asJson();
                    return $data;
                }
            } else {
                $data['message'] = \Yii::t('app', "User is not registered.");
            }
        } else {
            $data['message'] = \Yii::t('app', "Data Not Posted");
        }
        return $data;
    }

    /**
     *
     * @OA\Post(path="/user/verify-otp",
     *   summary="Verify Otp",
     *   tags={"User"},
     *   @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *              @OA\Property(property="User[contact_no]", type="string", format="text", example="",description=""),
     *              @OA\Property(property="User[country_code]", type="string", format="text", example="",description=""),
     *              @OA\Property(property="User[otp]", type="string", example="",description=""),
     *              @OA\Property(property="LoginForm[device_type]", type="string", example="1",description=""),
     *              @OA\Property(property="LoginForm[device_token]", type="string", example="3452435342534asdfdsf",description=""),
     *              @OA\Property(property="LoginForm[device_name]", type="string", example="android",description=""),
     *           ),
     *       ),
     *   ),
     *
     *
     *   @OA\Response(
     *     response=200,
     *     description="Create new user",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionVerifyOtp()
    {
        $this->setStatus(400);
        $data = [];
        $model = new User();
        $loginForm = new LoginForm();
        $post = Yii::$app->request->post();
        if ($model->load($post) && $loginForm->load($post)) {
            $user = User::find()->where([
                'otp' => $model->otp,
                'country_code' => $model->country_code,
                'contact_no' => $model->contact_no
            ])->one();
            if (! empty($user)) {

                $user->state_id = User::STATE_ACTIVE;
                $user->otp_verified = User::OTP_VERIFIED;
                $user->otp = '';
                if ($user->updateAttributes([
                    'state_id',
                    'otp_verified',
                    'otp',
                    'activation_key',
                    'access_token'
                ])) {
                    \Yii::$app->user->login($user);
                    AccessToken::add($loginForm, $user->getAuthKey());
                    $this->setStatus(200);
                    $data['access-token'] = $user->getAuthKey();
                    $data['detail'] = $user->asJSon();
                    $data['message'] = \yii::t('app', "OTP verified successfully!");
                } else {
                    $data['message'] = $user->getErrors();
                }
            } else {
                $data['message'] = \Yii::t('app', 'OTP verification code does not match');
            }
        } else {
            $data['message'] = \Yii::t('app', 'No data posted');
        }
        return $data;
    }

    /**
     *
     * @OA\Post(path="/user/resend-otp",
     *   summary="Resend Otp",
     *   tags={"User"},
     *   @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *              required={"User[contact_no]"},
     *               @OA\Property(property="User[country_code]", type="string",  example="+91",description="country code"),
     *              @OA\Property(property="User[contact_no]", type="string",format="number", example="87483434",description="User Contact Number"),
     *
     *           ),
     *       ),
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="resend otp to user",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionResendOtp()
    {
        $data = [];
        $this->setStatus(400);
        $model = new User();
        if ($model->load(Yii::$app->request->post())) {
            $user = User::findByContact($model->contact_no, $model->country_code);
            if (! empty($user)) {
                $user->otp_verified = User::OTP_VERIFIED_NOT;
                $user->otp = User::getRandomOtp();

                if ($user->updateAttributes([
                    'otp'
                ])) {

                    // $user->sendSms();

                    $this->setStatus(200);
                    $data['detail'] = $user->otp;
                    $data['message'] = \Yii::t('app', 'otp resend');
                } else {
                    $this->setStatus(400);
                    $data['message'] = $user->getErrors();
                }
            } else {
                $this->setStatus(400);
                $data['message'] = \Yii::t('app', 'No User found');
            }
        } else {
            $this->setStatus(400);
            $data['message'] = \Yii::t('app', 'No data posted');
        }
        return $data;
    }

    /**
     *
     * @OA\Post(path="/user/contact-us",
     *   summary="Contact Us",
     *   tags={"User"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   *   @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *
     *           @OA\Schema(
     *              required={
     *              "Information[email]",
     *              "Information[description]",
     *              "Information[full_name]",
     *              },
     *              @OA\Property(
     *              property="Information[email]",
     *              type="email", format="text",
     *              example="Sam@gmail.in",
     *              description="Enter Email"
     *              ),
     *              @OA\Property(
     *              property="Information[description]",
     *              type="string", format="text",
     *              example="I want to contact",
     *              description="Enter Description"
     *              ),
     *
     *              @OA\Property(
     *              property="Information[full_name]",
     *              type="string", format="text",
     *              example="Sam",
     *              description="Enter Full Name"
     *              ),
     *
     *
     *           ),
     *       ),
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Contact Successfull Message",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionContactUs()
    {
        $data = [];
        $this->setStatus(400);
        $model = new Information();
        if ($model->load(Yii::$app->request->post())) {
            $user = \Yii::$app->user->identity;
            $model->mobile = '+919876543277';
            $from = $model->email;

            if ($model->save()) {
                $message = \yii::$app->view->renderFile('@app/mail/contact.php', [
                    'user' => $model
                ]);
                $sub = 'New Contact Mail: ';
                EmailQueue::sendEmailToAdmins([
                    'from' => $from,
                    'subject' => $sub,
                    'html' => $message,
                    'type_id' => EmailQueue::TYPE_KEEP_AFTER_SEND
                ], false);

                $data['message'] = \Yii::t('app', "Warm Greetings!! Thank you for contacting us. We have received your request. Our representative will contact you soon.");
                $this->setStatus(200);
            } else {
                $data['error'] = $model->getErrors();
            }
        } else {
            $data['error'] = \Yii::t('app', "No Data Posted");
        }
        return $data;
    }

    /**
     *
     * @OA\Get(path="/user/logout",
     *   summary="Logout user [Token required]",
     *   tags={"User"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Response(
     *     response=200,
     *     description="Logout user from application",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionLogout()
    {
        $data = [];
        $this->setStatus(400);
        $user = \Yii::$app->user->identity;
        if (\Yii::$app->user->logout()) {
            $user->generateAuthKey();
            $user->updateAttributes([
                'activation_key'
            ]);
            AccessToken::deleteOldAppData($user->id);
            $this->setStatus(200);
            $data['message'] = \Yii::t('app', 'Logout successfully');
        }
        return $data;
    }

    /**
     *
     * @OA\Get(path="/user/get-page",
     *   summary="",
     *   tags={"User"},
     *
     *   @OA\Parameter(
     *     name="type_id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Returns newly created Plan info",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionGetPage($type_id)
    {
        $model = Page::findActive()->andWhere([
            'type_id' => $type_id,
            'state_id' => Page::STATE_ACTIVE
        ])->one();
        if ($model) {
            $this->setStatus(200);
            $data['message'] = \Yii::t('app', 'Data found successfully');
            $data['detail'] = $model;
        } else {
            $this->setStatus(400);
            $data['message'] = 'Page not found';
        }
        return $data;
    }

    /**
     *
     * @OA\Get(path="/user/delete-account",
     *   summary="User & provider delete account",
     *   tags={"User"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Response(
     *     response=200,
     *     description="Delete account for a particular user",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionDeleteAccount($page = null)
    {
        $data = [];
        $this->setStatus(400);
        $user = \Yii::$app->user->identity;
        if (! empty($user)) {
            $user->state_id = User::STATE_DELETED;
            $user->updateAttributes([
                'state_id'
            ]);
            $user->generateAuthKey();
            $user->updateAttributes([
                'activation_key'
            ]);
            AccessToken::deleteOldAppData($user->id);
            $this->setStatus(200);
            $data['message'] = \Yii::t('app', 'Account Deleted Successfully');
        } else {
            $data['message'] = \Yii::t('app', 'User Not Found');
        }

        return $data;
    }

    /**
     *
     * @OA\Post(path="/user/change-password",
     *   summary="change-password",
     *   tags={"User"},
     *   @OA\Parameter(
     *     name="access-token",
     *     in="query",
     *     @OA\Schema(
     *       type="string"
     *
     *     )
     *   ),
     *   @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *              required={"User[password]"},
     *              @OA\Property(property="User[password]", type="string", format="password", example="admin@123",description="Password"),
     *              @OA\Property(property="User[confirm_password]", type="string", format="password", example="admin@123",description="Confirm Password"),
     *           ),
     *       ),
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Changes the password of user",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionChangePassword()
    {
        $data = [];
        $this->setStatus(400);
        $model = \Yii::$app->user->identity;
        $newModel = new User([
            'scenario' => 'changepassword'
        ]);
        if ($newModel->load(Yii::$app->request->post())) {

            if ($newModel->password == $newModel->confirm_password) {
                $model->setPassword($newModel->password);
                $model->generateAuthKey();
                if ($model->updateAttributes([
                    'password'
                ])) {
                    $this->setStatus(200);
                    $data['message'] = \Yii::t('app', 'Password Changed Successfully');
                } else {
                    $data['message'] = $model->getErrors();
                }
            } else {
                $data['message'] = \Yii::t('app', 'Passwords do not match ');
            }
        }
        return $data;
    }

    /**
     *
     *  @OA\Post(path="/user/profile-setup",
     *   summary="Profile Setup",
     *   tags={"User"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *              required={},
     *              @OA\Property(property="User[first_name]",type="string", example="",description="First Name"),
     *              @OA\Property(property="User[last_name]",type="string", example="",description="Last Name"),
     *              @OA\Property(property="User[email]", type="email", example="",description="Email"),
     *              @OA\Property(property="User[address]", type="email", example="",description="Address"),
     *              @OA\Property(property="User[country_code]", type="integer", example="",description="country code"),
     *              @OA\Property(property="User[contact_no]", type="integer", example="",description="contact number"),
     *              @OA\Property(property="User[gender]", type="integer" ,example="", description="Gender"),
     *              @OA\Property(property="User[latitude]", type="integer" ,example="", description="latitude"),
     *              @OA\Property(property="User[longitude]", type="integer" ,example="", description="longitude"),
     *              @OA\Property(property="User[blood_group]",type="string", example="",description="blood_group"),
     *              @OA\Property(property="User[location]",type="string", example="",description="location"),
     *              @OA\Property(property="User[weight]", type="integer" ,example="", description="weight"),
     *              @OA\Property(property="User[date_of_birth]", type="string", format="date", example="", description="Date of Birth (YYYY-MM-DD)"),
     *              @OA\Property(property="User[country]", type="integer", example="",description="country"),
     *              @OA\Property(property="User[profile_file]", type="file", format="", example="",description="Select profile image")
     *
     *           ),
     *       ),
     *   ),
     * @OA\Response(
     *     response=200,
     *     description="Profile Detail Update",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionProfileSetup()
    {
        $data = [];
        $this->setStatus(400);
        $model = \Yii::$app->user->identity;
        $id = \Yii::$app->user->identity->id;

        $first_name = $model->first_name;
        $last_name = $model->last_name;
        $email = $model->email;
        $address = $model->address;
        $country_code = $model->country_code;
        $contact_no = $model->contact_no;
        $gender = $model->gender;
        $date_of_birth = $model->date_of_birth;
        $country = $model->country;
        $location = $model->location;
        $blood_group = $model->blood_group;
        $weight = $model->weight;
        $lat = $model->latitude;
        $long = $model->longitude;
        $old_profile = $model->profile_file;
        $model = $this->findModel($id);

        if ($model->load(\Yii::$app->request->post())) {

            $model->profile_file = $old_profile;

            $profile_file = UploadedFile::getInstance($model, 'profile_file');

            $file = File::add($model, $profile_file);
            if (! empty($file)) {
                $model->profile_file = $file->id;
            }

            if (empty($model->first_name)) {
                $model->first_name = $first_name;
            }
            if (empty($model->last_name)) {
                $model->last_name = $last_name;
            }
            if (empty($model->email)) {
                $model->email = $email;
            }
            if (empty($model->address)) {
                $model->address = $address;
            }
            if (empty($model->location)) {
                $model->location = $location;
            }
            if (empty($model->weight)) {
                $model->weight = $weight;
            }
            if (empty($model->blood_group)) {
                $model->blood_group = $blood_group;
            }
            if (empty($model->country_code)) {
                $model->country_code = $country_code;
            }
            if (empty($model->contact_no)) {
                $model->contact_no = $contact_no;
            }
            if (empty($model->gender)) {
                $model->gender = $gender;
            }
            if (empty($model->latitude)) {
                $model->latitude = $lat;
            }
            if (empty($model->longitude)) {
                $model->longitude = $long;
            }
            if (empty($model->date_of_birth)) {
                $model->date_of_birth = $date_of_birth;
            }
            if (empty($model->country)) {
                $model->country = $country;
            }

            $model->full_name = $model->getFullname();
            $model->is_profile_setup = User::STATE_ACTIVE;

            if ($model->save()) {
                $this->setStatus(200);
                $data['access-token'] = $model->activation_key;
                $data['message'] = \Yii::t('app', 'Profile Updated Successfully');
                $data['detail'] = $model->asJson();
            } else {
                $this->setStatus(400);
                $data['message'] = $model->getErrors();
            }
        } else {
            $data['message'] = \Yii::t('app', 'Data not posted');
        }
        return $data;
    }

    /**
     *
     * @OA\Post(path="/user/add-availability",
     *   tags={"Provider"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     * @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *              required={},
     *               @OA\Property(property="Availability[slots]", type="string", example="",description="slot"),
     *           ),
     *       ),
     *   ),
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns newly created support info",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionAddAvailability()
    {
        $this->setStatus(400);
        $data = [];
        $post = Yii::$app->request->post();
        $user = \Yii::$app->user->identity->id;

        $model = new Availability();

        // Load data into the model
        if (! $model->load($post)) {

            $data['message'] = \Yii::t('app', 'No Data Posted');
            return $data;
        }

        $slots = json_decode($model->slots, true);
        if ($slots === null) {
            $data['message'] = \Yii::t('app', 'Invalid JSON data');
            return $data;
        }
        if (! is_array($slots)) {
            $data['message'] = \Yii::t('app', 'Slots data is not an array');
            return $data;
        }

        // Check for duplicate dayId in the input data
        $dayIdCounts = [];
        foreach ($slots as $slot) {
            if (! is_array($slot) || ! isset($slot['dayId'], $slot['startTime'], $slot['endTime'])) {
                $data['message'] = \Yii::t('app', 'Invalid slot data in JSON array');
                return $data;
            }

            $dayId = $slot['dayId'];
            if (isset($dayIdCounts[$dayId])) {
                $data['message'] = \Yii::t('app', 'Duplicate dayId detected in the input data.');
                return $data;
            }
            $dayIdCounts[$dayId] = true;
        }

        // Delete existing availability for this provider
        Availability::deleteAll([
            'created_by_id' => $user,
            'state_id' => User::STATE_ACTIVE
        ]);

        // Add new slots
        foreach ($slots as $slot) {
            $availability = new Availability();
            $availability->provider_id = $user; // Assuming this should be dynamic based on the context
            $availability->day_id = $slot['dayId'];
            $availability->start_time = $slot['startTime'];
            $availability->end_time = $slot['endTime'];
            $availability->state_id = Availability::STATE_ACTIVE;

            if (! $availability->save()) {
                $data['message'] = $availability->getErrorsString();
                return $data;
            }
        }

        $this->setStatus(200);
        $data['message'] = "Availability added successfully";

        return $data;
    }

    /**
     *
     * @OA\Post(path="/user/add-unavailability",
     *   tags={"Provider"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     * @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *              required={},
     *               @OA\Property(property="Availability[type_id]", type="integer", example="",description="Unavailability Type"),
     *               @OA\Property(property="Availability[day_id]", type="integer", example="",description="Unavailability day"),
     *               @OA\Property(property="Availability[date]", type="string", example="",description="Date"),
     *               @OA\Property(property="Availability[slots]", type="string", example="",description="slot")
     *           ),
     *       ),
     *   ),
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns newly created support info",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionAddUnavailability()
    {
        $this->setStatus(400);
        $data = [];
        $model = new Availability();
        $user = \Yii::$app->user->identity->id;
        $post = Yii::$app->request->post();

        if ($model->load($post)) {
            $slots = json_decode($model->slots, true);
            if (empty($slots) || ! is_array($slots)) {
                return [
                    'message' => "Invalid Slot"
                ];
            }

            foreach ($slots as $slot) {
                $availability = new Availability();
                $availability->provider_id = $user;
                $availability->type_id = $model->type_id;
                if ($model->type_id == Availability::DAY) {
                    $availability->day_id = $model->day_id;
                    $availability->date = $model->date;
                }
                if ($model->type_id == Availability::CHECK_DATE) {
                    $availability->date = $model->date;
                    $availability->day_id = $model->day_id;
                }
                $availability->start_time = $slot['startTime'];
                $availability->end_time = $slot['endTime'];
                $availability->state_id = Availability::STATE_UNAVAILABILITY;

                if ($availability->type_id == Availability::CHECK_DATE) {

                    $all_day_check = Availability::find()->where([
                        'provider_id' => $user,
                        'day_id' => $availability->day_id,
                        'type_id' => Availability::CHECK_DATE
                        // 'date' => $availability->date,
                    ])->exists();

                    if ($all_day_check) {

                        return [
                            'message' => "Unavailability already added for this date and time"
                        ];
                    }
                } else {

                    $all_day_check = Availability::find()->where([
                        'provider_id' => $user,
                        'day_id' => $availability->day_id,
                        'type_id' => Availability::CHECK_DATE
                        // 'date' => $availability->date,
                    ])->exists();

                    if ($all_day_check) {

                        return [
                            'message' => "Unavailability already added for this date and time"
                        ];
                    }
                    // Check for existing unavailability
                    $exists = Availability::find()->where([
                        'provider_id' => $user,
                        'day_id' => $availability->day_id,
                        // 'type_id' => Availability::CHECK_DATE,
                        'date' => $availability->date,
                        'start_time' => $availability->start_time,
                        'end_time' => $availability->end_time
                    ])->exists();

                    if ($exists) {
                        $this->setStatus(200);
                        return [
                            'message' => "Unavailability already added for this date and time"
                        ];
                    }
                }

                if (! $availability->save()) {
                    return [
                        'message' => $availability->getErrorsString()
                    ];
                }
            }
            $this->setStatus(200);
            $data['message'] = "Unavailability added successfully";
        } else {
            $this->setStatus(400);
            $data['message'] = \Yii::t('app', 'No Data Posted');
        }
        return $data;
    }

    /**
     *
     * @OA\Get(path="/user/availability-list",
     *   summary="",
     *   tags={"Provider"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Response(
     *     response=200,
     *     description="Return list of all the users",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionAvailabilityList($page = 0)
    {
        $this->setStatus(400);
        $query = Availability::findActive()->andWhere([
            "type_id" => User::STATE_INACTIVE
        ])->my();
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ],
            'sort' => [
                'defaultOrder' => [
                    'day_id' => SORT_ASC
                ]
            ]
        ]);
        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     *
     * @OA\Get(path="/user/un-availability-list",
     *   summary="",
     *   tags={"Provider"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Response(
     *     response=200,
     *     description="Return list of all the users",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionUnAvailabilityList($page = 0)
    {
        $this->setStatus(400);

        // Fetch data from the database
        $query = Availability::find()->where([
            'state_id' => Availability::STATE_UNAVAILABILITY
        ])
            ->groupBy('day_id')
            ->my()
            ->distinct();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ],
            'sort' => [
                'defaultOrder' => [
                    'day_id' => SORT_ASC
                ]
            ]
        ]);

        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     *
     * @OA\Get(path="/user/delete-un-availability",
     *   summary="",
     *   tags={"Provider"},
     *    security={
     *   {"bearerAuth": {}}
     *   },
     *     @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Returns success message",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionDeleteUnAvailability($id)
    {
        $data = [];
        $userId = \Yii::$app->user->identity->id;

        // Delete records matching the criteria
        $deletedCount = Availability::deleteAll([
            'created_by_id' => $userId,
            'day_id' => $id,
            'state_id' => Availability::STATE_UNAVAILABILITY
        ]);

        if ($deletedCount > 0) {
            $this->setStatus(200);
            $data['message'] = \Yii::t('app', 'Un-availability Deleted Successfully!');
        } else {
            $this->setStatus(400);
            $data['message'] = \Yii::t('app', 'No records found or deleted.');
        }

        return $data;
    }

    /**
     *
     * @OA\Post(path="/user/update-availability",
     *   summary="Update availability",
     *   tags={"Provider"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *              required={},
     *               @OA\Property(property="Availability[id]", type="integer", example="2",description="Id"),
     *               @OA\Property(property="Availability[slots]", type="string", example="",description="slot"),
     *           ),
     *       ),
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Availability updated successfully",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionUpdateAvailability()
    {
        $data = [];
        $this->setStatus(400);

        $post = \Yii::$app->request->post();
        $availabilityId = $post['Availability']['id'];

        $availabilityModel = Availability::findOne($availabilityId);

        if (! $availabilityModel) {
            $data['message'] = \Yii::t('app', "Availability not found.");
            return $data;
        }
        $slots = json_decode($post['Availability']['slots'], true);
        $startTime = $slots[0]['startTime'];
        $endTime = $slots[0]['endTime'];
        $dayId = $slots[0]['dayId'];
        $availabilityModel->start_time = $startTime;
        $availabilityModel->end_time = $endTime;
        $availabilityModel->day_id = $dayId;
        if (! $availabilityModel->save()) {
            $data['message'] = \Yii::t('app', "Failed to update availability.");
            $data['error'] = $availabilityModel->getErrors();
        } else {
            $this->setStatus(200);
            $data['message'] = \Yii::t('app', "Availability Updated Successfully");
        }

        return $data;
    }

    /**
     * Service Detail
     *
     * @OA\Get(path="/user/get-provider-slot",
     *   summary="",
     *   tags={"Provider"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="day_id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Parameter(
     *     name="provider_id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Provider detail",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionGetProviderSlot($day_id, $provider_id)
    {
        $data = [];

        $availabilityQuery = Availability::find()->where([
            'provider_id' => $provider_id,
            'day_id' => $day_id
        ]);
        $list = [];

        foreach ($availabilityQuery->each() as $availability) {
            $dateStart = date('Y-m-d', strtotime(date('Y-m-d')));

            $availability_start_one = $dateStart . ' ' . date('H:i:s', strtotime($availability->start_time));
            $availability_end_one = $dateStart . ' ' . date('H:i:s', strtotime($availability->end_time));
            $start = new \DateTime($availability_start_one);
            $end = new \DateTime($availability_end_one);

            while ($start->getTimestamp() < $end->getTimestamp()) {

                $startTime = $start->format('Y-m-d H:i:s');
                $endTime = date('Y-m-d H:i:s', strtotime($startTime . "+ 60 minutes"));
                // if ($startTime >= $availability->start_time && $endTime <= $availability->end_time) {

                $list[] = [
                    'start_time' => $startTime,
                    'end_time' => $endTime,
                    'day_id' => $day_id
                    // 'type_id' => Availability::checkSlotAvailability($startTime, $endTime, $provider_id)
                ];
                // }

                $start->add(\DateInterval::createFromDateString('60 minutes'));
            }
        }
        usort($list, function ($a, $b) {

            return strtotime($a['start_time']) - strtotime($b['start_time']);
        });

        $data['list'] = $list;
        return $data;
    }

    /**
     * Service Detail
     *
     * @OA\Get(path="/user/service-slot",
     *   summary="",
     *   tags={"Provider"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="day_id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Parameter(
     *     name="provider_id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Parameter(
     *     name="date",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Service detail",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionServiceSlot($day_id, $provider_id, $date)
    {
        $data = [];

        if (empty($date)) {
            $date = date('Y-m-d');
        }

        $date = date('Y-m-d', strtotime($date));

        // Fetch availability where provider is available (state_id = 1)
        $availabilityQuery = Availability::find()->where([
            'provider_id' => $provider_id,
            'day_id' => $day_id,
            'state_id' => Availability::STATE_ACTIVE
        ]);

        // Fetch unavailability where provider is not available (state_id = 2)
        $unavailabilityQuery = Availability::find()->where([
            'provider_id' => $provider_id,
            'day_id' => $day_id,
            'state_id' => Availability::STATE_UNAVAILABILITY
        ]);

        $list = [];
        $unavailablePeriods = [];

        // Get unavailability
        foreach ($unavailabilityQuery->each() as $unavailability) {
            $dateStart = date('Y-m-d', strtotime($date));
            $unavailable_start = $dateStart . ' ' . date('H:i:s', strtotime($unavailability->start_time ?: '00:00:00'));
            $unavailable_end = $dateStart . ' ' . date('H:i:s', strtotime($unavailability->end_time ?: '23:59:59'));
            $unavailablePeriods[] = [
                'start_time' => new \DateTime($unavailable_start),
                'end_time' => new \DateTime($unavailable_end)
            ];
        }

        // Process availability and slot creation
        foreach ($availabilityQuery->each() as $availability) {
            $dateStart = date('Y-m-d', strtotime($date));
            $availability_start_one = $dateStart . ' ' . date('H:i:s', strtotime($availability->start_time ?: '00:00:00'));
            $availability_end_one = $dateStart . ' ' . date('H:i:s', strtotime($availability->end_time ?: '23:59:59'));
            $start = new \DateTime($availability_start_one);
            $end = new \DateTime($availability_end_one);

            while ($start->getTimestamp() < $end->getTimestamp()) {
                $current_time = date('Y-m-d H:i:s');

                $slotStartTime = $start->format('Y-m-d H:i:s');
                $slotEndTime = date('Y-m-d H:i:s', strtotime($slotStartTime . "+ 60 minutes"));
                $slotStart = new \DateTime($slotStartTime);
                $slotEnd = new \DateTime($slotEndTime);

                // Check if the slot falls within any unavailability period
                $slotIsAvailable = true;
                foreach ($unavailablePeriods as $period) {
                    if (($slotStart < $period['end_time'] && $slotEnd > $period['start_time'])) {
                        $slotIsAvailable = false;
                        break;
                    }
                }

                if ($slotIsAvailable && strtotime($slotStartTime) >= strtotime($current_time) && strtotime($slotEndTime) <= strtotime($dateStart . ' ' . $availability->end_time)) {
                    $list[] = [
                        'start_time' => $slotStartTime,
                        'end_time' => $slotEndTime,
                        'day_id' => $day_id,
                        'type_id' => Availability::checkSlotAvailability($slotStartTime, $slotEndTime, $provider_id, $date)
                    ];
                }

                $start->add(\DateInterval::createFromDateString('60 minutes'));
            }
        }

        usort($list, function ($a, $b) {
            return strtotime($a['start_time']) - strtotime($b['start_time']);
        });

        $data['list'] = $list;

        return $data;
    }

    /**
     *
     * @OA\Get(path="/user/provider-search",
     *   summary="",
     *   tags={"Provider"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *    @OA\Parameter(
     *     name="search",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *    @OA\Parameter(
     *     name="type_id",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Return list of all the users",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionProviderSearch($search = null, $type_id = null, $page = 0)
    {
        $query = User::findActive()->alias('u')
            ->joinWith('providerDetail.providerService.serviceName as sn')
            ->joinWith('providerDetail as c')
            ->where([
            'u.role_id' => User::ROLE_PROVIDER,
            'is_approved' => User::IS_APPROVED
        ]);

        $states = [
            User::STATE_DELETED,
            User::STATE_BANNED,
            User::STATE_INACTIVE
        ];
        $query->andWhere([
            'not in',
            'u.state_id',
            $states
        ]);
        if (! empty($search)) {
            $query->andWhere([
                'or',
                [
                    'like',
                    'u.full_name',
                    $search
                ],
                [
                    'like',
                    'sn.title',
                    $search
                ]
            ]);
        }

        if (! empty($type_id)) {
            $query->andWhere([
                'c.profession' => $type_id
            ]);
        }

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ],
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ]
        ]);

        $this->setStatus(200);

        return $dataProvider;
    }

    /**
     *
     * @OA\Get(path="/user/search-list",
     *   summary="",
     *   tags={"Provider"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Response(
     *     response=200,
     *     description="Return list of all the users search",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionSearchList($page = 0)
    {
        $this->setStatus(400);
        $query = SearchUser::findActive()->my();
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 10,
                'page' => $page
            ],
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ]
        ]);
        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     * Service Detail
     *
     * @OA\Get(path="/user/search-delete",
     *   summary="",
     *   tags={"Provider"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Delete a user search data",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionSearchDelete($id)
    {
        $data = [];
        $searchUser = SearchUser::findOne($id);

        if ($searchUser) {
            $searchUser->delete();
            $this->setStatus(200);
            $data['message'] = \Yii::t('app', "Recent search deleted successfully.");
            return $data;
        }

        $data['message'] = \Yii::t('app', "Recent search not found.");
        return $data;
    }

    /**
     *
     * @OA\Get(path="/user/service-provider-detail",
     *   summary="",
     *   tags={"Service"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="provider_id",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="get the details of services",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     *
     *
     */
    public function actionServiceProviderDetail($provider_id = null, $page = 0)
    {
        // Initialize query
        $query = User::findActive();
        if (! empty($provider_id)) {
            $query = $query->andWhere([
                'id' => $provider_id
            ]);
        }

        // Create data provider
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 20,
                'page' => (int) $page // Ensure page is cast to integer
            ]
        ]);

        // Set status code after successful data provider creation
        $this->setStatus(200);

        return $dataProvider;
    }

    /**
     * Service Detail
     *
     * @OA\Get(path="/user/service-detail",
     *   summary="Get service detail",
     *   tags={"Service"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Service detail",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionServiceDetail($id)
    {
        $data = [];
        $model = User::findOne($id);
        if (! empty($model)) {
            $data['detail'] = $model->asJson();
        } else {
            $this->setStatus(400);
            $data['message'] = \Yii::t('app', "Service not found.");
        }

        return $data;
    }

    /**
     *
     * @OA\Get(path="/user/notification",
     *   summary="Notification On/Off",
     *   tags={"Notification"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Response(
     *     response=200,
     *     description="Switch the Notification On and Off",
     *     @OA\MediaType(
     *         mediaType="application/json"
     *     ),
     *   ),
     * )
     */
    public function actionNotification()
    {
        $data = [];
        $this->setStatus(200);
        $model = \Yii::$app->user->identity;
        if ($model->is_notify == User::NOTIFICATION_OFF) {
            $model->is_notify = User::NOTIFICATION_ON;
            $data['message'] = \Yii::t('app', 'Notification Turned ON');
        } else {
            $model->is_notify = User::NOTIFICATION_OFF;
            $data['message'] = \Yii::t('app', 'Notification Turned OFF');
        }
        $model->updateAttributes([
            'is_notify'
        ]);
        $this->setStatus(200);
        $data['detail'] = $model->asJson();
        return $data;
    }

    /**
     *
     * @OA\Get(path="/user/notification-list",
     *   summary="Notification List",
     *   tags={"Notification"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Notification list",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionNotificationList($page = null)
    {
        $query = Notification::find()->my('to_user_id')->andWhere([
            '!=',
            'model_type',
            Chat::class
        ]);
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 100,
                'page' => $page
            ]
        ]);
        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     *
     * @OA\Get(path="/user/notification-detail",
     *   summary="Notification Deatil",
     *   tags={"Notification"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Notification detail",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionNotificationDetail($id)
    {
        $this->setStatus(400);
        $data = [];
        $model = Notification::findOne($id);
        if (! empty($model)) {
            if ($model->is_read == Notification::IS_NOT_READ) {
                $model->is_read = Notification::IS_READ;
                $model->updateAttributes([
                    'is_read'
                ]);
            }
            $this->setStatus(200);
            $data['detail'] = $model->asJson();
        } else {
            $data['message'] = \Yii::t('app', 'Notification Not Found');
        }
        return $data;
    }

    /**
     *
     * @OA\Get(path="/user/clear-notification",
     *   summary="Notification Clear",
     *   tags={"Notification"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Response(
     *     response=200,
     *     description="Clear Notifications",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionClearNotification()
    {
        $data = [];
        Notification::deleteAll([
            'to_user_id' => \Yii::$app->user->id
        ]);
        $this->setStatus(200);
        $data['message'] = \Yii::t('app', 'Notification cleared!!');
        return $data;
    }

    /**
     *
     * @OA\Post(path="/user/provider-profile-update",
     *   summary="Provider's profile setup api",
     *   tags={"User"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *
     * @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *              required={},
     *              @OA\Property(property="User[first_name]", type="string", example="",description="first_name"),
     *              @OA\Property(property="User[last_name]", type="string", example="",description="last_name"),
     *              @OA\Property(property="User[email]", type="string", example="",description="email"),
     *              @OA\Property(property="User[longitude]", type="integer", example="",description="Longitude"),
     *              @OA\Property(property="User[latitude]", type="integer", example="",description="Latitude"),
     *              @OA\Property(property="User[contact_no]", type="integer", example="",description="contact_no"),
     *              @OA\Property(property="User[country_code]", type="integer", example="",description="country_code"),
     *              @OA\Property(property="User[location]", type="string", example="chd",description="Location"),
     *              @OA\Property(property="User[about_me]", type="string", example="",description="Bio"),
     *              @OA\Property(property="User[profile_file]", type="file", format="", example="",description="Select profile image"),
     *              @OA\Property(property="Provider[profession]", type="string", example="",description="profession"),
     *              @OA\Property(property="Provider[degree]", type="string", example="",description="degree"),
     *              @OA\Property(property="Provider[identity_id]", type="string", example="",description="string"),
     *              @OA\Property(property="Provider[specilization]", type="string", example="",description="Experience"),
     *              @OA\Property(property="Provider[professional_classification_no]", type="string", example="",description="professional_classification_no"),
     *              @OA\Property(property="ServiceDetail[json_data]", type="string", example="",description=""),
     *              @OA\Property(property="ServiceDetail[rates]", type="string", example="",description="rates"),
     *              @OA\Property(property="Add multiple images",property="File[iqama][]",type="array", @OA\Items(type="file",format="binary")),
     *              @OA\Property(property="Add multiple images",property="File[bls_license][]",type="array", @OA\Items(type="file",format="binary")),
     *              @OA\Property(property="Add multiple images",property="File[medical_insurance][]",type="array", @OA\Items(type="file",format="binary")),
     *              @OA\Property(property="Add multiple images",property="File[professional_qualification][]",type="array", @OA\Items(type="file",format="binary")),
     *
     *           ),
     *       ),
     *   ),
     * @OA\Response(
     *     response=200,
     *     description="Profile Detail Update",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionProviderProfileUpdate()
    {
        $data = [];
        $this->setStatus(400);
        $fileModel = new File();
        $user = \Yii::$app->user->identity;
        $detail = Provider::find()->my()->one();
        if (empty($detail)) {
            $detail = new Provider();
        }
        $service_detail = ServiceDetail::find()->my()->one();
        if (empty($service_detail)) {
            $service_detail = new ServiceDetail();
        }
        $post = \Yii::$app->request->post();

        $user->scenario = 'user-update';

        $old_profile = $user->profile_file;

        if ($user->load($post)) {

            $user->profile_file = $old_profile;

            $profile_file = UploadedFile::getInstance($user, 'profile_file');

            $file = File::add($user, $profile_file);
            if (! empty($file)) {
                $user->profile_file = $file->id;
            }

            if ($detail->load($post)) {

                if ($service_detail->load($post)) {

                    $jsonData = json_decode($service_detail->json_data, true);

                    if ($jsonData === null) {
                        $data['message'] = \Yii::t('app', 'Invalid JSON data');
                        return $data;
                    }

                    // Check if $jsonData is an array before iterating over it
                    if (! is_array($jsonData)) {
                        $data['message'] = \Yii::t('app', 'JSON data is not an array');
                        return $data;
                    }

                    // Collect all service_ids from the JSON data
                    $incomingServiceIds = [];
                    foreach ($jsonData as $item) {
                        if (! is_array($item) || ! isset($item['service_id'])) {
                            $data['message'] = \Yii::t('app', 'Invalid service data in JSON array');
                            return $data;
                        }

                        $incomingServiceIds[] = $item['service_id'];
                    }

                    // Check for duplicates within incoming data
                    if (count($incomingServiceIds) !== count(array_unique($incomingServiceIds))) {
                        $data['message'] = \Yii::t('app', 'Duplicate service_id found in the provided data');
                        return $data;
                    }

                    // Load existing service details for the current user
                    $existingServices = ServiceDetail::find()->where([
                        'created_by_id' => $user->id
                    ])
                        ->indexBy('service_id')
                        ->all();

                    // Determine service_ids to delete
                    $existingServiceIds = array_keys($existingServices);
                    $serviceIdsToDelete = array_diff($existingServiceIds, $incomingServiceIds);
                    $serviceIdsToAdd = array_diff($incomingServiceIds, $existingServiceIds);

                    // Delete services that are no longer in the incoming data
                    foreach ($serviceIdsToDelete as $serviceId) {
                        $serviceModel = $existingServices[$serviceId];
                        if (! $serviceModel->delete()) {
                            $data['message'] = \Yii::t('app', 'Failed to delete service_id: ' . $serviceId);
                            return $data;
                        }
                    }

                    // Add new services
                    foreach ($jsonData as $item) {
                        $serviceId = $item['service_id'];

                        if (in_array($serviceId, $serviceIdsToAdd)) {
                            // Create new service
                            $serviceModel = new ServiceDetail();
                            $serviceModel->service_id = $serviceId;
                            $serviceModel->state_id = ServiceDetail::STATE_ACTIVE;
                            $serviceModel->rates = $item['rates'] ?? $service_detail->rates;
                            $serviceModel->created_by_id = $user->id;
                        } else {
                            // Update existing service
                            $serviceModel = $existingServices[$serviceId];
                            $serviceModel->state_id = ServiceDetail::STATE_ACTIVE;
                            $serviceModel->rates = $item['rates'] ?? $service_detail->rates;
                        }

                        if (! $serviceModel->save()) {
                            $data['message'] = $serviceModel->getErrors();
                            return $data;
                        }
                    }
                    // Update full name
                    $user->full_name = $user->getFullname();
                    $user->is_profile_setup = User::STATE_ACTIVE;
                    $user->is_approved = User::STATE_INACTIVE;

                    if ($user->save()) {
                        if ($detail->save()) {

                            // iqama_image

                            $certficate_file = UploadedFile::getInstances($fileModel, 'iqama');

                            if (! empty($certficate_file)) {

                                File::deleteRelatedAll([
                                    'created_by_id' => $user->id,
                                    'model_type' => Provider::class,
                                    'type_id' => FILE::TYPE_IQAMA
                                ]);

                                if (! empty($_FILES)) {
                                    foreach ($certficate_file as $file) {
                                        File::add($detail, $file, null, File::TYPE_IQAMA);
                                    }
                                }
                            }

                            // bls_license

                            $upload_file = UploadedFile::getInstances($fileModel, 'bls_license');
                            if (! empty($upload_file)) {

                                File::deleteRelatedAll([
                                    'created_by_id' => $user->id,
                                    'model_type' => Provider::class,
                                    'type_id' => FILE::TYPE_BLS_LICENSE
                                ]);

                                if (! empty($_FILES)) {
                                    foreach ($upload_file as $file) {
                                        File::add($detail, $file, null, FILE::TYPE_BLS_LICENSE);
                                    }
                                }
                            }

                            // medical_insurance

                            $upload_front_image = UploadedFile::getInstances($fileModel, 'medical_insurance');
                            if (! empty($upload_front_image)) {

                                File::deleteRelatedAll([
                                    'created_by_id' => $user->id,
                                    'model_type' => Provider::class,
                                    'type_id' => FILE::TYPE_MEDICAL_INSURANCE
                                ]);

                                if (! empty($_FILES)) {
                                    foreach ($upload_front_image as $file) {
                                        File::add($detail, $file, null, FILE::TYPE_MEDICAL_INSURANCE);
                                    }
                                }
                            }

                            // professional_qualification

                            $upload_test_image = UploadedFile::getInstances($fileModel, 'professional_qualification');
                            if (! empty($upload_test_image)) {

                                File::deleteRelatedAll([
                                    'created_by_id' => $user->id,
                                    'model_type' => Provider::class,
                                    'type_id' => FILE::TYPE_PROFESSIONAL_QUALIFICATION
                                ]);

                                if (! empty($_FILES)) {
                                    foreach ($upload_test_image as $file) {
                                        File::add($detail, $file, null, FILE::TYPE_PROFESSIONAL_QUALIFICATION);
                                    }
                                }
                            }
                            $this->setStatus(200);
                            $data['detail'] = $user->asJson();
                            $data['message'] = \Yii::t('app', 'Profile Setup Successfully');
                        } else {
                            $data['message'] = $detail->getErrors();
                        }
                    } else {
                        $data['message'] = $user->getErrors();
                    }
                } else {
                    $data['message'] = \Yii::t('app', 'Data Not Posted');
                }
            } else {
                $data['message'] = \Yii::t('app', 'Data Not Posted');
            }
        } else {
            $data['message'] = \Yii::t('app', 'DetailModel Not Posted');
        }
        return $data;
    }

    /**
     *
     * @OA\Get(path="/user/delete-image",
     *   summary="",
     *   tags={"User"},
     *    security={
     *   {"bearerAuth": {}}
     *   },
     *     @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Returns success message",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionDeleteImage($id)
    {
        $data = [];
        $model = File::findOne($id);

        if (! empty($model)) {
            $model->delete();
            $this->setStatus(200);
            $data['message'] = \Yii::t('app', 'Image Deleted Successfully!');
        } else {
            $this->setStatus(400);
            $data['message'] = \Yii::t('app', 'Page not found');
        }
        return $data;
    }

    /**
     *
     * Get Qualifications which are added by admin accourding to profession
     *
     * @OA\Get(path="/user/degree",
     *   summary="Qualification list from panel",
     *   tags={"User"},
     *    @OA\Parameter(
     *     name="type_id",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *
     *   @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Get the list of Qualifications",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionDegree($type_id = null, $page = null)
    {
        $query = Qualification::findActive();
        if (! empty($type_id)) {
            $query = $query->andWhere([
                'type_id' => $type_id
            ]);
        }
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => false
        ]);
        $this->setStatus(200);

        return $dataProvider;
    }

    /**
     *
     * @OA\Post(path="/user/add-bank-details",
     *   summary="Add Bank Details",
     *   tags={"Bank"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     * @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *              required={},
     *              @OA\Property(property="BankDetail[acc_holder_name]", type="string", example="",description="acc_holder_name"),
     *              @OA\Property(property="BankDetail[account_no]", type="string", example="",description="account_no"),
     *              @OA\Property(property="BankDetail[iban_no]", type="string", example="",description="iban_no"),
     *
     *
     *           ),
     *       ),
     *   ),
     *
     *   @OA\Response(
     *     response=200,
     *     description="Add Bank Details",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionAddBankDetails()
    {
        $data = [];
        $this->setStatus(400);
        $user = \Yii::$app->user->identity->id;
        $model = new BankDetail();
        $post = \Yii::$app->request->post();

        if ($model->load($post)) {
            $model->state_id = BankDetail::STATE_ACTIVE;

            if (BankDetail::find()->where([
                'account_no' => $model->account_no,
                'created_by_id' => $user
            ])->exists()) {
                $data['message'] = \Yii::t('app', 'Account number already exists.');
                return $data;
            }

            // Save the model if validation passed
            if ($model->save()) {
                $this->setStatus(200);
                $data['message'] = \Yii::t('app', 'Bank details added successfully');
            } else {
                $data['error'] = $model->getErrorsString();
            }
        } else {
            $data['message'] = \Yii::t('app', 'Data not posted.');
        }

        return $data;
    }

    /**
     *
     * @OA\Post(path="/user/delete-bank",
     *   summary="",
     *   tags={"Bank"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     * @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Delete bank",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionDeleteBank($id)
    {
        $data = [];
        $this->setStatus(400);
        $model = BankDetail::findOne($id);
        if (! empty($model)) {
            $model->delete();
            $this->setStatus(200);
            $data['message'] = \Yii::t('app', 'Bank deleted successfully.');
        } else {
            $data['message'] = \Yii::t('app', 'Bank not found!');
        }
        return $data;
    }

    /**
     *
     * @OA\Get(path="/user/bank-list",
     *   summary="Bank List",
     *   tags={"Bank"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Notification list",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionBankList($page = null)
    {
        $query = BankDetail::findActive()->my();
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 100,
                'page' => $page
            ]
        ]);
        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     * Bank Detail
     *
     * @OA\Get(path="/user/bank-details",
     *   summary="",
     *   tags={"Bank"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Bank detail",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionBankDetails($id)
    {
        $data = [];
        $model = BankDetail::findOne($id);
        if (! empty($model)) {
            $data['detail'] = $model->asJson();
        } else {
            $this->setStatus(400);
            $data['message'] = User::getMessage("Bank not found.");
        }
        return $data;
    }

    /**
     *
     * @OA\Post(path="/user/update-bank",
     *   summary="Update bank",
     *   security={
     *     {"bearerAuth": {}}
     *   },
     *   tags={"Bank"},
     *   @OA\Parameter(
     *     name="id",
     *     in="query",
     *     description="Bank ID",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *
     *     )
     *   ),
     *   @OA\RequestBody(
     *     @OA\MediaType(
     *       mediaType="multipart/form-data",
     *       @OA\Schema(
     *         required={},
     *          @OA\Property(property="BankDetail[acc_holder_name]", type="string", example="",description="acc_holder_name"),
     *          @OA\Property(property="BankDetail[account_no]", type="string", example="",description="account_no"),
     *          @OA\Property(property="BankDetail[iban_no]", type="string", example="",description="iban_no"),
     *       ),
     *     ),
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Update bank",
     *     @OA\MediaType(
     *       mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionUpdateBank($id)
    {
        $this->setStatus(400);
        $data = [];
        $model = BankDetail::findOne($id);

        if (! $model) {
            $data['message'] = \Yii::t('app', 'Bank not found');
            return $data;
        }

        $post = \Yii::$app->request->post();
        if ($model->load($post)) {

            if ($model->save()) {

                $this->setStatus(200);
                $data['message'] = \Yii::t('app', "Bank updated successfully.");
                $data['detail'] = $model->asjson();
            } else {
                $data['message'] = \Yii::t('app', 'Failed to update bank.');
            }
        } else {
            $data['message'] = \Yii::t('app', 'No data posted');
        }

        return $data;
    }

    /**
     *
     * @OA\Get(path="/user/add-recent-search",
     *   summary="",
     *   tags={"Provider"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="search",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Bank detail",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionAddRecentSearch($search, $id)
    {
        $this->setStatus(400);
        $data = [];
        $searchUser = SearchUser::find()->where([
            'title' => $search,
            'provider_search_id' => $id
        ])->one();

        if (! empty($searchUser)) {
            $searchUser->delete();
        }

        $searchUser = new SearchUser();
        $searchUser->state_id = SearchUser::STATE_ACTIVE;
        $searchUser->title = $search;
        $searchUser->provider_search_id = $id;
        $searchUser->save();

        $this->setStatus(200);
        $data['message'] = \Yii::t('app', "Recent search added successfully.");

        return $data;
    }

    /**
     *
     * @OA\Post(path="/user/update-user-location",
     *   summary="update location",
     *   tags={"User"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *              @OA\Property(
     *              property="User[latitude]",
     *              type="number", format="number",
     *              example="",
     *              description="Enter latitude"
     *              ),
     *              @OA\Property(
     *              property="User[longitude]",
     *              type="number", format="number",
     *              example="",
     *              description="Enter longitude"
     *              ),
     *              @OA\Property(
     *              property="User[location]",
     *              type="", format="string",
     *              example="",
     *              description="Enter location"
     *              ),
     *           ),
     *       ),
     *   ),
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns newly created user info",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionUpdateUserLocation()
    {
        $data = [];
        $model = \Yii::$app->user->identity;
        $post = Yii::$app->request->post();
        if ($model->load($post)) {
            if (! empty($model->latitude) && ! empty($model->longitude) && ! empty($model->location)) {
                if ($model->save()) {
                    $this->setStatus(200);
                    $data['access-token'] = $model->getAuthKey();
                    $data['message'] = \Yii::t('app', "Location updated successfully");
                    $data['detail'] = $model->asjson();
                } else {
                    $data['error'] = $model->getErrors();
                }
            } else {
                $data['message'] = \Yii::t('app', 'No Data Posted');
            }
        } else {
            $data['message'] = \Yii::t('app', 'Unable To Load Data');
        }
        return $data;
    }
}
