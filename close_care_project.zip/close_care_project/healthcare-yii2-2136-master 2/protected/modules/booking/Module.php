<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\booking;

use app\components\TController;
use app\components\TModule;
use app\models\User;
use app\components\filters\AccessControl;
use app\components\filters\AccessRule;

/**
 * booking module definition class
 */
class Module extends TModule
{

    const NAME = 'booking';

    public $controllerNamespace = 'app\modules\booking\controllers';

    // public $defaultRoute = 'booking';

    // public static function subNav()
    // {
    // return TController::addMenu(\Yii::t('app', 'Bookings'), '#', 'list ', Module::isAdmin(), [
    // // TController::addMenu(\Yii::t('app', 'Home'), '//booking', 'lock', Module::isAdmin()),
    // ]);
    // }
    public static function subNav()
    {
        return TController::addMenu(\Yii::t('app', 'Booking'), '#', 'list ', Module::isAdmin(), [
            TController::addMenu(\Yii::t('app', 'Bookings'), '//booking', 'list-alt', Module::isAdmin()),
            TController::addMenu(\Yii::t('app', 'Transaction'), '/payment/transaction', 'list-alt', Module::isAdmin())
        ]);
    }

    public static function dbFile()
    {
        return __DIR__ . '/db/install.sql';
    }

    public static function getRules()
    {
        return [
            'booking/update/<id:\d+>/<title>' => 'booking/booking/update',
            'booking/delete/<id:\d+>/<title>' => 'booking/booking/delete',

            'booking/update/<id:\d+>' => 'booking/booking/update',
            'booking/delete/<id:\d+>' => 'booking/booking/delete',

            'booking/view/<id:\d+>/<title>' => 'booking/booking/view',
            'booking/view/<id:\d+>' => 'booking/booking/view',

            'booking/<action>/view/<id:\d+>' => 'booking/<action>/view',
            'booking/index' => 'booking/booking/index',
            'booking/add' => 'booking/service/add',
            'booking' => 'booking/booking'
        ];
    }
}
