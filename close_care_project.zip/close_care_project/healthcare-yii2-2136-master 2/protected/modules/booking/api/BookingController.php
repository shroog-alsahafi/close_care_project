<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\booking\api;

use app\models\User;
use app\modules\api\components\ApiBaseController;
use app\modules\booking\models\Booking;
use app\modules\service\models\Service;
use yii\data\ActiveDataProvider;
use app\components\filters\AccessControl;
use app\components\filters\AccessRule;
use yii\web\UploadedFile;
use app\models\File;
use app\modules\booking\models\Report;
use app\modules\api\models\Rating;
use app\modules\payment\models\Transaction;
use app\modules\booking\models\Revenue;
use app\modules\notification\models\Notification;
use app\modules\payment\models\Gateway;
use function GuzzleHttp\json_decode;
use app\modules\payment\components\Paypal;
use Stripe\Refund;

/**
 * BookingController implements the API actions for Booking model.
 */
class BookingController extends ApiBaseController
{

    public $modelClass = "app\modules\booking\models\booking";

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [
                    [
                        'actions' => [
                            'list',
                            'add',
                            'pending-list',
                            'change-state',
                            'patient-info',
                            'patient-list',
                            'add-rating',
                            'report',
                            'rating-list',
                            'revenue',
                            'get-transaction',
                            'my-transaction',
                            'patient-booking',
                            'get-refund',
                            'transaction-list'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isUser() || User::isProvider();
                        }
                    ]
                ]
            ]
        ];
    }

    /**
     *
     * @OA\Get(path="/booking/list",
     *   summary="booking list",
     *   tags={"Booking"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *    @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *     @OA\Parameter(
     *     name="type",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns the list of booking",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionList($type, $page = 0)
    {
        $bookingQuery = Booking::find();

        if (User::isUser()) {
            $bookingQuery->my('created_by_id');
        } else {
            $bookingQuery->my('provider_id');
        }
        switch ($type) {
            case Booking::BOOKING_TYPE_TODAY:
                $bookingQuery = $bookingQuery->andWhere([
                    'and',
                    /* [
                        'date' => date('Y-m-d')
                    ], */
                    [
                        'in',
                        'state_id',
                        [
                            Booking::STATE_INPROGRESS,
                            Booking::STATE_ACCEPTED,
                            Booking::STATE_PENDING
                        ]
                    ]
                ]);

                break;

            case Booking::BOOKING_TYPE_ONLY_TODAY:
                $bookingQuery = $bookingQuery->andWhere([
                    'and',
                    [
                        'date' => date('Y-m-d')
                    ],
                    [
                        'in',
                        'state_id',
                        [
                            Booking::STATE_INPROGRESS,
                            Booking::STATE_ACCEPTED
                        ]
                    ]
                ]);

                break;
            // code block
            case Booking::BOOKING_TYPE_UPCOMING:
                // code block;
                $bookingQuery = $bookingQuery->andWhere([
                    'and',
                    [
                        '>',
                        'date',
                        date('Y-m-d')
                    ],
                    [
                        'in',
                        'state_id',
                        [
                            Booking::STATE_ACCEPTED
                        ]
                    ]
                ]);
                break;

            case Booking::BOOKING_TYPE_PAST:
                // code block
                $bookingQuery = $bookingQuery->andWhere([
                    'in',
                    'state_id',
                    [
                        Booking::STATE_REJECTED,
                        Booking::STATE_COMPLETED,
                        Booking::STATE_CANCELLED
                    ]
                ]);
                break;
            case Booking::BOOKING_TYPE_REST:
                // code block
                $bookingQuery = $bookingQuery->andWhere([
                    'in',
                    'state_id',
                    [
                        Booking::STATE_INPROGRESS,
                        Booking::STATE_ACCEPTED,
                        Booking::STATE_PENDING,
                        Booking::STATE_CANCELLED
                    ]
                ]);
                break;
            default:
            // code block
        }

        $dataProvider = new ActiveDataProvider([
            'query' => $bookingQuery,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ]
        ]);

        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     *
     * @OA\Post(path="/booking/add",
     *   summary="booking",
     *   tags={"Booking"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     * @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *              required={},
     *               @OA\Property(property="Booking[service_id]", type="integer", example="",description="Service Id"),
     *               @OA\Property(property="Booking[provider_id]", type="integer", example="",description="provider_id"),
     *               @OA\Property(property="Booking[price]", type="integer", example="",description="price"),
     *                @OA\Property(property="Booking[day_id]",type="integer", example="1",description=""),
     *                 @OA\Property(property="Booking[date]", type="string", example="",description="date"),
     *                 @OA\Property(property="Booking[start_time]", type="string", example="",description="start_time"),
     *                 @OA\Property(property="Booking[end_time]", type="string", example="",description="end_time"),
     *                 @OA\Property(property="Booking[total_price]", type="string", example="",description="total_price"),
     *
     *                 @OA\Property(property="File[key][]", type="array",description="Upload report",@OA\Items(type="file",format="binary")),
     *
     *           ),
     *       ),
     *   ),
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns newly created support info",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionAdd()
    {
        $this->setStatus(400);
        $data = [];

        $model = new Booking();
        $paymentModel = new Transaction();
        $post = \Yii::$app->request->post();

        $model->state_id = Booking::STATE_PENDING;

        if ($model->load($post)) {
            // $day_ids = array_filter(array_map('trim', explode(",", $model->day_ids)));

            // if (empty($day_ids) || ! is_array($day_ids)) {
            // $data['message'] = "Invalid Days";
            // return $data;
            // }

            $serviceQuery = Service::findOne($model->service_id);

            if (empty($serviceQuery)) {
                $data['message'] = \Yii::t('app', 'No service found !!');
                return $data;
            }

            $existingBooking = Booking::find()->where([
            'service_id' => $model->service_id,
            'day_id' => $model->day_id,
            'state_id' => Booking::STATE_PENDING,
            'start_time' => $model->start_time,
            'end_time' => $model->end_time
            ])
            ->one();

            // Check if an existing booking was found
            if (!empty($existingBooking)) {
            $data['message'] = \Yii::t('app', 'This slot is already booked by another patient.');
            return $data;
            }

            // Generate appointment ID
            $model->appointment_id = Booking::generateUniqueId();

            // Save the booking model
            if ($model->save()) {
                // Save payment details
                $paymentModel->amount = $model->total_price;
                $paymentModel->model_id = $model->id;
                $paymentModel->model_type = Booking::class;
                $paymentModel->user_ip = $model->provider_id;
                $paymentModel->created_by_id = \Yii::$app->user->identity->id;
                $paymentModel->state_id = Transaction::STATE_INPROGRESS;

                if ($paymentModel->save()) {

                    $fileModel = new File();
                    if (! empty($_FILES)) {

                        $files = UploadedFile::getInstances($fileModel, 'key');

                        if (! empty($files)) {
                            foreach ($files as $file) {
                                File::add($model, $file, null, FILE::TYPE_UPLOAD_REPORT);
                            }
                        }
                    }

                    $this->setStatus(200);
                    $data['message'] = \Yii::t('app', 'Your Booking Request Sent Successfully');
                    $data['details'] = $model->asJson();
                } else {
                    $data['message'] = \Yii::t('app', $paymentModel->getErrorsString());
                }
            } else {
                $data['message'] = \Yii::t('app', $model->getErrorsString());
            }
        } else {
            $data['message'] = \Yii::t('app', 'No Data Posted or Invalid Data.');
        }

        return $data;
    }

    /**
     *
     * @OA\Get(path="/booking/patient-booking",
     *   summary="",
     *   tags={"Provider"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *    @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Bank detail",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionPatientBooking($id, $page = 0)
    {
        $this->setStatus(400);
        $data = [];
        $query = Booking::find()->where([
            'created_by_id' => $id
            // 'provider_id' => \Yii::$app->user->id
        ]);
        // if (User::isUser()) {
        // $query->my('created_by_id');
        // } else {
        // $query->my('provider_id');
        // }
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ]
        ]);

        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     *
     * @OA\Get(path="/booking/pending-list",
     *   summary="booking pending list",
     *   tags={"Booking"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *    @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns the list of booking",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionPendingList($page = 0)
    {
        $successfulTransactionIds = Transaction::find()->select('model_id')->where([
            'state_id' => Transaction::STATE_SUCCESS
        ]);

        $bookingQuery = Booking::find()->my('provider_id')->andWhere([
            'state_id' => Booking::STATE_PENDING,
            'id' => $successfulTransactionIds
        ]);

        $dataProvider = new ActiveDataProvider([
            'query' => $bookingQuery,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ]
        ]);

        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     *
     * @OA\Get(path="/booking/change-state",
     *   summary="booking change state",
     *   tags={"Booking"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *
     *     @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *     @OA\Parameter(
     *     name="state_id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns the list of booking",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionChangeState($id, $state_id)
    {
        $this->setStatus(400);
        $data = [];
        $revenue = new Revenue();
        $bookingQuery = Booking::findOne($id);

        if (empty($bookingQuery)) {
            $data['message'] = \Yii::t('app', 'Booking not found');
            return $data;
        }

        if ($state_id == Booking::STATE_REJECTED && $bookingQuery->state_id !== Booking::STATE_PENDING) {
            $data['message'] = \Yii::t('app', 'Cannot change state to rejected');
            return $data;
        }

        if ($state_id == Booking::STATE_COMPLETED) {
            // Calculate admin commission and provider amount
            $admin_commission = User::getAdminCommission();

            if (! is_numeric($admin_commission) || $admin_commission <= 0) {
                $data['message'] = \Yii::t('app', 'Invalid admin commission set');
                return $data;
            }

            $admin_amount = ($admin_commission / 100) * $bookingQuery->total_price;
            $provider_amount = $bookingQuery->total_price - $admin_amount;

            $revenue->admin_amount = strval(round($admin_amount, 2));
            $revenue->provider_amount = strval(round($provider_amount, 2));
            $revenue->booking_id = $bookingQuery->id;
            $revenue->provider_id = $bookingQuery->provider_id;
            $revenue->final_amount = $bookingQuery->total_price;

            if (! $revenue->save()) {
                $data['message'] = $revenue->getErrorsString();
                return $data;
            }

            // On complete mark booking by provider send notification to user.
            $msg = \Yii::t('app', "Your booking has been completed.");
            Notification::create([
                'html' => $msg,
                'to_user_id' => $bookingQuery->created_by_id, // Notify user
                'created_by_id' => \Yii::$app->user->identity->id,
                'title' => 'Booking Completed',
                'description' => $msg,
                'model' => $bookingQuery,
                'type_id' => Notification::STATE_ACTIVE,
                'state_id' => Notification::STATE_ACTIVE
            ], false);
        } else if ($state_id == Booking::STATE_CANCELLED) {

            $transaction = Transaction::find()->where([
                'model_id' => $bookingQuery->id,
                'model_type' => Booking::class
            ])->one();

            if (! empty($transaction)) {

                $paypal = new Paypal();
                $refund_response = $paypal->getRefund($transaction->id, $bookingQuery);
            }

            // On cancelled booking by user send notification to provider.
            $msg = \Yii::t('app', "Your booking has been cancelled.");
            Notification::create([
                'html' => $msg,
                'to_user_id' => $bookingQuery->provider_id, // Notify provider
                'created_by_id' => \Yii::$app->user->identity->id,
                'title' => 'Booking Cancelled',
                'description' => $msg,
                'model' => $bookingQuery,
                'type_id' => Notification::STATE_ACTIVE,
                'state_id' => Notification::STATE_ACTIVE
            ], false);

            $bookingQuery->state_id = $state_id;
        } else {
            // Handle accepted, in-progress, and rejected states(send notification to user when provider change these state)
            $bookingQuery->state_id = $state_id;

            $transaction = Transaction::find()->where([
                'model_id' => $bookingQuery->id,
                'model_type' => Booking::class
            ])->one();

            if (! empty($transaction)) {
                $paypal = new Paypal();
                $refund_response = $paypal->getRefund($transaction->id, $bookingQuery);
            }

            if ($state_id == Booking::STATE_ACCEPTED) {
                $action = 'accepted';
            } elseif ($state_id == Booking::STATE_REJECTED) {
                $action = 'rejected';
            } elseif ($state_id == Booking::STATE_INPROGRESS) {
                $action = 'in progress';
            }

            $msg = \Yii::t('app', "Your booking has been " . $action . ".");
            Notification::create([
                'html' => $msg,
                'to_user_id' => $bookingQuery->created_by_id,
                'created_by_id' => \Yii::$app->user->identity->id,
                'title' => 'Booking ' . ucfirst($action),
                'description' => $msg,
                'model' => $bookingQuery,
                'type_id' => Notification::STATE_ACTIVE,
                'state_id' => Notification::STATE_ACTIVE
            ], false);
        }

        // Update booking state
        $bookingQuery->updateAttributes([
            'state_id' => $state_id
        ]);

        $this->setStatus(200);
        $data['message'] = \Yii::t('app', 'Service Request ' . $bookingQuery->getState() . ' Successfully');
        $data['detail'] = $bookingQuery->asJson();

        return $data;
    }

    /**
     *
     * @OA\Get(path="/booking/patient-info",
     *   summary="booking change state",
     *   tags={"Booking"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *
     *     @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns the list of booking",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionPatientInfo($id)
    {
        $this->setStatus(400);
        $data = [];
        $bookingQuery = Booking::findOne($id);

        if (empty($bookingQuery)) {

            $data['message'] = \Yii::t('app', 'Booking not found');
            return $data;
        }

        $this->setStatus(200);

        $data['detail'] = $bookingQuery->asJson();
        return $data;
    }

    /**
     *
     * @OA\Post(path="/booking/report",
     *   summary="booking report",
     *   tags={"Booking"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     * @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *              required={},
     *               @OA\Property(property="Report[name]", type="string", example="",description="Service Id"),
     *               @OA\Property(property="Report[patient_id]", type="integer", example="",description="patient_id"),
     *               @OA\Property(property="Report[provider_id]", type="integer", example="",description="provider_id"),
     *               @OA\Property(property="Report[booking_id]", type="integer", example="",description="booking_id"),
     *               @OA\Property(property="Report[date_of_birth]", type="string", example="",description="date_of_birth"),
     *               @OA\Property(property="Report[age]", type="integer", example="",description="date_of_birth"),
     *               @OA\Property(property="Report[nationality]", type="string", example="",description="nationality"),
     *               @OA\Property(property="Report[blood_pressure]", type="string", example="",description="blood_pressure"),
     *               @OA\Property(property="Report[pulse]", type="string", example="",description="pulse"),
     *               @OA\Property(property="Report[temperature]", type="string", example="",description="temperature"),
     *               @OA\Property(property="Report[skin]", type="string", example="",description="skin"),
     *               @OA\Property(property="Report[conclusion]", type="string", example="",description="conclusion"),
     *           ),
     *       ),
     *   ),
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns newly created support info",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionReport()
    {
        $data = [];
        $this->setStatus(400);
        $model = new Report();
        $post = \Yii::$app->request->post();
        if ($model->load($post)) {

            $model->state_id = Report::STATE_ACTIVE;
            if ($model->save()) {

                $this->setStatus(200);
                $data['message'] = \yii::t('app', "Report Added Successfully");
            } else {
                $data['error'] = $model->getErrorsString();
            }
        } else {
            $data['message'] = \yii::t('app', "Data not posted.");
        }
        return $data;
    }

    /**
     *
     * @OA\Get(path="/booking/my-transaction",
     *   summary="",
     *   tags={"Booking"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *
     *     @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns the list of transaction",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionMyTransaction($id)
    {
        $this->setStatus(400);
        $data = [];
        $bookingQuery = Transaction::find()->my();

        if (empty($bookingQuery)) {

            $data['message'] = \Yii::t('app', 'Transaction not found');
            return $data;
        }

        $this->setStatus(200);

        $data['detail'] = $bookingQuery->asJson();
        return $data;
    }

    /**
     *
     * @OA\Get(path="/booking/patient-list",
     *   summary="booking patient list",
     *   tags={"Booking"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *    @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns the list of booking",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionPatientList($page = 0)
    {
        $bookingQuery = User::find()->alias('u')
            ->joinWith([
            'booking as b'
        ])
            ->where([
            'b.provider_id' => \Yii::$app->user->id
        ]);

        $dataProvider = new ActiveDataProvider([
            'query' => $bookingQuery,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ]
        ]);

        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     *
     * @OA\Post(path="/booking/add-rating",
     *   summary="rating",
     *   tags={"Booking"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *
     *    @OA\Parameter(
     *     name="booking_id",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *    @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *           required={"Rating[rating]"},
     *              @OA\Property(property="Rating[rating]",type="integer", example="5",description="Rating"),
     *              @OA\Property(property="Rating[comment]",type="string",example="good",description="Reviews"),
     *              @OA\Property(property="Rating[title]",type="integer",example="good",description="Reviews"),
     *
     *
     *           ),
     *       ),
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Add rating of the charging space",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionAddRating($booking_id = null)
    {
        $this->setStatus(400);
        $data = [];
        $ratingModel = new Rating();
        $post = \Yii::$app->request->post();

        if (! empty($booking_id)) {
            $bookingQuery = Booking::findOne($booking_id);

            if (empty($bookingQuery)) {
                $data['message'] = \yii::t('app', "Booking not found");
                return $data;
            }
            $ratingModel->model_type = Booking::class;
            $ratingModel->model_id = $bookingQuery->id;
            $ratingModel->service_id = $bookingQuery->service_id;
        }

        if ($ratingModel->load($post)) {

            $ratingQuery = Rating::find()->where([
                'model_type' => $ratingModel->model_type,
                'model_id' => $ratingModel->model_id
            ])
                ->my()
                ->one();

            if (! empty($ratingQuery)) {
                $ratingModel = $ratingQuery;
            }

            // $ratingModel->title = \Yii::t('app', 'Review');
            // $ratingModel->title = \Yii::t('app', 'Review');
            $ratingModel->state_id = Rating::STATE_ACTIVE;

            if (! $ratingModel->save()) {
                $data['message'] = $ratingModel->getErrors();
                return $data;
            }
            $this->setStatus(200);
            $data['message'] = \Yii::t('app', 'Rating added successfully');
            // $data['detail'] = $ratingModel->asJson(fasle);

            return $data;
        } else {
            $data['message'] = \Yii::t('app', 'Data Not Posted');
        }
        return $data;
    }

    /**
     *
     * @OA\Get(path="/booking/rating-list",
     *   summary="booking pending list",
     *   tags={"Booking"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *    @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns the list of booking",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionRatingList($page = 0)
    {
        $ratingQuery = Rating::find()->where([
            'model_type' => Booking::class
        ])->my('title');

        $dataProvider = new ActiveDataProvider([
            'query' => $ratingQuery,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ]
        ]);

        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     *
     * @OA\Get(path="/booking/revenue",
     *   summary="get earning for weekly = 3 for monthly = 4 and yearly = 5",
     *   tags={"revenue"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Parameter(
     *     name="type",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Returns newly created user info",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionRevenue($page = 0, $type = '')
    {
        $provider_id = \Yii::$app->user->id;

        $model = Revenue::find()->where([
            'provider_id' => $provider_id
        ]);

        if ($type == Revenue::TYPE_MONTHLY) {
            $model->andWhere([
                'MONTH(created_on)' => date('m')
            ]);
        } elseif ($type == Revenue::TYPE_WEEKLLY) {
            $currentDate = date('Y-m-d');
            $startOfWeek = date('Y-m-d', strtotime('last Monday', strtotime($currentDate)));

            $endOfWeek = date('Y-m-d', strtotime('next Sunday', strtotime($currentDate)));
            $model->andWhere([
                'between',
                'DATE(created_on)',
                $startOfWeek,
                $endOfWeek
            ]);
        } elseif ($type == Revenue::TYPE_YEARLY) {
            $model->andWhere([
                'YEAR(created_on)' => date('Y')
            ]);
        }

        $totalEarning = $model->sum('provider_amount');

        $dataProvider = new ActiveDataProvider([
            'query' => $model,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ]
        ]);
        $this->extraData = [
            'total_revenue' => $totalEarning
        ];

        return $dataProvider;
    }

    /**
     *
     * @OA\Get(path="/booking/get-transaction",
     *   summary="",
     *   tags={"Booking"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *
     *     @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns the list of transaction",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionGetTransaction($id)
    {
        $this->setStatus(400);
        $data = [];
        $transaction = Transaction::findOne($id);

        if (empty($transaction)) {
            $data['message'] = \Yii::t('app', 'Transaction not found');
            return $data;
        }

        if ($transaction->state_id == Transaction::STATE_SUCCESS) {
            $data['message'] = \Yii::t('app', 'Transaction is successful');
            $this->setStatus(200);
        } elseif ($transaction->state_id == Transaction::STATE_FAIL) {
            $data['message'] = \Yii::t('app', 'Transaction has failed');
            $this->setStatus(200);
        } else {
            $data['message'] = \Yii::t('app', 'Transaction state is neither success nor failure');
        }

        return $data;
    }

    /**
     *
     * @OA\Get(path="/booking/transaction-list",
     *   summary="",
     *   tags={"Booking"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *
     *     @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *
     *   @OA\Response(
     *     response=200,
     *     description="Returns the list of transaction",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionTransactionList($page = 0)
    {
        $this->setStatus(400);
        $data = [];
        $transaction = Transaction::find()->my();
        $dataProvider = new ActiveDataProvider([
            'query' => $transaction,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ]
        ]);
        $this->setStatus(200);

        return $dataProvider;
    }

    /**
     *
     * @OA\Get(path="/booking/get-refund",
     *   summary="",
     *   tags={"Booking"},
     *  security={
     *   {"bearerAuth": {}}
     *   },
     *    @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Returns the list of transaction",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionGetRefund($page = 0)
    {
        if (User::isClient()) {
            $gateway = \app\modules\payment\models\Refund::findActive()->andWhere([
                'user_id' => \Yii::$app->user->id
            ]);
        } else {
            $gateway = \app\modules\payment\models\Refund::findActive()->andWhere([
                'provider_id' => \Yii::$app->user->id
            ]);
        }
        $dataProvider = new ActiveDataProvider([
            'query' => $gateway,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ]
        ]);

        $this->setStatus(200);
        return $dataProvider;
    }
}
