-- -------------------------------------------

SET SQL_QUOTE_SHOW_CREATE = 1;
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;

-- -------------------------------------------
-- -------------------------------------------
-- START BACKUP
-- -------------------------------------------

-- -------------------------------------------
-- TABLE `tbl_booking`
-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_booking`;
CREATE TABLE IF NOT EXISTS `tbl_booking` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(126) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_id` varchar(126) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` int NOT NULL,
  `full_name` varchar(126) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_no` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(126) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(126) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(126) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(126) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `latitude` varchar(126) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `longitude` varchar(126) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `appointment_id` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `day_id` int DEFAULT NULL,
  `booking_service_type` int DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `price` varchar(6) DEFAULT '0',
  `total_price` varchar(6) DEFAULT '0',
  `commission_price` varchar(6) DEFAULT NULL,
  `date` datetime NOT NULL,
  `state_id` int NOT NULL DEFAULT '0',
  `type_id` int NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  INDEX(`title`),
  INDEX(`service_id`),
  INDEX(`provider_id`),
  INDEX(`date`),
  INDEX(`state_id`),
  INDEX(`created_by_id`),
  KEY `fk_booking_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_booking_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------
-- TABLE `tbl_booking_track`
-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_booking_track`;
CREATE TABLE IF NOT EXISTS `tbl_booking_track` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(126) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_id` int NOT NULL,
  `state_id` int NOT NULL DEFAULT '0',
  `type_id` int NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  INDEX(`title`),
  INDEX(`booking_id`),
  INDEX(`state_id`),
  INDEX(`created_by_id`),
  KEY `fk_booking_track_booking_id` (`booking_id`),
  CONSTRAINT `fk_booking_track_booking_id` FOREIGN KEY (`booking_id`) REFERENCES `tbl_booking` (`id`),
  KEY `fk_booking_track_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_booking_track_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -------------------------------------------
-- TABLE `tbl_booking_feedback`
-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_booking_feedback`;
CREATE TABLE IF NOT EXISTS `tbl_booking_feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(126) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `booking_id` int NOT NULL,
  `provider_id` int NOT NULL,
  `rating` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state_id` int NOT NULL DEFAULT '0',
  `type_id` int NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  INDEX(`title`),
  INDEX(`booking_id`),
  INDEX(`provider_id`),
  INDEX(`state_id`),
  INDEX(`rating`),
  INDEX(`created_by_id`),
  KEY `fk_booking_feedback_booking_id` (`booking_id`),
  CONSTRAINT `fk_booking_feedback_booking_id` FOREIGN KEY (`booking_id`) REFERENCES `tbl_booking` (`id`),
  KEY `fk_booking_feedback_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_booking_feedback_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- -------------------------------------------
-- TABLE `tbl_booking_report`
-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_booking_report`;
CREATE TABLE IF NOT EXISTS `tbl_booking_report` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(126) COLLATE utf8mb4_unicode_ci NOT NULL,
  `patient_id` int NOT NULL,
  `booking_id` int NOT NULL,
  `date_of_birth` date NOT NULL,
  `age` int NOT NULL,
  `nationality` varchar(126) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blood_pressure` varchar(126) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pulse` varchar(126) COLLATE utf8mb4_unicode_ci NOT NULL,
  `temperature` varchar(126) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skin` varchar(126) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conclusion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `state_id` int NOT NULL DEFAULT '0',
  `type_id` int NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  INDEX(`name`),
  INDEX(`booking_id`),
  INDEX(`patient_id`),
  INDEX(`state_id`),
  INDEX(`created_by_id`),
  KEY `fk_booking_report_booking_id` (`booking_id`),
  CONSTRAINT `fk_booking_report_booking_id` FOREIGN KEY (`booking_id`) REFERENCES `tbl_booking` (`id`),
  KEY `fk_booking_report_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_booking_report_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------

-- -------------------------------------------
-- TABLE `tbl_booking_revenue`
-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_booking_revenue`;
CREATE TABLE IF NOT EXISTS `tbl_booking_revenue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `booking_id` int NOT NULL,
  `final_amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `admin_amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `provider_amount` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '0',
  `provider_id` int DEFAULT NULL,   
  `state_id` int NOT NULL DEFAULT '0',
  `type_id` int NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  INDEX(`booking_id`),
  INDEX(`state_id`),
  INDEX(`created_by_id`),
  KEY `fk_booking_revenue_booking_id` (`booking_id`),
  CONSTRAINT `fk_booking_revenue_booking_id` FOREIGN KEY (`booking_id`) REFERENCES `tbl_booking` (`id`),
  KEY `fk_booking_revenue_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_booking_revenue_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- -------------------------------------------
-- END BACKUP
-- -------------------------------------------
