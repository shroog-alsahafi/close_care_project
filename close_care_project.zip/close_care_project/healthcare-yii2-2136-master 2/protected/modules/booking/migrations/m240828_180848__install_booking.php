<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
use yii\db\Migration;

/**
 * php console.php module/migrate
 */
class m240828_180848__install_booking extends Migration{

    public function safeUp()
    {
        
        $dbfile = __DIR__ . '/../db/install.sql';
        if (is_file($dbfile)) {
        	echo "m240828_180848__install_booking installing module.... :$dbfile \n";
            $sql = file_get_contents( $dbfile);
            $this->execute($sql);
        }
    }
    
    public function safeDown()
    {
        echo "m240828_180848__install_booking migrating down by doing nothing....\n";
    }
}