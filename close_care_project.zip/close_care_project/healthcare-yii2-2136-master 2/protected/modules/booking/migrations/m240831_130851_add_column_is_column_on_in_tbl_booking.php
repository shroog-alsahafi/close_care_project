<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
use yii\db\Migration;

/**
 * php console.php module/migrate
 */
class m240831_130851_add_column_is_column_on_in_tbl_booking extends Migration
{

    public function safeUp()
    {
        $table = Yii::$app->db->schema->getTableSchema('{{%booking}}');
        if (! isset($table->columns['day_id'])) {
            $this->addColumn('{{%booking}}', 'day_id', $this->integer()
                ->defaultValue(NULL));
        }
        if (! isset($table->columns['start_time'])) {
            $this->addColumn('{{%booking}}', 'start_time', $this->time()
                ->defaultValue(NULL));
        }
        if (! isset($table->columns['end_time'])) {
            $this->addColumn('{{%booking}}', 'end_time', $this->time()
                ->defaultValue(NULL));
        }
        if (! isset($table->columns['price'])) {
            $this->addColumn('{{%booking}}', 'price', $this->string(6)
                ->defaultValue(0));
        }
        if (! isset($table->columns['total_price'])) {
            $this->addColumn('{{%booking}}', 'total_price', $this->string(6)
                ->defaultValue(0));
        }
    }

    public function safeDown()
    {
        $table = Yii::$app->db->schema->getTableSchema('{{%booking}}');
        if (isset($table->columns['day_id'])) {
            $this->dropColumn('{{%booking}}', 'day_id');
        }
        if (isset($table->columns['start_time'])) {
            $this->dropColumn('{{%booking}}', 'start_time');
        }
        if (isset($table->columns['end_time'])) {
            $this->dropColumn('{{%booking}}', 'end_time');
        }
        if (isset($table->columns['price'])) {
            $this->dropColumn('{{%booking}}', 'price');
        }
        if (isset($table->columns['total_price'])) {
            $this->dropColumn('{{%booking}}', 'total_price');
        }
    }
}