<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
use yii\db\Migration;

/**
 * php console.php module/migrate
 */
class m240918_090936_add_columns_in_tbl_booking_revenue extends Migration
{

    public function safeUp()
    {
        $table = Yii::$app->db->getTableSchema('{{%booking_revenue}}');
        
        if ($table !== null && ! isset($table->columns['provider_id'])) {
            $this->addColumn('{{%booking_revenue}}', 'provider_id', $this->integer()
                ->defaultValue(null));
        }
    }

    public function safeDown()
    {
        $table = Yii::$app->db->getTableSchema('{{%booking_revenue}}');
        
        if ($table !== null && ! isset($table->columns['provider_id'])) {
            $this->addColumn('{{%booking_revenue}}', 'provider_id', $this->integer()
                ->defaultValue(null));
        }
    }
}