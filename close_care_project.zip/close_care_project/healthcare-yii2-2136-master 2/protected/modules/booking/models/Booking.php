<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\booking\models;

use Yii;
use app\models\Feed;
use app\models\User;
use yii\helpers\ArrayHelper;
use app\modules\service\models\Service;
use app\models\File;
use app\modules\api\models\Rating;
use yii\helpers\Url;
use app\modules\payment\models\Transaction;
use app\modules\chat\models\Chat;

/**
 * This is the model class for table "tbl_booking".
 *
 * @property integer $id
 * @property string $title
 * @property string $service_id
 * @property string $full_name
 * @property string $contact_no
 * @property string $address
 * @property string $city
 * @property string $state
 * @property string $country
 * @property string $latitude
 * @property string $longitude
 * @property string $description
 * @property string $date
 * @property integer $state_id
 * @property integer $type_id
 * @property string $created_on
 * @property string $updated_on
 * @property integer $created_by_id
 * @property User $createdBy
 * @property Feedback[] $feedbacks
 * @property Track[] $tracks
 */
class Booking extends \app\components\TActiveRecord
{

    public function __toString()
    {
        return (string) ! empty($this->service->title) ? $this->service->title : '';
    }

    const STATE_INACTIVE = 0;

    const STATE_ACTIVE = 1;

    const STATE_DELETED = 2;

    const STATE_PENDING = 3;

    const STATE_INPROGRESS = 4;

    const STATE_COMPLETED = 5;

    const STATE_REJECTED = 6;

    const STATE_ACCEPTED = 7;

    const STATE_CANCELLED = 8;

    const BOOKING_TYPE_TODAY = 1;

    const BOOKING_TYPE_ONLY_TODAY = 0;

    const BOOKING_TYPE_UPCOMING = 2;

    const BOOKING_TYPE_PAST = 3;

    const BOOKING_TYPE_REST = 4;

    const MONDAY = 1;

    const TUESDAY = 2;

    const WEDNESDAY = 3;

    const THURSDAY = 4;

    const FRIDAY = 5;

    const SATURDAY = 6;

    const SUNDAY = 7;

    const HOME_SERVICE = 9;

    const ONLINE_SERVICE = 10;

    public $day_ids;

    public $slots;

    public static function getStateOptions()
    {
        return [
            self::STATE_PENDING => "Pending",
            self::STATE_ACCEPTED => "Accepted",
            self::STATE_INPROGRESS => "Inprogress",
            self::STATE_COMPLETED => "Completed",
            self::STATE_REJECTED => "Rejected",
            self::STATE_CANCELLED => "Cancelled"
        ];
    }

    public function getState()
    {
        $list = self::getStateOptions();
        return isset($list[$this->state_id]) ? $list[$this->state_id] : 'Not Defined';
    }

    public function getStateBadge()
    {
        $list = [
            self::STATE_PENDING => "secondary",
            self::STATE_ACCEPTED => "info",
            self::STATE_INPROGRESS => "warning",
            self::STATE_COMPLETED => "success",
            self::STATE_REJECTED => "danger",
            self::STATE_CANCELLED => "danger"
        ];
        return isset($list[$this->state_id]) ? \yii\helpers\Html::tag('span', $this->getState(), [
            'class' => 'badge bg-' . $list[$this->state_id]
        ]) : 'Not Defined';
    }

    public static function getActionOptions()
    {
        return [
            self::STATE_PENDING => "Pending",
            self::STATE_ACCEPTED => "Accepted",
            self::STATE_INPROGRESS => "Inprogress",
            self::STATE_COMPLETED => "Completed",
            self::STATE_REJECTED => "Rejected",
            self::STATE_CANCELLED => "Cancelled"
        ];
    }

    public static function getTypeOptions()
    {
        return [
            "TYPE1",
            "TYPE2",
            "TYPE3"
        ];
    }

    public function getType()
    {
        $list = self::getTypeOptions();
        return isset($list[$this->type_id]) ? $list[$this->type_id] : 'Not Defined';
    }

    public function beforeValidate()
    {
        if ($this->isNewRecord) {
            if (empty($this->created_on)) {
                $this->created_on = \date('Y-m-d H:i:s');
            }
            if (empty($this->updated_on)) {
                $this->updated_on = \date('Y-m-d H:i:s');
            }
            if (empty($this->created_by_id)) {
                $this->created_by_id = self::getCurrentUser();
            }
        } else {
            $this->updated_on = date('Y-m-d H:i:s');
        }
        return parent::beforeValidate();
    }

    /**
     *
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%booking}}';
    }

    /**
     *
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [
                    'service_id',
                    'date',
                    'created_by_id'
                ],
                'required'
            ],
            [
                [
                    'description'
                ],
                'string'
            ],
            [
                [
                    'day_id',
                    'date',
                    'day_ids',
                    'slots',
                    'created_on',
                    'updated_on',
                    'start_time',
                    'end_time',
                    'price',
                    'total_price',
                    'booking_id'
                ],
                'safe'
            ],
            [
                [
                    'state_id',
                    'type_id',
                    'created_by_id',
                    'provider_id'
                ],
                'integer'
            ],
            [
                [
                    'title',
                    'service_id',
                    'full_name',
                    'address',
                    'city',
                    'state',
                    'country',
                    'latitude',
                    'longitude'
                ],
                'string',
                'max' => 126
            ],
            [
                [
                    'contact_no'
                ],
                'string',
                'max' => 16
            ],

            [
                [
                    'price',
                    'total_price'
                ],
                'string',
                'max' => 6
            ],
            [
                [
                    'created_by_id'
                ],
                'exist',
                'skipOnError' => true,
                'targetClass' => User::class,
                'targetAttribute' => [
                    'created_by_id' => 'id'
                ]
            ],
            [
                [
                    'title',
                    'service_id',
                    'full_name',
                    'address',
                    'city',
                    'state',
                    'country',
                    'latitude',
                    'longitude',
                    'contact_no'
                ],
                'trim'
            ],
            [
                [
                    'full_name'
                ],
                'app\components\validators\TNameValidator'
            ],
            [
                [
                    'state_id'
                ],
                'in',
                'range' => array_keys(self::getStateOptions())
            ],
            [
                [
                    'type_id'
                ],
                'in',
                'range' => array_keys(self::getTypeOptions())
            ]
        ];
    }

    /**
     *
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'title' => Yii::t('app', 'Title'),
            'service_id' => Yii::t('app', 'Service'),
            'full_name' => Yii::t('app', 'Full Name'),
            'contact_no' => Yii::t('app', 'Contact No'),
            'address' => Yii::t('app', 'Address'),
            'city' => Yii::t('app', 'City'),
            'state' => Yii::t('app', 'State'),
            'country' => Yii::t('app', 'Country'),
            'latitude' => Yii::t('app', 'Latitude'),
            'longitude' => Yii::t('app', 'Longitude'),
            'description' => Yii::t('app', 'Description'),
            'date' => Yii::t('app', 'Date'),
            'state_id' => Yii::t('app', 'State'),
            'type_id' => Yii::t('app', 'Type'),
            'created_on' => Yii::t('app', 'Created On'),
            'updated_on' => Yii::t('app', 'Updated On'),
            'created_by_id' => Yii::t('app', 'Created By')
        ];
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), [
            'id' => 'created_by_id'
        ])->cache();
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getSubmitReport()
    {
        return $this->hasOne(Report::className(), [
            'booking_id' => 'id'
        ])->cache();
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProviderName()
    {
        return $this->hasOne(User::className(), [
            'id' => 'provider_id'
        ])->cache();
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getService()
    {
        return $this->hasOne(Service::className(), [
            'id' => 'service_id'
        ])->cache();
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBookingTransaction()
    {
        return $this->hasOne(Transaction::className(), [
            'model_id' => 'id'
        ])->cache();
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBookingRevenue()
    {
        return $this->hasOne(Revenue::className(), [
            'booking_id' => 'id'
        ])->cache();
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBookingReport()
    {
        return $this->hasOne(Report::className(), [
            'booking_id' => 'id'
        ])->cache();
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFeedbacks()
    {
        return $this->hasMany(Feedback::className(), [
            'booking_id' => 'id'
        ]);
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTracks()
    {
        return $this->hasMany(Track::className(), [
            'booking_id' => 'id'
        ]);
    }

    public static function getHasManyRelations()
    {
        $relations = [];

        $relations['Feedbacks'] = [
            'feedbacks',
            'Feedback',
            'id',
            'booking_id'
        ];
        $relations['Tracks'] = [
            'tracks',
            'Track',
            'id',
            'booking_id'
        ];
        $relations['feeds'] = [
            'feeds',
            'Feed',
            'model_id'
        ];
        return $relations;
    }

    public static function getHasOneRelations()
    {
        $relations = [];
        $relations['created_by_id'] = [
            'createdBy',
            'User',
            'id'
        ];
        return $relations;
    }

    public function beforeDelete()
    {
        if (! parent::beforeDelete()) {
            return false;
        }
        // TODO : start here
        Feedback::deleteRelatedAll([
            'booking_id' => $this->id
        ]);
        Track::deleteRelatedAll([
            'booking_id' => $this->id
        ]);

        return true;
    }

    public function IsRated()
    {
        $model_id = \Yii::$app->request->get('id');

        $exists = Rating::find()->where([
            'created_by_id' => \Yii::$app->user->identity->id,
            'model_id' => $model_id,
            'model_type' => self::class
        ])
            ->my()
            ->one();

        if (! empty($exists)) {
            return true;
        }

        return false;
    }

    public function IsReported()
    {
        $model = Report::find()->where([
            'booking_id' => $this->id
        ])
            ->my()
            ->exists();

        return $model;
    }

    public function IsSubmitReport()
    {
        $model = Report::find()->where([
            'booking_id' => $this->id
        ])->exists();

        return $model;
    }

    public function getMessage()
    {
        $model = Chat::find()->where([
            'booking_id' => $this->id,
            'is_read' => Chat::IS_READ_NO,
            'to_id' => \Yii::$app->user->id
        ])
            ->orderBy('id DESC')
            ->one();

        if (! ! $model) {
            return true;
        } else {
            return false;
        }
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getAverageRating()
    {
        return Rating::find()->where([
            'title' => $this->provider_id,
            'model_type' => Booking::class
        ])->average('rating');
    }

    /**
     * get profile image
     *
     * @return \yii\db\ActiveQuery
     */
    public function getImageFile()
    {
        return $this->hasMany(File::class, [
            'model_id' => 'id'
        ])->andOnCondition([
            'model_type' => self::class
        ]);
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getFile()
    {
        return $this->hasOne(File::className(), [
            'model_id' => 'id'
        ])->andOnCondition([
            'model_type' => self::class
        ]);
    }

    public function asPatientJson($with_relations = false)
    {
        $json = [];
        $json['id'] = $this->id;
        $json['title'] = $this->title;
        $json['appointment_id'] = $this->appointment_id;
        $json['service_id'] = $this->service_id;
        $json['service_name'] = ! empty($this->service->title) ? $this->service->title : '';
        $json['profile_file'] = ! empty($this->createdBy->profile_file) ? $this->createdBy->getImageUrl() : '';
        $json['provider_profile_file'] = ! empty($this->providerName->profile_file) ? $this->providerName->getImageUrl() : '';
        $json['provider_name'] = ! empty($this->providerName) ? $this->providerName->full_name : '';
        $json['provider_id'] = $this->provider_id;
        $json['start_time'] = $this->start_time;
        $json['end_time'] = $this->end_time;
        $json['date'] = $this->date;
        $json['full_name'] = $this->full_name;
        // $json['contact_no'] = $this->contact_no;
        $json['address'] = $this->address;
        $json['city'] = $this->city;
        // $json['state'] = $this->state;
        $json['country'] = $this->country;
        $json['latitude'] = $this->latitude;
        $json['longitude'] = $this->longitude;
        $json['description'] = $this->description;
        $json['price'] = $this->price;
        $json['total_price'] = $this->total_price;
        $json['state_id'] = $this->state_id;
        $json['type_id'] = $this->type_id;
        $json['created_on'] = $this->created_on;
        $json['created_by_id'] = $this->created_by_id;
        $json['is_rating'] = $this->IsRated();
        $json['created_on'] = $this->created_on;
        $json['commission_price'] = \Yii::$app->settings->getValue('admin_commission_percent', null, 'booking');
        // $json['upload_report_image'] = ! empty($this->file) ? $this->file->getAbsoluteUrl() : '';
        $json['is_submit_reported'] = $this->IsSubmitReport();
        $json['is_message'] = $this->getMessage();
        $json['provider_rating'] = $this->getAverageRating();
        $json['booking_transaction_id'] = ! empty($this->bookingTransaction) ? $this->bookingTransaction->id : '';
        $json['payment_status'] = ! empty($this->bookingTransaction) ? $this->bookingTransaction->state_id : '';

        // createdBy
        $list = $this->createdBy;

        if (is_array($list)) {
            $relationData = array_map(function ($item) {
                return $item->asJson();
            }, $list);

            $json['createdBy'] = $relationData;
        } else {

            if (empty($list)) {
                $json['createdBy'] = $list;
            } else {
                $json['createdBy'] = $list->asPatientJson();
            }
        }

        // upload reports

        $list = $this->uploadReport;

        if (is_array($list)) {
            $relationData = array_map(function ($item) {
                return $item->asJson();
            }, $list);

            $json['uploadReport'] = $relationData;
        } else {
            $json['uploadReport'] = $list;
        }

        // Submit report
        $list = $this->submitReport;

        if (is_array($list)) {
            $relationData = array_map(function ($item) {
                return $item->asJson();
            }, $list);

            $json['submit_report'] = $relationData;
        } else {
            $json['submit_report'] = $list;
        }

        // upload reports

        $list = $this->uploadReport;

        if (is_array($list)) {
            $relationData = array_map(function ($item) {
                return $item->asJson();
            }, $list);

            $json['uploadReport'] = $relationData;
        } else {
            $json['uploadReport'] = $list;
        }

        // Submit report
        $list = $this->submitReport;

        if (is_array($list)) {
            $relationData = array_map(function ($item) {
                return $item->asJson();
            }, $list);

            $json['submit_report'] = $relationData;
        } else {
            $json['submit_report'] = $list;
        }

        return $json;
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getUploadReport()
    {
        return $this->hasMany(File::className(), [
            'model_id' => 'id'
        ])->andOnCondition([
            'model_type' => self::class,
            'type_id' => File::TYPE_UPLOAD_REPORT
        ]);
    }

    public function asJson($with_relations = false)
    {
        $actionId = Yii::$app->controller->action->id;
        if ($actionId == 'patient-info') {
            return $this->asPatientJson();
        }
        if ($actionId == "pending") {
            $json = [];
            $json['id'] = $this->id;
            $json['start_time'] = $this->start_time;
            $json['service_name'] = ! empty($this->service->title) ? $this->service->title : '';
            $json['appointment_id'] = $this->appointment_id;
            $json['end_time'] = $this->end_time;
            $json['date'] = $this->date;
            $json['day_id'] = $this->day_id;
            $json['price'] = $this->price;
            $json['total_price'] = $this->total_price;
            $json['state_id'] = $this->state_id;
            $json['type_id'] = $this->type_id;
            $json['full_name'] = $this->createdBy->full_name;
            $json['email'] = $this->createdBy->email;
            $json['date_of_birth'] = $this->createdBy->date_of_birth;
            $json['gender'] = $this->createdBy->gender;
            $json['booking_transaction_id'] = ! empty($this->bookingTransaction) ? $this->bookingTransaction->id : '';

            $json['contact_no'] = $this->createdBy->contact_no;
            $json['profile_file'] = ! empty($this->createdBy->profile_file) ? $this->createdBy->fileUrl->absoluteUrl : '';
            $json['provider_profile_file'] = ! empty($this->createdBy->profile_file) ? $this->createdBy->fileUrl->absoluteUrl : '';
            // $json['provider_profile_file'] = ! empty($this->service->createdBy->profile_file) ? $this->service->createdBy->absoluteUrl : '';
            $json['is_rating'] = $this->IsRated();
            $json['created_on'] = $this->created_on;
            $json['commission_price'] = \Yii::$app->settings->getValue('admin_commission_percent', null, 'booking');
        $json['booking_transaction_id'] = ! empty($this->bookingTransaction) ? $this->bookingTransaction->id : '';

            if ($with_relations = TRUE) {
                // createdBy
                $list = $this->service;

                if (is_array($list)) {
                    $relationData = array_map(function ($item) {
                        return $item->asJson();
                    }, $list);

                    $json['service'] = $relationData;
                } else {
                    $json['service'] = $list;
                }
                $list = $this->imageFile;

                if (is_array($list)) {
                    $relationData = array_map(function ($item) {
                        return $item->asJson();
                    }, $list);

                    $json['imageFile'] = $relationData;
                } else {
                    $json['imageFile'] = $list;
                }
            }
            return $json;
        }

        $actionId = Yii::$app->controller->action->id;
        if ($actionId == "list" || $actionId == "pending-list" || $actionId = "patient-booking") {
            $json = [];

            $json['id'] = $this->id;
            $json['start_time'] = $this->start_time;
            $json['appointment_id'] = $this->appointment_id;
            $json['end_time'] = $this->end_time;
            $json['service_name'] = ! empty($this->service->title) ? $this->service->title : '';

            $json['date'] = $this->date;
            $json['day_id'] = $this->day_id;
            $json['price'] = $this->price;
            $json['total_price'] = $this->total_price;
            $json['state_id'] = $this->state_id;
            $json['type_id'] = $this->type_id;
            $json['full_name'] = $this->createdBy->full_name;
            $json['email'] = $this->createdBy->email;
            $json['date_of_birth'] = $this->createdBy->date_of_birth;
            $json['gender'] = $this->createdBy->gender;
            $json['contact_no'] = $this->createdBy->contact_no;
            $json['profile_file'] = ! empty($this->createdBy->profile_file) ? $this->createdBy->getImageUrl() : '';
            // $json['profile_file'] = ! empty($this->createdBy->profile_file) ? $this->createdBy->getImageUrl() : '';
            $json['provider_full_name'] = ! empty($this->providerName) ? $this->providerName->full_name : '';
            $json['provider_email'] = ! empty($this->providerName) ? $this->providerName->email : '';
            $json['provider_date_of_birth'] = ! empty($this->providerName) ? $this->providerName->date_of_birth : '';
            $json['provider_profile_file'] = ! empty($this->providerName->profile_file) ? $this->providerName->getImageUrl() : '';
            // $json['provider_profile_file'] = ! empty($this->service->createdBy->profile_file) ? $this->service->createdBy->absoluteUrl : '';
            $json['provider_id'] = ! empty($this->provider_id) ? $this->provider_id : '';
            $json['is_rating'] = $this->IsRated();
            $json['created_on'] = $this->created_on;
            $json['created_by_id'] = $this->created_by_id;
            $json['commission_price'] = \Yii::$app->settings->getValue('admin_commission_percent', null, 'booking');
            $json['booking_transaction_id'] = ! empty($this->bookingTransaction) ? $this->bookingTransaction->id : '';

            $json['is_message'] = $this->getMessage();
            $json['booking_transaction_id'] = ! empty($this->bookingTransaction) ? $this->bookingTransaction->id : '';

            // $json['upload_report_image'] = ! empty($this->file) ? $this->file->getAbsoluteUrl() : '';
            if ($with_relations = TRUE) {
                // createdBy
                $list = $this->service;

                if (is_array($list)) {
                    $relationData = array_map(function ($item) {
                        return $item->asJson();
                    }, $list);

                    $json['service'] = $relationData;
                } else {
                    $json['service'] = $list;
                }
            }
            return $json;
        }

        $actionId = Yii::$app->controller->action->id;
        if ($actionId == "detail") {
            $json = [];
            $json['id'] = $this->id;
            $json['start_time'] = $this->start_time;
            $json['appointment_id'] = $this->appointment_id;
            $json['end_time'] = $this->end_time;
            $json['service_name'] = ! empty($this->service->title) ? $this->service->title : '';

            $json['date'] = $this->date;
            $json['day_id'] = $this->day_id;
            $json['price'] = $this->price;
            $json['total_price'] = $this->total_price;
            $json['address'] = $this->address;
            $json['state_id'] = $this->state_id;
            $json['type_id'] = $this->type_id;
            $json['full_name'] = $this->createdBy->full_name;
            $json['email'] = $this->createdBy->email;
            $json['date_of_birth'] = $this->createdBy->date_of_birth;
            $json['gender'] = $this->createdBy->gender;
            $json['contact_no'] = $this->createdBy->contact_no;
            $json['country_code '] = $this->createdBy->country_code;
            // $json['profile_file'] = ! empty($this->fileUrl) ? $this->fileUrl->absoluteUrl : '';
            $json['profile_file'] = ! empty($this->createdBy->profile_file) ? $this->createdBy->getImageUrl() : '';
            $json['provider_full_name'] = $this->createdBy->full_name;
            $json['provider_email'] = $this->createdBy->email;
            $json['provider_date_of_birth'] = $this->service->createdBy->date_of_birth;
            $json['booking_transaction_id'] = ! empty($this->bookingTransaction) ? $this->bookingTransaction->id : '';

            $json['provider_profile_file'] = ! empty($this->createdBy->profile_file) ? $this->createdBy->getImageUrl() : '';
            // $json['provider_profile_file'] = ! empty($this->service->createdBy->profile_file) ? $this->service->createdBy->absoluteUrl : '';
            $json['provider_id'] = ! empty($this->provider_id) ? $this->provider_id : '';
            $json['is_rating'] = $this->IsRated();
            $json['created_on'] = $this->created_on;
            $json['commission_price'] = \Yii::$app->settings->getValue('admin_commission_percent', null, 'booking');
            $json['booking_transaction_id'] = ! empty($this->bookingTransaction) ? $this->bookingTransaction->id : '';

            if ($with_relations = TRUE) {
                // createdBy
                $list = $this->service;

                if (is_array($list)) {
                    $relationData = array_map(function ($item) {
                        return $item->asJson();
                    }, $list);

                    $json['service'] = $relationData;
                } else {
                    $json['service'] = $list;
                }
            }
            return $json;
        }

        $json = [];
        $json['id'] = $this->id;
        $json['title'] = $this->title;
        $json['appointment_id'] = $this->appointment_id;
        $json['service_id'] = $this->service_id;
        $json['provider_id'] = $this->provider_id;
        $json['service_name'] = ! empty($this->service->title) ? $this->service->title : '';

        $json['start_time'] = $this->start_time;
        $json['end_time'] = $this->end_time;
        $json['date'] = $this->date;
        $json['full_name'] = $this->full_name;
        // $json['contact_no'] = $this->contact_no;
        $json['address'] = $this->address;
        $json['city'] = $this->city;
        // $json['state'] = $this->state;
        $json['country'] = $this->country;
        $json['latitude'] = $this->latitude;
        $json['longitude'] = $this->longitude;
        $json['description'] = $this->description;
        $json['price'] = $this->price;
        $json['total_price'] = $this->total_price;
        $json['state_id'] = $this->state_id;
        $json['type_id'] = $this->type_id;
        $json['created_on'] = $this->created_on;
        $json['created_by_id'] = $this->created_by_id;
        $json['is_rating'] = $this->IsRated();
        $json['is_reported'] = $this->IsReported();
        $json['created_on'] = $this->created_on;
        $json['commission_price'] = \Yii::$app->settings->getValue('admin_commission_percent', null, 'booking');
        $json['booking_transaction_id'] = ! empty($this->bookingTransaction) ? $this->bookingTransaction->id : '';

        // createdBy
        $list = $this->createdBy;

        if (is_array($list)) {
            $relationData = array_map(function ($item) {
                return $item->asJson();
            }, $list);

            $json['createdBy'] = $relationData;
        } else {

            if (! empty($list)) {
                $json['createdBy'] = $list->asJson();
            } else {
                $json['createdBy'] = $list;
            }
        }
        if ($with_relations) {
            // createdBy
            $list = $this->createdBy;

            if (is_array($list)) {
                $relationData = array_map(function ($item) {
                    return $item->asJson();
                }, $list);

                $json['createdBy'] = $relationData;
            } else {
                $json['createdBy'] = $list;
            }

            // feedbacks
            $list = $this->feedbacks;

            if (is_array($list)) {
                $relationData = array_map(function ($item) {
                    return $item->asJson();
                }, $list);

                $json['feedbacks'] = $relationData;
            } else {
                $json['feedbacks'] = $list;
            }
            // tracks
            $list = $this->tracks;

            if (is_array($list)) {
                $relationData = array_map(function ($item) {
                    return $item->asJson();
                }, $list);

                $json['tracks'] = $relationData;
            } else {
                $json['tracks'] = $list;
            }
        }

        $list = $this->service;

        if (is_array($list)) {
            $relationData = array_map(function ($item) {
                return $item->asJson();
            }, $list);

            $json['service'] = $relationData;
        } else {
            $json['service'] = $list;
        }

        // upload reports

        $list = $this->uploadReport;

        if (is_array($list)) {
            $relationData = array_map(function ($item) {
                return $item->asJson();
            }, $list);

            $json['uploadReport'] = $relationData;
        } else {
            $json['uploadReport'] = $list;
        }

        return $json;
    }

    public function getControllerID()
    {
        return '/booking/' . parent::getControllerID();
    }

    public static function addTestData($count = 1)
    {
        $faker = \Faker\Factory::create();
        $states = array_keys(self::getStateOptions());
        for ($i = 0; $i < $count; $i ++) {
            $model = new self();
            $model->loadDefaultValues();
            $model->title = $faker->text(10);
            $model->service_id = 1;
            $model->full_name = $faker->name;
            $model->contact_no = $faker->text(10);
            $model->address = $faker->text(10);
            $model->city = $faker->text(10);
            $model->state = 0;
            $model->country = $faker->text(10);
            $model->latitude = $faker->text(10);
            $model->longitude = $faker->text(10);
            $model->description = $faker->text;
            $model->date = \date('Y-m-d H:i:s');
            $model->state_id = $states[rand(0, count($states))];
            $model->type_id = 0;
            $model->save();
        }
    }

    public function getImageUrl($thumbnail = false)
    {
        $params = [
            '/' . $this->getControllerID() . '/image'
        ];
        $params['id'] = $this->id;

        if (isset($this->image) && ! empty($this->image)) {
            $params['file'] = $this->image;
        }

        if ($thumbnail)
            $params['thumbnail'] = is_numeric($thumbnail) ? $thumbnail : 150;
        return Url::toRoute($params);
    }

    public static function addData($data)
    {
        if (self::find()->count() != 0) {
            return;
        }

        $faker = \Faker\Factory::create();
        foreach ($data as $item) {
            $model = new self();
            $model->loadDefaultValues();

            $model->title = isset($item['title']) ? $item['title'] : $faker->text(10);

            $model->service_id = isset($item['service_id']) ? $item['service_id'] : 1;

            $model->full_name = isset($item['full_name']) ? $item['full_name'] : $faker->name;

            $model->contact_no = isset($item['contact_no']) ? $item['contact_no'] : $faker->text(10);

            $model->address = isset($item['address']) ? $item['address'] : $faker->text(10);

            $model->city = isset($item['city']) ? $item['city'] : $faker->text(10);

            $model->state = isset($item['state']) ? $item['state'] : 0;

            $model->country = isset($item['country']) ? $item['country'] : $faker->text(10);

            $model->latitude = isset($item['latitude']) ? $item['latitude'] : $faker->text(10);

            $model->longitude = isset($item['longitude']) ? $item['longitude'] : $faker->text(10);

            $model->description = isset($item['description']) ? $item['description'] : $faker->text;

            $model->date = isset($item['date']) ? $item['date'] : \date('Y-m-d H:i:s');
            $model->state_id = self::STATE_ACTIVE;

            $model->type_id = isset($item['type_id']) ? $item['type_id'] : 0;
            $model->save();
        }
    }

    public function isAllowed()
    {
        if (User::isAdmin())
            return true;
        if ($this->hasAttribute('created_by_id') && $this->created_by_id == Yii::$app->user->id) {
            return true;
        }

        return User::isUser();
    }

    public function afterSave($insert, $changedAttributes)
    {
        return parent::afterSave($insert, $changedAttributes);
    }

    public static function generateUniqueId()
    {
        $randomNumber = mt_rand(100000, 999999); // Generates a random number between 100000 and 999999
        return $randomNumber;
    }
}
