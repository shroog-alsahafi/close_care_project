<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\booking\models;

use Yii;
use app\models\Feed;
use app\modules\booking\models\Booking as Booking;
use app\models\User;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "tbl_booking_report".
 *
 * @property integer $id
 * @property string $name
 * @property integer $patient_id
 * @property integer $booking_id
 * @property string $date_of_birth
 * @property integer $age
 * @property string $nationality
 * @property string $blood_pressure
 * @property string $pulse
 * @property string $temperature
 * @property string $skin
 * @property string $conclusion
 * @property integer $state_id
 * @property integer $type_id
 * @property string $created_on
 * @property integer $created_by_id
 * @property Booking $booking
 * @property User $createdBy
 */
class Report extends \app\components\TActiveRecord
{

    public function __toString()
    {
        return (string) $this->name;
    }

    public static function getPatientOptions()
    {
        return [
            "TYPE1",
            "TYPE2",
            "TYPE3"
        ];
    }

    public function getPatient()
    {
        $list = self::getPatientOptions();
        return isset($list[$this->patient_id]) ? $list[$this->patient_id] : 'Not Defined';
    }

    public static function getBookingOptions()
    {
        return [
            "TYPE1",
            "TYPE2",
            "TYPE3"
        ];
        // return self::listData ( Booking::findActive ()->all () );
    }

    const STATE_INACTIVE = 0;

    const STATE_ACTIVE = 1;

    const STATE_DELETED = 2;

    public static function getStateOptions()
    {
        return [
            self::STATE_INACTIVE => "New",
            self::STATE_ACTIVE => "Active",
            self::STATE_DELETED => "Deleted"
        ];
    }

    public function getState()
    {
        $list = self::getStateOptions();
        return isset($list[$this->state_id]) ? $list[$this->state_id] : 'Not Defined';
    }

    public function getStateBadge()
    {
        $list = [
            self::STATE_INACTIVE => "secondary",
            self::STATE_ACTIVE => "success",
            self::STATE_DELETED => "danger"
        ];
        return isset($list[$this->state_id]) ? \yii\helpers\Html::tag('span', $this->getState(), [
            'class' => 'badge bg-' . $list[$this->state_id]
        ]) : 'Not Defined';
    }

    public static function getActionOptions()
    {
        return [
            self::STATE_INACTIVE => "Deactivate",
            self::STATE_ACTIVE => "Activate",
            self::STATE_DELETED => "Delete"
        ];
    }

    public static function getTypeOptions()
    {
        return [
            "TYPE1",
            "TYPE2",
            "TYPE3"
        ];
    }

    public function getType()
    {
        $list = self::getTypeOptions();
        return isset($list[$this->type_id]) ? $list[$this->type_id] : 'Not Defined';
    }

    public function beforeValidate()
    {
        if ($this->isNewRecord) {
            if (empty($this->created_on)) {
                $this->created_on = \date('Y-m-d H:i:s');
            }
            if (empty($this->created_by_id)) {
                $this->created_by_id = self::getCurrentUser();
            }
        } else {}
        return parent::beforeValidate();
    }

    /**
     *
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%booking_report}}';
    }

    /**
     *
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [
                    'name',
                    'patient_id',
                    'booking_id',
                    'date_of_birth',
                    'age',
                    'nationality',
                    'blood_pressure',
                    'pulse',
                    'temperature',
                    'skin',
                    'conclusion',
                    'created_by_id'
                ],
                'required'
            ],
            [
                [
                    'patient_id',
                    'booking_id',
                    'age',
                    'state_id',
                    'type_id',
                    'created_by_id'
                ],
                'integer'
            ],
            [
                [
                    'date_of_birth',
                    'created_on'
                ],
                'safe'
            ],
            [
                [
                    'conclusion'
                ],
                'string'
            ],
            [
                [
                    'name',
                    'nationality',
                    'blood_pressure',
                    'pulse',
                    'temperature',
                    'skin'
                ],
                'string',
                'max' => 126
            ],
            [
                [
                    'booking_id'
                ],
                'exist',
                'skipOnError' => true,
                'targetClass' => Booking::class,
                'targetAttribute' => [
                    'booking_id' => 'id'
                ]
            ],
            [
                [
                    'created_by_id'
                ],
                'exist',
                'skipOnError' => true,
                'targetClass' => User::class,
                'targetAttribute' => [
                    'created_by_id' => 'id'
                ]
            ],
            [
                [
                    'name',
                    'nationality',
                    'blood_pressure',
                    'pulse',
                    'temperature',
                    'skin'
                ],
                'trim'
            ],
           /*  [
                [
                    'name'
                ],
                'app\components\validators\TNameValidator'
            ], */
            [
                [
                    'state_id'
                ],
                'in',
                'range' => array_keys(self::getStateOptions())
            ],
            [
                [
                    'type_id'
                ],
                'in',
                'range' => array_keys(self::getTypeOptions())
            ]
        ];
    }

    /**
     *
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'patient_id' => Yii::t('app', 'Patient'),
            'booking_id' => Yii::t('app', 'Booking'),
            'date_of_birth' => Yii::t('app', 'Date Of Birth'),
            'age' => Yii::t('app', 'Age'),
            'nationality' => Yii::t('app', 'Nationality'),
            'blood_pressure' => Yii::t('app', 'Blood Pressure'),
            'pulse' => Yii::t('app', 'Pulse'),
            'temperature' => Yii::t('app', 'Temperature'),
            'skin' => Yii::t('app', 'Skin'),
            'conclusion' => Yii::t('app', 'Conclusion'),
            'state_id' => Yii::t('app', 'State'),
            'type_id' => Yii::t('app', 'Type'),
            'created_on' => Yii::t('app', 'Created On'),
            'created_by_id' => Yii::t('app', 'Created By')
        ];
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBooking()
    {
        return $this->hasOne(Booking::class, [
            'id' => 'booking_id'
        ])->cache();
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::class, [
            'id' => 'created_by_id'
        ])->cache();
    }
    
    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPatientName()
    {
        return $this->hasOne(User::class, [
            'id' => 'patient_id'
        ])->cache();
    }

    public static function getHasManyRelations()
    {
        $relations = [];

        $relations['feeds'] = [
            'feeds',
            'Feed',
            'model_id'
        ];
        return $relations;
    }

    public static function getHasOneRelations()
    {
        $relations = [];
        $relations['booking_id'] = [
            'booking',
            'Booking',
            'id'
        ];
        $relations['created_by_id'] = [
            'createdBy',
            'User',
            'id'
        ];
        return $relations;
    }

    public function beforeDelete()
    {
        if (! parent::beforeDelete()) {
            return false;
        }
        // TODO : start here

        return true;
    }

    public function beforeSave($insert)
    {
        if (! parent::beforeSave($insert)) {
            return false;
        }
        // TODO : start here

        return true;
    }

    public function asJson($with_relations = false)
    {
        $json = [];
        $json['id'] = $this->id;
        $json['name'] = $this->name;
        $json['patient_id'] = $this->patient_id;
        $json['booking_id'] = $this->booking_id;
        $json['date_of_birth'] = $this->date_of_birth;
        $json['age'] = $this->age;
        $json['nationality'] = $this->nationality;
        $json['blood_pressure'] = $this->blood_pressure;
        $json['pulse'] = $this->pulse;
        $json['temperature'] = $this->temperature;
        $json['skin'] = $this->skin;
        $json['conclusion'] = $this->conclusion;
        $json['state_id'] = $this->state_id;
        $json['type_id'] = $this->type_id;
        if ($with_relations) {
            // booking
            $list = $this->booking;

            if (is_array($list)) {
                $relationData = array_map(function ($item) {
                    return $item->asJson();
                }, $list);

                $json['booking'] = $relationData;
            } else {
                $json['booking'] = $list;
            }
            // createdBy
            $list = $this->createdBy;

            if (is_array($list)) {
                $relationData = array_map(function ($item) {
                    return $item->asJson();
                }, $list);

                $json['createdBy'] = $relationData;
            } else {
                $json['createdBy'] = $list;
            }
        }
        return $json;
    }

    public function getControllerID()
    {
        return '/booking/' . parent::getControllerID();
    }

    public static function addTestData($count = 1)
    {
        $faker = \Faker\Factory::create();
        $states = array_keys(self::getStateOptions());
        for ($i = 0; $i < $count; $i ++) {
            $model = new self();
            $model->loadDefaultValues();
            $model->name = $faker->text(10);
            $model->patient_id = 1;
            $model->booking_id = 1;
            $model->date_of_birth = \date('Y-m-d');
            $model->age = $faker->text(10);
            $model->nationality = $faker->text(10);
            $model->blood_pressure = $faker->text(10);
            $model->pulse = $faker->text(10);
            $model->temperature = $faker->text(10);
            $model->skin = $faker->text(10);
            $model->conclusion = $faker->text;
            $model->state_id = $states[rand(0, count($states) - 1)];
            $model->type_id = 0;
            $model->save();
        }
    }

    public static function addData($data)
    {
        if (self::find()->count() != 0) {
            return;
        }

        $faker = \Faker\Factory::create();
        foreach ($data as $item) {
            $model = new self();
            $model->loadDefaultValues();

            $model->name = isset($item['name']) ? $item['name'] : $faker->text(10);

            $model->patient_id = isset($item['patient_id']) ? $item['patient_id'] : 1;

            $model->booking_id = isset($item['booking_id']) ? $item['booking_id'] : 1;

            $model->date_of_birth = isset($item['date_of_birth']) ? $item['date_of_birth'] : \date('Y-m-d');

            $model->age = isset($item['age']) ? $item['age'] : $faker->text(10);

            $model->nationality = isset($item['nationality']) ? $item['nationality'] : $faker->text(10);

            $model->blood_pressure = isset($item['blood_pressure']) ? $item['blood_pressure'] : $faker->text(10);

            $model->pulse = isset($item['pulse']) ? $item['pulse'] : $faker->text(10);

            $model->temperature = isset($item['temperature']) ? $item['temperature'] : $faker->text(10);

            $model->skin = isset($item['skin']) ? $item['skin'] : $faker->text(10);

            $model->conclusion = isset($item['conclusion']) ? $item['conclusion'] : $faker->text;
            $model->state_id = self::STATE_ACTIVE;

            $model->type_id = isset($item['type_id']) ? $item['type_id'] : 0;
            $model->save();
        }
    }

    public function isAllowed()
    {
        if (User::isAdmin())
            return true;
        if ($this->hasAttribute('created_by_id') && $this->created_by_id == Yii::$app->user->id) {
            return true;
        }

        return User::isUser();
    }

    public function afterSave($insert, $changedAttributes)
    {
        return parent::afterSave($insert, $changedAttributes);
    }
}
