<?php
namespace app\modules\chat\api;

use app\components\filters\AccessControl;
use app\components\filters\AccessRule;
# use app\modules\chat\models\ChatMessage;
use app\modules\api\components\ApiBaseController;
use app\models\User;
use yii\data\ActiveDataProvider;
use yii\helpers\ArrayHelper;
use app\modules\chat\models\Chat;
use app\modules\api\components\TSerializer;
use yii\db\ActiveQuery;
use yii\data\ArrayDataProvider;
use app\modules\booking\models\Booking;
use app\modules\notification\models\Notification;

/**
 * ChatMessageController implements the API actions for ChatMessage model.
 */
class ChatMessageController extends ApiBaseController
{

    public $modelClass = "app\modules\chat\models\Chat";

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [
                    [
                        'actions' => [
                            'send-message',
                            'load-chat',
                            'load-new-message',
                            'user-list'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isUser() || User::isProvider();
                        }
                    ]
                ]
            ]
        ];
    }

    public function actions()
    {
        $actions = parent::actions();
        // unset($actions['create']);
        // unset($actions['update']);
        // unset($actions['delete']);
        // unset($actions['view']);
        // unset($actions['index']);
        return $actions;
    }

    /**
     *
     * @OA\Post(path="/chat/send-message",
     *   summary="",
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   tags={"Chat"},
     *    @OA\RequestBody(
     *       @OA\MediaType(
     *           mediaType="multipart/form-data",
     *           @OA\Schema(
     *           required={"Chat[message]","Chat[to_id]","Chat[type_id]"},
     *              @OA\Property(property="Chat[message]", type="string", format="text", example="Testing",description="Message"),
     *              @OA\Property(property="Chat[to_id]", type="integer", format="text", example="1",description="To ID"),
     *              @OA\Property(property="Chat[booking_id]", type="integer", format="text", example="1",description="Booking ID"),
     *              @OA\Property(property="Chat[type_id]", type="integer", example="1",description="
     *                           TYPE_TEXT_MESSAGE = 0;
     *                           TYPE_MEDIA_FILE = 1;
     *                            "),     *           ),
     *       ),
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Create new user",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionSendMessage()
    {
        $this->setStatus(400);
        $data = [];
        $chatModel = new Chat();
        $post = \Yii::$app->request->post();
        if ($chatModel->load($post) || ! empty($_FILES)) {

            $booking = Booking::findOne($chatModel->booking_id);

            if (empty($booking)) {
                $data['message'] = \Yii::t('app', 'Booking not found');
                return $data;
            }

            $fromID = \Yii::$app->user->id;
            $users = [
                $chatModel->to_id,
                $fromID
            ];
            $chatModel->from_id = $fromID;
            $chatModel->users = implode(',', $users);
            $chatModel->readers = implode(',', [
                \Yii::$app->user->id
            ]);
            $chatModel->is_read = Chat::IS_READ_NO;
            if ($chatModel->type_id == Chat::TYPE_MEDIA_FILE || $chatModel->type_id == Chat::TYPE_TEXT_MESSAGE) {
                if (! empty($_FILES)) {
                    $chatModel->saveUploadedFile($chatModel, 'message');
                }
            } else {
                $data['message'] = \Yii::t('app', 'Invalid type_id.');
                $data['detail'] = null;
                return $data;
            }
            if (! $chatModel->save()) {
                $data['error'] = $chatModel->getErrorsString();
            } else {

                Notification::create([
                    'html' => \Yii::t('app', $chatModel->message . ' from ' . \Yii::$app->user->identity->full_name),
                    'to_user_id' => $chatModel->to_id,
                    'created_by_id' => \Yii::$app->user->id,
                    'title' => \Yii::t('app', $chatModel->message . ' from ' . \Yii::$app->user->identity->full_name),
                    'model' => $chatModel
                ], false);

                $data['message'] = \Yii::t('app', 'Message send successfully');
                $this->setStatus(200);
                $data['list'] = $chatModel->asJson();
            }
        }
        return $data;
    }

    /**
     *
     * @OA\Get(path="/chat/load-chat",
     *   summary="",
     *   tags={"Chat"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     * @OA\Parameter(
     *     name="user_id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Parameter(
     *     name="booking_id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     * @OA\Parameter(
     *     name="date",
     *     in="query",
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Loading the user chat",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionLoadChat($user_id, $booking_id, $date = null, $search = null)
    {
        $query = Chat::find()->where([
            'booking_id' => $booking_id
        ])->andWhere([
            'or',
            [
                'from_id' => $user_id,
                'to_id' => \Yii::$app->user->id
            ],
            [
                'from_id' => \Yii::$app->user->id,
                'to_id' => $user_id
            ]
        ]);
        if (! empty($date)) {

            $query->andWhere([
                'date(created_on)' => $date
            ]);
        }
        if (! empty($search)) {

            $query->andWhere([
                'like',
                'message',
                $search
            ]);
        }
        $readQuery = Chat::find()->where([
            'from_id' => $user_id,
            'to_id' => \Yii::$app->user->id
        ]);

        $ids = $readQuery->column();
        foreach ($ids as $value) {
            $model = Chat::findOne($value);
            if (! empty($model)) {
                $model->is_read = Chat::IS_READ_YES;
                $model->updateAttributes([
                    'is_read'
                ]);
            }
        }

        if (! empty($date)) {
            $query->andWhere([
                'date(created_on)' => $date
            ]);
        }

        if (! empty($search)) {
            $query->andWhere([
                'like',
                'message',
                $search
            ]);
        }

        Chat::updateAll([
            'is_read' => Chat::IS_READ_YES
        ], [
            'from_id' => $user_id,
            'to_id' => \Yii::$app->user->id
        ]);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => false,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_ASC
                ]
            ]
        ]);
        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     *
     * @OA\Post(path="/chat/load-new-message",
     *   summary="",
     *   tags={"Chat"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *    @OA\Parameter(
     *     name="with_id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Parameter(
     *     name="booking_id",
     *     in="query",
     *     required=true,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *    @OA\Parameter(
     *     name="page",
     *     in="query",
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Create new user",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionLoadNewMessage($with_id, $booking_id, $page = 0)
    {
        $models = Chat::find()->select('id')
            ->where(new \yii\db\Expression('FIND_IN_SET(:readers,readers)'))
            ->andWhere([
            'from_id' => $with_id,
            'booking_id' => $booking_id,
            'to_id' => \Yii::$app->user->id
        ]);

        $models = $models->addParams([
            ':readers' => \Yii::$app->user->id
        ])->column();

        $query = Chat::find()->where([
            'from_id' => $with_id,
            'to_id' => \Yii::$app->user->id,
            'booking_id' => $booking_id,
            'is_read' => Chat::IS_READ_NO
        ])->andWhere([
            'not in',
            'id',
            $models
        ]);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ],

            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_ASC
                ]
            ]
        ]);
        $list = [];
        $id = \Yii::$app->user->id;
        if (! empty($dataProvider->getCount() > 0)) {
            foreach ($dataProvider->getModels() as $model) {
                $readers = [];
                if (! empty($model->readers)) {
                    $readers = explode(',', $model->readers);
                }
                $alreadyRead = in_array($id, $readers);
                if (! $alreadyRead) {
                    $model->readers = implode(',', array_merge($readers, [
                        $id
                    ]));
                    $model->is_read = Chat::IS_READ_YES;

                    $model->updateAttributes([
                        'readers',
                        'is_read'
                    ]);
                    $list[] = $model->asJson();
                }
            }
        }
        return $dataProvider;
    }

    function sortByID($a, $b, $keyName)
    {
        $a = $a[$keyName];
        $b = $b[$keyName];

        if ($a == $b)
            return 0;
        return ($a < $b) ? - 1 : 1;
    }

    /**
     *
     * @OA\Get(
     *     path="/chat/user-list",
     *     summary="",
     *     tags={"Chat"},
     *     security={
     *         {"bearerAuth": {}}
     *     },
     *
     *   @OA\Parameter(
     *     name="page",
     *     in="query",
     *     description="page",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *
     *     )
     *   ),
     *   @OA\Response(
     *         response=200,
     *         description="List of users",
     *         @OA\MediaType(
     *             mediaType="application/json"
     *         )
     *     )
     * )
     */
    public function actionUserList($page = 0)
    {
        $this->setStatus(400);

        $bookingQuery = User::find()->alias('u')
            ->joinWith([
            'booking as b'
        ])
            ->where([
            'b.provider_id' => \Yii::$app->user->id
        ]);

        $dataProvider = new ActiveDataProvider([
            'query' => $bookingQuery,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ]
        ]);

        $this->setStatus(200);
        return $dataProvider;
    }
}
