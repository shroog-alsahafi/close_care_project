<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
namespace app\modules\chat\controllers;

use Yii;
use app\components\TController;
use app\models\User;
use app\modules\chat\Module;
use app\modules\chat\models\Chat;
use yii\data\ActiveDataProvider;
use yii\filters\AccessControl;
use yii\filters\AccessRule;
use yii\db\ActiveQuery;

/**
 * Default controller for the `firestorechat` module
 */
class DefaultController extends TController
{

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'ruleConfig' => [
                    'class' => AccessRule::className()
                ],
                'rules' => [
                    [
                        'actions' => [
                            'chat-list',
                            'load-chat',
                            'send-message',
                            'index',
                            'load-new-message',
                            'unread-count',
                            'user-list',
                            'image',
                            'chat',
                            'message-read-status'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isUser();
                        }
                    ],
                    [
                        'actions' => [
                            'chat-list',
                            'load-chat',
                            'send-message',
                            'index',
                            'load-new-message',
                            'unread-count',
                            'user-list',
                            'image'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isAdmin();
                        }
                    ],
                    [
                        'actions' => [
                            'image'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isGuest();
                        }
                    ]
                ]
            ],
            'verbs' => [
                'class' => \yii\filters\VerbFilter::className(),
                'actions' => [
                    'delete' => [
                        'post'
                    ]
                ]
            ]
        ];
    }

     /**
     * Renders the index view for the module
     *
     * @return string
     */
    public function actionIndex()
    {
        return $this->render('index');
    }

    public function actionChat($id)
    {
        return $this->render('chat');
    }

    public function actions()
    {
        return [

            'image' => [
                'class' => 'app\components\actions\ImageAction',
                'modelClass' => Chat::class,
                'attribute' => 'message'
            ]
        ];
    }

    public function actionUnreadCount()
    {
        \Yii::$app->response->format = "json";

        $data = [];
        $unreadCount = Chat::find()->where([
            'to_id' => \Yii::$app->user->id
        ])
            ->andWhere([
            'is_read' => Chat::IS_READ_NO
        ])
            ->count();

        $data['unNotifiedMessage'] = Chat::notifyUsers();
        \Yii::$app->response->setStatusCode(200);
        $data['count'] = $unreadCount;

        return $data;
    }

    public function actionLoadNewMessage($user_id)
    {
        \Yii::$app->response->format = "json";
        \Yii::$app->response->setStatusCode(400);
        $data = [];

        $query = Chat::find()->where([
            'from_id' => $user_id,
            'to_id' => \Yii::$app->user->id
        ])->andWhere([
            'is_read' => Chat::IS_READ_NO
        ]);

        $list = [];
        if (! empty($query->count())) {
            $id = \Yii::$app->user->id;
            foreach ($query->each() as $model) {
                $alreadyRead = in_array($id, explode(',', ! empty($model->readers) ? $model->readers : ''));
                if (! $alreadyRead) {
                    $model->readers = empty($model->readers) ?: $model->readers . ',' . $id;
                }
                $list[] = $model->asJson();
                if ($model->to_id == \Yii::$app->user->id) {
                    $model->is_read = Chat::IS_READ_YES;
                    $model->notified_users = Chat::IS_READ_NO;
                }

                $model->save(false, [
                    'is_read',
                    'readers',
                    'notified_users'
                ]);
            }

            \Yii::$app->response->setStatusCode(200);
            $data['chat_messages'] = $list;
        } else {
            $data['error'] = "No new message found.";
        }

        return $data;
    }

    public function actionSendMessage($request_id = NULL)
    {
        \Yii::$app->response->format = "json";
        \Yii::$app->response->setStatusCode(400);
        $data = [];

        $chat = new Chat();

        if ($chat->load(\Yii::$app->request->post()) || ! empty($_FILES)) {

            if (! empty($request_id)) {
                $request_id = $request_id;
            } else {
                $request_id = $chat->request_id;
            }

            $fromID = \Yii::$app->user->id;
            $users = [
                $chat->to_id,
                $fromID
            ];

            $chat->from_id = $fromID;
            $chat->request_id = $request_id;

            $chat->users = implode(',', $users);
            $chat->is_read = Chat::IS_READ_NO;

            $chat->readers = (string) $fromID;

            $chat->saveUploadedFile($chat, 'message');
            if (! $chat->save()) {
                $data['error'] = $chat->getErrorsString();
            } else {
                \Yii::$app->response->setStatusCode(200);
                $data['message'] = $chat->asJson();
            }
        }
        return $data;
    }

    public function actionChatList($id = null, $query = NULL)
    {
        \Yii::$app->response->format = "json";
        \Yii::$app->response->setStatusCode(400);
        $data = [];

        $userModel = User::find()->alias('u')
            ->joinWith([
            'fromChat as fc',
            'toChat as tc'
        ])
            ->where([
            '!=',
            'u.id',
            \Yii::$app->user->id
        ])
            ->andWhere([
            'or',
            [
                'fc.from_id' => \Yii::$app->user->id
            ],
            [
                'fc.to_id' => \Yii::$app->user->id
            ],
            [
                'tc.from_id' => \Yii::$app->user->id
            ],
            [
                'tc.to_id' => \Yii::$app->user->id
            ]
        ]);

        if (! empty($query)) {
            $userModel = $userModel->andWhere([
                'like',
                "full_name",
                $query
            ]);
        }
        
        $userModel= $userModel->distinct();

        $list = [];

        foreach ($userModel->each() as $model) {

            $list[] = Chat::getUserDetail($model);
        }

        usort($list, function ($a, $b) {
            $a = $a['last_message_id'];
            $b = $b['last_message_id'];

            if ($a == $b)
                return 0;
            return ($a < $b) ? 1 : - 1;
        });

        \Yii::$app->response->setStatusCode(200);

        $data['chat_list'] = $list;

        return $data;
    }

    public function actionLoadChat($id, $page = 0)
    {
        \Yii::$app->response->format = "json";
        \Yii::$app->response->setStatusCode(400);
        $data = [];
        $toUser = Module::self()->identityClass::findOne($id);

        $query = Chat::find()->where([
            'OR',
            [
                'from_id' => $id,
                'to_id' => \Yii::$app->user->id
            ],
            [
                'from_id' => \Yii::$app->user->id,
                'to_id' => $id
            ]
        ]);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 8,
                'page' => $page
            ],

            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ]
        ]);
        $list = [];
        if (! empty($dataProvider->getCount() > 0)) {
            $id = \Yii::$app->user->id;
            foreach ($dataProvider->getModels() as $model) {

                if ($model->is_read == Chat::IS_READ_NO && $model->to_id == \Yii::$app->user->id) {
                    $model->is_read = Chat::IS_READ_YES;
                }
                $alreadyRead = in_array($id, explode(',', $model->readers ?? ''));

                if (! $alreadyRead) {
                    $model->readers = empty($model->readers) ?: $model->readers . ',' . $id;
                }
                $model->save(false, [
                    'is_read',
                    'readers'
                ]);
                $list[] = $model->asJson();
            }
            usort($list, function ($a, $b) {
                $a = $a['id'];
                $b = $b['id'];

                if ($a == $b)
                    return 0;
                return ($a < $b) ? - 1 : 1;
            });

            \Yii::$app->response->setStatusCode(200);
            $data['chat_messages'] = $list;

            $data['page'] = $page;
        } else {
            $data['error'] = "No chat found.";
        }
        $data['user_detail'] = ! empty($toUser) ? Chat::getUserDetail($toUser) : "";
        return $data;
    }

    function sortByID($a, $b, $keyName)
    {
        $a = $a[$keyName];
        $b = $b[$keyName];

        if ($a == $b)
            return 0;
        return ($a < $b) ? - 1 : 1;
    }

    public function actionUserList()
    {
        $query = \Yii::$app->request->get('query');
        \Yii::$app->response->setStatusCode(400);
        \Yii::$app->response->format = "json";
        $data = [];

        if (! empty($query)) {
            $userModels = User::find()->alias('u')
                ->joinWith([
                'fromChat as fc' => function (ActiveQuery $query) {
                    return $query->andWhere([
                        'or',
                        [
                            'fc.from_id' => \Yii::$app->user->id
                        ],
                        [
                            'fc.to_id' => \Yii::$app->user->id
                        ]
                    ])
                        ->orderBy('fc.created_on DESC');
                }
            ])
                ->andWhere([
                '!=',
                'u.id',
                \Yii::$app->user->id
            ]);
            $html = '';
            if (! empty($userModels)) {
                foreach ($userModels as $user) {
                    $html .= \Yii::$app->controller->renderPartial('user-list', [
                        'user' => $user
                    ]);
                }
                \Yii::$app->response->setStatusCode(200);
                $data['htmlData'] = $html;
            } else {
                $data['error'] = "No matching user found.";
            }
        } else {
            $data['error'] = "Start typing to search users";
        }
        return $data;
    }

    public function actionMessageReadStatus($id)
    {
        $data = [];
        \Yii::$app->response->setStatusCode(200);
        \Yii::$app->response->format = "json";
        $query = Chat::find()->where([
            'from_id' => \Yii::$app->user->id,
            'to_id' => $id,
            'notified_users' => Chat::IS_READ_NO
        ]);
        $list = [];
        foreach ($query->each() as $model) {
            $model->notified_users = Chat::IS_READ_YES;

            $model->updateAttributes([
                'notified_users'
            ]);

            $list[] = $model->asJson();
        }

        $data['list'] = $list;
        return $data;
    }
}
