<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
use yii\db\Migration;

/**
 * php console.php module/migrate
 */
class m240711_100716_add_tbl_chat extends Migration
{

    public function safeUp()
    {
        $table = Yii::$app->db->schema->getTableSchema('{{%chat}}');

        if (! isset($table)) {

            $this->execute("DROP TABLE IF EXISTS `tbl_chat`;
            CREATE TABLE IF NOT EXISTS `tbl_chat` (
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `message`longtext COLLATE utf8mb4_unicode_ci NOT NULL,
              `users` text COLLATE utf8mb4_unicode_ci,
              `from_id` int(11) DEFAULT NULL,
              `to_id` int(11) DEFAULT NULL,
              `request_id` int(11) DEFAULT NULL,
              `readers` text COLLATE utf8mb4_unicode_ci,
              `created_on` datetime DEFAULT NULL,
              `updated_on` datetime DEFAULT NULL,
              `is_read` int(11) NOT NULL DEFAULT '0',
              `notified_users` text COLLATE utf8mb4_unicode_ci,
              `state_id` int(11) NOT NULL DEFAULT '1',
              `type_id` int(11) NOT NULL DEFAULT '0',
              PRIMARY KEY (`id`)
            ) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        }
    }

    public function safeDown()
    {
        $table = Yii::$app->db->schema->getTableSchema('{{%chat}}');
        if (isset($table)) {
            $this->dropTable('{{%chat}}');
        }
    }
}