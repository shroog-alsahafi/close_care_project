<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\chat\models;

use Yii;
use app\models\Feed;
use yii\helpers\ArrayHelper;
use app\modules\chat\Module;
use app\models\User;
use yii\authclient\clients\Yandex;
use yii\helpers\Url;

/**
 * This is the model class for table "tbl_chat".
 *
 * @property integer $id
 * @property string $message
 * @property string $users
 * @property integer $from_id
 * @property integer $to_id
 * @property string $readers
 * @property string $created_on
 * @property string $updated_on
 * @property integer $is_read
 * @property integer $state_id
 * @property integer $type_id
 */
class Chat extends \app\components\TActiveRecord
{

    public function __toString()
    {
        return (string) $this->message;
    }

    const TYPE_TEXT_MESSAGE = 0;

    const TYPE_MEDIA_FILE = 1;

    const IS_READ_YES = 1;

    const IS_READ_NO = 0;

    const CHAT_USER = 0;

    public static function getIsReadOptions()
    {
        return [
            self::IS_READ_NO => "No",
            self::IS_READ_YES => "Yes"
        ];
    }

    public function getIsRead()
    {
        $list = self::getIsReadOptions();
        return isset($list[$this->is_read]) ? $list[$this->is_read] : 'Not Defined';
    }

    public function getFrom()
    {
        return $this->hasOne(Module::self()->identityClass::className(), [
            'id' => 'from_id'
        ]);
    }

    public function getTo()
    {
        return $this->hasOne(Module::self()->identityClass::className(), [
            'id' => 'to_id'
        ]);
    }

    public static function getGroupOptions()
    {
        return [
            "TYPE1",
            "TYPE2",
            "TYPE3"
        ];
    }

    const STATE_INACTIVE = 0;

    const STATE_ACTIVE = 1;

    const STATE_DELETED = 2;

    public static function getStateOptions()
    {
        return [
            self::STATE_INACTIVE => "New",
            self::STATE_ACTIVE => "Active",
            self::STATE_DELETED => "Deleted"
        ];
    }

    public function getState()
    {
        $list = self::getStateOptions();
        return isset($list[$this->state_id]) ? $list[$this->state_id] : 'Not Defined';
    }

    public function getStateBadge()
    {
        $list = [
            self::STATE_INACTIVE => "secondary",
            self::STATE_ACTIVE => "success",
            self::STATE_DELETED => "danger"
        ];
        return isset($list[$this->state_id]) ? \yii\helpers\Html::tag('span', $this->getState(), [
            'class' => 'badge badge-' . $list[$this->state_id]
        ]) : 'Not Defined';
    }

    public static function getActionOptions()
    {
        return [
            self::STATE_INACTIVE => "Deactivate",
            self::STATE_ACTIVE => "Activate",
            self::STATE_DELETED => "Delete"
        ];
    }

    public static function getTypeOptions()
    {
        return [
            self::TYPE_TEXT_MESSAGE => "text message",
            Self::TYPE_MEDIA_FILE => "Media file"
        ];
    }

    public function getType()
    {
        $list = self::getTypeOptions();
        return isset($list[$this->type_id]) ? $list[$this->type_id] : 'Not Defined';
    }

    public function beforeValidate()
    {
        if ($this->isNewRecord) {
            if (empty($this->created_on)) {
                $this->created_on = date('Y-m-d H:i:s');
            }
            if (empty($this->updated_on)) {
                $this->updated_on = date('Y-m-d H:i:s');
            }
        } else {
            $this->updated_on = date('Y-m-d H:i:s');
        }
        return parent::beforeValidate();
    }

    /**
     *
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%chat}}';
    }

    /**
     *
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [
//                     'message'
                ],
                'required'
            ],
            [
                [
                    'users',
                    'readers'
                ],
                'string'
            ],
            [
                [
                    'from_id',
                    // 'to_id',
                    'request_id',
                    'is_read',
                    'state_id',
                    'type_id'
                ],
                'integer'
            ],
            [
                [
                    'created_on',
                    'updated_on',
                    'readers',
                    'notified_users',
                    'to_id',
                    'request_id',
                    'booking_id'
                ],
                'safe'
            ],
           /*  [
                [
                    'message'
                ],
                'string',
                'max' => 1024
            ], */
            [
                [
                    'message'
                ],
                'trim'
            ],
            [
                [
                    'state_id'
                ],
                'in',
                'range' => array_keys(self::getStateOptions())
            ],
            [
                [
                    'type_id'
                ],
                'in',
                'range' => array_keys(self::getTypeOptions())
            ]
        ];
    }

    /**
     *
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'message' => Yii::t('app', 'Message'),
            'users' => Yii::t('app', 'Users'),
            'from_id' => Yii::t('app', 'From'),
            'to_id' => Yii::t('app', 'To'),
            'readers' => Yii::t('app', 'Readers'),
            'created_on' => Yii::t('app', 'Created On'),
            'updated_on' => Yii::t('app', 'Updated On'),
            'is_read' => Yii::t('app', 'Is Read'),
            'state_id' => Yii::t('app', 'State'),
            'type_id' => Yii::t('app', 'Type')
        ];
    }

    public static function getHasManyRelations()
    {
        $relations = [];

        $relations['feeds'] = [
            'feeds',
            'Feed',
            'model_id'
        ];
        return $relations;
    }

    public static function getHasOneRelations()
    {
        $relations = [];
        return $relations;
    }

    public function beforeDelete()
    {
        if (! parent::beforeDelete()) {
            return false;
        }
        // TODO : start here
        return true;
    }

    public function beforeSave($insert)
    {
        if (! parent::beforeSave($insert)) {
            return false;
        }
        // TODO : start here

        return true;
    }

    public function getToUser()
    {
        return $this->hasOne(User::className(), [
            'id' => 'to_id'
        ]);
    }

    public function getFromUser()
    {
        return $this->hasOne(User::className(), [
            'id' => 'from_id'
        ]);
    }

    // remove contact number and email from message at without subscription time
    public static function filterMessage($string)
    {
        $num = range(0, 9);
        $pattern = "/[^@\s]*@[^@\s]*\.[^@\s]*/";

        // replace contact number
        $string = str_replace($num, '*', $string);

        // replace contact number
        $string = preg_replace($pattern, '************', $string);

        return $string;
    }

    public function getMessageUrl($thumbnail = false)
    {
        $params = [
            '/' . $this->getControllerID() . '/default/image'
        ];
        $params['id'] = $this->id;

        if (isset($this->message) && ! empty($this->message)) {
            $params['file'] = $this->message;
        }

        if ($thumbnail)
            $params['thumbnail'] = is_numeric($thumbnail) ? $thumbnail : 150;

        return Url::toRoute($params, true);
    }

    public function asJson($with_relations = false)
    {
        $json = [];
        $json['id'] = $this->id;

        if ($this->type_id == Self::TYPE_MEDIA_FILE) {
            if (! empty($this->message) && file_exists(UPLOAD_PATH . '/' . basename($this->message))) {
                $json['message'] = $this->getMessageUrl();
            } else {
                $json['message'] = '';
            }

            $ext = pathinfo($this->message, PATHINFO_EXTENSION);

            if ($ext == 'pdf') {

                $json['is_pdf'] = true;
                $json['thumbnail'] = \Yii::$app->urlManager->createAbsoluteUrl([
                    'themes/new/img/pdf-1.png'
                ]);
            } else {
                $json['is_pdf'] = false;
            }
        } else {

            $json['message'] = self::filterMessage($this->message);

            $json['message'] = $this->message;
        }
        /* $json['users'] = $this->users; */
        $json['from_id'] = $this->from_id;
        $json['from_name'] = ! empty($this->fromUser->full_name) ? $this->fromUser->full_name : '';
        $json['to_name'] = ! empty($this->toUser->full_name) ? $this->toUser->full_name : '';
        $json['to_id'] = $this->to_id;
        $json['readers'] = $this->readers;
        $json['request_id'] = $this->request_id;
        $json['created_on'] = date("h:i A d M Y", strtotime($this->created_on));
        $json['is_read'] = $this->is_read;
        $json['state_id'] = $this->state_id;

        if (! empty($this->fromUser->profile_file)) {
            $json['from_user_profile_file'] = (! empty($this->fromUser->fileUrl) && ! empty($this->fromUser->fileUrl->absoluteUrl)) ? $this->fromUser->fileUrl->absoluteUrl : '';
        } else {

            $json['from_user_profile_file'] = \Yii::$app->urlManager->createAbsoluteUrl([
                'themes/new/img/default.jpg'
            ]);
        }

        if (! empty($this->toUser->profile_file)) {

            $json['to_user_profile_file'] = ! empty($this->toUser->profile_file) ? $this->toUser->fileUrl->absoluteUrl : '';
        } else {
            $json['to_user_profile_file'] = \Yii::$app->urlManager->createAbsoluteUrl([
                'themes/new/img/default.jpg'
            ]);
        }

        $json['message_status'] = Chat::getMessageReadStatus($this->id, $this->from_id, $this->to_id);
        $json['type_id'] = $this->type_id;

        $json['notified_users'] = $this->notified_users;
        $json['send_on'] = $this->created_on;

        if ($with_relations) {}
        return $json;
    }

    public function asSendMessageJson()
    {
        $json = [];
        $json['id'] = $this->id;
        if ($this->type_id == Self::TYPE_MEDIA_FILE) {
            if (! empty($this->message) && file_exists(UPLOAD_PATH . '/' . basename($this->message))) {
                $json['message'] = \Yii::$app->urlManager->createAbsoluteUrl([
                    '/file/files',
                    'file' => $this->message
                ]);
            } else {

                $json['message'] = '';
            }
        } else {
            if (User::getUserInfoStatus()) {
                $json['message'] = $this->message;
            } else {
                $json['message'] = utf8_encode($this->message);
            }
        }
        /* $json['users'] = $this->users; */
        $json['from_id'] = $this->from_id;
        $json['to_id'] = $this->to_id;
        $json['readers'] = $this->readers;
        $json['created_on'] = $this->created_on;
        $json['is_read'] = $this->is_read;
        $json['state_id'] = $this->state_id;

        if (! empty($this->fromUser->profile_file)) {
            $json['from_user_profile_file'] = (! empty($this->fromUser->fileUrl) && ! empty($this->fromUser->fileUrl->absoluteUrl)) ? $this->fromUser->fileUrl->absoluteUrl : '';
        } else {
            
            $json['from_user_profile_file'] = \Yii::$app->urlManager->createAbsoluteUrl([
                'themes/new/img/default.jpg'
            ]);
        }
        
        if (! empty($this->toUser->profile_file)) {
            
            $json['to_user_profile_file'] = ! empty($this->toUser->profile_file) ? $this->toUser->fileUrl->absoluteUrl : '';
        } else {
            $json['to_user_profile_file'] = \Yii::$app->urlManager->createAbsoluteUrl([
                'themes/new/img/default.jpg'
            ]);
        }
        $json['from_name'] = ! empty($this->fromUser->full_name) ? $this->fromUser->full_name : '';
        $json['to_name'] = ! empty($this->toUser->full_name) ? $this->toUser->full_name : '';
        $json['send_on'] = $this->created_on;
        $json['type_id'] = $this->type_id;
        return $json;
    }

    public static function getUserDetail($user = null)
    {
        if ($user->id != \Yii::$app->user->id) {
            $json = [];

            $json['id'] = $user->id;

            $json['full_name'] = ucfirst($user->full_name);
            $json['email'] = $user->email;
            $json['date_of_birth'] = $user->date_of_birth;
            $json['gender'] = $user->gender;
            /*
             * if (! empty($user->profile_file) && file_exists(UPLOAD_PATH . '/' . basename($user->profile_file))) {
             * $json['profile_file'] = $user->getImageUrl();
             * }
             */

            if (is_numeric($user->profile_file)) {
                $json['profile_file'] = (! empty($user->file) && ! empty($user->file->absoluteUrl)) ? $user->file->absoluteUrl : '';
            } else {
                $json['profile_file'] = \Yii::$app->urlManager->createAbsoluteUrl([
                    'themes/new/img/default.jpg'
                ]);
            }

            $json['role_id'] = $user->role_id;
            $json['state_id'] = $user->state_id;

            // $json['last_message'] = ! empty(self::getLastMessage($user->id)) ? substr(self::getLastMessage($user->id), 0, 20) : "";

            $lastMessage = self::getLastMessage($user->id);
            $json['last_message'] = ! empty($lastMessage) ? (strlen($lastMessage) > 20 ? substr($lastMessage, 0, 20) . '...' : $lastMessage) : "";

            $json['last_message_read_status'] = Chat::getLastMessageReadStatus($user->id);
            $last_message = self::getLastMessage($user->id, true);
            $json['last_message_id'] = $last_message;
            if (! empty($last_message)) {
                $chat = Chat::findOne($last_message);

                if (! empty($chat) && $chat->from_id == \Yii::$app->user->id) {

                    $json['from_send'] = true;
                } else {

                    $json['from_send'] = false;
                }
            } else {

                $json['from_send'] = false;
            }

            $json['is_online'] = self::isOnline($user->id);
            $json['last_message_time'] = self::getLastMessageTime($user->id);
            $json['unread_message_count'] = self::unreadMessageCount($user->id);

            return $json;
        }
    }

    public static function getChatJson($model)
    {
        $json = [];
        if (\Yii::$app->user->id == $model->seller_id) {
            $id = $model->created_by_id;
        } else {

            $id = $model->seller_id;
        }
        $user = User::find()->where([
            'id' => $id
        ])
            ->andWhere([
            'not in',
            'id',
            \Yii::$app->user->id
        ])
            ->one();

        // $chat = Chat::find()->where([
        // 'request_id' => $model->id,
        // 'to_id' => $user->id,
        // 'from_id' => \Yii::$app->user->id
        // ])
        // ->one();

        $json['id'] = $user->id;

        $json['request_id'] = ! empty($model->id) ? $model->id : '';
        $json['unique_id'] = ! empty($model->unique_id) ? $model->unique_id : '';
        $json['full_name'] = ucfirst($user->full_name);
        $json['email'] = $user->email;
        $json['date_of_birth'] = $user->date_of_birth;
        $json['gender'] = $user->gender;
        if (! empty($user->profile_file)) {
            $json['profile_file'] = $user->getImageUrl();
        } else {
            $json['profile_file'] = '';
        }
        $json['role_id'] = $user->role_id;
        $json['state_id'] = $user->state_id;
        $json['last_message'] = self::getLastMessage($user->id, $model->id);
        $json['last_message_id'] = self::getLastMessage($user->id, $model->id, true);
        $json['unread_message_count'] = self::unreadMessageCount($user->id, $model->id);
        $json['last_message_time'] = self::getLastMessageTime($user->id);

        $json['is_online'] = self::isOnline($user->id);
        // $json['send_on'] = !empty($chat->created_on) ? $chat->created_on:'';

        return $json;
    }

    public static function getUserDetails($model, $order)
    {
        $json = [];
        $json['request_id'] = (! empty($order)) ? $order->id : 0;
        $json['id'] = $model->id;
        $json['full_name'] = ucfirst($model->full_name);
        $json['email'] = $model->email;
        $json['date_of_birth'] = $model->date_of_birth;
        $json['gender'] = $model->gender;

        if (! empty($model->profile_file) && file_exists(UPLOAD_PATH . '/' . basename($model->profile_file))) {
            $json['profile_file'] = $model->getImageUrl();
        }

        $json['role_id'] = $model->role_id;
        $json['state_id'] = 1;
        $json['last_message_from_id'] = self::getLastMessageFromId($json['request_id']);
        $json['last_message'] = self::getLastMessage($model->id, false, $json['request_id']);
        $json['last_message_id'] = self::getLastMessage($model->id, true, $json['request_id']);
        $json['is_online'] = self::isOnline($model->id);
        $json['unread_message_count'] = self::unreadMessageCount($order->id, $json['request_id'], $model->id);
        $json['last_message_time'] = self::getLastMessageTime($model->id);

        return $json;
    }

    public static function getProdutDetail($model)
    {
        $json = [];
        $json['id'] = $model->id;
        $json['title'] = ucfirst($model->title);
        $json['last_message'] = self::getLastMessage($model->created_by_id, false, $model->id);
        $json['last_message_id'] = self::getLastMessage($model->created_by_id, true, $model->id);
        return $json;
    }

    public static function get_time_ago($time)
    {
        return Yii::$app->formatter->asRelativeTime($time);
    }

    public static function unreadMessageCount($id)
    {
        $count = Chat::find()->where([
            'from_id' => $id,
            'to_id' => Yii::$app->user->id,
            'is_read' => Chat::IS_READ_NO
        ])->count();
        return $count;
    }

    public static function isOnline($user_id)
    {
        $checkUser = Module::self()->identityClass::findOne([
            'id' => $user_id
        ]);

        if (! empty($checkUser) && ! empty($checkUser->last_action_time)) {

            $start = $checkUser->last_action_time;

            $end = date("Y-m-d H:i:s"); // Current time and date
            $diff = strtotime($end) - strtotime($start);
            $hours = floor($diff / (60 * 60));
            $mins = floor(($diff - ($hours * 60 * 60)) / 60);

            if ($mins > floatval(3)) {
                return self::get_time_ago(strtotime($checkUser->last_action_time));
            } else {
                return true;
            }
        }
        return false;
    }

    public static function getLastMessageTime($id, $return_id = false)
    {
        $role = User::findOne($id);
        if (! User::isAdmin()) {
            $otherUserMessage = Chat::find()->where([
                'OR',
                [
                    'from_id' => $id,
                    'to_id' => \Yii::$app->user->id
                ],
                [
                    'from_id' => \Yii::$app->user->id,
                    'to_id' => $id
                ]
            ])
                ->orderBy('created_on DESC')
                ->one();
        } else {
            $otherUserMessage = Chat::find()->where([
                'OR',
                [
                    'from_id' => $id,
                    'to_id' => \Yii::$app->user->id
                ],
                [
                    'from_id' => \Yii::$app->user->id,
                    'to_id' => $id
                ]
            ])
                ->orderBy('created_on DESC')
                ->one();
        }
        if (! empty($otherUserMessage)) {
            // $message = \Yii::$app->formatter->asRelativeTime($otherUserMessage->created_on);
            $message = $otherUserMessage->created_on;

            return ($return_id == false) ? $message : $otherUserMessage->id;
        }
        $currentUserMessage = Chat::find()->where([
            'from_id' => \Yii::$app->user->id,
            'to_id' => $id
        ])
            ->orderBy('created_on DESC')
            ->one();

        if (! empty($currentUserMessage)) {
            // $message = \Yii::$app->formatter->asRelativeTime($currentUserMessage->created_on);
            $message = $currentUserMessage->created_on;

            return ($return_id == false) ? $message : $currentUserMessage->id;
        }
        return false;
    }

    public static function getLastMessage($id, $return_id = false)
    {
        $role = User::findOne($id);
        if (! User::isAdmin()) {
            $otherUserMessage = Chat::find()->where([
                'OR',
                [
                    'from_id' => $id,
                    'to_id' => \Yii::$app->user->id
                ],
                [
                    'from_id' => \Yii::$app->user->id,
                    'to_id' => $id
                ]
            ])
                ->orderBy('created_on DESC')
                ->one();
        } else {
            $otherUserMessage = Chat::find()->where([
                'OR',
                [
                    'from_id' => $id,
                    'to_id' => \Yii::$app->user->id
                ],
                [
                    'from_id' => \Yii::$app->user->id,
                    'to_id' => $id
                ]
            ])
                ->orderBy('created_on DESC')
                ->one();
        }

        if (! empty($otherUserMessage)) {

            $message = $otherUserMessage->message;

            if ($otherUserMessage->type_id == self::TYPE_MEDIA_FILE) {
                $message = "Media File";
            }
            return ($return_id == false) ? $message : $otherUserMessage->id;
        }
        $currentUserMessage = Chat::find()->where([
            'from_id' => \Yii::$app->user->id,
            'to_id' => $id
        ])
            ->orderBy('created_on DESC')
            ->one();

        if (! empty($currentUserMessage)) {
            $message = $currentUserMessage->message;

            if ($currentUserMessage->type_id == self::TYPE_MEDIA_FILE) {
                $message = "Media File";
            }
            return ($return_id == false) ? "You: " . $message /* . " <i class='fa fa-reply pull-right'></i>" */:$currentUserMessage->id;
        }

        return "No Message";
    }

    public static function getMessage($id)
    {
        $Message = Chat::find()->where([
            'OR',
            [
                'from_id' => $id,
                'to_id' => \Yii::$app->user->id
            ],
            [
                'from_id' => \Yii::$app->user->id,
                'to_id' => $id
            ]
        ])
            ->orderBy('created_on DESC')
            ->one();
        if (! empty($Message)) {
            return $Message->message;
        } else {
            return "No Message";
        }
    }

    public static function notifyUsers()
    {
        $unNotifiedMessage = [];

        $id = \Yii::$app->user->id;
        $getUnreadMessages = self::find()->where([
            'to_id' => \Yii::$app->user->id,
            'is_read' => Self::IS_READ_NO
        ]);

        if (! empty($getUnreadMessages->count())) {
            foreach ($getUnreadMessages->each() as $unreadMessage) {

                $alreadyNotified = in_array($id, explode(',', $unreadMessage->notified_users));
                if (! $alreadyNotified) {

                    $NotificationRediectLink = \Yii::$app->urlManager->createAbsoluteUrl([
                        '/chat',
                        'id' => $unreadMessage->id
                    ]);
                    $unreadMessage->notified_users = empty($unreadMessage->notified_users) ?: $unreadMessage->notified_users . ',' . $id;
                    $message = $unreadMessage->from->full_name . " | " . $unreadMessage->message;

                    $unNotifiedMessage[] = [
                        'message' => $message,
                        'notification_url' => $NotificationRediectLink,
                        'header' => Yii::$app->params['company']
                    ];

                    $unreadMessage->updateAttributes([
                        'notified_users'
                    ]);
                }
            }
        }
        return $unNotifiedMessage;
    }

    /**
     * return last message read status
     */
    public static function getLastMessageReadStatus($user_id, $detail = false)
    {
        $self = Chat::find()->where([
            'OR',
            [
                'from_id' => $user_id,
                'to_id' => \Yii::$app->user->id
            ],
            [
                'from_id' => \Yii::$app->user->id,
                'to_id' => $user_id
            ]
        ])
            ->orderBy('id DESC')
            ->one();

        if ($detail) {
            if (! empty($self)) {

                return $self->from_id;
            } else {

                return '';
            }
        }

        if (! empty($self) && ($self->is_read == self::IS_READ_YES)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * return message read status
     */
    public static function getMessageReadStatus($id, $from_id, $to_id)
    {
        $from_read = $from_id . "," . $to_id;
        $to_read = $to_id . "," . $from_id;

        $self = Chat::find($id)->where([
            'id' => $id
        ])
            ->andWhere([
            'or',
            [
                
                'readers' => $from_read
            ],
            [
                'readers' => $to_read
            ]
        ])
            ->one();

        if (! empty($self)) {
            return true;
        }
        return false;
    }

    public static function getAdmin($detail = false)
    {
        $userModel = User::findOne([
            'role_id' => User::ROLE_ADMIN
        ]);

        if (! empty($userModel)) {
            if ($detail) {
                return $userModel;
            } else {
                return $userModel->id;
            }
        }

        return null;
    }
}
