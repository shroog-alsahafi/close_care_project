<?php
/**
 *@copyright : Ozvid Technologies Pvt. Ltd. < www.ozvid.com >
 */
namespace app\modules\notification\components;

use Yii;
use yii\base\Component;
use yii\helpers\VarDumper;
use yii\base\InvalidConfigException;
use yii\httpclient\Client;
use http\Message\Body;

/**
 *
 * @author Amr Alshroof
 */
class FireBaseNotification extends Component
{

    /**
     *
     * @var string the auth_key Firebase cloude messageing server key.
     */
    public $authKey = null;

    public $timeout = 5;

    public $sslVerifyHost = false;

    public $sslVerifyPeer = false;

    public $response;

    /**
     *
     * @var string the api_url for Firebase cloude messageing.
     */
    public $apiUrl;

    public static function dlog($string)
    {
        if (Yii::$app instanceof \yii\console\Application) {
            echo $string . PHP_EOL;
        } else {
            Yii::error("FIREBASE ERROR: " . $string);
        }
    }

    private function base64UrlEncode($text)
    {
        return str_replace([
            '+',
            '/',
            '='
        ], [
            '-',
            '_',
            ''
        ], base64_encode($text));
    }

    private function GenerateFirebaseToken()
    {
        try {

            $authConfigString = file_get_contents(BASE_PATH . '/closecare-23f45-firebase-adminsdk-x930v-b83d0b3f5b.json');

            // Parse service account details
            $authConfig = json_decode($authConfigString);

            // Parse service account details
            $authConfig = json_decode($authConfigString);

            // Read private key from service account details
            $secret = openssl_get_privatekey($authConfig->private_key);

            // Create the token header
            $header = json_encode([
                'typ' => 'JWT',
                'alg' => 'RS256'
            ]);

            $time = time();

            $payload = json_encode([
                "iss" => $authConfig->client_email,
                "scope" => "https://www.googleapis.com/auth/firebase.messaging",
                "aud" => "https://oauth2.googleapis.com/token",
                "exp" => $time + 3600,
                "iat" => $time
            ]);

            // Encode Header
            $base64UrlHeader = $this->base64UrlEncode($header);

            // Encode Payload
            $base64UrlPayload = $this->base64UrlEncode($payload);

            // Create Signature Hash
            $result = openssl_sign($base64UrlHeader . "." . $base64UrlPayload, $signature, $secret, OPENSSL_ALGO_SHA256);

            // Encode Signature to Base64Url String
            $base64UrlSignature = $this->base64UrlEncode($signature);

            // Create JWT
            $jwt = $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;

            $body = [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $jwt
            ];
            // -----Request token------

            $client = new Client();
            $token_url = 'https://oauth2.googleapis.com/token';
            $request = $client->createRequest()
                ->setMethod('POST')
                ->addHeaders([
                'content-type' => 'application/x-www-form-urlencoded'
            ])
                ->setData($body)
                ->setUrl($token_url);
            $response = $request->send();
            $api_response = $response->getData();

            $token = $api_response['access_token'];

            // \Yii::trace(\yii\helpers\VarDumper::dumpAsString('Firebase Token :' . $token));

            return $token;
        } catch (\Exception $e) {

            \Yii::error(\yii\helpers\VarDumper::dumpAsString('ERRROR During Generate Token :'));
            \Yii::error(\yii\helpers\VarDumper::dumpAsString($e->getMessage()));
        }
    }

    public function init()
    {
        parent::init();
        $firebase_project_id = \Yii::$app->settings->getValue('firebase_project_id', '', 'notification');

        $this->authKey = $this->GenerateFirebaseToken();

        $this->apiUrl = "https://fcm.googleapis.com/v1/projects/{$firebase_project_id}/messages:send";
        if ($this->authKey == null) {
            throw new InvalidConfigException('authKey must be set.');
        }
    }

    /**
     * send raw body to FCM
     *
     * @param array $body
     * @return mixed
     */
    public function send($body)
    {
        try {
            // send payload to FCM
            $client = new Client();
            $token_url = $this->apiUrl;
            $request = $client->createRequest()
                ->setMethod('POST')
                ->setHeaders([
                'content-type' => 'application/json'
            ])
                ->addHeaders([
                'authorization' => 'Bearer ' . $this->authKey
            ])
                ->setContent(json_encode($body))
                ->setUrl($token_url);
            $response = $request->send();
            $api_response = $response->getData();

            // self::dlog('Result: ' . VarDumper::dump($api_response));
            return $api_response;

            // \Yii::trace(\yii\helpers\VarDumper::dumpAsString('Firebase Token :' . $api_response));

            // self::dlog('Result: ' . VarDumper::dump($api_response));
        } catch (\Exception $e) {

            \Yii::error(\yii\helpers\VarDumper::dumpAsString('ERRROR During Generate Token :'));
            \Yii::error(\yii\helpers\VarDumper::dumpAsString($e->getMessage()));
        }
    }

    /**
     * send notification for a specific tokens with FCM
     *
     * @param array $tokens
     * @param array $data
     *            (can be something like ["message"=>$message] )
     * @param string $collapse_key
     * @param bool $delay_while_idle
     * @param
     *            array other
     * @return mixed
     */
    public function sendDataMessage($data, $tokens = [], $collapse_key = null, $delay_while_idle = null, $other = null)
    {
        // self::dlog('sendDataMessage: ' . VarDumper::dumpAsString($tokens));
        // $body = [
        // 'registration_ids' => $tokens,
        // 'data' => $data
        // ];
        foreach ($tokens as $token) {
            $body['message'] = [
                'token' => $token,
                'notification' => [
                    "body" => $data['message'],
                    "title" => 'Healthcare'
                    // "action" => $data['action']
                ],
                'data' => $data['detail']
            ];

            if ($collapse_key)
                $body['collapse_key'] = $collapse_key;
            if ($delay_while_idle !== null)
                $body['delay_while_idle'] = $delay_while_idle;
            if ($other)
                $body += $other;

            $this->send($body);
        }
    }
}
