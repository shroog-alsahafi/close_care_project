<?php

/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\notification\models;

use app\models\User;
use app\modules\api\Module;
use yii\helpers\Url;
use app\modules\chat\models\Chat;

/**
 * This is the model class for table "tbl_notification".
 *
 * @property integer $id
 * @property string $title
 * @property string $description
 * @property integer $model_id
 * @property string $model_type
 * @property integer $is_read
 * @property integer $state_id
 * @property integer $type_id
 * @property string $created_on
 * @property integer $to_user_id
 * @property integer $created_by_id
 */
class Notification extends \app\components\TActiveRecord
{

    public function __toString()
    {
        return (string) $this->title . ':' . $this->toUser;
    }

    const CALL_NOTIFICATION = 1;

    const CREATE_CALL_NOTIFICATION = 1;

    const END_CALL_NOTIFICATION = 2;

    const REJECT_CALL_NOTIFICATION = 3;

    const TYPE_FAV = 1;

    const TYPE_TEXT_MESSAGE = 0;

    const TYPE_MEDIA_FILE = 1;

    const TYPE_VIDEO_FILE = 2;

    const TYPE_AUDIO_FILE = 3;

    const TYPE_WAVE_MESSAGE = 5;

    public function getModel()
    {
        $modelType = $this->model_type;
        if (class_exists($modelType)) {
            return $modelType::find()->cache()
                ->where([
                'id' => $this->model_id
            ])
                ->one();
        }
        return null;
    }

    public $username;

    const STATE_INACTIVE = 0;

    const STATE_ACTIVE = 1;

    const STATE_DELETED = 2;

    public static function getStateOptions()
    {
        return [
            self::STATE_INACTIVE => "New",
            self::STATE_ACTIVE => "Active",
            self::STATE_DELETED => "Archived"
        ];
    }

    public function getState()
    {
        $list = self::getStateOptions();
        return isset($list[$this->state_id]) ? $list[$this->state_id] : 'Not Defined';
    }

    public function getStateBadge()
    {
        $list = [
            self::STATE_INACTIVE => "primary",
            self::STATE_ACTIVE => "success",
            self::STATE_DELETED => "danger"
        ];
        return isset($list[$this->state_id]) ? \yii\helpers\Html::tag('span', $this->getState(), [
            'class' => 'badge bg-' . $list[$this->state_id]
        ]) : 'Not Defined';
    }

    const IS_NOT_READ = 0;

    const IS_READ = 1;

    public static function getIsReadOptions()
    {
        return [
            self::IS_NOT_READ => "Not Read",
            self::IS_READ => "Read"
        ];
    }

    public function getIsRead()
    {
        $list = self::getIsReadOptions();
        return isset($list[$this->is_read]) ? $list[$this->is_read] : 'Not Defined';
    }

    public function getIsReadBadge()
    {
        $list = [
            self::IS_READ => "success",
            self::IS_NOT_READ => "danger"
        ];
        return isset($list[$this->is_read]) ? \yii\helpers\Html::tag('span', $this->getIsRead(), [
            'class' => 'badge bg-' . $list[$this->is_read]
        ]) : 'Not Defined';
    }

    public static function getTypeOptions()
    {
        return [
            self::TYPE_FAV => "Favorite",
            self::TYPE_TEXT_MESSAGE => "text message",
            Self::TYPE_MEDIA_FILE => "Media file",
            Self::TYPE_AUDIO_FILE => "Audio file",
            Self::TYPE_VIDEO_FILE => "video file",
            self::TYPE_WAVE_MESSAGE => "Wave message"
        ];
    }

    public function getType()
    {
        $list = self::getTypeOptions();
        return isset($list[$this->type_id]) ? $list[$this->type_id] : 'Not Defined';
    }

    public function beforeValidate()
    {
        if ($this->isNewRecord) {
            if (! isset($this->created_on))
                $this->created_on = date('Y-m-d H:i:s');
            if (! isset($this->to_user_id))
                $this->to_user_id = self::getCurrentUser();
            if (! isset($this->created_by_id))
                $this->created_by_id = self::getCurrentUser();
        } else {}
        return parent::beforeValidate();
    }

    /**
     *
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%notification}}';
    }

    /**
     *
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [
                    'title',
                    'model_id',
                    'model_type',
                    'created_on'
                ],
                'required'
            ],
            [
                [
                    'description'
                ],
                'string'
            ],
            [
                [
                    'model_id',
                    'is_read',
                    'state_id',
                    'type_id',
                    'to_user_id',
                    'created_by_id'
                ],
                'integer'
            ],
            [
                [
                    'created_on'
                ],
                'safe'
            ],
            [
                [
                    'title'
                ],
                'string',
                'max' => 1024
            ],
            [
                [
                    'model_type'
                ],
                'string',
                'max' => 256
            ],
            [
                [
                    'title',
                    'model_type',
                    'is_read'
                ],
                'trim'
            ],
            [
                [
                    'state_id'
                ],
                'in',
                'range' => array_keys(self::getStateOptions())
            ],
            [
                [
                    'type_id'
                ],
                'in',
                'range' => array_keys(self::getTypeOptions())
            ]
        ];
    }

    /**
     *
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => \Yii::t('app', 'ID'),
            'title' => \Yii::t('app', 'Title'),
            'description' => \Yii::t('app', 'Description'),
            'model_id' => \Yii::t('app', 'Model'),
            'model_type' => \Yii::t('app', 'Model Type'),
            'is_read' => \Yii::t('app', 'Is Read'),
            'state_id' => \Yii::t('app', 'State'),
            'type_id' => \Yii::t('app', 'Type'),
            'created_on' => \Yii::t('app', 'Created On'),
            'to_user_id' => \Yii::t('app', 'To User'),
            'created_by_id' => \Yii::t('app', 'Created By')
        ];
    }

    public function getToUser()
    {
        return $this->hasOne(User::className(), [
            'id' => 'to_user_id'
        ])->cache(10);
    }

    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), [
            'id' => 'created_by_id'
        ])->cache(10);
    }

    public function getProfileImage()
    {
        return $this->hasOne(User::className(), [
            'id' => 'created_by_id'
        ])->cache(10);
    }

    public static function getHasManyRelations()
    {
        $relations = [];
        return $relations;
    }

    public static function getHasOneRelations()
    {
        $relations = [];
        $relations['created_by_id'] = [
            'createdBy',
            'User',
            'id'
        ];
        $relations['to_user_id'] = [
            'toUser',
            'User',
            'id'
        ];
        return $relations;
    }

    public function beforeDelete()
    {
        return parent::beforeDelete();
    }

    public function asJson($with_relations = false)
    {
        $json = [];
        $json['id'] = ! empty($this->id) ? (string) ($this->id) : '';
        $json['controller'] = (string) \yii::$app->controller->id;
        $json['action'] = (string) \yii::$app->controller->action->id;
        $json['title'] = (string) $this->title;
        $json['description'] = (string) $this->description;
        $json['model_id'] = (string) $this->model_id;
        $json['model_type'] = (string) $this->model_type;
        $json['is_read'] = (string) $this->is_read;
        $json['state_id'] = (string) $this->state_id;
        $json['type_id'] = (string) $this->type_id;
        $json['created_on'] = (string) $this->created_on;
        $json['to_user_id'] = (string) $this->to_user_id;
        $json['created_by_id'] = (string) $this->created_by_id;
        $json['profile_image'] = (string) ! empty($this->createdBy->profile_file) ? $this->getImageUrls($this->createdBy->profile_file) : null;
        $json['username'] = (string) ! empty($this->createdBy->full_name) ? $this->createdBy->full_name : '';
        
        if ($this->model_type == Chat::className()) {
            $chat = Chat::findOne($this->model_id);
            if (! empty($chat)) {
                $json['booking_id'] = (string) $chat->booking_id;
                if (! empty($chat->from)) {
                    $json['from_full_name'] = (string) ! empty($chat->from->full_name) ? $chat->from->full_name : '';
                }
                if (! empty($chat->to)) {
                    $json['to_full_name'] = (string) ! empty($chat->to->full_name) ? $chat->to->full_name : '';
                }
                if (! empty($chat->to)) {
                    $json['from_id'] =  ! empty($chat->from->id) ? (string) $chat->from->id : '';
                }
            }
        }
        if ($with_relations) {}
        return $json;
    }

    public function getImageUrls($thumbnail = false)
    {
        $params = [
            '/' . $this->getControllerID() . '/image'
        ];
        $params['id'] = $this->id;

        if (isset($this->profile_file) && ! empty($this->profile_file)) {
            $params['file'] = $this->profile_file;
        }

        if ($thumbnail)
            $params['thumbnail'] = is_numeric($thumbnail) ? $thumbnail : 150;

        return Url::toRoute($params);
    }

    public function getControllerID()
    {
        return '/notification/' . parent::getControllerID();
    }

    public function isAllowed()
    {
        if ($this->to_user_id == \Yii::$app->user->id) {
            return true;
        }
        return parent::isAllowed();
    }

    /**
     * Create Notification
     *
     * Use :
     *
     * Notification::create([
     * 'model' => $model,
     * 'to_user_id' => 3,
     * 'title' => 'Lead Reminder',
     * 'created_by_id' => $model->id
     * ]);
     */
    public static function create($param = [])
    {
        $notification = new self();
        $notification->loadDefaultValues();
        $notification->to_user_id = $param['to_user_id'];
        $notification->created_by_id = $param['created_by_id'];
        $notification->title = $param['title'];
        $notification->username = $param['username'] ?? "";
        $notification->model_id = $param['model']->id;
        $notification->type_id = $param['type_id'] ?? "";
        $notification->description = $param['description'] ?? "";
        $notification->model_type = get_class($param['model']);

        $notification->is_read = Notification::IS_NOT_READ;

        if ($notification->save()) {

            \Yii::debug('notification created :' . $notification);
            // if (Module::self() && Module::self()->isnotificationOnApp) {
            $notification->sendNotificationOnApp();
            // }

            return true;
        } else

            return false;
    }

    /**
     * Check if notification send or not
     *
     * Use :
     *
     * Notification::create([
     * 'model' => $model,
     * 'to_user_id' => 3,
     * 'title' => 'Lead Reminder',
     * 'created_by_id' => $model->id
     * ]);
     */
    public static function isNotify($param = [])
    {
        $notification = self::find()->select([
            'id'
        ])
            ->where([
            'title' => $param['title'],
            'model_id' => $param['model']->id,
            'model_type' => get_class($param['model']),
            'to_user_id' => $param['to_user_id'],
            'created_by_id' => $param['created_by_id']
        ])
            ->one();
        return $notification;
    }

    public static function clear($model)
    {
        $query = self::find();
        $query->where([
            'model_id' => $model->id,
            'model_type' => get_class($model),
            'to_user_id' => self::getCurrentUser()
        ]);
        self::log("Cleaning up  Notifications: " . $query->count());
        foreach ($query->each() as $notification) {
            self::log("Deleting Notification :" . $notification->id . ' - ' . $notification);

            $notification->delete();
        }
        return false;
    }

    public function sendNotificationOnApp()
    {

        // if (Module::self()->isNotify === false) {
        // return;
        // }
        $androidtoken = [];
        $iostoken = [];
        $tokens = "";
        $data = [];
        $data['controller'] = (string) \yii::$app->controller->id;
        $data['action'] = (string) \yii::$app->controller->action->id;
        $data['message'] = (string) $this->title;
        $data['user_id'] = (string) $this->to_user_id;
        $data['detail'] = $this->asJson();
        $user = User::findOne($this->to_user_id);

        if (! empty($user)) {

            $tokens = $user->authSession;

            if (! empty($user)) {

                $tokens = $user->authSession;

                if (count($tokens) > 0) {

                    foreach ($tokens as $token) {
                        if ($token->device_type == 1) {
                            $androidtoken[] = $token->device_token;
                        }
                        if ($token->device_type == 2)
                            $iostoken[] = $token->device_token;
                    }
                    if (! empty($androidtoken)) {
                        try {
                            $datas = \Yii::$app->firebase->sendDataMessage($data, $androidtoken);
                        } catch (\Exception $e) {

                            \Yii::error(\yii\helpers\VarDumper::dumpAsString('android NOTIFICATION SEND ERRROR'));
                            \Yii::error(\yii\helpers\VarDumper::dumpAsString($e->getMessage()));
                        }
                    }

                    if (! empty($iostoken)) {

                        try {
                            $datas = \Yii::$app->firebase->sendDataMessage($data, $iostoken);
                        } catch (\Exception $e) {

                            \Yii::error(\yii\helpers\VarDumper::dumpAsString('IOS NOTIFICATION SEND ERRROR'));
                            \Yii::error(\yii\helpers\VarDumper::dumpAsString($e->getMessage()));
                        }
                    }

                    //
                }
            }
        }
    }
}
