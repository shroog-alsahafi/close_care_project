<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\payment;

use app\components\TController;
use app\components\TModule;
use app\models\User;
use app\components\filters\AccessControl;
use app\components\filters\AccessRule;

/**
 * payment module definition class
 */
class Module extends TModule
{

    const NAME = 'payment';

    public $controllerNamespace = 'app\modules\payment\controllers';

    public $defaultRoute = 'gateway';

    public static function subNav()
    {
        return TController::addMenu(\Yii::t('app', 'Payments'), '#', 'key ', Module::isAdmin(), [ // TController::addMenu(\Yii::t('app', 'Home'), '//payment', 'lock', Module::isAdmin()),
            TController::addMenu(\Yii::t('app', 'Home'), '//payment/default/index', 'home', Module::isAdmin()),
            TController::addMenu(\Yii::t('app', 'Gateways'), '//payment/gateway/index', 'credit-card', (Module::isAdmin())),
            TController::addMenu(\Yii::t('app', 'Transactions'), '//payment/transaction/index', 'suitcase', (Module::isAdmin())),
            TController::addMenu(\Yii::t('app', 'Refund'), '//payment/refund/index', 'suitcase', (Module::isAdmin())),
            TController::addMenu(\Yii::t('app', 'Settings'), '//payment/default/settings', 'cog', (User::isAdmin()))
        ]);
    }

    public static function dbFile()
    {
        return __DIR__ . '/db/install.sql';
    }

    public static function getRules()
    {
        return [
            'payment' => 'payment/gateway/list',
            'payment/<id:\d+>/<title>' => 'payment/transaction/share',
            'payment/<id:\d+>' => 'payment/transaction/share',
            'paypal' => '/payment/paypal',
            'stripe' => '/payment/stripe'
        ];
    }
}
