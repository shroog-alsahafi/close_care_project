# payment

#### About Brief
* Payment module is integrated for transactions securely. 
* Payment module is combination of both stripe and paypal gateways.

#### Features
* Used both stripe and paypal gateway in one payment module
* Have a Export and Import functionality.
* Secure and flexible payment option.
* Support to multiple currency payments.
* Have a subscription option for stripe payment method
* Have a option for QR code in transactions.
* Daily report summary of pending,process,in-progress and fail transactions.


## INSTALLATION 

## If you need to install single  module 

Steps-
1. Configure the payment module in **.gitmodules**.
2. Run **bash ../scripts/clone-submodules.sh**  command on  terminal.Wait till installation complete.
3. Run command **php console.php module/migrate**  for create table in database.
4. Migrate both paypal and stripe  gateway run this command  **php console.php payment/gateway/index**.
5. Migrate the transactions of both paypal and stripe run this command **php console.php payment/transaction/index**.

> add below code in your .gitmodule file.

      [submodule "protected/modules/payment"]
	   path = protected/modules/payment
	   url = http://192.168.10.21/yii2/modules/payment.git

> add below code in web.php file, located at protected/config/web.php

        $config['modules']['payment'] = [
         'class' => 'app\modules\payment\Module'
        ];
        
> add below code in console.php file, located at protected/config/console.php

        $config['modules']['payment'] = [
         'class' => 'app\modules\payment\Module'
        ];
        
> add module in side nav bar, located at protected/base/SideBarMenu.php

         if (yii::$app->hasModule('payment'))
                   $this->nav_left[] = \app\modules\payment\Module::subNav();


## How to test > you need to use these steps

Steps- 
1. Go to the Browser and open your project.And type payment after your project name.
2. Both Stripe and payment gateways show.
3. Select the one payment gateway.
4. Enter the valid card details for test gateway.

## Add client provided key
- To test the payment gateway it is neccessary to add  client secret key and client id from the admin panel.
 