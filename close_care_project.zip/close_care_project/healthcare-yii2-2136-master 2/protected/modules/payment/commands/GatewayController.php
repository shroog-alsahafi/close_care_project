<?php

/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\payment\commands;

use app\components\TConsoleController;
use app\modules\payment\models\Gateway;

class GatewayController extends TConsoleController
{

    /**
     * Migrate stripe and paypal module gateways to module
     */
    public function actionIndex()
    {
        $this->actionMigrateStripe();
        $this->actionMigratePaypal();
    }

    /**
     * Delete gateways of stripe and paypal
     */
    public function actionDeleteIndex()
    {
        $this->actionDeleteStripe();
        $this->actionDeletePaypal();
    }

    /**
     * Migrate stripe gateways to payment gateways
     */
    public function actionMigrateStripe()
    {
        self::log(__FUNCTION__ . 'Migrate Stripe Data');

        $StripeGateway = 'app\modules\stripe\models\Gateway';

        if (! class_exists($StripeGateway)) {
            return;
        }
        $query = $StripeGateway::find();

        self::log("Syncing stripe gateways :" . $query->count());

        foreach ($query->each() as $gateway) {
            self::log("Syncing gateways :" . $gateway);
            $model = new Gateway();
            $model->loadDefaultValues();

            $model->setAttributes($gateway->attributes);
            $model->country_code = 'IN';
            $model->description = '';
            $model->type_id = Gateway::GATEWAY_TYPE_STRIPE;
            $model->mode = $gateway->type_id;
            if ($model->save()) {
                self::log('Data Migrated : ' . $model);
            }
        }
    }

    /**
     * Migrate Paypal gateways to payment gateways
     */
    public function actionMigratePaypal()
    {
        self::log(__FUNCTION__ . 'Migrate Paypal Data');
        $PaypalGateway = 'app\modules\paypal\models\Gateway';

        if (! class_exists($PaypalGateway)) {
            return;
        }
        $query = $PaypalGateway::find();

        self::log("Syncing Paypal gateways :" . $query->count());

        foreach ($query->each() as $gateway) {
            self::log("Syncing gateways :" . $gateway);

            $model = new Gateway();
            $model->loadDefaultValues();

            $model->setAttributes($gateway->attributes);
            $model->country_code = 'IN';
            $model->type_id = Gateway::GATEWAY_TYPE_PAYPAL;
            $model->currency = 'INR';
            $model->description = '';
            $model->mode = $gateway->type_id;
            if ($model->save()) {
                self::log('Data Migrated : ' . $model);
            }
        }
        self::log('Paypal Data Migrated');
    }

    /**
     * Delete stripe module gateways
     */
    public function actionDeleteStripe()
    {
        self::log(__FUNCTION__ . 'Delete Stripe Data');
   
        
        // Delete table gateway and subscription
        $db = \Yii::$app->db;
        $cmd = $db->createCommand("DROP TABLE IF EXISTS {{stripe_gateway}}");
        $cmd ->execute();
        $cmd = $db->createCommand("DROP TABLE IF EXISTS {{stripe_subscription}}");
        $cmd ->execute();

        return 0;
    }

    /**
     * Delete Paypal module gateways
     */
    public function actionDeletePaypal()
    {
        self::log(__FUNCTION__ . 'Delete Paypal Data');

        
        $db = \Yii::$app->db;
        $cmd = $db->createCommand("DROP TABLE IF EXISTS {{paypal_gateway}}");
        $cmd ->execute();
        $cmd = $db->createCommand("DROP TABLE IF EXISTS {{paypal_subscription}}");
        $cmd ->execute();

        return 0;
    }

    /**
     * Delete Gateways
     *
     * @param boolean $truncate
     * @return number
     */
    public function actionClear($truncate = false)
    {
        $query = Gateway::find()->orderBy('id ASC');

        foreach ($query->batch() as $models) {
            foreach ($models as $model) {
                Gateway::log('Deleting :' . $model->id);
                $model->delete();
            }
        }

        if ($truncate) {
            Gateway::truncate();
        }
        return 0;
    }
}