<?php

/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\payment\commands;

use app\components\TConsoleController;
use app\components\helpers\TEmailTemplateHelper;
use app\models\EmailQueue;
use app\modules\payment\models\SettingsForm;
use app\modules\payment\models\Transaction;
use yii\console\ExitCode;

/**
 * Report controller for the Payment Report
 */
class ReportController extends TConsoleController
{

    /**
     * Display payment reoprt
     * @return number
     */
    public function actionSummary()
    {
        self::log(__FUNCTION__ . ' Send Payment Report');

        $moduleSettings = new SettingsForm();

        if (! $moduleSettings->enable) {
            self::log("Payment not enabled");
            return ExitCode::OK;
        }

        $date = date('Y-m-d');
        self::log('Report :' . $date);

        $query = Transaction::find();

        $query->andWhere([
            'state_id' => [
                Transaction::STATE_PENDING,
                Transaction::STATE_SUCCESS,
                Transaction::STATE_INPROGRESS,
                Transaction::STATE_FAIL
            ]
        ]);

        if (($query->count() > 0)) {
            $message = TEmailTemplateHelper::renderFile('@app/modules/payment/template/report.php', [
                'query' => $query
            ]);
            $subject = '[Report] Payments :' . ' [ ' . $date . ' ]';

            EmailQueue::add([
                'to' => 'pc@toxsltech.com',
                'subject' => $subject,
                'html' => $message
            ], true);
        }
    }
}