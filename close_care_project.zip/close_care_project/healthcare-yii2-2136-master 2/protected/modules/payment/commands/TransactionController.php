<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */

namespace app\modules\payment\commands;

use app\components\TConsoleController;
use app\modules\stripe\models\Transaction as StripeTransaction;
use app\modules\payment\models\Transaction;
use app\modules\paypal\models\Transaction as PaypalTransaction;
use app\modules\payment\models\Gateway;

class TransactionController extends TConsoleController
{

    /**
     * Migrate stripe and paypal Transactions to module Transactions
     */
    public function actionIndex()
    {
        $this->actionMigrateStripe();
        $this->actionMigratePaypal();
    }

    /**
     * Delete Transactions of stripe and paypal
     */
    public function actionDeleteIndex()
    {
        $this->actionDeleteStripe();
        $this->actionDeletePaypal();
    }

    /**
     * Migrate stripe Transactions to payment Transactions
     */
    public function actionMigrateStripe()
    {
        self::log(__FUNCTION__ . 'Migrate Stripe Data');

        $query = StripeTransaction::find();

        self::log("Syncing stripe transaction :" . $query->count());

        foreach ($query->each() as $transaction) {
            self::log("Syncing transaction :" . $transaction);
            $model = new Transaction();
            $model->loadDefaultValues();

            $model->setAttributes($transaction->attributes);

            $gateway = Gateway::find()->where([
                'title' => $transaction->type->title
            ])->one();

            if ($gateway) {
                $model->type_id = $gateway->id;
            }
            if ($model->save()) {
                self::log('Data Migrated : ' . $model);
            }
        }
    }

    /**
     * Migrate Paypal Transactions to payment Transactions
     */
    public function actionMigratePaypal()
    {
        self::log(__FUNCTION__ . 'Migrate Paypal Data');

        $query = PaypalTransaction::find();

        self::log("Syncing Paypal transaction :" . $query->count());

        foreach ($query->each() as $transaction) {
            self::log("Syncing transaction :" . $transaction);

            $model = new Transaction();
            $model->loadDefaultValues();

            $model->setAttributes($transaction->attributes);
            $model->id = 1000 + $transaction->id;

            $gateway = Gateway::find()->where([
                'title' => $transaction->type->title
            ])->one();

            if ($gateway) {
                $model->type_id = $gateway->id;
            }

            if ($model->save()) {
                self::log('Data Migrated : ' . $model);
            }
        }
        self::log('Paypal Data Migrated');
    }

    /**
     * Delete stripe module Transactions
     */
    public function actionDeleteStripe()
    {
        self::log(__FUNCTION__ . 'Delete Stripe Data');

        
        $db = \Yii::$app->db;
        $cmd = $db->createCommand("DROP TABLE IF EXISTS {{stripe_transaction}}");
        $cmd ->execute();

        return 0;
    }

    /**
     * Delete Paypal module Transactions
     */
    public function actionDeletePaypal()
    {
        self::log(__FUNCTION__ . 'Delete Paypal Data');

        
        $db = \Yii::$app->db;
        $cmd = $db->createCommand("DROP TABLE IF EXISTS {{paypal_transaction}}");
        $cmd ->execute();

        return 0;
    }

    /**
     * Delete Transactions
     *
     * @param boolean $truncate
     * @return number
     */
    public function actionClear($truncate = false)
    {
        $query = Transaction::find()->orderBy('id ASC');

        foreach ($query->batch() as $models) {
            foreach ($models as $model) {
                Transaction::log('Deleting :' . $model->id);
                $model->delete();
            }
        }

        if ($truncate) {
            Transaction::truncate();
        }
        return 0;
    }
}