<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\payment\components;

class Currency
{

    /**
     * Return the list of currency list
     *
     * @return string[]
     */
    public static function getCurrencyList()
    {
        $list = [
            'AED' => 'United Arab Emirates (AED)',
            'USD' => 'United States Dollar (USD)',
            'CAD' => 'Canada Dollar (CAD)',
            'EUR' => 'Euro Member Countries (EUR)',
            'HKD' => 'Hong Kong Dollar (HKD)',
            'INR' => 'India Rupee (INR)',
            'NZD' => 'New Zealand Dollar (NZD)',
            'SGD' => 'Singapore Dollar (SGD)',
            'GBP' => 'United Kingdom Pound (GBP)'
        ];
        return $list;
    }
}