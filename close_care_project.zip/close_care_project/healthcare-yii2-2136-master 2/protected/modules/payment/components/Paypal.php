<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\payment\components;

use app\modules\payment\models\Gateway;
use app\modules\payment\models\Transaction;
use function GuzzleHttp\json_decode;
use app\modules\payment\models\Refund;
use function GuzzleHttp\json_encode;

class Paypal
{

    public function getRefund($transation_id,$bookingQuery)
    {
        $gateway = Gateway::findActive()->one();

        $transaction = Transaction::findOne($transation_id);
        if (empty($transation_id)) {

            return false;
        }

        if (! empty($transaction->response)) {
            $response = json_decode(! empty($transaction->response) ? $transaction->response : '');

            if (isset($response->purchase_units[0]->payments->captures[0]->id)) {
                $capture_id = $response->purchase_units[0]->payments->captures[0]->id;
                $amount = $response->purchase_units[0]->payments->captures[0]->amount->value;
            } else {

                return false;
            }
            $refundModel = new Refund();
            $refundModel->transaction_id = $transaction->id;

            $clientId = $gateway->client_id;
            $clientSecret = $gateway->client_secret;

            $value = "{$clientId}:{$clientSecret}";
            $auth = base64_encode($value);

            // Step 1: Get Access Token
            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => 'https://api-m.sandbox.paypal.com/v1/oauth2/token',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => 'grant_type=client_credentials',
                CURLOPT_HTTPHEADER => array(
                    "Authorization: Basic {$auth}",
                    'Content-Type: application/x-www-form-urlencoded'
                )
            ));

            $response = curl_exec($curl);
            curl_close($curl);

            // Decode the JSON response
            $jsonDatas = json_decode($response, true);

            // Access the access token
            $accessToken = $jsonDatas['access_token'];

            // Step 2: Prepare the refund request
            $refundData = [
                "amount" => [
                    "currency_code" => "USD", // Change to the appropriate currency
                    "value" => $amount // Specify the refund amount
                ]
            ];

            $jsonRefundData = json_encode($refundData);

            // Step 3: Make the refund request
            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, "https://api-m.sandbox.paypal.com/v2/payments/captures/$capture_id/refund");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonRefundData);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                "Content-Type: application/json",
                "Authorization: Bearer {$accessToken}"
            ]);

            $response2 = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            $response2 = json_decode($response2);

            // Check the response
            if ($httpCode == 201) {
                $refundModel->transaction_id = $transaction->id;
                $refundModel->refund_id = $response2->id;
                $refundModel->response = json_encode($response2);
                $refundModel->state_id = Refund::STATE_ACTIVE;
                $refundModel->user_id = $bookingQuery->created_by_id;
                $refundModel->provider_id = $bookingQuery->provider_id;
                $refundModel->save();
                return true;
            } else {
                return false;
            }
        }
    }
}