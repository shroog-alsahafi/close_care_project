<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\payment\controllers;

use app\components\TActiveRecord;
use app\components\TController;
use app\models\User;
use app\modules\payment\models\Transaction;
use app\modules\payment\models\search\Transaction as TransactionSearch;
use Yii;
use yii\web\HttpException;
use app\components\filters\AccessControl;
use app\components\filters\AccessRule;
use yii\helpers\VarDumper;
use yii\helpers\Json;
use yii\web\NotFoundHttpException;
use Cashfree\Cashfree;
use Cashfree\Model\CreateOrderRequest;
use yii\helpers\Url;
use Cashfree\Model\OrderMeta;

/**
 * Default controller for the `payment` module
 */
class CashFreeController extends TController
{

    /**
     * Renders the index view for the module
     *
     *
     * @return string
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [
                    [
                        'actions' => [
                            'clear',
                            'delete'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isAdmin();
                        }
                    ],
                    [
                        'actions' => [
                            'index',
                            'view',
                            'update',
                            'clone',
                            'ajax'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isManager();
                        }
                    ],
                    [
                        'actions' => [
                            'add',
                            'process',
                            'success',
                            'error',
                            'share',
                            'qrcode',
                            'checkout',
                            'index'
                        ],
                        'allow' => true,
                        'roles' => [
                            '@',
                            '?',
                            '*'
                        ]
                    ]
                ]
            ]
        ];
    }

    public function beforeAction($action)
    {
        if ((\Yii::$app->controller->action->id == 'success')) {
            $this->enableCsrfValidation = false;
        }
        return parent::beforeAction($action);
    }

    /**
     * List of payment transactions
     *
     * @return \yii\web\Response
     */
    public function actionIndex()
    {
        return $this->redirect([
            '/payment/transaction'
        ]);
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return string
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $this->updateMenuItems($model);
        return $this->render('view', [
            'model' => $model
        ]);
    }

    /**
     * Displays a single transaction model in progress state.
     *
     * @param integer $id
     * @return yii\web\Response
     */
    public function actionProcess($id)
    {
        $this->layout = 'guest-main';
        $model = $this->findModel($id, false);
        if ($model->state_id == Transaction::STATE_SUCCESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }

        \yii::$app->session->set('cashfree', $model->id);
        $model->state_id = Transaction::STATE_INPROGRESS;
        $model->updateAttributes([
            'state_id'
        ]);
        Cashfree::$XClientId = $model->gateway->client_id;
        Cashfree::$XClientSecret = $model->gateway->client_secret;
        Cashfree::$XEnvironment = $model->gateway->mode ? Cashfree::$PRODUCTION : Cashfree::$SANDBOX;

        $cashfree = new Cashfree();

        $x_api_version = "2023-08-01";
        $create_orders_request = new CreateOrderRequest();
        $create_orders_request->setOrderAmount($model->amount);
        $create_orders_request->setOrderCurrency($model->currency);
        $customer_details = new \Cashfree\Model\CustomerDetails();
        $customer_details->setCustomerId('user' . $model->id);
        $customer_details->setCustomerPhone("9999999999");
        // $customer_details->setCustomerEmail($model->email ?? 'test');
        $returnUrl = $model->getGatewayUrl('success');
        $order_meta = new OrderMeta();
        $order_meta->setReturnUrl($returnUrl);
        $create_orders_request->setOrderMeta($order_meta);
        $create_orders_request->setCustomerDetails($customer_details);

        try {
            $result = $cashfree->PGCreateOrder($x_api_version, $create_orders_request);
            self::log(VarDumper::dumpAsString($result));
            $payment_session_id = $result[0]->getPaymentSessionId();
        } catch (\Exception $e) {
            self::log('Exception when calling PGCreateOrder: ' . $e->getMessage());
            return 'Exception when calling PGCreateOrder: ' . $e->getMessage();
        }
        $successUrl = Url::toRoute([
            '/payment/cash-free/success',
            'id' => $model->id,
            'session_id' => $payment_session_id
        ]);
        $model->updateHistory("checkout started from IP:" . Yii::$app->request->getUserIP());
        $this->updateMenuItems($model);
        return $this->render('process', [
            'model' => $model,
            'payment_session_id' => $payment_session_id,
            'successUrl' => $successUrl
        ]);
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionSuccess($id, $session_id = null)
    {
        if (is_null($id) && ! is_numeric($id)) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }
        $model = $this->findModel($id, false);
        if ($model->state_id != Transaction::STATE_INPROGRESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }

        $post = [
            'stripeToken' => null
        ];

        if (empty($session_id)) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }

        Yii::debug('stripe session id:' . $session_id);
        Yii::debug(VarDumper::dumpAsString($post));
        if (! empty($post)) {

            $model->remote_tx = $session_id;
            $model->response = Json::encode($post);

            $model->state_id = Transaction::STATE_SUCCESS;

            $model->save();

            $transactionModel = $model->getModel();
            if ($transactionModel && $transactionModel instanceof TActiveRecord) {
                return $this->redirect($transactionModel->getUrl('success', [
                    'id' => $transactionModel->id,
                    'transaction_id' => $model->id
                ]));
            }
        }
        $model->updateHistory("Success from IP:" . \Yii::$app->request->getUserIP());
        $this->updateMenuItems($model);
        return $this->render('success', [
            'model' => $model
        ]);
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionError($id)
    {
        $model = $this->findModel($id, false);
        if ($model->state_id != Transaction::STATE_INPROGRESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }
        $model->state_id = Transaction::STATE_FAILED;

        $model->save();

        $this->updateMenuItems($model);
        return $this->render('error', [
            'model' => $model
        ]);
    }

    /**
     * Finds the Transaction model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     *
     * @param integer $id
     * @param boolean $accessCheck
     * @return \app\modules\payment\models\Transaction|NULL
     */
    protected function findModel($id, $accessCheck = true)
    {
        if (($model = Transaction::findOne($id)) !== null) {
            if ($accessCheck && ! ($model->isAllowed()))
                throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}