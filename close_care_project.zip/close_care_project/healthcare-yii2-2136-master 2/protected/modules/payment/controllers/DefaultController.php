<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\payment\controllers;

use app\components\TActiveForm;
use app\components\TController;
use app\models\User;
use app\modules\payment\models\SettingsForm;
use app\modules\payment\models\Transaction;
use yii\filters\AccessControl;
use yii\filters\AccessRule;

/**
 * Default controller for the `payment` module
 */
class DefaultController extends TController
{

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [
                    [
                        'actions' => [
                            'index',
                            'settings'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isAdmin();
                        }
                    ],
                   
                ]
            ]
        ];
    }

    /**
     * Renders the index view for the module
     *
     * @return string
     */
    public function actionIndex()
    {
        return $this->render('index');
    }

    public function actionSettings()
    {
        $moduleSettings = new SettingsForm();
        
        if ($moduleSettings->load(\Yii::$app->request->post())) {
            if ($moduleSettings->validate() && $moduleSettings->Save()) {
                
                return $this->redirect([
                    'settings'
                ]);
            }
        }
        return $this->render('settings', [
            
            'model' => $moduleSettings
        ]);
    }
}
