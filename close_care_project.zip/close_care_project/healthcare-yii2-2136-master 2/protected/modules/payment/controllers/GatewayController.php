<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\payment\controllers;

use app\components\TActiveForm;
use app\components\TController;
use app\models\User;
use app\modules\payment\models\Gateway;
use app\modules\payment\models\ImportForm;
use app\modules\payment\models\SettingsForm;
use app\modules\payment\models\search\Gateway as GatewaySearch;
use Yii;
use yii\filters\AccessControl;
use yii\filters\AccessRule;
use yii\web\HttpException;
use yii\web\NotFoundHttpException;
use yii\web\UploadedFile;

/**
 * GatewayController implements the CRUD actions for Gateway model.
 */
class GatewayController extends TController
{

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [
                    [
                        'actions' => [
                            'clear',
                            'delete',
                            'detail',
                            'export',
                            'import'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isAdmin();
                        }
                    ],
                    [
                        'actions' => [
                            'index',
                            'add',
                            'view',
                            'update',
                            'clone',
                            'ajax',
                            'mass'
                        ],
                        'allow' => true,
                        'roles' => [
                            '@'
                        ]
                    ],
                    [
                        'actions' => [
                            'list'
                        ],
                        'allow' => true,
                        'roles' => [
                            '*',
                            '?',
                            '@'
                        ]
                    ]
                ]
            ]
        ];
    }

    /**
     * Lists all Gateway models.
     *
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new GatewaySearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $this->updateMenuItems();
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider
        ]);
    }

    /**
     * Lists all Gateway models.
     *
     * @return mixed
     */
    public function actionList()
    {
        $searchModel = new GatewaySearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        $dataProvider->query->andWhere([
            'state_id' => Gateway::STATE_ACTIVE
        ]);
        $this->updateMenuItems();
        return $this->render('list', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider
        ]);
    }

    /**
     * Displays a single Gateway model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $this->updateMenuItems($model);
        return $this->render('view', [
            'model' => $model
        ]);
    }

    /**
     * Creates a new Gateway model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     *
     * @return mixed
     */
    public function actionAdd(/* $id*/)
    {
        $model = new Gateway();
        $model->loadDefaultValues();
        $model->state_id = Gateway::STATE_ACTIVE;

        $settings = new SettingsForm();

        if (isset($settings->default_currency)) {
            $model->currency = $settings->default_currency;
        }

        /*
         * if (is_numeric($id)) {
         * $post = Post::findOne($id);
         * if ($post == null)
         * {
         * throw new NotFoundHttpException('The requested post does not exist.');
         * }
         * $model->id = $id;
         *
         * }
         */

        $model->checkRelatedData([]);
        $post = \yii::$app->request->post();
        if (\yii::$app->request->isAjax && $model->load($post)) {
            \yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }
        if ($model->load($post) && $model->save()) {
            return $this->redirect($model->getUrl());
        }
        $this->updateMenuItems();
        return $this->render('add', [
            'model' => $model
        ]);
    }

    /**
     * Updates an existing Gateway model.
     * If update is successful, the browser will be redirected to the 'view' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        $post = \yii::$app->request->post();
        if (\yii::$app->request->isAjax && $model->load($post)) {
            \yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }
        if ($model->load($post) && $model->save()) {
            return $this->redirect($model->getUrl());
        }
        $this->updateMenuItems($model);
        return $this->render('update', [
            'model' => $model
        ]);
    }

    /**
     * Clone an existing Gateway model.
     * If update is successful, the browser will be redirected to the 'view' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionClone($id)
    {
        $old = $this->findModel($id);

        $model = new Gateway();
        $model->loadDefaultValues();
        $model->state_id = Gateway::STATE_ACTIVE;

        // $model->id = $old->id;
        $model->title = $old->title;
        $model->mode = $old->mode;
        // $model->state_id = $old->state_id;
        $model->type_id = $old->type_id;
        $model->client_id = $old->client_id;
        $model->client_secret = $old->client_secret;
        $model->client_email = $old->client_email;
        // $model->created_on = $old->created_on;
        // $model->updated_on = $old->updated_on;
        // $model->created_by_id = $old->created_by_id;

        $post = \yii::$app->request->post();
        if (\yii::$app->request->isAjax && $model->load($post)) {
            \yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }
        if ($model->load($post) && $model->save()) {
            return $this->redirect($model->getUrl());
        }
        $this->updateMenuItems($model);
        return $this->render('update', [
            'model' => $model
        ]);
    }

    /**
     * Deletes an existing Gateway model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $model = $this->findModel($id);

        if (\yii::$app->request->post()) {
            $model->delete();
            return $this->redirect([
                'index'
            ]);
        }
        return $this->render('delete', [
            'model' => $model
        ]);
    }

    /**
     * Truncate an existing Gateway model.
     * If truncate is successful, the browser will be redirected to the 'index' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionClear($truncate = true)
    {
        $query = Gateway::find();
        foreach ($query->each() as $model) {
            $model->delete();
        }
        if ($truncate) {
            Gateway::truncate();
        }
        \Yii::$app->session->setFlash('success', 'Gateway Cleared !!!');
        return $this->redirect([
            'index'
        ]);
    }

    /**
     * Finds the Gateway model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     *
     * @param integer $id
     * @return Gateway the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id, $accessCheck = true)
    {
        if (($model = Gateway::findOne($id)) !== null) {

            if ($accessCheck && ! ($model->isAllowed()))
                throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));

            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    protected function updateMenuItems($model = null)
    {
        switch (\Yii::$app->controller->action->id) {

            case 'add':
                {
                    $this->menu['index'] = [
                        'label' => '<span class="glyphicon glyphicon-list"></span>',
                        'title' => Yii::t('app', 'Manage'),
                        'url' => [
                            'index'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                }
                break;
            case 'index':
                {
                    $this->menu['add'] = [
                        'label' => '<span class="glyphicon glyphicon-plus"></span>',
                        'title' => Yii::t('app', 'Add'),
                        'url' => [
                            'add'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                    $this->menu['import'] = array(
                        'label' => '<span class="glyphicon glyphicon-import"></span>' . Yii::t('app', ' Import'),
                        'title' => Yii::t('app', 'Import'),
                        'url' => [
                            'import'
                        ]
                        // 'visible' => User::isAdmin ()
                    );
                    $this->menu['clear'] = [
                        'label' => '<span class="glyphicon glyphicon-remove"></span>',
                        'title' => Yii::t('app', 'Clear'),
                        'url' => [
                            'clear'
                        ],
                        'htmlOptions' => [
                            'data-confirm' => "Are you sure to delete these items?"
                        ],
                        'visible' => User::isAdmin()
                    ];
                }
                break;
            case 'update':
                {
                    $this->menu['add'] = [
                        'label' => '<span class="glyphicon glyphicon-plus"></span>',
                        'title' => Yii::t('app', 'add'),
                        'url' => [
                            'add'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                    $this->menu['index'] = [
                        'label' => '<span class="glyphicon glyphicon-list"></span>',
                        'title' => Yii::t('app', 'Manage'),
                        'url' => [
                            'index'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                }
                break;

            default:
            case 'view':
                {
                    $this->menu['index'] = [
                        'label' => '<span class="glyphicon glyphicon-list"></span>',
                        'title' => Yii::t('app', 'Manage'),
                        'url' => [
                            'index'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                    if ($model != null) {
                        $this->menu['clone'] = [
                            'label' => '<span class="glyphicon glyphicon-copy">Clone</span>',
                            'title' => Yii::t('app', 'Clone'),
                            'url' => $model->getUrl('clone')
                            // 'visible' => User::isAdmin ()
                        ];
                        $this->menu['export'] = array(
                            'label' => '<i class="fas fa-print"></i> ' . Yii::t('app', 'Export'),
                            'title' => 'Export',
                            'url' => array(
                                'export',
                                'id' => $model->id
                            )
                        );
                        $this->menu['update'] = [
                            'label' => '<span class="glyphicon glyphicon-pencil"></span>',
                            'title' => Yii::t('app', 'Update'),
                            'url' => $model->getUrl('update')
                            // 'visible' => User::isAdmin ()
                        ];
                        $this->menu['delete'] = [
                            'label' => '<span class="glyphicon glyphicon-trash"></span>',
                            'title' => Yii::t('app', 'Delete'),
                            'url' => $model->getUrl('delete')
                            // 'visible' => User::isAdmin ()
                        ];
                    }
                }
        }
    }

    /**
     * Export data in json format
     *
     * @param integer $id
     * @return \yii\console\Response|\yii\web\Response
     */
    public function actionExport($id)
    {
        $rule = $this->findModel($id);

        $file = tempnam(sys_get_temp_dir(), str_replace(' ', '-', $rule->title));
        file_put_contents($file, json_encode($rule->asJson(true)));

        return Yii::$app->response->sendFile($file, basename($file) . '.json');
    }

    /**
     * Import data in json format
     *
     * @return array|array[]|NULL[]|string
     */
    public function actionImport()
    {
        $import = new ImportForm();

        $model = new Gateway();

        $post = \yii::$app->request->post();
        if (\yii::$app->request->isAjax && $import->load($post)) {
            \yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return TActiveForm::validate($import);
        }

        if ($import->load($post)) {
            $uploaded_file = UploadedFile::getInstance($import, "file");

            if ($uploaded_file != null) {

                $filename = $uploaded_file->tempName;

                $str = file_get_contents($filename);
                $json = json_decode($str, true);
                unset($json['id']);
                unset($json['created_by_id']);
                unset($json['created_on']);
                $model->setAttributes($json);
                if ($model->save()) {
                    $this->redirect([
                        'view',
                        'id' => $model->id
                    ]);
                }
            }
        }
        $this->updateMenuItems($model);
        return $this->render('import', [
            'model' => $model,
            'import' => $import
        ]);
    }
}
