<?php
namespace app\modules\payment\controllers;

use app\components\TActiveRecord;
use app\components\TController;
use app\models\User;
use app\modules\payment\models\Gateway;
use app\modules\payment\models\Transaction;
use app\modules\payment\models\search\Transaction as TransactionSearch;
use Yii;
use yii\filters\AccessControl;
use yii\filters\AccessRule;
use yii\helpers\Json;
use yii\web\HttpException;
use yii\web\NotFoundHttpException;
use app\modules\booking\models\Booking;
use app\modules\notification\models\Notification;
use app\modules\service\models\Service;

/**
 */
class PaypalController extends TController
{

    /**
     * Renders the index view for the module
     *
     * @return string
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [
                    [
                        'actions' => [
                            'clear',
                            'delete',
                            'process'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isAdmin();
                        }
                    ],
                    [
                        'actions' => [
                            'index',
                            'view',
                            'ajax' ,
                            'process'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isManager();
                        }
                    ],
                    [
                        'actions' => [
                            'process',
                            'success',
                            'error',
                            'index'
                        ],
                        'allow' => true,
                        'roles' => [
                            '@',
                            '?',
                            '*'
                        ]
                    ]
                ]
            ]
        ];
    }

    public function beforeAction($action)
    {
        if ($action->controller->action->id == 'success') {
            $this->enableCsrfValidation = false;
        }
        return parent::beforeAction($action);
    }

    /**
     * List of payment transactions
     *
     * @return \yii\web\Response
     */
    public function actionIndex()
    {
        return $this->redirect([
            '/payment/transaction'
        ]);
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return string
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $this->updateMenuItems($model);
        return $this->render('view', [
            'model' => $model
        ]);
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionProcess($id)
    {
        $this->layout = 'guest-main';
        $model = $this->findModel($id, false);
        if ($model->state_id == Transaction::STATE_SUCCESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }

        \yii::$app->session->set('paypal', $model->id);
        $model->state_id = Transaction::STATE_INPROGRESS;
        $model->updateAttributes([
            'state_id'
        ]);
        $model->updateHistory("processing from IP" . \Yii::$app->request->getUserIP());
        $this->updateMenuItems($model);
        return $this->render('process', [
            'model' => $model
        ]);
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return mixed
     */
    /*
     * public function actionSuccess($id = null)
     * {
     * if (is_null($id) && ! is_numeric($id)) {
     *
     * throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
     * }
     * $model = Transaction::findOne($id);
     *
     * $getBooking = Booking::findOne($model->id);
     * if ($model->state_id == Transaction::STATE_SUCCESS) {
     *
     * throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
     * }
     *
     * if (\yii::$app->request->isPost) {
     * $post = \yii::$app->request->post();
     * if (! empty($post)) {
     * $model->remote_tx = $post['id'];
     * if (isset($post['payments']['captures'][0]) && $post['payments']['captures'][0]) {
     * $payment = $post['payments']['captures'][0];
     * $model->remote_tx = $payment['id'];
     * }
     * if (isset($post['payer']) && $post['payer']) {
     * $model->email = $post['payer']['email_address'];
     * $model->name = $post['payer']['name']['given_name'] . ' ' . $post['payer']['name']['surname'];
     * }
     * $model->response = Json::encode($post);
     *
     * if ($post['status'] == 'COMPLETED') {
     * $model->state_id = Transaction::STATE_SUCCESS;
     * }
     * $model->save();
     *
     * // Redirect to the specified URL
     *
     * return $this->redirect('com.app.healthcare://paypalpay');
     * }
     * }
     * $model->updateHistory("Success started from IP:" . \Yii::$app->request->getUserIP());
     * $this->updateMenuItems($model);
     * return $this->render('success', [
     * 'model' => $model
     * ]);
     * }
     */
    public function actionSuccess($id = null)
    {
        if (is_null($id) || ! is_numeric($id)) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }

        $model = Transaction::findOne($id);

        $getBooking = Booking::findOne($model->model_id);

        $serviceQuery = Service::findOne($getBooking->service_id);

        if ($model->state_id == Transaction::STATE_SUCCESS) {

            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }

        if (\yii::$app->request->isPost) {
            $post = \yii::$app->request->post();
            if (! empty($post)) {
                $model->remote_tx = $post['id'];

                if (isset($post['payments']['captures'][0]) && $post['payments']['captures'][0]) {
                    $payment = $post['payments']['captures'][0];
                    $model->remote_tx = $payment['id'];
                }
                if (isset($post['payer']) && $post['payer']) {
                    $model->email = $post['payer']['email_address'];
                    $model->name = $post['payer']['name']['given_name'] . ' ' . $post['payer']['name']['surname'];
                }

                $model->response = Json::encode($post);

                if ($post['status'] == 'COMPLETED') {
                    $model->state_id = Transaction::STATE_SUCCESS;
                }

                if ($model->save() && $model->state_id == Transaction::STATE_SUCCESS) {

                    Notification::create([
                        'to_user_id' => $getBooking->provider_id,
                        'created_by_id' => $getBooking->created_by_id,
                        'title' => 'Booking Confirmed',
                        'description' => 'A booking has been successfully made for ' . $serviceQuery->title,
                        'model' => $getBooking // Assuming $getBooking is the relevant booking model
                    ], false);
                    return $this->render('success', [
                        'model' => $model
                    ]);
                }

                // Redirect to the specified URL
                // return $this->redirect('com.app.healthcare://paypalpay');
            }
        }

        $model->updateHistory("Success started from IP:" . \Yii::$app->request->getUserIP());
        $this->updateMenuItems($model);

        return $this->render('success', [
            'model' => $model
        ]);
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionError($id)
    {
        $model = $this->findModel($id, false);
        if ($model->state_id != Transaction::STATE_INPROGRESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }
        $model->state_id = Transaction::STATE_FAILED;

        $model->save();

        $this->updateMenuItems($model);
        return $this->render('error', [
            'model' => $model
        ]);
    }

    /**
     * Finds the Transaction model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     *
     * @param integer $id
     * @return \app\modules\payment\models\Transaction|NULL
     */
    protected function findModel($id)
    {
        if (($model = Transaction::findOne($id)) !== null) {
            if (! ($model->isAllowed()))
                throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
