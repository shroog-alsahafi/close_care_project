<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\payment\controllers;

use app\components\TActiveRecord;
use app\components\TController;
use app\models\User;
use app\modules\payment\models\Transaction;
use app\modules\payment\models\search\Transaction as TransactionSearch;
use Yii;
use yii\filters\AccessControl;
use yii\filters\AccessRule;
use yii\helpers\Json;
use yii\helpers\VarDumper;
use yii\web\HttpException;
use yii\web\NotFoundHttpException;

/**
 * Default controller for the `payment` module
 */
class StripeController extends TController
{

    /**
     * Renders the index view for the module
     *
     *
     * @return string
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [
                    [
                        'actions' => [
                            'clear',
                            'delete'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isAdmin();
                        }
                    ],
                    [
                        'actions' => [
                            'index',
                            'view',
                            'update',
                            'clone',
                            'ajax'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isManager();
                        }
                    ],
                    [
                        'actions' => [
                            'add',
                            'process',
                            'success',
                            'error',
                            'share',
                            'qrcode',
                            'checkout',
                            'index'
                        ],
                        'allow' => true,
                        'roles' => [
                            '@',
                            '?',
                            '*'
                        ]
                    ]
                ]
            ]
        ];
    }

    public function beforeAction($action)
    {
        if ((\Yii::$app->controller->action->id == 'success')) {
            $this->enableCsrfValidation = false;
        }
        return parent::beforeAction($action);
    }

    /**
     * List of payment transactions
     *
     * @return \yii\web\Response
     */
    public function actionIndex()
    {
        return $this->redirect([
            '/payment/transaction'
        ]);
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return string
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $this->updateMenuItems($model);
        return $this->render('view', [
            'model' => $model
        ]);
    }

    /**
     * Displays a single transaction model in progress state.
     *
     * @param integer $id
     * @return \yii\web\Response
     */
    public function actionProcess($id)
    {
        $this->layout = 'guest-main';
        $model = $this->findModel($id, false);
        if ($model->state_id == Transaction::STATE_SUCCESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }

        \yii::$app->session->set('stripe', $model->id);
        $model->state_id = Transaction::STATE_INPROGRESS;
        $model->updateAttributes([
            'state_id'
        ]);

        $privateKey = $model->gateway->client_secret;

        \Stripe\Stripe::setApiKey($privateKey);
        Yii::debug($model->getAbsoluteUrl('success'));
        $checkout_session = \Stripe\Checkout\Session::create([
            'line_items' => [
                [
                    'price_data' => [
                        'product' => $model->gateway->client_email,
                        'unit_amount' => $model->getAmount(),
                        'currency' => $model->getCurrency()
                    ],

                    'quantity' => 1
                ]
            ],
            'client_reference_id' => $model->id,
            'mode' => 'payment',
            'success_url' => $model->getGatewayUrl('success') . '&session_id={CHECKOUT_SESSION_ID}',
            'cancel_url' => $model->getGatewayUrl('error')
        ]);
        $model->updateHistory("checkout started from IP:" . \Yii::$app->request->getUserIP());
        return $this->redirect($checkout_session->url);
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionSuccess($id, $session_id = null)
    {
        if (is_null($id) && ! is_numeric($id)) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }
        $model = $this->findModel($id, false);
        if ($model->state_id != Transaction::STATE_INPROGRESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }

        $post = [
            'stripeToken' => null
        ];

        if (empty($session_id)) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }
        $privateKey = $model->gateway->client_secret;
        \Stripe\Stripe::setApiKey($privateKey);
        $post = \Stripe\Checkout\Session::retrieve($session_id);

        Yii::debug('stripe session id:' . $session_id);
        Yii::debug(VarDumper::dumpAsString($post));
        if (! empty($post)) {

            $model->remote_tx = $session_id;
            $model->response = Json::encode($post);

            $model->state_id = Transaction::STATE_FAIL;

            if (isset($post['payment_intent']) && $post['payment_intent']) {
                $model->remote_tx = $post['payment_intent'];
            }
            if (isset($post['customer_details']) && $post['customer_details']) {
                $model->email = $post['customer_details']['email'];
                $model->name = $post['customer_details']['name'];
            }

            if ($post['status'] == 'complete') {
                $model->state_id = Transaction::STATE_SUCCESS;
            }

            $model->save();

            $transactionModel = $model->getModel();
            if ($transactionModel && $transactionModel instanceof TActiveRecord) {
                return $this->redirect($transactionModel->getUrl('success', [
                    'id' => $transactionModel->id,
                    'transaction_id' => $model->id
                ]));
            }
        }
        $model->updateHistory("Success from IP:" . \Yii::$app->request->getUserIP());
        $this->updateMenuItems($model);
        return $this->render('success', [
            'model' => $model
        ]);
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionError($id)
    {
        $model = $this->findModel($id, false);
        if ($model->state_id != Transaction::STATE_INPROGRESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }
        $model->state_id = Transaction::STATE_FAILED;

        $model->save();

        $this->updateMenuItems($model);
        return $this->render('error', [
            'model' => $model
        ]);
    }

    /**
     * Finds the Transaction model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     *
     * @param integer $id
     * @param boolean $accessCheck
     * @return \app\modules\payment\models\Transaction|NULL
     */
    protected function findModel($id, $accessCheck = true)
    {
        if (($model = Transaction::findOne($id)) !== null) {
            if ($accessCheck && ! ($model->isAllowed()))
                throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}