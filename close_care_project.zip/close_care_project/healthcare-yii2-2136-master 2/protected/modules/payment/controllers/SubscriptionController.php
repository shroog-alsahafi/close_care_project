<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\payment\controllers;

use Mpdf\QrCode\QrCode;
use Mpdf\QrCode\Output\Png;
use app\components\TActiveForm;
use app\components\TActiveRecord;
use app\components\TController;
use app\models\User;
use app\modules\payment\components\StripeConfig;
use app\modules\payment\models\Gateway;
use app\modules\payment\models\Subscription;
use app\modules\payment\models\search\Subscription as SubscriptionSearch;
use Yii;
use yii\filters\AccessControl;
use yii\filters\AccessRule;
use yii\helpers\Json;
use yii\helpers\VarDumper;
use yii\web\HttpException;
use yii\web\NotFoundHttpException;

/**
 * SubscriptionController implements the CRUD actions for Subscription model.
 */
class SubscriptionController extends TController
{

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [
                    [
                        'actions' => [
                            'clear',
                            'delete'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isAdmin();
                        }
                    ],
                    [
                        'actions' => [
                            'index',
                            'add',
                            'view',
                            'update',
                            'clone',
                            'ajax'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isManager();
                        }
                    ],
                    [
                        'actions' => [
                            'add',
                            'process',
                            'success',
                            'error',
                            'share',
                            'qrcode',
                            'checkout'
                        ],
                        'allow' => true,
                        'roles' => [
                            '@',
                            '?',
                            '*'
                        ]
                    ]
                ]
            ]
        ];
    }

    public function beforeAction($action)
    {
        if ($action->controller->action->id == 'success') {
            $this->enableCsrfValidation = false;
        }
        return parent::beforeAction($action);
    }

    /**
     * Lists all Subscription models.
     *
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new SubscriptionSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $this->updateMenuItems();
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider
        ]);
    }

    /**
     * Displays a single Subscription model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $stripeConfig = new StripeConfig();

        $stripe = $stripeConfig->getStripeClient();
        try {

            $data = $stripe->subscriptions->retrieve($model->remote_tx, []);
        } catch (\Exception $e) {
            echo $e->getTraceAsString();
        }

        $this->updateMenuItems($model);
        return $this->render('view', [
            'model' => $model,
            'data' => $data
        ]);
    }

    /**
     * Displays a single Subscription model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionShare($id, $json = false)
    {
        $this->layout = 'guest-main';
        $model = $this->findModel($id, false);
        // $this->updateMenuItems($model);

        if ($json) {
            \yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            $model->response = null;
            return $model;
        }
        return $this->render('share', [
            'model' => $model
        ]);
    }

    /**
     * Displays QR Code for single Subscription model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionQrcode($id)
    {
        $model = $this->findModel($id, false);

        $qrCode = new QrCode($model->getAbsoluteUrl('share'));
        $output = new Png();
        echo $output->output($qrCode, 200, [
            255,
            255,
            255
        ], [
            0,
            0,
            0
        ]);
        exit();
    }

    /**
     * Displays a single Subscription model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionProcess($id)
    {
        $this->layout = 'guest-main';
        $model = $this->findModel($id, false);
        if ($model->state_id == Subscription::STATE_SUCCESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }

        \yii::$app->session->set('stripe.subscription', $model->id);
        $model->state_id = Subscription::STATE_INPROGRESS;
        $model->updateAttributes([
            'state_id'
        ]);
        $model->updateHistory("processing from IP: " . \Yii::$app->request->getUserIP());
        $this->updateMenuItems($model);
        return $this->render('process', [
            'model' => $model
        ]);
    }

    public function actionCheckout($id)
    {
        $this->layout = 'guest-main';
        $model = $this->findModel($id, false);
        if ($model->state_id == Subscription::STATE_SUCCESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }

        \yii::$app->session->set('stripe.subscription', $model->id);
        $model->state_id = Subscription::STATE_INPROGRESS;
        $model->updateAttributes([
            'state_id'
        ]);

        $stripeConfig = new StripeConfig();

        \Stripe\Stripe::setApiKey($stripeConfig->privateKey);

        $config = [
            'line_items' => [
                [
                    'price_data' => [
                        'product' => $model->type->client_email,
                        'unit_amount' => $model->getAmount(),
                        'currency' => $model->getCurrency(),
                        'recurring' => [
                            'interval' => 'year'
                        ]
                    ],

                    'quantity' => 1
                ]
            ],
            'client_reference_id' => $model->id,
            'mode' => 'subscription',
            'success_url' => $model->getAbsoluteUrl('success') . '&session_id={CHECKOUT_SESSION_ID}',
            'cancel_url' => $model->getAbsoluteUrl('error')
        ];
        $checkout_session = \Stripe\Checkout\Session::create($config);
        $model->updateHistory("checkout started from IP" . \Yii::$app->request->getUserIP());
        return $this->redirect($checkout_session->url);
    }

    public function actionWebhook()
    {
        $stripeConfig = new StripeConfig();
        \Stripe\Stripe::setApiKey($stripeConfig->privateKey);

        // Replace this endpoint secret with your endpoint's unique secret
        // If you are testing with the CLI, find the secret by running 'stripe listen'
        // If you are using an endpoint defined with the API or dashboard, look in your webhook settings
        // at https://dashboard.stripe.com/webhooks
        $endpoint_secret = 'whsec_12345';

        $payload = @file_get_contents('php://input');
        $event = null;
        try {
            $event = \Stripe\Event::constructFrom(json_decode($payload, true));
        } catch (\UnexpectedValueException $e) {
            // Invalid payload
            echo '⚠️  Webhook error while parsing basic request.';
            http_response_code(400);
            exit();
        }
        // Handle the event
        switch ($event->type) {
            case 'customer.subscription.trial_will_end':
                $subscription = $event->data->object; // contains a \Stripe\Subscription
                                                      // Then define and call a method to handle the trial ending.
                                                      // handleTrialWillEnd($subscription);
                break;
            case 'customer.subscription.created':
                $subscription = $event->data->object; // contains a \Stripe\Subscription
                                                      // Then define and call a method to handle the subscription being created.
                                                      // handleSubscriptionCreated($subscription);
                break;
            case 'customer.subscription.deleted':
                $subscription = $event->data->object; // contains a \Stripe\Subscription
                                                      // Then define and call a method to handle the subscription being deleted.
                                                      // handleSubscriptionDeleted($subscription);
                break;
            case 'customer.subscription.updated':
                $subscription = $event->data->object; // contains a \Stripe\Subscription
                                                      // Then define and call a method to handle the subscription being updated.
                                                      // handleSubscriptionUpdated($subscription);
                break;
            default:
                // Unexpected event type
                echo 'Received unknown event type';
        }
    }

    /**
     * Displays a single Subscription model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionSuccess($id, $session_id)
    {
        if (is_null($id) && ! is_numeric($id)) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }
        $model = $this->findModel($id, false);
        if ($model->state_id != Subscription::STATE_INPROGRESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }

        $post = [
            'stripeToken' => null
        ];

        if (empty($session_id)) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }
        $stripeConfig = new StripeConfig();
        \Stripe\Stripe::setApiKey($stripeConfig->privateKey);
        $post = \Stripe\Checkout\Session::retrieve($session_id);
        Yii::debug('stripe session id:' . $session_id);
        Yii::debug(VarDumper::dumpAsString($post));

        $model->remote_tx = $post['subscription'];
        $model->response = Json::encode($post);

        $model->state_id = Subscription::STATE_SUCCESS;

        $model->save();

        $transactionModel = $model->getModel();
        if ($transactionModel && $transactionModel instanceof TActiveRecord) {
            return $this->redirect($transactionModel->getUrl('success', [
                'transaction_id' => $model->id
            ]));
        }
        $model->updateHistory("Success started from IP" . \Yii::$app->request->getUserIP());
        $this->updateMenuItems($model);
        return $this->render('success', [
            'model' => $model
        ]);
    }

    /**
     * Displays a single Subscription model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionError($id)
    {
        $model = $this->findModel($id, false);
        if ($model->state_id != Subscription::STATE_INPROGRESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }
        $model->state_id = Subscription::STATE_FAILED;

        $model->save();

        $this->updateMenuItems($model);
        return $this->render('error', [
            'model' => $model
        ]);
    }

    /**
     *
     * Creates a new Subscription model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     *
     *
     * @param number $id
     *            gateway
     * @param number $a
     *            amount
     * @param string $c
     *            currency
     * @param string $d
     *            description
     * @param string $cn
     *            customer name
     * @param string $ce
     *            customer email
     * @param string $ps
     *            period start
     * @param string $pe
     *            period end
     * @throws NotFoundHttpException
     * @return array|array[]|NULL[]|\yii\web\Response|string
     */
    public function actionAdd($id = null, $a = null, $c = null, $d = null, $cn = null, $ce = null, $ps = null, $pe = null)
    {
        $model = new Subscription();
        $model->loadDefaultValues();
        $model->state_id = Subscription::STATE_PENDING;
        $model->amount = $a;
        $model->description = $d;
        $model->currency = $c;
        $model->name = $cn;
        $model->email = $ce;
        $model->current_period_start = $ps;
        $model->current_period_end = $pe;

        if (is_numeric($id)) {
            $gateway = Gateway::findActive()->andWhere([
                'id' => $id
            ]);
            if ($gateway == null) {
                throw new NotFoundHttpException('The requested post does not exist.');
            }
        } else {
            $gateway = Gateway::findActive()->one();
        }

        if (! empty($gateway)) {
            $model->type_id = $gateway->id;

            if (empty($model->currency)) {
                $model->currency = $gateway->currency;
            }
        }
        $model->checkRelatedData([]);
        $post = \yii::$app->request->post();
        if (\yii::$app->request->isAjax && $model->load($post)) {
            \yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }
        if ($model->load($post) && $model->save()) {
            $submit = trim($_POST['payment']);
            if ($submit == 'share') {
                return $this->redirect($model->getUrl('share'));
            }
            return $this->redirect($model->getUrl('process'));
        }
        $this->updateMenuItems();
        return $this->render('add', [
            'model' => $model
        ]);
    }

    /**
     * Updates an existing Subscription model.
     * If update is successful, the browser will be redirected to the 'view' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        $post = \yii::$app->request->post();
        if (\yii::$app->request->isAjax && $model->load($post)) {
            \yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }
        if ($model->load($post) && $model->save()) {
            return $this->redirect($model->getUrl('process'));
        }
        $this->updateMenuItems($model);
        return $this->render('update', [
            'model' => $model
        ]);
    }

    /**
     * Clone an existing Subscription model.
     * If update is successful, the browser will be redirected to the 'view' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionClone($id)
    {
        $old = $this->findModel($id);

        $model = new Subscription();
        $model->loadDefaultValues();
        $model->state_id = Subscription::STATE_ACTIVE;

        // $model->id = $old->id;
        $model->amount = $old->amount;
        $model->currency = $old->currency;
        $model->description = $old->description;
        $model->model_id = $old->model_id;
        $model->model_type = $old->model_type;
        $model->remote_tx = $old->remote_tx;
        $model->current_period_start = $old->current_period_start;
        $model->current_period_end = $old->current_period_end;
        $model->name = $old->name;
        $model->email = $old->email;
        $model->response = $old->response;
        // $model->state_id = $old->state_id;
        $model->type_id = $old->type_id;
        // $model->created_on = $old->created_on;
        // $model->created_by_id = $old->created_by_id;

        $post = \yii::$app->request->post();
        if (\yii::$app->request->isAjax && $model->load($post)) {
            \yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }
        if ($model->load($post) && $model->save()) {
            return $this->redirect($model->getUrl());
        }
        $this->updateMenuItems($model);
        return $this->render('update', [
            'model' => $model
        ]);
    }

    /**
     * Deletes an existing Subscription model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $model = $this->findModel($id);

        if (\yii::$app->request->post()) {
            $model->delete();
            return $this->redirect([
                'index'
            ]);
        }
        return $this->render('delete', [
            'model' => $model
        ]);
    }

    /**
     * Truncate an existing Subscription model.
     * If truncate is successful, the browser will be redirected to the 'index' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionClear($truncate = true)
    {
        $query = Subscription::find();
        foreach ($query->each() as $model) {
            $model->delete();
        }
        if ($truncate) {
            Subscription::truncate();
        }
        \Yii::$app->session->setFlash('success', 'Subscription Cleared !!!');
        return $this->redirect([
            'index'
        ]);
    }

    /**
     * Finds the Subscription model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     *
     * @param integer $id
     * @return Subscription the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id, $accessCheck = true)
    {
        if (($model = Subscription::findOne($id)) !== null) {

            if ($accessCheck && ! ($model->isAllowed()))
                throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));

            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    protected function updateMenuItems($model = null)
    {
        switch (\Yii::$app->controller->action->id) {

            case 'add':
                {
                    $this->menu['index'] = [
                        'label' => '<span class="glyphicon glyphicon-list"></span>',
                        'title' => Yii::t('app', 'Manage'),
                        'url' => [
                            'index'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                }
                break;
            case 'index':
                {
                    $this->menu['add'] = [
                        'label' => '<span class="glyphicon glyphicon-plus"></span>',
                        'title' => Yii::t('app', 'Add'),
                        'url' => [
                            'add'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                    $this->menu['clear'] = [
                        'label' => '<span class="glyphicon glyphicon-remove"></span>',
                        'title' => Yii::t('app', 'Clear'),
                        'url' => [
                            'clear'
                        ],
                        'htmlOptions' => [
                            'data-confirm' => "Are you sure to delete these items?"
                        ],
                        'visible' => User::isAdmin()
                    ];
                }
                break;
            case 'update':
                {
                    $this->menu['add'] = [
                        'label' => '<span class="glyphicon glyphicon-plus"></span>',
                        'title' => Yii::t('app', 'add'),
                        'url' => [
                            'add'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                    $this->menu['index'] = [
                        'label' => '<span class="glyphicon glyphicon-list"></span>',
                        'title' => Yii::t('app', 'Manage'),
                        'url' => [
                            'index'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                }
                break;

            default:
            case 'view':
                {
                    $this->menu['index'] = [
                        'label' => '<span class="glyphicon glyphicon-list"></span>',
                        'title' => Yii::t('app', 'Manage'),
                        'url' => [
                            'index'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                    if ($model != null) {
                        $this->menu['share'] = [
                            'label' => '<span class="glyphicon glyphicon-share">Share</span>',
                            'title' => Yii::t('app', 'Share'),
                            'url' => $model->getUrl('share', [
                                'id' => $model->id
                            ])
                            // 'visible' => User::isAdmin ()
                        ];
                        $this->menu['clone'] = [
                            'label' => '<span class="glyphicon glyphicon-copy"></span>',
                            'title' => Yii::t('app', 'Clone'),
                            'url' => $model->getUrl('clone')
                            // 'visible' => User::isAdmin ()
                        ];
                        $this->menu['update'] = [
                            'label' => '<span class="glyphicon glyphicon-pencil"></span>',
                            'title' => Yii::t('app', 'Update'),
                            'url' => $model->getUrl('update')
                            // 'visible' => User::isAdmin ()
                        ];
                        $this->menu['delete'] = [
                            'label' => '<span class="glyphicon glyphicon-trash"></span>',
                            'title' => Yii::t('app', 'Delete'),
                            'url' => $model->getUrl('delete')
                            // 'visible' => User::isAdmin ()
                        ];
                    }
                }
        }
    }
}
