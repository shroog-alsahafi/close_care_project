<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\payment\controllers;

use Yii;
use app\modules\payment\models\Transaction;
use app\modules\payment\models\search\Transaction as TransactionSearch;
use app\components\TController;
use yii\web\NotFoundHttpException;
use yii\filters\AccessControl;
use yii\filters\AccessRule;
use app\models\User;
use yii\web\HttpException;
use app\components\TActiveForm;
use app\modules\payment\models\Gateway;
use Mpdf\QrCode\QrCode;
use Mpdf\QrCode\Output\Png;

/**
 * TransactionController implements the CRUD actions for Transaction model.
 */
class TransactionController extends TController
{

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [
                    [
                        'actions' => [
                            'clear',
                            'delete'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isAdmin();
                        }
                    ],
                    [
                        'actions' => [
                            'index',
                            'add',
                            'view',
                            'update',
                            'clone',
                            'ajax',
                            'mass'
                        ],
                        'allow' => true,
                        'roles' => [
                            '@'
                        ]
                    ],
                    [
                        'actions' => [
                            'add',
                            'process',
                            'success',
                            'error',
                            'share',
                            'qrcode',
                            'checkout'
                        ],
                        'allow' => true,
                        'roles' => [
                            '@',
                            '?',
                            '*'
                        ]
                    ]
                ]
            ]
        ];
    }

    /**
     * Lists all Transaction models.
     *
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new TransactionSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $this->updateMenuItems();
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider
        ]);
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $model = $this->findModel($id);
        $this->updateMenuItems($model);
        return $this->render('view', [
            'model' => $model
        ]);
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionShare($id, $title = null, $json = false)
    {
        $this->layout = 'guest-main';
        $model = $this->findModel($id, false);

        if ($title == null) {
            return $this->redirect($model->getUrl());
        }
        if ($json) {
            \yii::$app->response->format = \yii\web\Response::FORMAT_JSON;

            return $model;
        }
        $this->updateMenuItems($model);
        return $this->render('share', [
            'model' => $model
        ]);
    }

    /**
     * Displays QR Code for single Transaction model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionQrcode($id)
    {
        $model = $this->findModel($id, false);

        $qrCode = new QrCode($model->getAbsoluteUrl('share'));
        $output = new Png();
        echo $output->output($qrCode, 200, [
            255,
            255,
            255
        ], [
            0,
            0,
            0
        ]);
        exit();
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionProcess($id)
    {
        $this->layout = 'guest-main';
        $model = $this->findModel($id, false);
        if ($model->state_id == Transaction::STATE_SUCCESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }

        return $this->redirect($model->getGatewayUrl('process'));
    }

    /**
     * Displays a single Transaction model.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionSucess($id)
    {
        $this->layout = 'guest-main';
        $model = $this->findModel($id, false);
        if ($model->state_id == Transaction::STATE_SUCCESS) {
            throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));
        }

        return $this->redirect($model->getGatewayUrl('success'));
    }

    /**
     * Creates a new Transaction model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     *
     * @return mixed
     */
    public function actionAdd($id = null, $a = null, $c = null, $d = null)
    {
        $model = new Transaction();
        $model->loadDefaultValues();
        $model->state_id = Transaction::STATE_PENDING;
        $model->amount = $a;
        $model->description = $d;
        $model->currency = $c;

        if (\Yii::$app instanceof \yii\web\Application) {
            $model->user_ip = \Yii::$app->request->getUserIP();
            $model->user_agent = \Yii::$app->request->getUserAgent();
        }

        if (is_numeric($id)) {
            $gateway = Gateway::findOne($id);
        } else {
            $gateway = Gateway::find()->one();
        }

        if ($gateway == null || ! $gateway->isActive()) {
            throw new NotFoundHttpException('The requested post does not exist.');
        }
        if (empty($model->currency)) {
            $model->currency = $gateway->currency;
        }

        $model->type_id = $gateway->id;

        $model->checkRelatedData();
        $post = \yii::$app->request->post();
        if (\yii::$app->request->isAjax && $model->load($post)) {
            \yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }
        if ($model->load($post) && $model->save()) {
            $submit = trim($_POST['payment']);
            if ($submit == 'share') {
                return $this->redirect($model->getUrl('share'));
            }
            return $this->redirect($model->getUrl('process'));
        }
        $this->updateMenuItems();
        return $this->render('add', [
            'model' => $model
        ]);
    }

    /**
     * Updates an existing Transaction model.
     * If update is successful, the browser will be redirected to the 'view' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        $post = \yii::$app->request->post();
        if (\yii::$app->request->isAjax && $model->load($post)) {
            \yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }
        if ($model->load($post) && $model->save()) {
            return $this->redirect($model->getUrl());
        }
        $this->updateMenuItems($model);
        return $this->render('update', [
            'model' => $model
        ]);
    }

    /**
     * Clone an existing Transaction model.
     * If update is successful, the browser will be redirected to the 'view' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionClone($id)
    {
        $old = $this->findModel($id);

        $model = new Transaction();
        $model->loadDefaultValues();
        $model->state_id = Transaction::STATE_ACTIVE;

        // $model->id = $old->id;
        $model->name = $old->name;
        $model->email = $old->email;
        $model->description = $old->description;
        $model->model_id = $old->model_id;
        $model->model_type = $old->model_type;
        $model->payment = $old->payment;
        $model->currency = $old->currency;
        $model->gateway_type = $old->gateway_type;
        $model->mode = $old->mode;
        // $model->state_id = $old->state_id;
        $model->type_id = $old->type_id;
        // $model->created_on = $old->created_on;

        $post = \yii::$app->request->post();
        if (\yii::$app->request->isAjax && $model->load($post)) {
            \yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
            return TActiveForm::validate($model);
        }
        if ($model->load($post) && $model->save()) {
            return $this->redirect($model->getUrl());
        }
        $this->updateMenuItems($model);
        return $this->render('update', [
            'model' => $model
        ]);
    }

    /**
     * Deletes an existing Transaction model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $model = $this->findModel($id);

        if (\yii::$app->request->post()) {
            $model->delete();
            return $this->redirect([
                'index'
            ]);
        }
        return $this->render('delete', [
            'model' => $model
        ]);
    }

    /**
     * Truncate an existing Transaction model.
     * If truncate is successful, the browser will be redirected to the 'index' page.
     *
     * @param integer $id
     * @return mixed
     */
    public function actionClear($truncate = true)
    {
        $query = Transaction::find();
        foreach ($query->each() as $model) {
            $model->delete();
        }
        if ($truncate) {
            Transaction::truncate();
        }
        \Yii::$app->session->setFlash('success', 'Transaction Cleared !!!');
        return $this->redirect([
            'index'
        ]);
    }

    /**
     * Finds the Transaction model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     *
     * @param integer $id
     * @return Transaction the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id, $accessCheck = true)
    {
        if (($model = Transaction::findOne($id)) !== null) {

            if ($accessCheck && ! ($model->isAllowed()))
                throw new HttpException(403, Yii::t('app', 'You are not allowed to access this page.'));

            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    protected function updateMenuItems($model = null)
    {
        switch (\Yii::$app->controller->action->id) {

            case 'add':
                {
                    $this->menu['index'] = [
                        'label' => '<span class="glyphicon glyphicon-list"></span>',
                        'title' => Yii::t('app', 'Manage'),
                        'url' => [
                            'index'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                }
                break;
            case 'index':
                {
                    $this->menu['add'] = [
                        'label' => '<span class="glyphicon glyphicon-plus"></span>',
                        'title' => Yii::t('app', 'Add'),
                        'url' => [
                            'add'
                        ],
                        'visible' => false
                    ];
                    $this->menu['clear'] = [
                        'label' => '<span class="glyphicon glyphicon-remove"></span>',
                        'title' => Yii::t('app', 'Clear'),
                        'url' => [
                            'clear'
                        ],
                        'htmlOptions' => [
                            'data-confirm' => "Are you sure to delete these items?"
                        ],
                        'visible' => false
                    ];
                }
                break;
            case 'update':
                {
                    $this->menu['add'] = [
                        'label' => '<span class="glyphicon glyphicon-plus"></span>',
                        'title' => Yii::t('app', 'add'),
                        'url' => [
                            'add'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                    $this->menu['index'] = [
                        'label' => '<span class="glyphicon glyphicon-list"></span>',
                        'title' => Yii::t('app', 'Manage'),
                        'url' => [
                            'index'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                }
                break;

            default:
            case 'view':
                {
                    $this->menu['index'] = [
                        'label' => '<span class="glyphicon glyphicon-list"></span>',
                        'title' => Yii::t('app', 'Manage'),
                        'url' => [
                            'index'
                        ]
                        // 'visible' => User::isAdmin ()
                    ];
                    if ($model != null) {
                        $this->menu['share'] = [
                            'label' => '<span class="glyphicon glyphicon-share">Share</span>',
                            'title' => Yii::t('app', 'Share'),
                            'url' => $model->getUrl('share', [
                                'id' => $model->id
                            ])
                            // 'visible' => User::isAdmin ()
                        ];
                        $this->menu['clone'] = [
                            'label' => '<span class="glyphicon glyphicon-copy">Clone</span>',
                            'title' => Yii::t('app', 'Clone'),
                            'url' => $model->getUrl('clone')
                            // 'visible' => User::isAdmin ()
                        ];
                        $this->menu['update'] = [
                            'label' => '<span class="glyphicon glyphicon-pencil"></span>',
                            'title' => Yii::t('app', 'Update'),
                            'url' => $model->getUrl('update')
                            // 'visible' => User::isAdmin ()
                        ];
                        $this->menu['delete'] = [
                            'label' => '<span class="glyphicon glyphicon-trash"></span>',
                            'title' => Yii::t('app', 'Delete'),
                            'url' => $model->getUrl('delete')
                            // 'visible' => User::isAdmin ()
                        ];
                    }
                }
        }
    }
}
