<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
use yii\db\Migration;

/**
 * php console.php module/migrate
 */
class m241120_081157_add_column_user_id_into_table_tbl_refund extends Migration
{

    public function safeUp()
    {
        $table = Yii::$app->db->getTableSchema('{{%refund}}');
        if (! isset($table->columns['user_id'])) {
            $this->addColumn('{{%refund}}', 'user_id', $this->integer()
                ->defaultValue(NULL));
        }
        if (! isset($table->columns['provider_id'])) {
            $this->addColumn('{{%refund}}', 'provider_id', $this->integer()
                ->defaultValue(NULL));
        }
    }

    public function safeDown()
    {
        $table = Yii::$app->db->schema->getTableSchema('{{%refund}}');
        if (isset($table)) {
            $this->dropTable('{{%refund}}');
        }
    }
}