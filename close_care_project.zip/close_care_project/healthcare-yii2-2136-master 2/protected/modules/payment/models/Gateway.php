<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\payment\models;

use app\components\helpers\World;
use app\models\User;
use app\modules\payment\components\Currency;
use Yii;
use yii\helpers\Html;
use yii\helpers\Url;
use app\components\helpers\TArrayHelper;

/**
 * This is the model class for table "tbl_payment_gateway".
 *
 * @property integer $id
 * @property string $title
 * @property string $description
 * @property string $client_id
 * @property string $client_secret
 * @property string $client_email
 * @property string $currency
 * @property integer $mode
 * @property string $country_code
 * @property integer $state_id
 * @property integer $type_id
 * @property string $created_on
 * @property string $updated_on
 * @property integer $created_by_id
 */
class Gateway extends \app\components\TActiveRecord
{

    public function __toString()
    {
        return (string) $this->title . '[' . $this->getCountry() . ']' . '[' . $this->getType() . ']' . '[' . $this->getModeType() . ']';
    }

    const STATE_INACTIVE = 0;

    const STATE_ACTIVE = 1;

    const STATE_DELETED = 2;

    public static function getStateOptions()
    {
        return [
            self::STATE_INACTIVE => "In-Active",
            self::STATE_ACTIVE => "Active",
            self::STATE_DELETED => "Deleted"
        ];
    }

    public function getState()
    {
        $list = self::getStateOptions();
        return isset($list[$this->state_id]) ? $list[$this->state_id] : 'Not Defined';
    }

    public function getStateBadge()
    {
        $list = [
            self::STATE_INACTIVE => "secondary",
            self::STATE_ACTIVE => "success",
            self::STATE_DELETED => "danger"
        ];
        return isset($list[$this->state_id]) ? \yii\helpers\Html::tag('span', $this->getState(), [
            'class' => 'badge bg-' . $list[$this->state_id]
        ]) : 'Not Defined';
    }

    public static function getActionOptions()
    {
        return [
            self::STATE_INACTIVE => "Deactivate",
            self::STATE_ACTIVE => "Activate",
            self::STATE_DELETED => "Delete"
        ];
    }

    const MODE_SANDBOX = 0;

    const MODE_PRODUCTION = 1;

    public static function getModeTypeOptions()
    {
        return [
            self::MODE_SANDBOX => "Sandbox",
            self::MODE_PRODUCTION => "Live"
        ];
    }

    public function getModeType()
    {
        $list = self::getModeTypeOptions();
        return isset($list[$this->mode]) ? $list[$this->mode] : 'Not Defined';
    }

    const GATEWAY_TYPE_PAYPAL = 0;

    const GATEWAY_TYPE_STRIPE = 1;

    const GATEWAY_TYPE_CASHFREE = 2;
    
    public static function getTypeOptions()
    {
        return [
            self::GATEWAY_TYPE_PAYPAL => \Yii::t('app', 'Paypal'),
            self::GATEWAY_TYPE_STRIPE => \Yii::t('app', 'Stripe'),
            self::GATEWAY_TYPE_CASHFREE => \Yii::t('app', 'CashFree')
        ];
    }

    public function getType()
    {
        $list = self::getTypeOptions();
        return isset($list[$this->type_id]) ? $list[$this->type_id] : 'Not Defined';
    }

    public function getCountryOptions()
    {
        return World::countries();
    }

    public function beforeValidate()
    {
        $settings = new SettingsForm();
        if ($this->isNewRecord) {
            if (empty($this->created_on)) {
                $this->created_on = \date('Y-m-d H:i:s');
            }
            if (empty($this->updated_on)) {
                $this->updated_on = \date('Y-m-d H:i:s');
            }
            if (empty($this->created_by_id)) {
                $this->created_by_id = self::getCurrentUser();
            }
            if (empty($this->currency) && isset($settings->default_currency)) {
                $this->currency = $settings->default_currency;
            }
        } else {
            $this->updated_on = date('Y-m-d H:i:s');
        }
        return parent::beforeValidate();
    }

    public function getCountry()
    {
        if ($this->country_code) {
            return World::findCountryByCode($this->country_code);
        }
        return 'INDIA';
    }

    /**
     *
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%payment_gateway}}';
    }

    /**
     *
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [
                    'title',
                    'type_id',
                    'client_id',
                    'client_secret',
                    'client_email',
                    'created_on',
                    'created_by_id'
                ],
                'required'
            ],
            [
                [
                    'mode',
                    'state_id',
                    'type_id',
                    'created_by_id'
                ],
                'integer'
            ],
            [
                [
                    'client_id',
                    'client_secret'
                ],
                'string',
                'max' => 255
            ],
            [
                'description',
                'string'
            ],
            [
                [
                    'country_code',
                    'currency'
                ],
                'string',
                'max' => 8
            ],
            [
                [
                    'title'
                ],
                'unique'
            ],
            [
                [
                    'created_on',
                    'updated_on'
                ],
                'safe'
            ],
            [
                [
                    'title',
                    'client_email'
                ],
                'string',
                'max' => 64
            ],
            [
                [
                    'title',
                    'client_email',
                    'client_id',
                    'client_secret'
                ],
                'trim'
            ],
            [
                [
                    'currency'
                ],
                'in',
                'range' => array_keys(Currency::getCurrencyList())
            ],
            [
                [
                    'state_id'
                ],
                'in',
                'range' => array_keys(self::getStateOptions())
            ],
            [
                [
                    'type_id'
                ],
                'in',
                'range' => array_keys(self::getTypeOptions())
            ]
        ];
    }

    /**
     *
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'title' => Yii::t('app', 'Title'),
            'value' => Yii::t('app', 'Value'),
            'mode' => Yii::t('app', 'Mode'),
            'country_code' => Yii::t('app', 'Country'),
            'client_id' => Yii::t('app', 'Client ID'),
            'client_secret' => Yii::t('app', 'Client Secret'),
            'client_email' => Yii::t('app', 'Product ID'),
            'currency' => Yii::t('app', 'Currency'),
            'description' => Yii::t('app', 'Description'),
            'state_id' => Yii::t('app', 'State'),
            'type_id' => Yii::t('app', 'Type'),
            'created_on' => Yii::t('app', 'Created On'),
            'updated_on' => Yii::t('app', 'Updated On'),
            'created_by_id' => Yii::t('app', 'Created By')
        ];
    }

    public function getCreatedBy()
    {
        return $this->hasOne(User::class, [
            'id' => 'created_by_id'
        ])->cache();
    }

    public function getTransactions()
    {
        return $this->hasMany(Transaction::class, [
            'type_id' => 'id'
        ]);
    }

    public function getClient()
    {
        return $this->mode == 0 ? 'sb' : $this->client_id;
    }

    public static function getHasManyRelations()
    {
        $relations = [];

        $relations['feeds'] = [
            'feeds',
            'Feed',
            'model_id'
        ];
        return $relations;
    }

    public static function getHasOneRelations()
    {
        $relations = [];
        $relations['created_by_id'] = [
            'createdBy',
            'User',
            'id'
        ];
        return $relations;
    }

    public function beforeDelete()
    {
        if (! parent::beforeDelete()) {
            return false;
        }
        // TODO : start here
        Transaction::deleteRelatedAll([
            'type_id' => $this->id
        ]);

        return true;
    }

    public function beforeSave($insert)
    {
        if (! parent::beforeSave($insert)) {
            return false;
        }
        // TODO : start here

        return true;
    }

    public function asJson($with_relations = false)
    {
        $json = [];
        $json['id'] = $this->id;
        $json['title'] = $this->title;
        $json['mode'] = $this->mode;
        $json['country_code'] = $this->country_code;
        $json['client_id'] = $this->client_id;
        $json['client_secret'] = $this->client_secret;
        $json['client_email'] = $this->client_email;
        $json['currency'] = $this->currency;
        $json['description'] = $this->description;
        $json['state_id'] = $this->state_id;
        $json['type_id'] = $this->type_id;
        $json['created_on'] = $this->created_on;
        $json['created_by_id'] = $this->created_by_id;
        if ($with_relations) {}
        return $json;
    }

    public function getControllerID()
    {
        return '/payment/' . parent::getControllerID();
    }

    public static function addTestData($count = 1)
    {
        $faker = \Faker\Factory::create();
        $states = array_keys(self::getStateOptions());
        for ($i = 0; $i < $count; $i ++) {
            $model = new self();
            $model->loadDefaultValues();
            $model->title = $faker->text(10);
            $model->description = $faker->text;
            $model->value = $faker->text;
            $model->mode = $faker->text(10);
            $model->client_id = 1;
            $model->client_secret = $faker->text(10);
            $model->client_email = $faker->text(10);
            $model->state_id = $states[rand(0, count($states))];
            $model->type_id = 0;
            $model->save();
        }
    }

    public static function addData($data)
    {
        if (self::find()->count() != 0) {
            return;
        }

        $faker = \Faker\Factory::create();
        foreach ($data as $item) {
            $model = new self();
            $model->loadDefaultValues();

            $model->title = isset($item['title']) ? $item['title'] : $faker->text(10);

            $model->description = isset($item['description']) ? $item['description'] : $faker->text;

            $model->value = isset($item['value']) ? $item['value'] : $faker->text;

            $model->mode = isset($item['mode']) ? $item['mode'] : $faker->text(10);
            $model->client_id = isset($item['client_id']) ? $item['client_id'] : 1;

            $model->client_secret = isset($item['client_secret']) ? $item['client_secret'] : $faker->text(10);

            $model->client_email = isset($item['client_email']) ? $item['client_email'] : $faker->text(10);
            $model->state_id = self::STATE_ACTIVE;

            $model->type_id = isset($item['type_id']) ? $item['type_id'] : 0;
            $model->save();
        }
    }

    public function isAllowed()
    {
        if (User::isAdmin())
            return true;
        if ($this->hasAttribute('created_by_id') && $this->created_by_id == Yii::$app->user->id) {
            return true;
        }

        return User::isUser();
    }

    public function afterSave($insert, $changedAttributes)
    {
        return parent::afterSave($insert, $changedAttributes);
    }

    public function getClientIDHtml($view)
    {
        $html = '';

        $html .= '<div id="client_id"> ' . $this->client_id . '';

        $html .= Html::button('<i class="fa fa-copy"></i>', [
            'id' => 'buttonCopyText',
            'class' => 'btn btn-success position-absolute ms-3',
            'title' => 'Copy'
        ]);

        $html .= '</div>';

        $view->registerJs("
$('#buttonCopyText').click(function () {
    var copyText = document.getElementById('client_id');
    navigator.clipboard.writeText(copyText.value);
})
", 'client_id');

        return $html;
    }

    public function getPaymentLink()
    {
        $params = TArrayHelper::merge([
            '/payment/transaction/add',
            'id' => $this->id
        ], Yii::$app->request->queryParams);
        return Url::toRoute($params);
    }
}
