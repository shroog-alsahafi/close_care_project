<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\payment\models;

use app\components\helpers\TEmailTemplateHelper;
use app\models\EmailQueue;
use app\models\User;
use app\modules\payment\components\Currency;
use Yii;
use yii\helpers\Url;
use app\modules\booking\models\Booking;

/**
 * This is the model class for table "tbl_payment_transaction".
 *
 * @property integer $id
 * @property string $name
 * @property string $email
 * @property string $description
 * @property integer $model_id
 * @property string $model_type
 * @property string $amount
 * @property string $currency
 * @property string $completed_on
 * @property string $response
 * @property string $user_ip
 * @property string $user_agent
 * @property integer $state_id
 * @property integer $type_id
 * @property string $created_on
 */
class Transaction extends \app\components\TActiveRecord
{

    public function __toString()
    {
        return (string) ! empty($this->createdBy) ? $this->createdBy->full_name : '';
    }

    const STATE_PENDING = 0;

    const STATE_SUCCESS = 1;

    const STATE_INPROGRESS = 2;

    const STATE_FAIL = 3;
    
    const STATE_REFUND = 4;

    public static function getStateOptions()
    {
        return [
            self::STATE_PENDING => \Yii::t('app', 'Pending'),
            self::STATE_INPROGRESS => \Yii::t('app', 'In-progress'),
            self::STATE_SUCCESS => \Yii::t('app', 'Paid'),
            self::STATE_FAIL => \Yii::t('app', 'Failed'),
            self::STATE_REFUND => \Yii::t('app', 'Refunded'),
            
        ];
    }

    public function getState()
    {
        $list = $this->getStateOptions();
        return isset($list[$this->state_id]) ? $list[$this->state_id] : 'NEW';
    }

    public function getStateBadge()
    {
        $list = [
            self::STATE_PENDING => "secondary",
            self::STATE_INPROGRESS => "warning",
            self::STATE_SUCCESS => "success",
            self::STATE_FAIL => "danger",
            self::STATE_REFUND => "danger",
            
        ];
        return isset($list[$this->state_id]) ? \yii\helpers\Html::tag('span', $this->getState(), [
            'class' => 'badge bg-' . $list[$this->state_id]
        ]) : 'Not Defined';
    }

    public static function getActionOptions()
    {
        return [
            self::STATE_PENDING => \Yii::t('app', 'Pending'),
            self::STATE_INPROGRESS => \Yii::t('app', 'In-progress'),
            self::STATE_SUCCESS => \Yii::t('app', 'Paid'),
            self::STATE_FAIL => \Yii::t('app', 'Failed'),
            self::STATE_REFUND => \Yii::t('app', 'Refund')
            
        ];
    }

    public function beforeValidate()
    {
        if ($this->isNewRecord) {
            if (empty($this->created_on)) {
                $this->created_on = \date('Y-m-d H:i:s');
            }
        } else {}
        return parent::beforeValidate();
    }

    public static function getTypeOptions()
    {
        return self::listData(Gateway::findActive()->all());
    }

    /**
     *
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%payment_transaction}}';
    }

    /**
     *
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [
                    // 'name',
                    // 'email',
                    'amount',
                    // 'currency',
                    'created_on'
                ],
                'required'
            ],
            [
                [
                    'description',
                    'response',
                    'currency',
                    'amount'
                ],
                'string'
            ],
            [
                [
                    'model_id',
                    'state_id',
                    'type_id'
                ],
                'integer'
            ],
            [
                [
                    'name',
                    'email',
                    'created_on',
                    'completed_on',
                    'model_type'
                ],
                'safe'
            ],
            [
                [
                    'description',
                    'user_agent'
                ],
                'string',
                'max' => 255
            ],
            [
                [
                    'description'
                ],
                'match',
                'pattern' => '/^[a-zA-Z0-9.,\-\/\s]+$/'
            ],
            [
                [
                    'currency'
                ],
                'string',
                'max' => 125
            ],
            [
                [
                    'name',
                    'email',
                    'model_type',
                    'amount',
                    'currency'
                ],
                'trim'
            ],
            [
                [
                    'name'
                ],
                'app\components\validators\TNameValidator'
            ],
           /*  [
                [
                    'amount'
                ],
                'string',
                'min' => 10,
                'max' => 100000
            ], */
            [
                [
                    'email'
                ],
                'email'
            ],
            [
                [
                    'currency'
                ],
                'in',
                'range' => array_keys(Currency::getCurrencyList())
            ],
            [
                [
                    'state_id'
                ],
                'in',
                'range' => array_keys(self::getStateOptions())
            ]
        ];
    }

    /**
     *
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'name' => Yii::t('app', 'Name'),
            'email' => Yii::t('app', 'Email'),
            'description' => Yii::t('app', 'Description'),
            'model_id' => Yii::t('app', 'Model'),
            'model_type' => Yii::t('app', 'Model Type'),
            'amount' => Yii::t('app', 'Amount'),
            'currency' => Yii::t('app', 'Currency'),
            'response' => Yii::t('app', 'Response'),
            'user_ip' => Yii::t('app', 'User Ip'),
            'user_agent' => Yii::t('app', 'User Agent'),
            'completed_on' => Yii::t('app', 'Completed On'),
            'state_id' => Yii::t('app', 'State'),
            'type_id' => Yii::t('app', 'Gateway'),
            'created_on' => Yii::t('app', 'Created On')
        ];
    }

    public function getGateway()
    {
        return $this->hasOne(Gateway::class, [
            'id' => 'type_id'
        ]);
    }

    public function getType()
    {
        return $this->getGateway();
    }

    public function getCreatedBy()
    {
        return $this->hasOne(User::class, [
            'id' => 'created_by_id'
        ])->cache();
    }
    
    public function getBooking()
    {
        return $this->hasOne(Booking::class, [
            'id' => 'model_id'
        ])->cache();
    }

    public static function getHasManyRelations()
    {
        $relations = [];

        $relations['feeds'] = [
            'feeds',
            'Feed',
            'model_id'
        ];
        return $relations;
    }

    public static function getHasOneRelations()
    {
        $relations = [];

        $relations['type_id'] = [
            'gateway',
            'Gateway',
            'id'
        ];
        return $relations;
    }

    public function beforeDelete()
    {
        if (! parent::beforeDelete()) {
            return false;
        }
        // TODO : start here

        return true;
    }

    public function beforeSave($insert)
    {
        if (! parent::beforeSave($insert)) {
            return false;
        }
        // TODO : start here
        $old_state = isset($this->oldAttributes['state_id']) ? $this->oldAttributes['state_id'] : $this->state_id;
        if ($old_state != $this->state_id) {
            switch ($this->state_id) {
                case self::STATE_SUCCESS:
                    $this->completed_on = date('Y-m-d H:i:s');
                    return true;
                    break;

                case self::STATE_FAIL:
                    $this->completed_on = null;
                    break;
            }
        }
        return true;
    }

    public function asJson($with_relations = false)
    {
        $json = [];
        $json['id'] = $this->id;
        $json['name'] = $this->name;
        $json['email'] = $this->email;
        $json['description'] = $this->description;
        $json['model_id'] = $this->model_id;
        $json['model_type'] = $this->model_type;
        $json['amount'] = $this->amount;
        $json['currency'] = $this->currency;
        $json['response'] = $this->response;
        $json['state_id'] = $this->state_id;
        $json['type_id'] = $this->type_id;
        $json['created_on'] = $this->created_on;
        if ($with_relations) {}
        return $json;
    }

    public function getControllerID()
    {
        return '/payment/' . parent::getControllerID();
    }

    public function getGatewayUrl($action = 'success')
    {
        switch ($this->gateway->type_id) {
            case Gateway::GATEWAY_TYPE_STRIPE:
                $controller = 'stripe';
                break;
            case Gateway::GATEWAY_TYPE_PAYPAL:
                $controller = 'paypal';
                break;
            case Gateway::GATEWAY_TYPE_CASHFREE:
                $controller = 'cash-free';
                break;
        }

        $params = [
            '/payment/' . $controller . '/' . $action
        ];

        $params['id'] = $this->id;

        return Url::toRoute($params, true);
    }

    public static function addTestData($count = 1)
    {
        $faker = \Faker\Factory::create();
        $states = array_keys(self::getStateOptions());
        for ($i = 0; $i < $count; $i ++) {
            $model = new self();
            $model->loadDefaultValues();
            $model->name = $faker->text(10);
            $model->email = $faker->email;
            $model->description = $faker->text;
            $model->model_id = 1;
            $model->model_type = $faker->text(10);
            $model->amount = $faker->text(10);
            $model->currency = $faker->text(10);
            $model->response = $faker->text(10);
            $model->state_id = $states[rand(0, count($states))];
            $model->type_id = 0;
            $model->save();
        }
    }

    public static function addData($data)
    {
        if (self::find()->count() != 0) {
            return;
        }

        $faker = \Faker\Factory::create();
        foreach ($data as $item) {
            $model = new self();
            $model->loadDefaultValues();

            $model->name = isset($item['name']) ? $item['name'] : $faker->text(10);

            $model->email = isset($item['email']) ? $item['email'] : $faker->email;

            $model->description = isset($item['description']) ? $item['description'] : $faker->text;

            $model->model_id = isset($item['model_id']) ? $item['model_id'] : 1;

            $model->model_type = isset($item['model_type']) ? $item['model_type'] : $faker->text(10);

            $model->amount = isset($item['amount']) ? $item['amount'] : $faker->text(10);

            $model->currency = isset($item['currency']) ? $item['currency'] : $faker->text(10);

            $model->response = isset($item['response']) ? $item['response'] : $faker->text;

            $model->state_id = self::STATE_ACTIVE;

            $model->type_id = isset($item['type_id']) ? $item['type_id'] : 0;
            $model->save();
        }
    }

    public function isAllowed()
    {
        if (User::isAdmin())
            return true;
        if ($this->hasAttribute('created_by_id') && $this->created_by_id == Yii::$app->user->id) {
            return true;
        }

        return User::isUser();
    }

    public function getCurrency()
    {
        return strtolower($this->currency);
    }

    public function getModel()
    {
        $modelType = $this->model_type;
        if (class_exists($modelType)) {
            return $modelType::findOne($this->model_id);
        }
    }

    public function getAmountwithCurrency()
    {
        return $this->amount . ' ' . $this->currency;
    }

    public function getAmount()
    {
        return $this->amount * 100;
    }

    public function afterSave($insert, $changedAttributes)
    {
        $old_state = isset($changedAttributes['state_id']) ? $changedAttributes['state_id'] : $this->state_id;

        if (! \Yii::$app instanceof \yii\console\Application && ! defined('MIGRATION_IN_PROGRESS') && ($insert || $old_state != $this->state_id)) {
            switch ($this->state_id) {
                case self::STATE_SUCCESS:
                    $this->sendSuccessMail();
                    break;
                case self::STATE_FAIL:
                    break;
            }
        }
        return parent::afterSave($insert, $changedAttributes);
    }

    public function sendSuccessMail()
    {
        $message = TEmailTemplateHelper::renderFile('@app/modules/payment/templates/success.php', [
            'model' => $this
        ]);

        EmailQueue::add([
            'to' => $this->email,
            'subject' => 'Payment Successful : ' . $this->name,
            'html' => $message
        ], true);
    }

    public function isPending()
    {
        return in_array($this->state_id, [
            self::STATE_PENDING,
            self::STATE_INPROGRESS
        ]);
    }
}
