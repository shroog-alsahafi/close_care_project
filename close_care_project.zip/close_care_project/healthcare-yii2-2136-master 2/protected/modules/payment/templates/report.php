
<tr>
	<td style="padding: 20px 40px;">
		<p>Payments List</p>
		<table cellspacing="0" cellpadding="0" border="1"
			class="release_sheet" width="100%">
			<thead>
				<tr>
					<th>Sr.No.</th>
					<th>Transaction ID</th>
					<th>Amount</th>
					<th>Currency</th>
					<th>Payment Status</th>
					<th>Description</th>
				</tr>
			</thead>
			<tbody>
			<?php
if ($query->count() > 0) {
    foreach ($query->each() as $key => $payment) {
        ?>
			<tr>
					<td><?php echo $key+1; ?></td>
					<td><?php echo $payment->id; ?></td>
					<td><?php echo $payment->amount; ?></td>
					<td><?php echo $payment->currency; ?></td>
					<td><?php echo $payment->state_id; ?></td>
					<td><?php echo $payment->description; ?></td>

				</tr>
  			<?php } } ?>
		</tbody>
			</tbody>
		</table>
	</td>
</tr>

