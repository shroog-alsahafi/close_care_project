<tr>
    <td align="left"
        style="font-family: Lato, sans-serif; padding-top: 30px; padding-bottom: 0; color: #333333;">
        <h4 style="margin: 0; font-weight: 500; font-size: 19px;">Dear Admin</h4>
    </td>
</tr>
<tr>
    <td align="left">
        <p style="font-size: 14px; padding: 0 0px 23px; border-bottom: 1px solid #ececec; text-align: left; color: #666; margin-bottom: 8px;">
            <?= \Yii::t('app', "Payment transaction has been made.") ?></br>
            <?= \Yii::t('app', "Please find the transaction details below.") ?>
        </p>
        <?php
        if (!empty($model)) {
            // Check if $model->response is a string before calling json_decode
            $response = is_string($model->response) ? json_decode($model->response) : null;
            ?>
            <p>
                Payment Link: <?= $model->getAbsoluteUrl() ?>
            </p>
            <p>
                Transaction ID : <?= $model->id ?>
            </p>
            <p>
                Name: <?= $model->name ?>
            </p>
            <p>
                Email: <?= $model->email ?>
            </p>
            <p>
                Amount : <?= $model->getAmountwithCurrency() ?>
            </p>
            <p>
                Payment Status : <?= $model->getState() ?>
            </p>
            <?php
        }
        ?>
    </td>
</tr>
