-- -------------------------------------------

SET SQL_QUOTE_SHOW_CREATE = 1;
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;

-- -------------------------------------------
-- -------------------------------------------
-- START BACKUP
-- -------------------------------------------

-- -------------------------------------------
-- TABLE `tbl_provider`
-- -------------------------------------------
DROP TABLE IF EXISTS `tbl_provider`;
CREATE TABLE IF NOT EXISTS `tbl_provider` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(126) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(126) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_no` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profession` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specilization` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state_id` int NOT NULL DEFAULT '0',
  `type_id` int NOT NULL DEFAULT '0',
  `degree` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identity_id` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `professional_classification_no` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  INDEX(`first_name`),
  INDEX(`last_name`),
  INDEX(`email`),
  INDEX(`contact_no`),
  INDEX(`profession`),
  INDEX(`state_id`),
  INDEX(`created_by_id`),
  KEY `fk_provider_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_provider_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------
-- TABLE `tbl_provider_availability`
-- -------------------------------------------

DROP TABLE IF EXISTS `tbl_provider_availability`;
CREATE TABLE IF NOT EXISTS `tbl_provider_availability` (
  `id` int NOT NULL AUTO_INCREMENT,
  `provider_id` int NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `day_id`   int DEFAULT NULL,
  `state_id` int NOT NULL DEFAULT '0',
  `type_id` int NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int NOT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX(`provider_id`),
  INDEX(`start_time`),
  INDEX(`end_time`),
  INDEX(`created_by_id`),
  KEY `fk_tbl_provider_availability_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_tbl_provider_availability_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------

-- -------------------------------------------
-- TABLE `tbl_provider_service_detail`
-- -------------------------------------------

DROP TABLE IF EXISTS `tbl_provider_service_detail`;
CREATE TABLE IF NOT EXISTS `tbl_provider_service_detail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `service_id` int NOT NULL,
  `rates` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state_id` int NOT NULL DEFAULT '0',
  `type_id` int NOT NULL DEFAULT '0',
  `created_on` datetime DEFAULT NULL,
  `created_by_id` int NOT NULL,
  PRIMARY KEY (`id`),
  INDEX(`created_by_id`),
  KEY `fk_provider_service_detail_created_by_id` (`created_by_id`),
  CONSTRAINT `fk_provider_service_detail_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------

-- -------------------------------------------
-- TABLE `tbl_provider_qualification`
-- -------------------------------------------

DROP TABLE IF EXISTS `tbl_provider_qualification`;
CREATE TABLE IF NOT EXISTS `tbl_provider_qualification` (
	`id` INT NOT NULL AUTO_INCREMENT,
	`title` VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
	`description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
	`state_id` INT NOT NULL DEFAULT '1',
	`type_id` INT NOT NULL DEFAULT '0',
	`created_on` DATETIME DEFAULT NULL,
	`created_by_id` INT(11) NOT NULL,
	PRIMARY KEY (`id`),
	INDEX (`title`),
	KEY `fk_provider_qualification_created_by_id` (`created_by_id`),
	CONSTRAINT `fk_provider_qualification_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
----------------------------------------------

-- -------------------------------------------
-- TABLE `tbl_provider_bank_detail`
-- -------------------------------------------

DROP TABLE IF EXISTS `tbl_provider_bank_detail`;
CREATE TABLE IF NOT EXISTS `tbl_provider_bank_detail` (
          `id` int NOT NULL AUTO_INCREMENT,
          `acc_holder_name` varchar(126) COLLATE utf8mb4_unicode_ci NOT NULL,
          `account_no` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
          `iban_no` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
          `state_id` int NOT NULL DEFAULT '0',
          `type_id` int NOT NULL DEFAULT '0',
          `created_on` datetime DEFAULT NULL,
          `created_by_id` int NOT NULL,
          PRIMARY KEY (`id`),
          INDEX(`created_by_id`),
          KEY `fk_provider_bank_detail_created_by_id` (`created_by_id`),
          CONSTRAINT `fk_provider_bank_detail_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
----------------------------------------------


SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- -------------------------------------------
-- END BACKUP
-- -------------------------------------------
