<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
use yii\db\Migration;

/**
 * php console.php module/migrate
 */
class m240830_140821__install_provider extends Migration{

    public function safeUp()
    {
        
        $dbfile = __DIR__ . '/../db/install.sql';
        if (is_file($dbfile)) {
        	echo "m240830_140821__install_provider installing module.... :$dbfile \n";
            $sql = file_get_contents( $dbfile);
            $this->execute($sql);
        }
    }
    
    public function safeDown()
    {
        echo "m240830_140821__install_provider migrating down by doing nothing....\n";
    }
}