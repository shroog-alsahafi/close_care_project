<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
use yii\db\Migration;

/**
 * php console.php module/migrate
 */
class m240907_100945_add_new_tbl_provider_qualification extends Migration
{

    public function safeUp()
    {
        $table = Yii::$app->db->getTableSchema('{{%provider_qualification}}');

        if (! isset($table)) {
            $this->execute("DROP TABLE IF EXISTS `tbl_provider_qualification`;
           CREATE TABLE IF NOT EXISTS `tbl_provider_qualification` (
          `id` INT NOT NULL AUTO_INCREMENT,
          `title` VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
          `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
          `state_id` INT NOT NULL DEFAULT '1',
          `type_id` INT NOT NULL DEFAULT '0',
          `created_on` DATETIME DEFAULT NULL,
          `created_by_id` INT(11) NOT NULL,
          PRIMARY KEY (`id`),
          INDEX (`title`),
          KEY `fk_provider_qualification_created_by_id` (`created_by_id`),
          CONSTRAINT `fk_provider_qualification_created_by_id` FOREIGN KEY (`created_by_id`) REFERENCES `tbl_user` (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
        }
    }

    public function safeDown()
    {
        $table = Yii::$app->db->schema->getTableSchema('{{%provider_qualification}}');
        if (isset($table)) {
            $this->dropTable('{{%provider_qualification}}');
        }
    }
}