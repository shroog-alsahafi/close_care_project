<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
use yii\db\Migration;

/**
 * php console.php module/migrate
 */
class m240909_100935_add_new_column_in_tbl_provider extends Migration
{

    public function safeUp()
    {
        $table = Yii::$app->db->getTableSchema('{{%provider}}');
        if (! isset($table->columns['degree'])) {
            $this->addColumn('{{%provider}}', 'degree', $this->string(36)
                ->defaultValue(null));
        }
        if (! isset($table->columns['identity_id'])) {
            $this->addColumn('{{%provider}}', 'identity_id', $this->string(36)
                ->defaultValue(null));
        }
        if (! isset($table->columns['professional_classification_no'])) {
            $this->addColumn('{{%provider}}', 'professional_classification_no', $this->string(36)
                ->defaultValue(null));
        }
    }

    public function safeDown()
    {
        $table = Yii::$app->db->getTableSchema('{{%provider}}');
        if (! isset($table->columns['degree'])) {
            $this->addColumn('{{%provider}}', 'degree', $this->string(36)
                ->defaultValue(null));
        }
        if (! isset($table->columns['identity_id'])) {
            $this->addColumn('{{%provider}}', 'identity_id', $this->string(36)
                ->defaultValue(null));
        }
        if (! isset($table->columns['professional_classification_no'])) {
            $this->addColumn('{{%provider}}', 'professional_classification_no', $this->string(36)
                ->defaultValue(null));
        }
    }
}