<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
use yii\db\Migration;

/**
 * php console.php module/migrate
 */
class m240909_120931_alter_service_id_column_in_tbl_provider_service_detail extends Migration
{

    public function safeUp()
    {
        $table = Yii::$app->db->getTableSchema('{{%provider_service_detail}}');
        if (isset($table->columns['service_id'])) {
            $this->execute("ALTER TABLE `tbl_provider_service_detail` CHANGE `service_id` `service_id`  integer NULL DEFAULT NULL; ");
        }
    }

    public function safeDown()
    {
        $table = Yii::$app->db->getTableSchema('{{%provider_service_detail}}');
        if (isset($table->columns['service_id'])) {
            $this->execute("ALTER TABLE `tbl_provider_service_detail` CHANGE `service_id` `service_id` integer NOT NULL;");
        }
    }
}