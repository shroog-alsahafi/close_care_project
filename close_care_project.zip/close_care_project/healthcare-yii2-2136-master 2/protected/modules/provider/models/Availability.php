<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\provider\models;

use Yii;
use app\models\Feed;
use app\models\User;
use yii\helpers\ArrayHelper;
use app\modules\provider\models\Provider;
use app\modules\booking\models\Booking;

/**
 * This is the model class for table "tbl_provider_availability".
 *
 * @property integer $id
 * @property integer $provider_id
 * @property string $start_time
 * @property string $end_time
 * @property integer $day_id
 * @property integer $state_id
 * @property integer $type_id
 * @property string $created_on
 * @property integer $created_by_id
 * @property User $createdBy
 */
class Availability extends \app\components\TActiveRecord
{

    public function __toString()
    {
        return (string) $this->provider_id;
    }

    public static function getProviderOptions()
    {
        return [
            "TYPE1",
            "TYPE2",
            "TYPE3"
        ];
    }

    public function getProvider()
    {
        $list = self::getProviderOptions();
        return isset($list[$this->provider_id]) ? $list[$this->provider_id] : 'Not Defined';
    }

    const STATE_INACTIVE = 0;

    const STATE_ACTIVE = 1;

    const STATE_DELETED = 2;

    const STATE_UNAVAILABILITY = 2;

    const MONDAY = 1;

    const TUESDAY = 2;

    const WEDNESDAY = 3;

    const THURSDAY = 4;

    const FRIDAY = 5;

    const SATURDAY = 6;

    const SUNDAY = 7;

    const DAY = 0;

    const CHECK_DATE = 1;

    public $day_ids;

    public $slots;

    public static function getStateOptions()
    {
        return [
            self::STATE_INACTIVE => "New",
            self::STATE_ACTIVE => "Active",
            self::STATE_DELETED => "Deleted"
        ];
    }

    public static function getDayOptions()
    {
        return [
            self::MONDAY => "Monday",
            self::TUESDAY => "Tuesday",
            self::WEDNESDAY => "Wednesday",
            self::THURSDAY => "Thursday",
            self::FRIDAY => "Friday",
            self::SATURDAY => "Saturday",
            self::SUNDAY => "Sunday"
        ];
    }

    public function getDay()
    {
        $list = self::getDayOptions();
        return isset($list[$this->day_id]) ? $list[$this->day_id] : 'Not Defined';
    }

    public function getState()
    {
        $list = self::getStateOptions();
        return isset($list[$this->state_id]) ? $list[$this->state_id] : 'Not Defined';
    }

    public function getStateBadge()
    {
        $list = [
            self::STATE_INACTIVE => "secondary",
            self::STATE_ACTIVE => "success",
            self::STATE_DELETED => "danger"
        ];
        return isset($list[$this->state_id]) ? \yii\helpers\Html::tag('span', $this->getState(), [
            'class' => 'badge bg-' . $list[$this->state_id]
        ]) : 'Not Defined';
    }

    public static function getActionOptions()
    {
        return [
            self::STATE_INACTIVE => "Deactivate",
            self::STATE_ACTIVE => "Activate",
            self::STATE_DELETED => "Delete"
        ];
    }

    public static function getTypeOptions()
    {
        return [
            "TYPE1",
            "TYPE2",
            "TYPE3"
        ];
    }

    public function getType()
    {
        $list = self::getTypeOptions();
        return isset($list[$this->type_id]) ? $list[$this->type_id] : 'Not Defined';
    }

    public function beforeValidate()
    {
        if ($this->isNewRecord) {
            if (empty($this->created_on)) {
                $this->created_on = \date('Y-m-d H:i:s');
            }
            if (empty($this->created_by_id)) {
                $this->created_by_id = self::getCurrentUser();
            }
        } else {}
        return parent::beforeValidate();
    }

    /**
     *
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%provider_availability}}';
    }

    /**
     *
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [

                    'created_by_id'
                ],
                'required'
            ],
            [
                [
                    'provider_id',
                    'day_id',
                    'state_id',
                    'type_id',
                    'created_by_id'
                ],
                'integer'
            ],
            [
                [
                    'slots',
                    'day_ids',
                    'start_time',
                    'end_time',
                    'created_on',
                    'date'
                ],
                'safe'
            ],
            [
                [
                    'created_by_id'
                ],
                'exist',
                'skipOnError' => true,
                'targetClass' => User::class,
                'targetAttribute' => [
                    'created_by_id' => 'id'
                ]
            ],
            [
                [
                    'state_id'
                ],
                'in',
                'range' => array_keys(self::getStateOptions())
            ],
            [
                [
                    'type_id'
                ],
                'in',
                'range' => array_keys(self::getTypeOptions())
            ]
        ];
    }

    /**
     *
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'provider_id' => Yii::t('app', 'Provider'),
            'start_time' => Yii::t('app', 'Start Time'),
            'end_time' => Yii::t('app', 'End Time'),
            'day_id' => Yii::t('app', 'Day'),
            'state_id' => Yii::t('app', 'State'),
            'type_id' => Yii::t('app', 'Type'),
            'created_on' => Yii::t('app', 'Created On'),
            'created_by_id' => Yii::t('app', 'Created By')
        ];
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), [
            'id' => 'created_by_id'
        ])->cache();
    }

    public function getProviders()
    {
        return $this->hasOne(Provider::className(), [
            'id' => 'provider_id'
        ])->cache();
    }

    public static function getHasManyRelations()
    {
        $relations = [];

        $relations['feeds'] = [
            'feeds',
            'Feed',
            'model_id'
        ];
        return $relations;
    }

    public static function getHasOneRelations()
    {
        $relations = [];
        $relations['created_by_id'] = [
            'createdBy',
            'User',
            'id'
        ];
        return $relations;
    }

    public function beforeDelete()
    {
        if (! parent::beforeDelete()) {
            return false;
        }
        // TODO : start here

        return true;
    }

    public function beforeSave($insert)
    {
        if (! parent::beforeSave($insert)) {
            return false;
        }
        // TODO : start here

        return true;
    }

    public function getModelsByDayId($state_id = self::STATE_UNAVAILABILITY)
    {
        return self::find()->where([
            'day_id' => $this->day_id,
            'state_id' => $state_id
        ])->my();
    }

    public function getUnAvailabilityTimeArray()
    {
        $data = [];
        foreach ($this->getModelsByDayId()->each() as $model) {
            $data[] = [
                'start_time' => $model->start_time,
                'end_time' => $model->end_time
            ];
        }

        return $data;
    }

    public function asUnAvailJson()
    {
        $json = [
            'id' => $this->id,
            'day_id' => $this->day_id,
            'state_id' => $this->state_id,
            'type_id' => $this->type_id,
            'created_on' => $this->created_on,
            'created_by_id' => $this->created_by_id,
            'date' => $this->date,
            'availability' => $this->getUnAvailabilityTimeArray()
        ];

        return $json;
    }

    public function asJson($with_relations = false)
    {
        $arr = [
            'un-availability-list'
        ];
        if (in_array(\Yii::$app->controller->action->id, $arr)) {

            return $this->asUnAvailJson();
        }
        $json = [];
        $json['id'] = $this->id;
        $json['provider_id'] = $this->provider_id;
        $json['start_time'] = $this->start_time;
        $json['end_time'] = $this->end_time;
        $json['day_id'] = $this->day_id;
        $json['state_id'] = $this->state_id;
        $json['type_id'] = $this->type_id;
        $json['created_on'] = $this->created_on;
        $json['created_by_id'] = $this->created_by_id;
        if ($with_relations) {
            // createdBy
            $list = $this->createdBy;

            if (is_array($list)) {
                $relationData = array_map(function ($item) {
                    return $item->asJson();
                }, $list);

                $json['createdBy'] = $relationData;
            } else {
                $json['createdBy'] = $list;
            }
        }
        return $json;
    }

    public function getControllerID()
    {
        return '/provider/' . parent::getControllerID();
    }

    public static function addTestData($count = 1)
    {
        $faker = \Faker\Factory::create();
        $states = array_keys(self::getStateOptions());
        for ($i = 0; $i < $count; $i ++) {
            $model = new self();
            $model->loadDefaultValues();
            $model->provider_id = 1;
            $model->start_time = \date('H:i:s');
            $model->end_time = \date('H:i:s');
            $model->day_id = 1;
            $model->state_id = $states[rand(0, count($states))];
            $model->type_id = 0;
            $model->save();
        }
    }

    public static function addData($data)
    {
        if (self::find()->count() != 0) {
            return;
        }

        $faker = \Faker\Factory::create();
        foreach ($data as $item) {
            $model = new self();
            $model->loadDefaultValues();

            $model->provider_id = isset($item['provider_id']) ? $item['provider_id'] : 1;

            $model->start_time = isset($item['start_time']) ? $item['start_time'] : \date('H:i:s');

            $model->end_time = isset($item['end_time']) ? $item['end_time'] : \date('H:i:s');

            $model->day_id = isset($item['day_id']) ? $item['day_id'] : 1;
            $model->state_id = self::STATE_ACTIVE;

            $model->type_id = isset($item['type_id']) ? $item['type_id'] : 0;
            $model->save();
        }
    }

    public function isAllowed()
    {
        if (User::isAdmin())
            return true;
        if ($this->hasAttribute('created_by_id') && $this->created_by_id == Yii::$app->user->id) {
            return true;
        }

        return User::isUser();
    }

    public function afterSave($insert, $changedAttributes)
    {
        return parent::afterSave($insert, $changedAttributes);
    }

    public static function checkSlotAvailability($start_time, $end_time, $provider_id, $date)
    {
        // $booking = BookingService::find()->where([
        // 'start_time' => $date . ' ' . $start_time,
        // 'end_time' => $date . ' ' . $end_time,
        // 'provider_id' => $this->created_by_id,
        // 'service_id' => $service_id
        // ])
        // ->exists();
        $start_at = date('H:i:s', strtotime($start_time));
        $end_at = date('H:i:s', strtotime($end_time));

        $bookingCount = Booking::find()->where([
            'and',
            [
                '<=',
                'date(start_time)',
                $start_time
            ],
            [
                'time(start_time)' => $start_at
            ]
        ])
            ->andWhere([
            'and',
            [
                '>=',
                'end_time',
                $end_time
            ],
            [
                'time(end_time)' => $end_at
            ]
        ])
            ->andWhere([
            'date(date)' => $date
        ])
            ->andWhere([
            'provider_id' => $provider_id
        ])
            ->andWhere([
            'not in',
            'state_id',
            [
                Booking::STATE_COMPLETED,
                Booking::STATE_REJECTED,
                Booking::STATE_CANCELLED
            ]
        ])
            ->count();

        if ($bookingCount > 0) {
            return false;
        }

        return true;
    }
}
