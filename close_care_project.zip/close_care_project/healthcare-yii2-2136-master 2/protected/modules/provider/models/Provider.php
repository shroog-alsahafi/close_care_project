<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\provider\models;

use Yii;
use app\models\Feed;
use app\models\User;
use yii\helpers\ArrayHelper;
use app\modules\service\models\Service;
use app\models\File;
use app\modules\api\models\Rating;
use app\modules\booking\models\Booking;

/**
 * This is the model class for table "tbl_provider".
 *
 * @property integer $id
 * @property string $first_name
 * @property string $last_name
 * @property string $email
 * @property string $contact_no
 * @property string $password
 * @property string $profession
 * @property string $specilization
 * @property string $address
 * @property string $price
 * @property string $service_type
 * @property integer $state_id
 * @property integer $type_id
 * @property string $created_on
 * @property string $updated_on
 * @property integer $created_by_id
 * @property User $createdBy
 */
class Provider extends \app\components\TActiveRecord
{

    public function __toString()
    {
        return (string) $this->first_name;
    }

    const STATE_INACTIVE = 0;

    const STATE_ACTIVE = 1;

    const STATE_DELETED = 2;

    public $provider_id;

    const PHYSIOTHERAPIST = 1;

    const NURSE = 2;

    public static function getStateOptions()
    {
        return [
            self::STATE_INACTIVE => "New",
            self::STATE_ACTIVE => "Active",
            self::STATE_DELETED => "Deleted"
        ];
    }

    public static function getProfessionOptions()
    {
        return [
            self::PHYSIOTHERAPIST => \Yii::t('app', "Physiotherapist"),
            self::NURSE => \Yii::t('app', "Nurse")
        ];
    }

    public function getProType()
    {
        $list = self::getProfessionOptions();
        return isset($list[$this->profession]) ? $list[$this->profession] : 'N/A';
    }

    public function getState()
    {
        $list = self::getStateOptions();
        return isset($list[$this->state_id]) ? $list[$this->state_id] : 'Not Defined';
    }

    public function getStateBadge()
    {
        $list = [
            self::STATE_INACTIVE => "secondary",
            self::STATE_ACTIVE => "success",
            self::STATE_DELETED => "danger"
        ];
        return isset($list[$this->state_id]) ? \yii\helpers\Html::tag('span', $this->getState(), [
            'class' => 'badge bg-' . $list[$this->state_id]
        ]) : 'Not Defined';
    }

    public static function getActionOptions()
    {
        return [
            self::STATE_INACTIVE => "Deactivate",
            self::STATE_ACTIVE => "Activate",
            self::STATE_DELETED => "Delete"
        ];
    }

    public static function getTypeOptions()
    {
        return [
            "TYPE1",
            "TYPE2",
            "TYPE3"
        ];
    }

    public function getType()
    {
        $list = self::getTypeOptions();
        return isset($list[$this->type_id]) ? $list[$this->type_id] : 'Not Defined';
    }

    public function beforeValidate()
    {
        if ($this->isNewRecord) {
            if (empty($this->created_on)) {
                $this->created_on = \date('Y-m-d H:i:s');
            }
            if (empty($this->updated_on)) {
                $this->updated_on = \date('Y-m-d H:i:s');
            }
            if (empty($this->created_by_id)) {
                $this->created_by_id = self::getCurrentUser();
            }
        } else {
            $this->updated_on = date('Y-m-d H:i:s');
        }
        return parent::beforeValidate();
    }

    /*
     * public function scenarios()
     * {
     * $scenarios = parent::scenarios();
     *
     * $scenarios['provider-service-update'] = [
     * 'profession',
     * 'degree',
     * 'identity_id',
     * 'professional_classification_no'
     * ];
     *
     * return $scenarios;
     * }
     */

    /**
     *
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%provider}}';
    }

    /**
     *
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [
                [
                    /*
                     * 'first_name',
                     * 'last_name',
                     * 'email',
                     */

                    'created_by_id'
                ],
                'required'
            ],
            [
                [
                    'state_id',
                    'type_id',
                    'created_by_id'
                ],
                'integer'
            ],
            [
                [
                    'provider_id',
                    'created_on',
                    'updated_on',
                    'profession',
                    'degree',
                    'identity_id',
                    'professional_classification_no'
                ],
                'safe'
            ],

            [
                [
                    'professional_classification_no'
                ],
                'unique'
            ],
            [
                [
                    'identity_id'
                ],
                'unique'
            ],
            [
                [
                    'first_name',
                    'last_name'
                ],
                'string',
                'max' => 126
            ],
            [
                [
                    'email',
                    'specilization',
                    'address',
                    'service_type'
                ],
                'string',
                'max' => 255
            ],
            [
                [
                    'contact_no',
                    'profession',
                    'price'
                ],
                'string',
                'max' => 32
            ],
            [
                [
                    'password'
                ],
                'string',
                'max' => 128
            ],
            [
                [
                    'created_by_id'
                ],
                'exist',
                'skipOnError' => true,
                'targetClass' => User::class,
                'targetAttribute' => [
                    'created_by_id' => 'id'
                ]
            ],
            [
                [
                    'first_name',
                    'last_name',
                    'email',
                    'specilization',
                    'address',
                    'service_type',
                    'contact_no',
                    'profession',
                    'price',
                    'password'
                ],
                'trim'
            ],
            [
                [
                    'first_name'
                ],
                'app\components\validators\TNameValidator'
            ],
            [
                [
                    'last_name'
                ],
                'app\components\validators\TNameValidator'
            ],
            [
                [
                    'email'
                ],
                'email'
            ],
            [
                [
                    'password'
                ],
                'app\components\validators\TPasswordValidator',
                'length' => 8
            ],
            [
                [
                    'state_id'
                ],
                'in',
                'range' => array_keys(self::getStateOptions())
            ],
            [
                [
                    'type_id'
                ],
                'in',
                'range' => array_keys(self::getTypeOptions())
            ]
        ];
    }

    /**
     *
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'first_name' => Yii::t('app', 'First Name'),
            'last_name' => Yii::t('app', 'Last Name'),
            'email' => Yii::t('app', 'Email'),
            'contact_no' => Yii::t('app', 'Contact No'),
            'password' => Yii::t('app', 'Password'),
            'profession' => Yii::t('app', 'Profession'),
            'specilization' => Yii::t('app', 'Specilization'),
            'address' => Yii::t('app', 'Address'),
            'price' => Yii::t('app', 'Price'),
            'service_type' => Yii::t('app', 'Service Type'),
            'state_id' => Yii::t('app', 'State'),
            'type_id' => Yii::t('app', 'Type'),
            'created_on' => Yii::t('app', 'Created On'),
            'updated_on' => Yii::t('app', 'Updated On'),
            'created_by_id' => Yii::t('app', 'Created By')
        ];
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getCreatedBy()
    {
        return $this->hasOne(User::className(), [
            'id' => 'created_by_id'
        ])->cache();
    }

    public static function getHasManyRelations()
    {
        $relations = [];

        $relations['feeds'] = [
            'feeds',
            'Feed',
            'model_id'
        ];
        return $relations;
    }

    public static function getHasOneRelations()
    {
        $relations = [];
        $relations['created_by_id'] = [
            'createdBy',
            'User',
            'id'
        ];
        return $relations;
    }

    public function beforeDelete()
    {
        if (! parent::beforeDelete()) {
            return false;
        }
        // TODO : start here

        return true;
    }

    public function beforeSave($insert)
    {
        if (! parent::beforeSave($insert)) {
            return false;
        }
        // TODO : start here

        return true;
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProviderQualification()
    {
        return $this->hasOne(Qualification::class, [
            'id' => 'degree'
        ]);
    }

    public function getProviderService()
    {
        return $this->hasMany(ServiceDetail::class, [
            'created_by_id' => 'created_by_id'
        ]);
    }

    public function getServiceByCondition()
    {
        $query = $this->hasOne(ServiceDetail::class, [
            'created_by_id' => 'created_by_id'
        ]);
        if (\Yii::$app->request->get('id')) {
            $id = \Yii::$app->request->get('id');
            $query = $query->andOnCondition([
                'service_id' => $id
            ]);
        }

        return $query;
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getIqamaImage()
    {
        return $this->hasMany(File::className(), [
            'model_id' => 'id'
        ])->andOnCondition([
            'model_type' => self::class,
            'type_id' => File::TYPE_IQAMA
        ]);
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getBlsImage()
    {
        return $this->hasMany(File::className(), [
            'model_id' => 'id'
        ])->andOnCondition([
            'model_type' => self::class,
            'type_id' => File::TYPE_BLS_LICENSE
        ]);
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getMedicalImage()
    {
        return $this->hasMany(File::className(), [
            'model_id' => 'id'
        ])->andOnCondition([
            'model_type' => self::class,
            'type_id' => File::TYPE_MEDICAL_INSURANCE
        ]);
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getProQualificationImage()
    {
        return $this->hasMany(File::className(), [
            'model_id' => 'id'
        ])->andOnCondition([
            'model_type' => self::class,
            'type_id' => File::TYPE_PROFESSIONAL_QUALIFICATION
        ]);
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function getAverageRating()
    {
        return Rating::find()->where([
            'title' => $this->created_by_id,
            'model_type' => Booking::class
        ])->average('rating');
    }

    public function asServiceProviderJson($with_relations = false)
    {
        $json = [];
        $json['id'] = $this->id;
        $json['profession'] = $this->profession;
        $json['specilization'] = $this->specilization;
        $json['provider_name'] = ! empty($this->createdBy) ? $this->createdBy->full_name : '';
        $json['image_file'] = ! empty($this->createdBy->fileUrl) ? $this->createdBy->fileUrl->absoluteUrl : '';
        $json['ratings'] = $this->getAverageRating();
        $json['state_id'] = $this->state_id;
        $json['type_id'] = $this->type_id;
        $json['created_on'] = $this->created_on;
        $json['created_by_id'] = $this->created_by_id;
        $json['service_name'] = ! empty($this->serviceByCondition->serviceName) ? $this->serviceByCondition->serviceName->title : '';

        return $json;
    }

    /**
     *
     * @return \yii\db\ActiveQuery
     */
    public function asJson($with_relations = true)
    {
        $arr = [
            'service-provider'
        ];
        if (in_array(\Yii::$app->controller->action->id, $arr)) {

            return $this->asServiceProviderJson();
        }
        $json = [];
        $json['id'] = $this->id;
        $json['profession'] = $this->profession;
        $json['specilization'] = $this->specilization;
        $json['image_file'] = ! empty($this->createdBy->fileUrl) ? $this->createdBy->fileUrl->absoluteUrl : '';
        $json['degree'] = $this->degree;
        $json['degree_name'] = ! empty($this->providerQualification) ? $this->providerQualification->title : '';
        $json['ratings'] = $this->getAverageRating();
        $json['identity_id'] = $this->identity_id;
        $json['professional_classification_no'] = $this->professional_classification_no;
        $json['state_id'] = $this->state_id;
        $json['type_id'] = $this->type_id;
        $json['created_on'] = $this->created_on;
        $json['created_by_id'] = $this->created_by_id;
        if ($with_relations) {
            // services

            $list = $this->providerService;

            if (is_array($list)) {
                $relationData = array_map(function ($item) {
                    return $item->asJson();
                }, $list);

                $json['providerServices'] = $relationData;
            } else {
                $json['providerServices'] = $list;
            }

            // iqama images

            $list = $this->iqamaImage;

            if (is_array($list)) {
                $relationData = array_map(function ($item) {
                    return $item->asJson();
                }, $list);

                $json['iqamaImage'] = $relationData;
            } else {
                $json['iqamaImage'] = $list;
            }

            // bls images

            $list = $this->blsImage;

            if (is_array($list)) {
                $relationData = array_map(function ($item) {
                    return $item->asJson();
                }, $list);

                $json['blsLicense'] = $relationData;
            } else {
                $json['blsLicense'] = $list;
            }

            // medical insurance images

            $list = $this->medicalImage;

            if (is_array($list)) {
                $relationData = array_map(function ($item) {
                    return $item->asJson();
                }, $list);

                $json['medicalInsuranceImage'] = $relationData;
            } else {
                $json['medicalInsuranceImage'] = $list;
            }

            // professional qualification images

            $list = $this->proQualificationImage;

            if (is_array($list)) {
                $relationData = array_map(function ($item) {
                    return $item->asJson();
                }, $list);

                $json['professionalQualificationImage'] = $relationData;
            } else {
                $json['professionalQualificationImage'] = $list;
            }
        }
        return $json;
    }

    public function getControllerID()
    {
        return '/provider/' . parent::getControllerID();
    }

    public static function addTestData($count = 1)
    {
        $faker = \Faker\Factory::create();
        $states = array_keys(self::getStateOptions());
        for ($i = 0; $i < $count; $i ++) {
            $model = new self();
            $model->loadDefaultValues();
            $model->first_name = $faker->name;
            $model->last_name = $faker->name;
            $model->email = $faker->email;
            $model->contact_no = $faker->text(10);
            $model->profession = $faker->text(10);
            $model->specilization = $faker->text(10);
            $model->address = $faker->text(10);
            $model->price = $faker->text(10);
            $model->service_type = $faker->text(10);
            $model->state_id = $states[rand(0, count($states))];
            $model->type_id = 0;
            $model->save();
        }
    }

    public static function addData($data)
    {
        if (self::find()->count() != 0) {
            return;
        }

        $faker = \Faker\Factory::create();
        foreach ($data as $item) {
            $model = new self();
            $model->loadDefaultValues();

            $model->first_name = isset($item['first_name']) ? $item['first_name'] : $faker->name;

            $model->last_name = isset($item['last_name']) ? $item['last_name'] : $faker->name;

            $model->email = isset($item['email']) ? $item['email'] : $faker->email;

            $model->contact_no = isset($item['contact_no']) ? $item['contact_no'] : $faker->text(10);

            $model->profession = isset($item['profession']) ? $item['profession'] : $faker->text(10);

            $model->specilization = isset($item['specilization']) ? $item['specilization'] : $faker->text(10);

            $model->address = isset($item['address']) ? $item['address'] : $faker->text(10);

            $model->price = isset($item['price']) ? $item['price'] : $faker->text(10);

            $model->service_type = isset($item['service_type']) ? $item['service_type'] : $faker->text(10);
            $model->state_id = self::STATE_ACTIVE;

            $model->type_id = isset($item['type_id']) ? $item['type_id'] : 0;
            $model->save();
        }
    }

    public function isAllowed()
    {
        if (User::isAdmin())
            return true;
        if ($this->hasAttribute('created_by_id') && $this->created_by_id == Yii::$app->user->id) {
            return true;
        }

        return User::isUser();
    }

    public function afterSave($insert, $changedAttributes)
    {
        return parent::afterSave($insert, $changedAttributes);
    }
}
