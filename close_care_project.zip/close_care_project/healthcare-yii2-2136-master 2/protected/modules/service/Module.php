<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * the property of ToXSL Technologies Pvt. Ltd. and its partners.
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\service;

use app\components\TController;
use app\components\TModule;
use app\models\User;
use app\components\filters\AccessControl;
use app\components\filters\AccessRule;

/**
 * service module definition class
 */
class Module extends TModule
{

    const NAME = 'service';

    public $controllerNamespace = 'app\modules\service\controllers';

    // public $defaultRoute = 'service';
    public static function subNav()
    {
        return TController::addMenu(\Yii::t('app', 'Services'), '//service', 'list-alt ', Module::isAdmin(), []);
    }

    public static function dbFile()
    {
        return __DIR__ . '/db/install.sql';
    }

     
    
    public static function getRules()
    {
        return [
            'service/update/<id:\d+>/<title>' => 'service/service/update',
            'service/delete/<id:\d+>/<title>' => 'service/service/delete',
            
            'service/update/<id:\d+>' => 'service/service/update',
            'service/delete/<id:\d+>' => 'service/service/delete',
            
            'service/view/<id:\d+>/<title>' => 'service/service/view',
            'service/view/<id:\d+>' => 'service/service/view',
            
            'service/<action>/view/<id:\d+>' => 'service/<action>/view',
            'service/index' => 'service/service/index',
            'service/add' => 'service/service/add',
            'service' => 'service/service'
        ];
    }
}
