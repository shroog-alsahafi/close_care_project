<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author    : Shiv Charan Panjeta < shiv@toxsl.com >
 *
 * All Rights Reserved.
 * Proprietary and confidential :  All information contained herein is, and remains
 * Unauthorized copying of this file, via any medium is strictly prohibited.
 *
 */
namespace app\modules\service\api;

use app\components\filters\AccessControl;
use app\components\filters\AccessRule;
use app\models\User;
use app\modules\api\components\ApiBaseController;
use app\modules\service\models\Service;
use Yii;
use yii\data\ActiveDataProvider;
use app\models\File;
use yii\web\UploadedFile;
use yii\data\ArrayDataProvider;
use app\modules\booking\models\Booking;
use function couchbase\extension\query;
use app\modules\provider\models\ServiceDetail;
use app\modules\provider\models\Provider;
use app\modules\api\models\Rating;

/**
 * ServiceController implements the API actions for Service model.
 */
class ServiceController extends ApiBaseController
{

    public $modelClass = "app\modules\service\models\service";

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'ruleConfig' => [
                    'class' => AccessRule::class
                ],
                'rules' => [

                    [
                        'actions' => [
                            'list',
                            'near-by-provider',
                            'service-provider'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isUser() || User::isProvider();
                        }
                    ],
                    [
                        'actions' => [
                            'list'
                        ],
                        'allow' => true,
                        'matchCallback' => function () {
                            return User::isGuest();
                        }
                    ]
                ]
            ]
        ];
    }

    public function actions()
    {
        $actions = parent::actions();
        // unset($actions['create']);
        unset($actions['update']);
        unset($actions['delete']);
        // unset($actions['view']);
        // unset($actions['index']);
        return $actions;
    }

    /**
     *
     * Get Services which are added by admin accourding to profession
     *
     * @OA\Get(path="/service/list",
     *   summary="",
     *   tags={"Admin Service"},
     *    @OA\Parameter(
     *     name="type_id",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *
     *   @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Get the list of service",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionList($type_id = null, $page = null)
    {
        $query = Service::findActive();
        if (! empty($type_id)) {
            $query = $query->andWhere([
                'type_id' => $type_id
            ]);
        }
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => false
        ]);
        $this->setStatus(200);

        return $dataProvider;
    }

    /**
     *
     * @OA\Get(path="/service/near-by-provider",
     *   summary="",
     *   tags={"Service"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *    @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *    @OA\Parameter(
     *     name="search",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *    @OA\Parameter(
     *     name="type_id",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *
     *    @OA\Parameter(
     *     name="lat",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *     @OA\Parameter(
     *     name="long",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="string"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description=" Show all the Driver List",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *     ),
     *   ),
     * )
     */
    public function actionNearByProvider($page = null, $lat = '', $long = '', $search = null, $type_id = null)
    {
        // Initialize the query
        $query = User::find()->alias('u')
            ->joinWith('providerDetail as c')
            ->joinWith('rating as r')
            ->where([
            'u.role_id' => User::ROLE_PROVIDER
        ])
            ->andWhere([
            'u.state_id' => User::STATE_ACTIVE,
            'u.is_approved' => User::IS_APPROVED
        ])
            ->select([
            'u.id as id',
            'avg(r.rating) as avg'
        ]);

        if ($lat !== '' && $long !== '') {
            $query->select([
                'u.*',
                "(6371 * acos(cos(radians(:lat)) * cos(radians(u.latitude)) * cos(radians(u.longitude) - radians(:long)) + sin(radians(:lat)) * sin(radians(u.latitude)))) AS distance"
            ])
                ->addParams([
                ':lat' => $lat,
                ':long' => $long
            ])
                ->having("distance <= :distance")
                ->addParams([
                ':distance' => User::getDistance()
            ]);
        }

        if (! empty($search)) {
            $query->andWhere([
                'like',
                'u.full_name',
                $search
            ]);
        }

        if (! empty($type_id)) {
            $query->andWhere([
                'c.profession' => $type_id
            ]);
        }

        $query->groupBy([
            'id'
        ])->orderBy([
            'avg' => SORT_DESC
        ]);
        

        $dataProvider = new ActiveDataProvider([
            'query' => $query->distinct(),
            'sort' => [
                'defaultOrder' => [
                    'avg_rating' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ]
        ]);

        $this->setStatus(200);
        return $dataProvider;
    }

    /**
     * Service Provider's Detail with service.
     *
     * @OA\Get(path="/service/service-provider",
     *   summary="",
     *   tags={"Service"},
     *   security={
     *   {"bearerAuth": {}}
     *   },
     *   @OA\Parameter(
     *     name="id",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *
     *    @OA\Parameter(
     *     name="page",
     *     in="query",
     *     required=false,
     *     @OA\Schema(
     *       type="integer"
     *     )
     *   ),
     *   @OA\Response(
     *     response=200,
     *     description="Service detail",
     *     @OA\MediaType(
     *         mediaType="application/json",
     *
     *     ),
     *   ),
     * )
     */
    public function actionServiceProvider($id = null, $page = null)
    {
        $query = Provider::find()->alias('p')->joinWith('serviceByCondition as c');
        if (! empty($id)) {
            $query = $query->where([
                'c.service_id' => $id
            ]);
        }

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [
                    'id' => SORT_DESC
                ]
            ],
            'pagination' => [
                'pageSize' => 20,
                'page' => $page
            ]
        ]);
        $this->setStatus(200);
        return $dataProvider;
    }
}
