<?php
use app\components\TDashBox;
use app\components\notice\Notices;
use app\models\EmailQueue;
use app\models\LoginHistory;
use app\modules\logger\models\Log;
use yii\helpers\Url;
use app\models\User;
use app\models\search\User as UserSearch;
use miloschuman\highcharts\Highcharts;
use app\modules\booking\api\BookingController;
use app\modules\booking\models\Booking;
use app\modules\booking\models\Revenue;
/**
 *
 * @copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 * @author : Shiv Charan Panjeta < shiv@toxsl.com >
 */
/* @var $this yii\web\View */
// $this->title = Yii::t ( 'app', 'Dashboard' );

$this->params['breadcrumbs'][] = [
    'label' => Yii::t('app', 'Dashboard')
];
?>


<div class="wrapper">
	<!--state overview start-->
         <?php

        $totalAdminAmount = Revenue::find()->sum('admin_amount');

        $formattedAdminAmount = number_format(! empty($totalAdminAmount) ? $totalAdminAmount : 0, 2);

        echo TDashBox::widget([
            'items' => [
                [
                    'url' => Url::toRoute([
                        '/user?role=' . User::ROLE_USER
                    ]),
                    'color' => 'green',
                    'data' => User::find()->andWhere([
                        'role_id' => User::ROLE_USER
                    ])->count(),
                    'header' => 'Patients'
                ],
                [
                    'url' => Url::toRoute([
                        '//user/provider'
                    ]),
                    'color' => 'green',
                    'data' => User::find()->andWhere([
                        'role_id' => User::ROLE_PROVIDER
                    ])->count(),
                    'header' => 'Service Provider'
                ],
                [
                    'url' => Url::toRoute([
                        '/booking/booking'
                    ]),
                    'color' => 'green',
                    'data' => Booking::find()->andWhere([
                        'state_id' => Booking::STATE_COMPLETED
                    ])->count(),
                    'header' => 'Total Booking completed'
                ],

                [
                    'url' => Url::toRoute([
                        '/booking/revenue'
                    ]),
                    'color' => 'green',
                    'data' => '$' . $formattedAdminAmount,
                    'header' => 'Revenue Generated'
                ],
                [
                    'url' => Url::toRoute([
                        '/smtp/email-queue'
                    ]),
                    'color' => 'bg-warning',
                    'data' => EmailQueue::findActive(0)->count(),
                    'header' => 'Pending Emails',
                    'icon' => 'fa fa-envelope'
                ],
                [
                    'url' => Url::toRoute([
                        '/logger/log'
                    ]),
                    'color' => 'bg-info',
                    'data' => Log::find()->count(),
                    'header' => 'Logs',
                    'icon' => 'fa fa-sign-in'
                ],
                [
                    'url' => Url::toRoute([
                        '/login-history/index'
                    ]),
                    'color' => 'red',
                    'data' => LoginHistory::find()->count(),
                    'header' => 'LoginHistory',
                    'icon' => 'fa fa-history'
                ]
            ]
        ]);
        ?>
    <?php

    if (User::isAdmin()) {
        ?>
	<div class="row">
		<div class="col-md-6">

			<div class="card my-3 m-md-0">
				<div class="card-heading">
					<span class="tools pull-right"> </span>
				</div>
				<div class="card-body">
					<div class="row daily-monthly-reports mb-1">
						<div
							class="col-lg-5 col-xl-5 d-xl-flex justify-content-xl-start gap-2">
							<button
								class="users-data-btn btn chart-user-btn active mr-2 mb-2 chart_type"
								data-id="dailyData" type="button"><?=Yii::t('app', 'Daily')?></button>
							<button
								class="users-data-btn btn chart-user-btn mr-2 mb-2 chart_type"
								data-id="monthlyData" type="button"><?=Yii::t('app', 'Monthly')?></button>
							<button
								class="users-data-btn btn chart-user-btn mr-2 mb-2 chart_type"
								data-id="yearlyData" type="button"><?=Yii::t('app', 'Annual')?></button>
						</div>
					</div>
					<div class=" d-flex active data-row" id="dailyData">
						<div class="w-100">
							<div class="card-heading">
								<span class="tools pull-right"> </span>
							</div>
							
                <?php
        $data = User::daily(User::STATE_ACTIVE);
        $provider = User::daily(User::STATE_ACTIVE, User::ROLE_PROVIDER);
        $user = User::daily(User::STATE_ACTIVE, User::ROLE_USER);

        echo Highcharts::widget([
            'options' => [
                'credits' => array(
                    'enabled' => false
                ),
                'title' => [
                    'text' => Yii::t('app', 'Daily Users')
                ],
                'chart' => [
                    'type' => 'area'
                ],
                'xAxis' => [
                    'categories' => array_keys($data)
                ],
                'yAxis' => [
                    'title' => [
                        'text' => Yii::t('app', 'Count')
                    ]
                ],
                'series' => [
                    [
                        'name' => Yii::t('app', 'Provider'),
                        'data' => array_values($provider)
                    ],
                    [
                        'name' => Yii::t('app', 'Patient'),
                        'data' => array_values($user)
                    ]
                ]
            ]
        ]);
        ?>
             
						</div>
					</div>
					<div class="card d-none data-row" id="monthlyData">
						<div class="card mb-4">
							<div class="card-heading">
								<span class="tools pull-right"> </span>
							</div>
							
                  <?php
        $data = User::monthly(User::STATE_ACTIVE);
        $provider = User::monthly(User::STATE_ACTIVE, User::ROLE_PROVIDER);
        $user = User::monthly(User::STATE_ACTIVE, User::ROLE_USER);
        echo Highcharts::widget([
            'options' => [
                'credits' => array(
                    'enabled' => false
                ),

                'title' => [
                    'text' => Yii::t('app', 'Monthly Users')
                ],
                'chart' => [
                    'type' => 'area'
                ],
                'xAxis' => [
                    'categories' => array_keys($data)
                ],
                'yAxis' => [
                    'title' => [
                        'text' => Yii::t('app', 'Count')
                    ]
                ],
                'series' => [
                    [
                        'name' => Yii::t('app', 'Provider'),
                        'data' => array_values($provider)
                    ],
                    [
                        'name' => Yii::t('app', 'Patient'),
                        'data' => array_values($user)
                    ]
                ]
            ]
        ]);
        ?>
              
						</div>
					</div>
					<div class="card d-none data-row" id="yearlyData">

						<div class="card-heading">
							<span class="tools pull-right"> </span>
						</div>
							
                  <?php
        $data = User::yearly(User::STATE_ACTIVE);
        $provider = User::yearly(User::STATE_ACTIVE, User::ROLE_PROVIDER);
        $user = User::yearly(User::STATE_ACTIVE, User::ROLE_USER);
        echo Highcharts::widget([
            'options' => [
                'credits' => array(
                    'enabled' => false
                ),

                'title' => [
                    'text' => Yii::t('app', 'Yearly Users')
                ],
                'chart' => [
                    'type' => 'area'
                ],
                'xAxis' => [
                    'categories' => array_keys($data)
                ],
                'yAxis' => [
                    'title' => [
                        'text' => Yii::t('app', 'Count')
                    ]
                ],
                'series' => [
                    [
                        'name' => Yii::t('app', 'Provider'),
                        'data' => array_values($provider)
                    ],
                    [
                        'name' => Yii::t('app', 'Patient'),
                        'data' => array_values($user)
                    ]
                ]
            ]
        ]);
        ?>
					</div>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="card mb-4">
				<div class="card-body">
					<div class="row mt-4 daily-monthly-reports mb-4"></div> 

		<?php
        echo Highcharts::widget([
            'scripts' => [
                'highcharts-3d',
                'modules/exporting'
            ],

            'options' => [
                'credits' => array(
                    'enabled' => false,
                    'exportable' => true
                ),
                'chart' => [
                    'plotBackgroundColor' => null,
                    'plotBorderWidth' => null,
                    'plotShadow' => false,
                    'type' => 'pie'
                ],
                'title' => [
                    'text' => Yii::t('app', 'Users Registered')
                ],
                'tooltip' => [
                    'valueSuffix' => ''
                ],
                'plotOptions' => [
                    'pie' => [
                        'allowPointSelect' => true,
                        'cursor' => 'pointer',
                        'dataLabels' => [
                            'enabled' => true
                        ],
                        'showInLegend' => true
                    ]
                ],

                'series' => [
                    [
                        'name' => Yii::t('app', 'Total Count'),
                        'colorByPoint' => true,

                        'data' => [
                            [
                                'name' => Yii::t('app', 'Provider'),
                                'y' => (int) User::find()->andWhere([
                                    'role_id' => User::ROLE_PROVIDER
                                ])->count(),
                                'sliced' => true,
                                'selected' => true
                            ],

                            [
                                'name' => Yii::t('app', 'Patient'),
                                'y' => (int) User::find()->andWhere([
                                    'role_id' => User::ROLE_USER
                                ])->count(),
                                'sliced' => true,
                                'selected' => true
                            ]
                        ]
                    ]
                ]
            ]
        ]);
        ?>
                   
				</div>
			</div>
		</div>
	</div>

	<?php
    }
    ?>
	
	
</div>
<script>
$(document).ready(function(){
    $('.chart_type').on('click', function (){
      $('.chart_type').removeClass('active');
      $('.data-row').removeClass('d-flex').addClass('d-none');
      var data_id = $(this).data('id');
      $('#'+data_id).addClass('d-flex');
      $('#'+data_id).removeClass('d-none');
      $('#'+data_id).addClass('active');
    });
});
</script>
