<?php
/* @var $this yii\web\View */
use app\modules\contact\widgets\ContactWidget;
use app\components\TActiveForm;
use yii\helpers\Html;
use app\models\Information;

// $this->title = "Contact Us ";

?>
<section class="pagetitle-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 text-center">
				<h1 class="mb-0 mt-0">Contact Us</h1>
			</div>
		</div>
	</div>
</section>

<!-- page title area end  -->

<section class="contact-us py-5">
	<div class="container">
		<div class="contact-us-inr mb-5">
			<div class="contact-content">
				<div class="row">

					<div class="col-md-6">
						<div class="contact-info">
							<div class="contact-info-content">
								<h5>Call Us</h5>
								<p>
									<a
										href="tel:<?=Yii::$app->settings->getValue('phone_number', null, 'contact')?>"><?=Yii::$app->settings->getValue('phone_number', null, 'contact')?></a>




								</p>
							</div>
						</div>
					</div>
					<div class="col-md-6">
						<div class="contact-info">

							<div class="contact-info-content">
								<h5>Email Us</h5>
								<p>
									<a
										href="email:<?=Yii::$app->settings->getValue('email', null, 'contact')?>"><?=Yii::$app->settings->getValue('email', null, 'contact')?></a>
									</a>
								</p>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
		<div class="contact-wrapper">
			<div class="row">
				<div class="col-lg-6 align-self-center">
					<div class="contact-img">
						<img src="<?= $this->theme->getUrl('/images/login.png')  ?>"
							alt="img">

					</div>
				</div>
				<div class="col-lg-6 align-self-center">
					<div class="contact-form">
						<div class="contact-form-header">
							<h2>Get In Touch</h2>
							<p>It is a long established fact that a reader will be distracted
								by the readable content of a page randomised words which don't
								look even slightly when looking at its layout.</p>
						</div>
						
            <?php
            $form = TActiveForm::begin([
                'options' => [
                    'id' => 'support_form',
                    'class' => 'profile-form'
                ],
                'enableAjaxValidation' => false,
                'enableClientValidation' => true
            ]);
            $model = new Information();
            ?>
              <div class="row">
							<div class="form-group col-md-12 mb-4">
								<?php echo $form->field($model, 'full_name')->textInput(['maxlength' => 255,'placeholder' => 'Full Name'])->label(false) ?>
							</div>

							<div class="form-group col-md-12 mb-4">
								<?php echo $form->field($model, 'email')->textInput(['maxlength' => 255,'placeholder' => 'Email'])->label(false) ?>
							</div>

							<div class="form-group col-md-12 mb-4">
								<?php echo $form->field($model, 'mobile')->textInput(['maxlength' => 255,'placeholder' => 'Mobile'])->label(false) ?>
							</div>


							<div class="form-group col-md-12 mb-4">
								<?php echo $form->field($model, 'description')->textarea(['rows' => 8,'placeholder' => 'Description'])->label(false);  ?>
							</div>

							<div class="col-md-12 text-center">
								 
								 
								  <?php
        echo Html::submitButton('Submit Now', [
            'class' => 'btn main-btn',
            'id' => 'support_form',
            'name' => 'submit-button'
        ])?>
						<!--             </form> -->
<?php TActiveForm::end(); ?>
          </div>
							<!-- Contact Form end -->
						</div>

					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="map-card">
	<div class="container-fluid">
		<iframe
			src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3430.1858849053356!2d76.70709767631952!3d30.71317427459373!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390f954ea4b2c735%3A0x44c7b39d86228a72!2sToXSL%20Technologies%20-%20Mobile%20App%20Development%20And%20Web%20Development%20Company!5e0!3m2!1sen!2sin!4v1688710190651!5m2!1sen!2sin"
			width="100%" height="500" style="border: 0;" allowfullscreen=""
			loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
	</div>
</section>


