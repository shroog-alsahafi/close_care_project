<body>
  <!-- Page-wrapper-Start -->
  <div class="page_wrapper">
    <!-- Banner-Section-Start -->
    <section class="banner_section">
      <!-- container start -->
      <div class="container">
        <!-- row start -->
        <div class="row">
          <!-- shape animation  -->
          <span class="banner_shape1"> <img src="<?=$this->theme->getUrl ('images/banner-shape1.png')?>" alt="image">
          </span>
          <span class="banner_shape2"> <img src="<?=$this->theme->getUrl ('images/banner-shape2.png')?>" alt="image">
          </span>
          <span class="banner_shape3"> <img src="<?=$this->theme->getUrl ('images/banner-shape3.png')?>" alt="image">
          </span>

          <div class="col-lg-8 col-md-12 mx-auto ">
            <!-- banner text -->
            <div class="banner_text">
              <h1>Welcome You to <br />Healthcare!</h1>
              <p>It's easier to get a doctor without having to go to the hospital.</p>
            </div>
          </div>
        </div>
        <!-- row end -->
      </div>
      <!-- container end -->

      <!-- banner images start -->
      <div class="container-fluid aos-init">
        <div class="banner_images">
          <div class="row d-flex justify-content-center">
            <!-- screen 1 -->
            <div class="col-md-2 col-lg-2 col-sm-4 col-xs-4 d-none d-lg-block">
              <div class="banner_screen screen1">
                <img class="moving_animation" src="<?=$this->theme->getUrl('images/hero-image-5.png')?>" alt="image">
              </div>
            </div>

            <!-- screen 2 -->
            <div class="col-md-4 col-lg-2 col-sm-4 col-xs-4">
              <div class="banner_screen screen2">
                <img class="moving_animation" src="<?=$this->theme->getUrl('images/hero-image-4.png')?>" alt="image">
              </div>
            </div>

            <!-- screen 3 -->
            <div class="col-md-4 col-lg-3 col-sm-4 col-xs-4">
              <div class="banner_screen screen3">
                <img class="moving_animation" src="<?=$this->theme->getUrl('images/hero-image-1.png')?>" alt="image">
              </div>
            </div>

            <!-- screen 4 -->
            <div class="col-md-4 col-lg-2 col-sm-4 col-xs-4">
              <div class="banner_screen screen4">
                <img class="moving_animation" src="<?=$this->theme->getUrl('images/hero-image-2.png')?>" alt="image">
              </div>
            </div>

            <!-- screen 5 -->
            <div class="col-md-2 col-lg-2 col-sm-4 col-xs-4 d-none d-lg-block">
              <div class="banner_screen screen5">
                <img class="moving_animation" src="<?=$this->theme->getUrl('images/hero-image-3.png')?>" alt="image">
              </div>
            </div>
          </div>

        </div>
      </div>
      <!-- banner images end -->
    </section>
    <!-- Banner-Section-end -->

    <!-- Download button  Section start -->
    <section class="row_am download_section">
      <!-- container start -->
      <div class="container">
        <!-- icon start -->
        <ul class="app_btn aos-init">
          <li>
            <a href="#" class="app_store">
              <img class="blue_img" src="<?=$this->theme->getUrl ('images/appstore_blue.png')?>" alt="image">
              <img class="white_img" src="<?=$this->theme->getUrl ('images/appstore_white.png')?>" alt="image">
            </a>
          </li>
          <li>
            <a href="#">
              <img class="blue_img" src="<?=$this->theme->getUrl ('images/googleplay_blue.png')?>" alt="image">
              <img class="white_img" src="<?=$this->theme->getUrl ('images/googleplay_white.png')?>" alt="image">
            </a>
          </li>
        </ul>
        <!-- icon  end -->
      </div>
      <!-- container end -->
    </section>
    <!-- Download button Section Section ends -->


    <!-- Features-Section-Start -->
    <section class="row_am features_section" id="features">
      <!-- container start -->
      <div class="container">
        <div class="features_inner">
          <div class="section_title aos-init">
            <!-- h2 -->
            <h2><span>Features</span> that we provide you</h2>
            <!-- p -->
            <p>Our features can significantly enhance the quality of care, improve patient experience, <br />and
              streamline healthcare operations.</p>
          </div>

          <!-- story -->
          <div class="features_block">
            <div class="row">
              <div class="col-md-4">
                <div class="feature_box aos-init">
                  <div class="image">
                    <img src="<?=$this->theme->getUrl ('images/features1.png')?>" alt="image">
                  </div>
                  <div class="text">
                    <h4>Patient Management</h4>
                    <p>we provide you tools for booking, rescheduling, and canceling appointments and monitoring patient
                      progress and managing follow-up care.</p>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="feature_box aos-init" data-aos-duration="1700">
                  <div class="image">
                    <img src="<?=$this->theme->getUrl ('images/features2.png')?>" alt="image">
                  </div>
                  <div class="text">
                    <h4>Telemedicine</h4>
                    <p>We provide you video or phone consultations with healthcare providers also Confidential
                      communication between patients and providers.</p>
                  </div>
                </div>
              </div>

              <div class="col-md-4">
                <div class="feature_box aos-init" data-aos-duration="1900">
                  <div class="image">
                    <img src="<?=$this->theme->getUrl ('images/features3.png')?>" alt="image">
                  </div>
                  <div class="text">
                    <h4>24/7 Help Desk</h4>
                    <p>Support for technical issues or patient inquiries. Tools to support users with disabilities, such
                      as screen readers and voice commands.
                    </p>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
      <!-- container end -->
    </section>
    <!-- Features-Section-end -->

    <!-- ModernUI-Section-Start -->
    <section class="row_am modern_ui_section">
      <!-- container start -->
      <div class="container">
        <!-- row start -->
        <div class="row">
          <div class="col-lg-6">
            <!-- UI content -->
            <div class="ui_text">
              <div class="section_title aos-init">
                <h2>About <span>Healthcare</span></h2>
                <p>Healthcare is a broad and multifaceted field dedicated to the prevention, diagnosis, treatment, and management of illnesses and health conditions. It encompasses a wide range of services, professions, and practices aimed at improving and maintaining the health and well-being of individuals and populations. Here's a comprehensive overview of healthcare</p>
              </div>
              <ul class="design_block">
                <li class="aos-init">
                  <h4>Online Consultations</h4>
                  <p>Telemedicine platform allowing patients to consult with healthcare providers remotely via video or
                    phone calls.</p>
                </li>
                <li class="aos-init">
                  <h4>Health Assessments</h4>
                  <p>Online quizzes or assessments to evaluate patient's health risks, provide personalized
                    recommendations, and suggest preventive measures.</p>
                </li>
                <li class="aos-init">
                  <h4>Appointment Scheduling</h4>
                  <p>Online scheduling system for patients to book appointments with healthcare providers or schedule
                    procedures.</p>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-lg-6">
            <!-- UI Image -->
            <div class="ui_images aos-init">
              <div class="left_img">
                <img class="moving_position_animatin" src="<?=$this->theme->getUrl ('images/modern01.png')?>"
                  alt="image">
              </div>
              <!-- UI Image -->
              <div class="right_img">
                <img class="moving_position_animatin" src="<?=$this->theme->getUrl ('images/secure_data.png')?>"
                  alt="image">
                <img class="moving_position_animatin" src="<?=$this->theme->getUrl ('images/modern02.png')?>"
                  alt="image">
                <img class="moving_position_animatin" src="<?=$this->theme->getUrl ('images/modern03.png')?>"
                  alt="image">
              </div>
            </div>
          </div>
        </div>
        <!-- row end -->
      </div>
      <!-- container end -->
    </section>
    <!-- ModernUI-Section-end -->

    <!-- How-It-Workes-Section-Start -->
    <section class="row_am how_it_works" id="how_it_work">
      <!-- container start -->
      <div class="container">
        <div class="how_it_inner">
          <div class="section_title aos-init">
            <!-- h2 -->
            <h2><span>How it works</span> - 3 easy steps</h2>
            <!-- p -->
            <p>Here's a structured outline detailing how healthcare works, broken down into steps</p>
          </div>
          <div class="step_block">
            <!-- UL -->
            <ul>
              <!-- step -->
              <li>
                <div class="step_text aos-init">
                  <h4>Download app</h4>
                  <div class="app_icon">
                    <a href="#"><i class="icofont-brand-android-robot"></i></a>
                    <a href="#"><i class="icofont-brand-apple"></i></a>
                    <a href="#"><i class="icofont-brand-windows"></i></a>
                  </div>
                  <p>Download App either for Apple or Android</p>
                </div>
                <div class="step_number">
                  <h3>01</h3>
                </div>
                <div class="step_img aos-init" data-aos="fade-left">
                  <img src="<?=$this->theme->getUrl ('images/download_app.jpg')?>" alt="image">
                </div>
              </li>

              <!-- step -->
              <li>
                <div class="step_text aos-init" data-aos="fade-left">
                  <h4>Create account</h4>
                  <p>Sign up free for App account. One account for all devices.</p>
                </div>
                <div class="step_number">
                  <h3>02</h3>
                </div>
                <div class="step_img aos-init">
                  <img src="<?=$this->theme->getUrl ('images/create_account.jpg')?>" alt="image">
                </div>
              </li>

              <!-- step -->
              <li>
                <div class="step_text aos-init">
                  <h4>It’s done, enjoy the app</h4>
                  <span>Have any questions check our <a href="#">FAQs</a></span>
                  <p>Get most amazing app experience,Explore and share the app</p>
                </div>
                <div class="step_number">
                  <h3>03</h3>
                </div>
                <div class="step_img aos-init" data-aos="fade-left">
                  <img src="<?=$this->theme->getUrl ('images/enjoy_app.jpg')?>" alt="image">
                </div>
              </li>
            </ul>
          </div>
        </div>

      </div>
      <!-- container end -->
    </section>
    <!-- How-It-Workes-Section-end -->

    <!-- Beautifull-interface-Section start -->
    <section class="row_am interface_section">
      <!-- container start -->
      <div class="container-fluid">
        <div class="section_title aos-init">
          <!-- h2 -->
          <h2>Beautifull <span>interface</span></h2>
          <!-- p -->
          <p>Creating a beautiful and functional interface for a healthcare application or website requires careful <br/>attention to design principles, user experience (UX), and accessibility</p>
        </div>

        <!-- screen slider start -->
        <div class="screen_slider">
          <div id="screen_slider" class="owl-carousel owl-theme owl-loaded owl-drag">






            <div class="owl-stage-outer">
              <div class="owl-stage"
                style="transition: 2.5s; width: 6080px; transform: translate3d(-1140px, 0px, 0px);">
                <div class="owl-item active center">
                  <div class="item">
                    <div class="screen_frame_img">
                      <img src="<?=$this->theme->getUrl ('images/screen-1.png')?>" alt="image">
                    </div>
                  </div>
                </div>
                <div class="owl-item active">
                  <div class="item">
                    <div class="screen_frame_img">
                      <img src="<?=$this->theme->getUrl ('images/screen-2.png')?>" alt="image">
                    </div>
                  </div>
                </div>
                <div class="owl-item active">
                  <div class="item">
                    <div class="screen_frame_img">
                      <img src="<?=$this->theme->getUrl ('images/screen-3.png')?>" alt="image">
                    </div>
                  </div>
                </div>
                <div class="owl-item">
                  <div class="item">
                    <div class="screen_frame_img">
                      <img src="<?=$this->theme->getUrl ('images/screen-4.png')?>" alt="image">
                    </div>
                  </div>
                </div>
                <div class="owl-item">
                  <div class="item">
                    <div class="screen_frame_img">
                      <img src="<?=$this->theme->getUrl ('images/screen-5.png')?>" alt="image">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="owl-dots">
              <button role="button" class="owl-dot active"><span></span></button><button role="button"
                class="owl-dot"><span></span></button><button role="button"
                class="owl-dot"><span></span></button><button role="button"
                class="owl-dot"><span></span></button><button role="button"
                class="owl-dot"><span></span></button><button role="button" class="owl-dot"><span></span></button>
            </div>
          </div>
        </div>
        <!-- screen slider end -->
      </div>
      <!-- container end -->
    </section>
    <!-- Beautifull-interface-Section end -->

    <!-- Download-Free-App-section-Start  -->
    <section class="row_am free_app_section" id="getstarted">
      <!-- container start -->
      <div class="container">
        <div class="free_app_inner aos-init">
          <!-- row start -->
          <div class="row">
            <!-- content -->
            <div class="col-md-6">
              <div class="free_text">
                <div class="section_title">
                  <h2>Let’s download free from apple and play store</h2>
                  <p>Instant free download from apple and play store orem Ipsum is simply dummy text of the printing.
                    and typese tting indus orem Ipsum has beenthe standard</p>
                </div>
                <ul class="app_btn">
                  <li>
                    <a href="#">
                      <img src="<?=$this->theme->getUrl ('images/appstore_blue.png')?>" alt="image">
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <img src="<?=$this->theme->getUrl ('images/googleplay_blue.png')?>" alt="image">
                    </a>
                  </li>
                </ul>
              </div>
            </div>

            <!-- images -->
            <div class="col-md-6">
              <div class="free_img">
                <img src="<?=$this->theme->getUrl ('images/download-screen01.png')?>" alt="image">
                <img class="mobile_mockup" src="<?=$this->theme->getUrl ('images/download-screen02.png')?>" alt="image">
              </div>
            </div>
          </div>
          <!-- row end -->
        </div>
      </div>
      <!-- container end -->
    </section>
    <!-- Download-Free-App-section-end  -->

</body>