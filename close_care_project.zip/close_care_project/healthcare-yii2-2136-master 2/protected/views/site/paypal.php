<?php
use yii\helpers\Url;

?>
<div id="paypal-button-container"
	style="display: flex; justify-content: center; align-items: center; height: 100vh;"></div>

<!-- Include the PayPal JavaScript SDK -->
<script
	src="https://www.paypal.com/sdk/js?client-id=AZ_lZnOg1ssXJ_5Dz8b76wmiefiXzCcvgxNuVaWJPMVxqXKnuM1z98MT7aETfb1lXcW9V4l-1GcSkdQU&components=buttons"></script>

<script>
// Render the PayPal button into #paypal-button-container
paypal.Buttons({
    
    style: {
        layout: 'horizontal',
        color: 'blue',
        shape: 'rect'
    },
    // Set up the transaction
    createOrder: function(data, actions) {
        return actions.order.create({
            purchase_units: [{
                amount: {
                    value: '<?php echo $model->amount ?>' // Use the sanitized amount
                }
            }]
        });
    },
    
    // Finalize the transaction after payer approval
    onApprove: function (data, actions) {
	return actions.order.capture().then(function (orderData) {
		// Successful capture! For dev/demo purposes:
		console.log('Capture result', orderData, JSON.stringify(orderData, null, 2));
		var transaction = orderData.purchase_units[0].payments.captures[0];
		//alert('Transaction '+ transaction.status + ': ' + transaction.id + '\n\nSee console for all available details');

		// When ready to go live, remove the alert and show a success message within this page. For example:
		var element = document.getElementById('paypal-button-container');
		element.innerHTML = '';
		element.innerHTML = '<h3>Thank you for your payment!</h3>';

		$.post("<?php echo Yii::$app->urlManager->createAbsoluteUrl(['/payment/paypal/success','id' => $model->id]);
         ?>
		", orderData)	
				.done(function () {
					console.log("second success");
				})
				.fail(function () {
					console.log("error");
				})
				.always(function () {
					console.log("finished");
				});
		});
	}
}).render('#paypal-button-container');
</script>
