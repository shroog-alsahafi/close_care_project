<?php
use app\components\TActiveForm;
use app\models\User;
use yii\helpers\Html;
use app\base\TPhoneInput;
use borales\extensions\phoneInput\PhoneInput;

/* @var $this yii\web\View */
/* @var $model app\models\User */
/* @var $form yii\widgets\ActiveForm */
?>
<?php
$fieldOptions1 = [
    'inputTemplate' => "{input}<span  class='fa fa-fw fa-eye-slash field-icon toggle-password pass-toggle ' toggle='#user-password' id='password-reveal2'></span>"
];

$fieldOptions2 = [
    'inputTemplate' => "{input}<span  class='fa fa-fw fa-eye-slash field-icon toggle-password confirm-toggle' toggle='#user-confirm_password' id='password-reveal3'></span>"
];
?>
<style>
.field-user-contact_no .invalid-feedback {
	display: block !important
}
</style>
<header class="card-header">
    <?php echo strtoupper(Yii::$app->controller->action->id); ?>
                        </header>
<div class="card-body">
    <?php
    $form = TActiveForm::begin([
        'id' => 'user-form',
        'options' => [
            'class' => 'row'
        ]
    ]);

    ?>

	<div class="col-lg-6">
			
			<?php echo $form->field($model, 'first_name')->textInput(['maxlength' => 20]) ?>
			<?php echo $form->field($model, 'last_name')->textInput(['maxlength' => 20]) ?>

            <?= $form->field($model, 'email')->textInput(['maxlength' => 25]) ?>

		 
		 <?php if (User::isManager() && $model->role_id != User::ROLE_ADMIN){?>
		  <?php /*echo $form->field($model, 'state_id')->dropDownList($model->getStateOptions(), ['prompt' => '']) */?>
		 
		 
		 <?php
}
?>
<?php
$model->contact_no = $model->getReverseContact();
?>
	<?=$form->field($model,'contact_no',['template' => '{label}{input}{error}'])->widget(TPhoneInput::class, ['defaultOptions' => ['maxlength' => 15,'class' => 'form-control','placeholder' => Yii::t('app', 'Phone Number'),'oninput' => "this.value = this.value.replace(/[^0-9]/g, '')"]])->label('Contact no');?>
<?=$form->field($model, 'country_code')->hiddenInput()->label(false)?>		 
		 
		
</div>




	<div class="col-lg-6">
	 <?php if (User::isManager() && $model->role_id != User::ROLE_ADMIN){?>
		
		 <?php /*cho $form->field($model, 'status')->inline(true)->radioList($model->getStatusOptions()) */?>
		 
		 <?php
}
?>
 		
 		 <?php

    echo $form->field($model, 'profile_file')->fileInput([
        // 'required' => (Yii::$app->controller->action->id == 'add-provider') ? true : false,
        'onchange' => 'ValidateSingleInput(this)'
    ])?>
 		
 		 
		<?php if (User::isManager() && $model->role_id != User::ROLE_ADMIN){?>
<?php if(Yii::$app->controller->action->id != 'update'){?>
	 		<?php echo $form->field($model, 'password',$fieldOptions1)->passwordInput(['maxlength' => 128]) ?>
	 		<?php echo $form->field($model, 'confirm_password',$fieldOptions2)->passwordInput(['maxlength' => 128]) ?>
	 		
	 		<?php } ?>
		   
		    
		    <?php echo $form->field($model, 'gender')->dropDownList($model->getGenderOptions(), ['prompt' => Yii::t('app','Select Gender')]) ?>
		    
	 		

	
		<?php }?>

</div>


	<div class="form-group col-lg-12 text-left">
	
        <?= Html::submitButton($model->isNewRecord ? Yii::t('app', 'Save') : Yii::t('app', 'Update'), ['id' => 'user-form-submit','class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>
	

    <?php TActiveForm::end(); ?>

</div>

<script>

$(document).ready(function () {
     $("#user-country_code").val($('.iti__selected-dial-code').html());
     
     console.log($("#user-country_code").val());
        $("#user-contact_no").intlTelInput({
            preferredCountries: ["IN" ],
            separateDialCode: true,
            initialCountry: ""
        }).on('countrychange', function (e, countryData) {
         var myString =$("#user-contact_no").intlTelInput("getSelectedCountryData").dialCode;
         var avoid = "+";

          var data=myString.replace(avoid, '');
            $("#user-country_code").val(data);

        });

        var myString =($('.iti__selected-dial-code').text());
         var avoid = "+";

          var data=myString.replace(avoid, '');
   $("#user-country_code").val(data);


    });

</script>
<script>
    var _validFileExtensions = [".jpg", ".jpeg", ".bmp", ".png"];

    function ValidateSingleInput(oInput) {
        if (oInput.type == "file") {
            var sFileName = oInput.value;
            if (sFileName.length > 0) {
                var blnValid = false;
                for (var j = 0; j < _validFileExtensions.length; j++) {
                    var sCurExtension = _validFileExtensions[j];
                    if (sFileName.substr(sFileName.length - sCurExtension.length, sCurExtension.length).toLowerCase() == sCurExtension.toLowerCase()) {
                        blnValid = true;
                        break;
                    }
                }

                if (!blnValid) {
                    alert("Sorry, " + sFileName + " is invalid, allowed extensions are: " + _validFileExtensions.join(", "));
                    oInput.value = "";
                    $('#user-form').yiiActiveForm('validateAttribute', 'user-profile_file')
                    return false;
                }
            }
        }
        return true;
    }
</script>

<script>
    function highlightSelectedGender(element) {
        var labels = document.querySelectorAll('.gender-label');
        labels.forEach(function(label) {
            label.classList.remove('selected');
        });
        var label = document.querySelector('label[for="' + element.id + '"]');
        label.classList.add('selected');
    }
    
    function highlightSelectedStatus(element) {
        var labels = document.querySelectorAll('.status-label');
        labels.forEach(function(label) {
            label.classList.remove('selected');
        });
        var label = document.querySelector('label[for="' + element.id + '"]');
        label.classList.add('selected');
    }
</script>

<script>
$(".toggle-password").click(function() {
    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
        input.attr("type", "text");
    } else {
        input.attr("type", "password");
    }
});

</script>


