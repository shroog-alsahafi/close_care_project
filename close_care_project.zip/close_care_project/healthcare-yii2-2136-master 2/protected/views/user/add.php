<?php
use app\models\User;

/* @var $this yii\web\View */
/* @var $model app\models\User */

/* $this->title = Yii::t('app', 'Add'); */

if ($model->role_id == User::ROLE_USER) {
    $this->params['breadcrumbs'][] = [
        'label' => Yii::t('app', 'Patients'),
        'url' => [
            'index'
        ]
    ];
}
if ($model->role_id == User::ROLE_PROVIDER) {

    $this->params['breadcrumbs'][] = [
        'label' => Yii::t('app', 'Provider'),
        'url' => [
            'user/provider'
        ]
    ];
}
$this->params['breadcrumbs'][] = Yii::t('app', 'Add');
?>
<div class="wrapper">
	<div class="user-create card">
	<?php if ($model->role_id == User::ROLE_USER) {?>
	<div class="page-head">
			<h1>Patients</h1>


		</div>

	
	<?php }?>
	<?php if ($model->role_id == User::ROLE_PROVIDER) {?>
			<div class="page-head">
			<h1>Provider</h1>
		</div>
	<?php }?>
	</div>

	<div class="content-section card">
		<?= $this->render ( '_form', [ 'model' => $model ] )?></div>
</div>

