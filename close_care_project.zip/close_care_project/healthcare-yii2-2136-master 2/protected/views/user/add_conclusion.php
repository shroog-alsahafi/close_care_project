<?php
use yii\helpers\Html;
use yii\grid\GridView;
use app\components\TActiveForm;

/* @var $this yii\web\View */
/* @var $searchModel app\models\search\User */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->params['breadcrumbs'][] = [
    'label' => Yii::t('app', 'User'),
    'url' => [
        'index'
    ]
];
$this->params['breadcrumbs'][] = Yii::t('app', 'Index');
?>
<div class="wrapper">
	<div class="card">
		<div class="ticket-create">
			<?=  \app\components\PageHeader::widget(); ?>
		</div>
	</div>

	<div class="content-section clearfix card">
		<header class="card-header">
   <?php echo strtoupper(Yii::$app->controller->action->id); ?>
</header>
		<div class="card-body">
   <?php

$form = TActiveForm::begin([

    'id' => 'user-conclusion-form'
]);
?>
                              <?php //echo  $form->field($model, 'conclusion')->widget ( app\components\TRichTextEditor::className (), [ 'options' => [ 'rows' => 6 ,],'preset' => 'basic' ] ); ?>
                           <?php  echo $form->field($model, 'conclusion')->textarea(['rows' => 6]);  ?>
                          <div class="col-md-12 text-end">
      <?= Html::submitButton(Yii::t('app', 'Save'), ['id'=> 'user-conclusion-form-submit','class' => 'btn btn-success']) ?>
   </div>
   <?php TActiveForm::end(); ?>
</div>
	</div>
</div>



