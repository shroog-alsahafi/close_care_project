<?php
use app\models\User;

/* @var $this yii\web\View */
/* @var $searchModel app\models\search\User */
/* @var $dataProvider yii\data\ActiveDataProvider */

/* $this->title = Yii::t('app', 'Index'); */
// $this->params['breadcrumbs'][] = [
// 'label' => Yii::t('app', 'Users'),
// 'url' => [
// 'index'
// ]
// ];

// ?>
<?php
if ($role == User::ROLE_USER) {
    $this->params['breadcrumbs'][] = [
        'label' => Yii::t('app', 'Patients / Index'),
        'url' => [
            'index'
        ]
    ];
}
if ($role == User::ROLE_PROVIDER) {

    $this->params['breadcrumbs'][] = [
        'label' => Yii::t('app', 'Provider / Index'),
        'url' => [
            'user/provider'
        ]
    ];
}
?>
<div class="wrapper">
	<div class="card">
<?php if($role == User::ROLE_PROVIDER){ ?>
<?=  \app\components\PageHeader::widget(['title'=>'Providers']); ?>
<?php }else{?>	
	<?=  \app\components\PageHeader::widget(['title'=>'Patients']); ?>	
	<?php } ?>
	
	</div>
	<div class="card">
		<header class="card-header">   <?php echo strtoupper(Yii::$app->controller->action->id); ?> </header>
		<div class="card-body">
			<?php echo $this->render('_grid', ['dataProvider' => $dataProvider, 'searchModel' => $searchModel]); ?>
		</div>
	</div>
</div>


