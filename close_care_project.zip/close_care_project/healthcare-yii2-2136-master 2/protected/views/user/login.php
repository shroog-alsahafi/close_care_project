<?php
use app\components\TActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;
use app\components\PageHeader;
use app\components\FlashMessage;

/* @var $this yii\web\View */

// $this->title = 'Sign In';
?>
<?php

$fieldOptions1 = [
    'options' => [
        'class' => 'form-group has-feedback'
    ],

    'inputTemplate' => "{input}<span class='glyphicon glyphicon-envelope form-control-feedback'></span>"
];

$fieldOptions2 = [
    'options' => [
        'class' => 'form-group has-feedback'
    ],
    'inputTemplate' => "{input}<span class='fa fa-lock form-control-feedback'></span>"
];
$fieldOptions3 = [
    'inputTemplate' => "{input}<span  class='fa fa-fw fa-eye-slash field-icon toggle-password' toggle='#loginform-password' id='password-reveal'></span>"
];
?>



<section class="pagetitle-section">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 text-center">
				<h1 class="mb-0 mt-0">
					<b></b>
				</h1>
			</div>
		</div>
	</div>
</section>
<?= FlashMessage::widget()?>



<section class="login-signup py-5">
	<div class="container-fluid">
		<div class=" row p-3 justify-content-center">
			<div class="order-1 col-lg-6 order-lg-2">
				<div class="login-box">
					<h3 id="profile-name" class="section-title">
						<b>
                            <?=Yii::t('app','Log In')?>
                        </b>
					</h3>
					<p class="text-center mt-2">Please login to your account</p>
                    <?php

                    $form = TActiveForm::begin([
                        'id' => 'login-form',
                        'enableAjaxValidation' => false,
                        'enableClientValidation' => false,
                        'options' => [
                            'class' => 'form-signin'
                        ]
                    ]);
                    ?>

                    <span id="reauth-email" class="reauth-email"></span>


					<div class="mb-4 form-group">
						<label class="mb-2">Email Address</label>
                        <?= $form->field ( $model, 'username', $fieldOptions1 )->label ( false )->textInput ( [ 'placeholder' => $model->getAttributeLabel ( 'email' ) ] )?>
                    </div>
					<div class="mb-4 form-group">
						<label class="mb-2">Password</label>
                        <?= $form->field ( $model, 'password', $fieldOptions3 )->label ( false )->passwordInput ( [ 'placeholder' => $model->getAttributeLabel ( 'password' ) ] )?>
                    </div>
					<div class="row mb-3">
						<div class="col-md-6">
							<div id="remember" class="checkbox">
                                <?php echo $form->field($model, 'rememberMe')->checkbox();?>
                            </div>
						</div>
						<div class="col-md-6 text-start text-md-end">
							<a class="forgot-password"
								href="<?php echo Url::toRoute(['user/recover'])?>">
                                <?=Yii::t('app','Forgot Password')?>?
                            </a>
						</div>
					</div>
                    <?=Html::submitButton ( Yii::t('app','Login'), [ 'class' => 'btn btn-theme btn-block btn-signin  w-100 mt-4 mt-md-0','id' => 'login','name' => 'login-button' ] )?>

                    <?php TActiveForm::end()?>
                </div>
			</div>
		</div>
		<!-- /card-container -->
	</div>
	<!-- /container -->
</section>

<?= $this->registerJsFile($this->theme->getUrl('js/login.js'));?>