<?php
use app\components\TActiveForm;
use yii\helpers\Html;
/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */

// $this->title = 'Request password reset';
$this->params['breadcrumbs'][] = [
    'label' => Yii::t('app', 'Request passwordReset'),
    'url' => [
        'index'
    ]
];
$this->params['breadcrumbs'][] = \yii\helpers\Inflector::camel2words(Yii::$app->controller->action->id);
?>
<div class="box-header with-border">
    <?php

    if (Yii::$app->session->hasFlash('success')) {
        ?>
    	<div class="alert alert-success">
    <?php echo Yii::$app->session->getFlash('success') ?>
            </div>
    <?php
    }
    ?>
	 <?php

if (Yii::$app->session->hasFlash('error')) {
    ?>
    	<div class="alert alert-danger">
    <?php echo Yii::$app->session->getFlash('error') ?>
            </div>
    <?php
}
?>

<section class="pagetitle-section">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12 text-center">
        <h1 class="mb-0 mt-0"><b>Reset Password</b></h1>
      </div>
    </div>
  </div>
</section>

<section class="login-signup py-5">
  <div class="container-fluid">
    <div class="row p-3 justify-content-center">
      <div class="order-1 col-lg-6 order-lg-2">
        <div class="login-box">
				<p>Please fill out your email. A link to reset password will be sent
					there.</p>
          	   <?php

            $form = TActiveForm::begin([
                'id' => 'request-password-reset-form',
                'enableAjaxValidation' => false,
                'enableClientValidation' => true
            ]);
            ?>
                    <?= $form->field($model, 'email') ?>
                    <div class="form-group">
                        <?= Html::submitButton('Send', ['name'=>'send-button','class' => 'btn btn-theme w-100']) ?>
                    </div>
                <?php TActiveForm::end(); ?>
			</div>
		</div>
	</section>
</div>



