<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use app\components\TActiveForm;

// $this->title = 'Change Password';
$this->params['breadcrumbs'][] = $this->title;
$fieldOptions2 = [
    'inputTemplate' => "{input}<span  class='fa fa-fw fa-eye-slash field-icon toggle-password pass-toggle ' toggle='#user-password' id='password-reveal'></span>"
];
?>
<?php

$fieldOptions3 = [
    'inputTemplate' => "{input}<span  class='fa fa-fw fa-eye-slash field-icon toggle-password confirm-toggle' toggle='#user-confirm_password' id='password-reveal'></span>"
];
?>
<section class="login-signup py-5">
	<div class="container-fluid">
		<div class=" row p-3 justify-content-center">
			<div class="order-1 col-lg-5 order-lg-2">
				<div class="login-box">
					<h3 class="section-title mb-3"><?=Yii::t('app','change password')?></h3>
					<p><?=Yii::t('app','Please fill out the following fields to change password ')?>:</p>
					 <?php

    $form = TActiveForm::begin([
        'id' => 'changepassword-form',
        'options' => [
            'class' => 'form-horizontal'
        ],
        'fieldConfig' => [
            'template' => "{label}
                                        {input}
                                        {error}"
        ]
    ]);
    ?>
                         <?=$form->field ( $model, 'password', $fieldOptions2)->passwordInput ()?>
                         <?=$form->field ( $model, 'confirm_password', $fieldOptions3 )->passwordInput (['class' => 'form-control'])?>
                        <div class="text-center">
                			 <?=Html::submitButton (Yii::t('app','Change password'), [ 'class' => 'btn btn-primary' ] )?>
                        </div>
                    <?php TActiveForm::end(); ?>
					     </div>
			</div>
		</div>

	</div>
</section>

<script>
$(".toggle-password").click(function() {
    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
        input.attr("type", "text");
    } else {
        input.attr("type", "password");
    }
});

</script>
