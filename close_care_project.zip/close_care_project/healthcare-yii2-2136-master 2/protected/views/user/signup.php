<?php
use app\components\TActiveForm;
use yii\helpers\Html;
use yii\captcha\Captcha;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */

// $this->title = 'Signup';
?>
<?php
    $fieldOptions1 = [
        'inputTemplate' => "{input}<span  class='fa fa-fw fa-eye-slash field-icon toggle-password' toggle='#user-password' id='password-reveal1'></span>"
    ];
    $fieldOptions2 = [
        'inputTemplate' => "{input}<span  class='fa fa-fw fa-eye-slash field-icon toggle-password' toggle='#user-confirm_password' id='password-reveal2'></span>"
    ];
?>

<section class="pagetitle-section">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12 text-center">
        <h1 class="mb-0 mt-0"><b>Sign Up</b></h1>
      </div>
    </div>
  </div>
</section>

<section class="login-signup py-5">
  <div class="container-fluid">
    <div class="row p-3 justify-content-center">
      <div class="order-1 col-lg-6 order-lg-2">
        <div class="login-box">
          <?php
                            $form = TActiveForm::begin([
                                'id' => 'form-signup',
                                'options' => [
                                    'class' => 'form-signin'
                                ]
                            ]);
                        ?>
          <span id="reauth-email" class="reauth-email"></span>
          <div class="mb-4 form-group">
            <label class="mb-2">Email Address</label>
            <?=$form->field ( $model, 'full_name', [ 'template' => '{input}{error}' ] )->textInput ( [ 'maxlength' => true,'placeholder' => 'Full Name' ] )->label ( false )?>
          </div>
          <div class="mb-4 form-group">
            <label class="mb-2">Email Address</label>
            <?=$form->field ( $model, 'email', [ 'template' => '{input}{error}' ] )->textInput ( [ 'maxlength' => true,'placeholder' => 'Email' ] )->label ( false )?>
          </div>
          <div class="mb-4 form-group">
            <label class="mb-2">Password</label>
            <?=$form->field ( $model, 'password', $fieldOptions1 )->passwordInput ( [ 'maxlength' => true,'placeholder' => 'Password' ] )->label ( false )?>
          </div>
          <div class="mb-4 form-group">
            <label class="mb-2">Confirm Password</label>
            <?=$form->field ( $model, 'confirm_password', $fieldOptions2)->passwordInput ( [ 'maxlength' => true,'placeholder' => 'Confirm Password' ] )->label ( false )?>
          </div>


          <?=$form->field($model, 'tos')->checkbox(['required' => true])->label('I accept the 
										 <a target="_blank" class="sign-link"
										href="' . Url::toRoute(["/site/terms"]) . '">Terms and
										Conditions</a>');?>
          <br />
          <?=Html::submitButton('Signup', ['class' => 'btn  btn-theme w-100 btn-signin','name' => 'signup-button'])?>

          <?php TActiveForm::end(); ?>

        </div>
      </div>
    </div>
  </div>
</section>

<script>
  $(".toggle-password").click(function () {
    $(this).toggleClass("fa-eye fa-eye-slash");
    var input = $($(this).attr("toggle"));
    if (input.attr("type") == "password") {
      input.attr("type", "text");
    } else {
      input.attr("type", "password");
    }
  });
</script>