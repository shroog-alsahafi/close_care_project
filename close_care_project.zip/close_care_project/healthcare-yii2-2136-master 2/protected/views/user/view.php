<?php
// use app\components\useraction\UserAction;
use app\models\User;
use yii\helpers\Html;
use app\components\useraction\UserAction;

/* @var $this yii\web\View */
/* @var $model app\models\User */

/* $this->title = $model->label() .' : ' . $model->id; */
// $this->params['breadcrumbs'][] = [
// 'label' => Yii::t('app', 'Users'),
// 'url' => [
// 'index'
// ]
// ];
// $this->params['breadcrumbs'][] = (string) $model;
?>
<?php
if ($model->role_id == User::ROLE_USER) {
    $this->params['breadcrumbs'][] = [
        'label' => Yii::t('app', 'Patients'),
        'url' => [
            'index'
        ]
    ];
}
if ($model->role_id == User::ROLE_PROVIDER) {

    $this->params['breadcrumbs'][] = [
        'label' => Yii::t('app', 'Provider'),
        'url' => [
            'user/provider'
        ]
    ];
}
$this->params['breadcrumbs'][] = (string) $model;
?>

<div class="wrapper">
	<div class="card mb-4">
   <?php
echo \app\components\PageHeader::widget([
    'model' => $model
]);
?>
</div>
	<div class="content-section clearfix">
		<div class="widget light-widget">
			<div class="user-view">
				<div class="card">
					<div class="card-body">
						<div class="row">
							<div class="col-md-2">
            <?php
            echo Html::img($model->getImageUrl(150), [
                'class' => 'img-responsive mt-5',
                'alt' => $model,
                'width' => '200',
                'height' => '200'
            ])?><br /> <br />
							</div>
							<div class="col-md-10">     
            <?php
            echo \app\components\TDetailView::widget([
                'model' => $model,

                'options' => [
                    'class' => 'table table-bordered'
                ],
                'attributes' => [
                    'id',

                    [
                        'attribute' => 'full_name',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return $data->full_name;
                        },
                        'visible' => ! empty($model->full_name)
                    ],
                    [
                        'attribute' => 'first_name',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return $data->first_name;
                        },
                        'visible' => ! empty($model->first_name) && ($model->role_id != User::ROLE_ADMIN)
                    ],
                    [
                        'attribute' => 'last_name',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return $data->last_name;
                        },
                        'visible' => ! empty($model->last_name) && ($model->role_id != User::ROLE_ADMIN)
                    ],
                    'email:email',
                       /*'password',
                       'date_of_birth:date',
                            'gender',
                            'about_me',
                            'contact_no',
                            'address',
                            'latitude',
                            'longitude',
                            'city',
                            'country',
                            'zipcode',
                            'language',
                            'profile_file',
                            'tos:boolean',*/
                        
                            [
                        'attribute' => 'role_id',
                        'format' => 'raw',
                        'value' => $model->getRole()
                    ],
                    [
                        'attribute' => 'profession',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return ! empty($data->providerDetail) ? $data->providerDetail->getProType() : 'N/A';
                        },
                        'visible' => ! empty($model->providerDetail) && ($model->role_id != User::ROLE_ADMIN) && ($model->role_id != User::ROLE_USER)
                    ],
                    [
                        'attribute' => 'degree',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return ! empty($data->providerDetail->providerQualification) ? $data->providerDetail->providerQualification->title : 'N/A';

                        },
                        'visible' => ! empty($model->providerDetail) && ($model->role_id != User::ROLE_ADMIN) && ($model->role_id != User::ROLE_USER)
                    ],
                    [
                        'attribute' => 'identity_id',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return ! empty($data->providerDetail->identity_id) ? $data->providerDetail->identity_id : 'N/A';
                        },
                        'visible' => ! empty($model->providerDetail) && ($model->role_id != User::ROLE_ADMIN) && ($model->role_id != User::ROLE_USER)
                    ],
                    [
                        'attribute' => 'professional_classification_no',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return ! empty($data->providerDetail->professional_classification_no) ? $data->providerDetail->professional_classification_no : 'N/A';
                        },
                        'visible' => ! empty($model->providerDetail) && ($model->role_id != User::ROLE_ADMIN) && ($model->role_id != User::ROLE_USER)
                    ],
                    [
                        'attribute' => 'is_approved',
                        'format' => 'raw',
                        'value' => $model->getApprove(),
                        'visible' => $model->role_id == User::ROLE_PROVIDER
                    ],
                    [
                        'attribute' => 'contact_no',
                        'format' => 'raw',
                        'value' => function ($data) {

                            return $data->country_code . '' . $data->contact_no;
                        },
                        'visible' => (! empty($model->contact_no))
                    ],
                    [
                        'attribute' => 'address',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return $data->address;
                        },
                        'visible' => ! empty($model->address) && ($model->role_id != User::ROLE_ADMIN)
                    ],
                    [
                        'attribute' => 'location',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return $data->location;
                        },
                        'visible' => ! empty($model->location) && ($model->role_id != User::ROLE_ADMIN)
                    ],
                    [
                        'attribute' => 'weight',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return ! empty($data->weight) ? $data->weight . ' Kg' : '';
                        },
                        'visible' => ! empty($model->weight) && ($model->role_id != User::ROLE_ADMIN)
                    ],

                    [
                        'attribute' => 'country',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return $data->country;
                        },
                        'visible' => ! empty($model->country) && ($model->role_id != User::ROLE_ADMIN)
                    ],

                    [
                        'attribute' => 'country',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return $data->country;
                        },
                        'visible' => ! empty($model->country) && ($model->role_id != User::ROLE_ADMIN)
                    ],

                    [
                        'attribute' => 'blood_group',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return $data->blood_group;
                        },
                        'visible' => ! empty($model->blood_group) && ($model->role_id != User::ROLE_ADMIN)
                    ],

                    [
                        'attribute' => 'gender',
                        'format' => 'raw',
                        'value' => $model->getGenderType(),
                        'visible' => ($model->role_id != User::ROLE_ADMIN)
                    ],
                    [
                        'attribute' => 'date_of_birth',
                        'format' => 'raw',
                        'value' => function ($data) {
                            return $data->date_of_birth;
                        },
                        'visible' => ! empty($model->date_of_birth) && ($model->role_id != User::ROLE_ADMIN)
                    ],
                    
                       /* [
                           'attribute' => 'state_id',
                           'format' => 'raw',
                           'value' => $model->getStateBadge()
                       
                       ], */
                            /* [
                                    'attribute' => 'type_id',
                                    'value' => $model->getType ()
                            ], */
                    // 'login_error_count',
                    /* 'activation_key', */
                    // 'timezone',
                    'created_on:datetime'
                ]
            ])?>
           
         </div>
						</div>
					</div>
				</div>
				
				<?php if ($model->role_id != User::ROLE_ADMIN) { ?>
     
     
             <?php
        echo UserAction::widget([
            'model' => $model,
            'attribute' => 'state_id',
            'states' => $model->getStateOptions(),
            'visible' => User::isAdmin()
        ]);
        ?>
         
      <div class="card">
					<div class="card-body">
            <?php
        $this->context->startPanel();

        $this->context->addPanel('Login Histories', 'loginHistories', 'LoginHistory', $model, null, false);
        $this->context->addPanel('Activities', 'feeds', 'Feed', $model);
        $this->context->addPanel(Yii::t('app', 'Access Token'), 'authSession', 'AccessToken', $model, null, false);

        if ($model->role_id == User::ROLE_PROVIDER) {

            $this->context->addPanel(Yii::t('app', 'Service'), 'services', 'ServiceDetail', $model, null, false);

            $this->context->addPanel(Yii::t('app', 'Availablity'), 'availablityDetail', 'Availability', $model, null, false);
            
            $this->context->addPanel(Yii::t('app', 'Bank Details'), 'bankDetails', 'BankDetail', $model, null, false);
        }

        $this->context->addPanel('Files', 'filesDetail', 'File', $model, null, false);
        // $this->context->addPanel('Comments', 'comments', 'Comment', $model);
        $this->context->endPanel();
        ?>
         </div>
				</div>
				
				<?php }?>
      
        
   </div>
		</div>
	</div>
</div>
