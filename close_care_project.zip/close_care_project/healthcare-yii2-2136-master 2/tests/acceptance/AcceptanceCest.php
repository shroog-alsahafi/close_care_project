<?php
require (__DIR__ . '/../Helper.php');

class AcceptanceCest
{

    public $id;

    protected $data = [];

    public function _data()
    {
        $this->data['full_name'] = \Helper::faker()->name;
        $this->data['email'] = \Helper::faker()->email;

        $this->data['password'] = \Helper::faker()->password;
    }

    public function _before(AcceptanceTester $I)
    {}

    public function _after(AcceptanceTester $I)
    {}

    /**
     *
     * @group guest
     */
    public function SignUpFormWorks(AcceptanceTester $I)
    {
        $I->amOnPage('/user/signup');
        $I->seeElement('#form-signup');
        $I->canSeeResponseCodeIs(200);
    }

    /**
     *
     * @group guest
     */
    public function SignUpFormCanBeSubmittedEmpty(AcceptanceTester $I)
    {
        $I->amOnPage('/user/signup');
        $I->seeElement('#form-signup');
        $I->amGoingTo('submit sign up form without credentials');
        $I->click('//*[@id="form-signup"]/button');
        $I->canSeeResponseCodeIs(200);
        $I->expectTo('see validations errors');

        $req = $I->grabMultiple('.required');
        $count = count($req);

        $I->expectTo('see validations errors:' . $count);
        $I->seeNumberOfElements('.invalid-feedback', $count);
    }

    /**
     *
     * @group guest
     */
    public function SignUpFormWithRightCredentials(AcceptanceTester $I)
    {
        $password = \Helper::faker()->password;

        $I->amOnPage('/user/signup');
        $I->seeElement('#form-signup');
        $I->amGoingTo('submit sign up form for  user');
        $I->fillField('User[full_name]', \Helper::faker()->name);
        $I->fillField('User[email]', \Helper::faker()->email);
        $I->fillField('User[password]', $password);
        $I->fillField('User[confirm_password]', $password);
        $I->click('//*[@id="form-signup"]/button');
        $I->canSeeResponseCodeIs(200);
    }

    /**
     *
     * @group guest
     */
    public function LoginFormWorks(AcceptanceTester $I)
    {
        $I->amOnPage('/user/login');
        $I->seeElement('#login-form');
    }

    /**
     *
     * @group guest
     */
    public function LogInFormCanBeSubmittedEmpty(AcceptanceTester $I)
    {
        $I->amOnPage('/user/login');
        $I->seeElement('#login-form');
        $I->amGoingTo('submit login form without credentials');
        $I->click('login-button');
        $I->expectTo('see validations errors');
        $req = $I->grabMultiple('.required');
        $count = count($req);
        $I->seeNumberOfElements('.invalid-feedback', $count);
    }

    public function LoginFormWithRightCredentials(AcceptanceTester $I)
    {
        $I->amOnPage('/user/login');
        $I->seeElement('#login-form');
        $I->amGoingTo('submit login form with right credentials');

        $I->fillField('#loginform-username', Helper::$email);
        $I->fillField('#loginform-password', Helper::$password);
        $I->click('login-button');
        // $I->seeElement ( 'span.brand-name' );
    }

    public function LoginFormWithWrongEmailFormat(AcceptanceTester $I)
    {
        $I->amOnPage('/user/login');
        $I->seeElement('#login-form');
        $I->amGoingTo('submit login form with wrong email');
        $I->fillField('#loginform-username', 'abc');
        $I->fillField('#loginform-password', 'wrong');
        $I->click('login-button');
        $I->expectTo('see validations errors');
        $I->seeElement('.invalid-feedback');
    }

    public function LoginFormWithWrongCredentials(AcceptanceTester $I)
    {
        $I->amOnPage('/user/login');
        $I->seeElement('#login-form');
        $I->amGoingTo('submit login form with wrong credentials');
        $I->fillField('#loginform-username', 'abc@gmail.com');
        $I->fillField('#loginform-password', 'wrong');
        $I->click('login-button');
        $I->expectTo('see validations errors');
        $I->seeElement('.invalid-feedback');
    }

    public function PasswordRecoverFormWorks(AcceptanceTester $I)
    {
        $I->amOnPage('/user/login');
        $I->seeElement('.forgot-password');
        $I->click('Forgot Password?');
        $I->seeElement('#request-password-reset-form');
    }

    public function PasswordRecoverFormWithoutEmail(AcceptanceTester $I)
    {
        $I->amOnPage('/user/recover');
        $I->seeElement('#request-password-reset-form');
        $I->amGoingTo('submit email field without email');
        $I->click('send-button');
        $I->expectTo('see validations errors');
        $I->seeElement('.required');
    }
}
