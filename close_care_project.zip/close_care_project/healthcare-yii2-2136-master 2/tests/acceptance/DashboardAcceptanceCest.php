 <?php
	class DashboardAcceptanceCest {
		public $id = null;
		public function _before(AcceptanceTester $I) {
			Helper::login($I);
		}
		public function _after(AcceptanceTester $I) {
		}
		public function IndexWorks(AcceptanceTester $I) {
			$I->amOnPage ( '/dashboard/index' );
			$I->expectTo ( 'See dashboard index works' );
			
		}
	}