<?php
class EmailQueueAcceptanceCest {
	
	public function _before(AcceptanceTester $I) {
		Helper::login ( $I );
	}
	public function _after(AcceptanceTester $I) {
	}

	public function Index(AcceptanceTester $I){
		$I->amOnPage ( '/email-queue' );
		$I->expectTo ( 'See icon in page head' );
		$I->canSeeResponseCodeIs(200);
		$I->seeElement ( '.grid-view' );
	}

	
}