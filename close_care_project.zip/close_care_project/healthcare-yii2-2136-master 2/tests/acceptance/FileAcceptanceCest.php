<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
class FileAcceptanceCest 

{
	public $id = null;	
	public function _before(AcceptanceTester $I) 
	{
			Helper::login($I);
	}
	public function _after(AcceptanceTester $I) 
	{
	
	
	}

	public function IndexWorks(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/file/index' );
			$I->canSeeResponseCodeIs(200);
			$I->seeElement ( '.grid-view' );
	}
	/* public function AddFormCanBeSubmittedEmpty(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/file/add' );
			$I->seeElement ( '#file-form' );
			$I->amGoingTo ( 'add form without credentials' );
			$I->click ( '#file-form-submit' );
			$I->expectTo ( 'see validations errors' );
			$req = $I->grabMultiple ( '.required' );
			$count = count ( $req );
			$I->seeNumberOfElements ( '.has-error', $count );
	}
	public function AddWorksWithData(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/file/add' );
			$I->seeElement ( '#file-form' );
			$I->amGoingTo ( 'add form with right data' );
			$I->fillField ('#file-name','Test string');
			$I->fillField ('#file-size','12');
			$I->fillField ('#file-key','Test string');
			$I->fillField ('#file-model_type','Test string');
			$I->fillField ('#file-model_id','1');
			$I->selectOption ('#file-type_id','0');
			$I->click ( '#file-form-submit' );
			$I->dontseeElement ( '#file-form' );
			$I->see ( 'Test String', 'h1' );
			$I->seeElement ( '.table-bordered');
			$this->id = $I->grabFromCurrentUrl ( '/file\/(\d+)$/' );
			echo $this->id;
	}
	
	public function ViewWorks(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/file/' . $this->id );
			$I->amGoingTo ( 'View file details' );
			$I->see ( 'Test String', 'h1' );
			$I->seeElement ( '.table-bordered');
	}
	public function UpdateWorks(AcceptanceTester $I) 
{
			$I->amOnPage ( '/file/update/'. $this->id  );
			$I->seeElement ( '#file-form' );
			$I->amGoingTo ( 'add form with right data' );
			$I->fillField ('#file-name','Test string');
			$I->fillField ('#file-size','11');
			$I->fillField ('#file-key','Test string');
			$I->fillField ('#file-model_type','Test string');
			$I->fillField ('#file-model_id','1');
			$I->selectOption ('#file-type_id','0');
			$I->click ( '#file-form-submit' );
			$I->dontseeElement ( '#file-form' );
			$I->see ( 'Test String', 'h1' );
		    $I->seeElement ( '.table-bordered');
	}
	public function DeleteWorks(AcceptanceTester $I) 
	{
		$I->sendAjaxPostRequest ( '/file/delete/' . $this->id );
			$I->expectTo ( 'delete file works' );
			$I->amOnPage ( '/file/' . $this->id );
	}
	 */
		

	
	
}
