<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
class LogAcceptanceCest 

{
	public $id = null;	
	public function _before(AcceptanceTester $I) 
	{
			Helper::login($I);
	}
	public function _after(AcceptanceTester $I) 
	{
	
	
	}

	public function IndexWorks(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/log/index' );
			$I->canSeeResponseCodeIs(200);
			$I->seeElement ( '.grid-view' );
	}
	
}
	