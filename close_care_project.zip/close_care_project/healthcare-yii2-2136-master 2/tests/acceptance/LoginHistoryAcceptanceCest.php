<?php
/**
 *@copyright : ToXSL Technologies Pvt. Ltd. < www.toxsl.com >
 *@author	 : Shiv Charan Panjeta < shiv@toxsl.com >
 */
class LoginHistoryAcceptanceCest 

{
	public $id = null;	
	public function _before(AcceptanceTester $I) 
	{
			Helper::login($I);
	}
	public function _after(AcceptanceTester $I) 
	{
	
	
	}

	public function IndexWorks(AcceptanceTester $I) 
	{
			$I->amOnPage ( '/login-history/index' );
			$I->canSeeResponseCodeIs(200);
			$I->seeElement ( '.grid-view' );
	}
	
	
	public function GrabUrlForView(AcceptanceTester $I) {
		$I->amOnPage ( '/login-history/index/' );
		$I->see ( 'View' );
		$this->url = $I->grabAttributeFrom ( 'td a[title=View]', 'href' );
		echo $this->url;
	}
	public function ViewWorks(AcceptanceTester $I) {
		$I->amOnPage ( $this->url );
		$I->amGoingTo ( 'View User details' );
		
	}
	
/* 	public function DeleteWorks(AcceptanceTester $I) 
	{
		$I->sendAjaxPostRequest ( '/login-history/delete/' . $this->id );
			$I->expectTo ( 'delete login-history works' );
			$I->amOnPage ( '/login-history/' . $this->id );
	} */
	
/* 	public function DeleteWorks(AcceptanceTester $I) {
		$I->amOnPage ( '/login-history/index' );
		$I->seeElement ( '.glyphicon-trash' );
		$this->url = $I->grabAttributeFrom ( 'td a[title=Delete]', 'href' );
		$I->sendAjaxPostRequest (  $this->url );
	} */

}
