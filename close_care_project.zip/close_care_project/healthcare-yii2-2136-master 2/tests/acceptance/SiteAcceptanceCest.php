<?php

class SiteAcceptanceCest
{

    public $id;

    protected $data = [];

    public function _before(AcceptanceTester $I)
    {}

    public function _after(AcceptanceTester $I)
    {}

    /**
     *
     * @group guest
     */
    public function Homepage(AcceptanceTester $I)
    {
        $I->wantTo('frontpage works');
        $I->amOnPage('/');
        $I->see('Talent Management System', 'h1');
        $I->see(' All The Features That Work For You ', 'h2');
        $I->click('//*[@id="why"]/div/div/div/div/div[1]/a/div/div[2]/h3');
        $I->amOnPage('/feature/' . $this->id);
        $I->amGoingTo('Freature page details');
        $I->canSeeResponseCodeIs(200);
        $I->see(array_key_exists('title', $this->data) ? $this->data['title'] : '', 'h1');
        $I->amOnPage('/');
        $I->click('//*[@id="why"]/div/div/div/div/a');
        $I->see('Features', 'h1');
        $I->canSeeResponseCodeIs(200);
        $I->amOnPage('/');
        $I->see('Latest Updates', 'h2');
        $I->click('//*[@id="promo"]/section[3]/div/div/div/div[2]/div/a');
        $I->amOnPage('/blog/' . $this->id);
        $I->amGoingTo('blog page details');
        $I->canSeeResponseCodeIs(200);
        $I->see(array_key_exists('title', $this->data) ? $this->data['title'] : '', 'h1');
    }

    /**
     *
     * @group guest
     */
    public function FooterAllLinks(AcceptanceTester $I)
    {
        $I->amOnPage('/');
        $I->click('Terms of services');
        $I->canSeeResponseCodeIs(200);
        $I->see('Terms of services', 'h1');
        $I->click('About Us');
        $I->canSeeResponseCodeIs(200);
        $I->see('About Us', 'h1');
        $I->click('Privacy Policy');
        $I->canSeeResponseCodeIs(200);
        $I->see('Privacy Policy', 'h1');
    }

    /**
     *
     * @group guest
     */
    public function FeatureWorks(AcceptanceTester $I)
    {
        $I->amOnPage('/');
        $I->click('Features');
        $I->canSeeResponseCodeIs(200);
    }

    /**
     *
     * @group guest
     */
    public function FeatureViewWorks(AcceptanceTester $I)
    {
        $I->amOnPage('/feature/' . $this->id);
        $I->amGoingTo('Feature page details');
        $I->canSeeResponseCodeIs(200);
        $I->see(array_key_exists('title', $this->data) ? $this->data['title'] : '', 'h1');
    }

    /**
     *
     * @group guest
     */
    public function PricingWorks(AcceptanceTester $I)
    {
        $I->amOnPage('/');
        $I->click('Pricing');
        $I->canSeeResponseCodeIs(200);
    }

    /**
     *
     * @group guest
     */
    public function CandidateWorks(AcceptanceTester $I)
    {
        $I->amOnPage('/');
        $I->click('Candidate');
        $I->see('Talent Management System', 'h1');
        $I->canSeeResponseCodeIs(200);
    }
}

