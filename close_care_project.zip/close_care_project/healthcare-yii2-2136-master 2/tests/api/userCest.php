<?php
require (__DIR__ . '/../Helper.php');

class userCest
{

    public function _before(ApiTester $I)
    {}

    // tests
    public function tryToTest(ApiTester $I)
    {}

    public function createUserViaAPI(\ApiTester $I)
    {
        $I->haveHttpHeader('Content-Type', 'application/x-www-form-urlencoded');
        $I->sendPOST('/user/login', [
            'username' => Helper::$email,
            'email' => Helper::$password
        ]);
        $I->seeResponseCodeIs(\Codeception\Util\HttpCode::OK); // 200
        $I->seeResponseIsJson();
    }
}
