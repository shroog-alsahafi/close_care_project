<?php
use app\assets\AppAsset;
use app\components\gdpr\Gdpr;
use app\models\User;
use yii\helpers\Html;
use yii\helpers\Url;
use app\components\FlashMessage;

/* @var $this \yii\web\View */
/* @var $content string */

AppAsset::register($this);
?>
<?php $this->beginPage()?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
<meta name="viewport"
	content="width=device-width,initial-scale=1,maximum-scale=1">
<meta charset="<?= Yii::$app->charset ?>" />
      <?= Html::csrfMetaTags()?>
      <title> <?= Html::encode($this->title) ?></title>
      <?php $this->head()?>
         <?php
        $this->registerLinkTag([
            'rel' => 'icon',
            'type' => 'image/png',
            'href' => $this->theme->getUrl('img/favicon.ico')
        ]);
        /* -- Plugins CSS -- */
        $this->registerCssFile($this->theme->getUrl('css/font-awesome.css'));
        $this->registerCssFile($this->theme->getUrl('css/styles.css'));
        $this->registerCssFile($this->theme->getUrl('css/main.css'));
        $this->registerCssFile($this->theme->getUrl('css/owl.carousel.min.css'));
        ?>
   </head>
<body class="home-page">
      <?php $this->beginBody()?>
      <!-- ******HEADER****** -->
	<header class="py-2">
		<div class="container-fluid">
			<nav
				class="navbar navbar-expand-lg bg-white align-items-center p-0 pt-4">
				<a class="navbar-brand" href="<?= Url::home();?>">
					<h3 class="mb-0 text-light"><?=Yii::$app->name?></h3>
				</a>
				<?php if (\Yii::$app->controller->action->id !== 'paypal') : ?>
    				<button class="navbar-toggler" type="button"
					data-toggle="collapse" data-target="#collapsibleNavbar">
					<span class="navbar-toggler-icon w-auto h-auto"><i
						class="fa fa-bars"></i></span>
				</button>
				<?php endif; ?>
				<div class="collapse navbar-collapse" id="collapsibleNavbar"></div>
			</nav>
		</div>
	</header>
	<!--//header-->
      <?= Gdpr::widget();?>
       
      <!-- body content start-->
	<div class="main_wrapper">
	              
	
         <?= $content?>
      </div>
	<!--body wrapper end-->

	<!-- Footer-Section start -->
	<footer class="p-0">
		<div class="top_footer" id="contact">
			<!-- container start -->
			<div class="container">
				<!-- row start -->
				<div class="row">
					<!-- shape animation  -->
					<span class="banner_shape1"> <img
						src="<?=$this->theme->getUrl ('images/banner-shape1.png')?>"
						alt="image">
					</span> <span class="banner_shape2"> <img
						src="<?=$this->theme->getUrl ('images/banner-shape2.png')?>"
						alt="image">
					</span> <span class="banner_shape3"> <img
						src="<?=$this->theme->getUrl ('images/banner-shape3.png')?>"
						alt="image">
					</span>

					<!-- footer link 1 -->
					<div class="col-lg-4 col-md-6 col-12">
						<div class="abt_side">
							<div class="logo">
								<a class="navbar-brand" href="<?= Url::home();?>">
									<h3 class="mb-0 text-white"><?=Yii::$app->name?></h3>
								</a>
							</div>
							<ul class="p-0">
								<li><a
									href="email:<?=Yii::$app->settings->getValue('email', null, 'contact')?>"><?=Yii::$app->settings->getValue('email', null, 'contact')?></a>
									</a></li>
								<li><a
									href="tel:<?=Yii::$app->settings->getValue('phone_number', null, 'contact')?>"><?=Yii::$app->settings->getValue('phone_number', null, 'contact')?></a>


								</li>
							</ul>
						</div>
					</div>

					<!-- footer link 2 -->
					<div class="col-lg-3 col-md-6 col-12">
						<div class="links">
							<h3>Useful Links</h3>
							<ul>
								<li><a href="<?php echo Url::home()?>"> Home </a></li>
								<li><a href="<?php echo url::toRoute(['site/about'])?>"> About
										Us</a></li>

							</ul>
						</div>
					</div>

					<!-- footer link 3 -->
					<div class="col-lg-3 col-md-6 col-12">
						<div class="links">
							<h3>Help &amp; Suport</h3>
							<ul>
								<li><a href="<?php echo url::toRoute(['/contactus'])?>">Contact
										Us</a></li>
								<li><a href="<?php echo url::toRoute(['site/terms'])?>">Terms
										&amp; conditions</a></li>
								<li><a href="<?php echo url::toRoute(['site/privacy'])?>">Privacy
										policy</a></li>
							</ul>
						</div>
					</div>

					<!-- footer link 4 -->
					<div class="col-lg-2 col-md-6 col-12">
						<div class="try_out">
							<h3>Let’s Try Out</h3>
							<ul class="app_btn">
								<li><a href="#"> <img
										src="<?=$this->theme->getUrl ('images/appstore_blue.png')?>"
										alt="image">
								</a></li>
								<li><a href="#"> <img
										src="<?=$this->theme->getUrl ('images/googleplay_blue.png')?>"
										alt="image">
								</a></li>
							</ul>
						</div>
					</div>
				</div>
				<!-- row end -->
			</div>
			<!-- container end -->
		</div>

		<!-- last footer -->
		<div class="bottom_footer">
			<!-- container start -->
			<div class="container">
				<!-- row start -->
				<div class="row">
					<div class="col-md-6 mx-auto">
						<p class="developer_text">&copy;
                <?php echo date('Y')?>
                <a href="<?= Url::home();?>"><?=Yii::$app->name?></a> |
							All Rights Reserved. Developed By <a target="_blank"
								href="<?= Yii::$app->params['companyUrl'];?>">
                  <?= Yii::$app->params['company']?>
                </a>
						</p>
					</div>
				</div>
				<!-- row end -->
			</div>
			<!-- container end -->
		</div>
	</footer>
	<!-- Footer-Section end -->

	<!-- Javascript -->
   
     <?php $this->endBody()?>
	 <script
		src="<?php echo $this->theme->getUrl ( 'js/owl.carousel.min.js' )?>"></script>
	<script src="<?php echo $this->theme->getUrl ( 'js/main.js' )?>"></script>
</body>
   <?php $this->endPage()?>
</html>